// Independent CSV-export counterexample probe (reviewer-authored, ignored runtime dir).
// Uses the reviewed results.ts compiled with the repo's locked TypeScript, and the
// approved contracts validator, to record real export bytes for edge cells.
import ts from 'typescript'
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..')
const require = createRequire(path.join(root, 'package.json'))
const compile = (source, filename) =>
  ts.transpileModule(source, {
    fileName: filename,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
      esModuleInterop: true,
    },
  }).outputText
const original = { '.ts': require.extensions['.ts'] }
require.extensions['.ts'] = (mod, filename) =>
  mod._compile(compile(readFileSync(filename, 'utf8'), filename), filename)

// Load through the real path so the module's own relative imports resolve from
// their true directory, exactly as the desktop build does.
const load = (relative) => require(path.join(root, relative))
const results = load('apps/desktop/src/renderer/src/query/results.ts')
try {
} finally {
  for (const [ext, handler] of Object.entries(original)) {
    if (handler) require.extensions[ext] = handler
    else delete require.extensions[ext]
  }
}

const id = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`
const hash = 'a'.repeat(64)
const metadata = {
  projectId: id(1),
  resultId: id(2),
  jobId: id(3),
  kind: 'query',
  definitionId: 'Q-01',
  inputSnapshotId: hash,
  inputProjectRevision: 3,
  dependencyVector: { 'facts:asserted': 3 },
  definitionSetDigests: {},
  implementation: {
    executionSemanticsVersion: 'v1',
    engineVersion: '0.1.0',
    dependencyLockHash: hash,
  },
  scope: 'asserted',
  parametersHash: hash,
  state: 'current',
  staleReason: [],
  payloadStatus: 'available',
  createdAtMs: 1,
  historicalSelectionRequired: false,
}
const binding = {
  projectId: id(1),
  resultId: id(2),
  inputSnapshotId: hash,
  scope: 'asserted',
  parametersHash: hash,
  order: 'ordinal+rowId:asc',
}
const makePage = (cells) => ({
  binding,
  rows: [{ rowId: id(4), ordinal: 0, cells }],
  nextCursor: null,
})
const columns = ['c0', 'c1', 'c2', 'c3']

const scenarios = [
  ['numeric_negative', [-5, 3.5, 0, 42]],
  ['numeric_positive', [1, 2, 3, 4]],
  ['formula_strings', ['=SUM(1)', '+1', '-1', '@SUM(A1)']],
  ['leading_space_formula', ['  =SUM(1)', 'x', 'y', 'z']],
  ['control_chars', ['a\nb', 'a\tb', 'a\r\nb', 'plain']],
  ['null_and_bool', [null, true, false, 'plain']],
  ['quote_and_comma', ['a,b', 'say "hi"', "it's", 'plain']],
]

for (const [label, cells] of scenarios) {
  const page = makePage(cells)
  const accepted = results.acceptPage(page, results.queryMetadata(metadata), columns)
  const csv = results.exportPageCsv(accepted, columns)
  console.log(`--- ${label}`)
  console.log(JSON.stringify(csv))
}

// Bounded-page guard: 201 rows must be refused by the approved page schema.
const many = {
  binding,
  rows: Array.from({ length: 201 }, (_, i) => ({
    rowId: id(1000 + i),
    ordinal: i,
    cells: ['a', 'b', 'c', 'd'],
  })),
  nextCursor: null,
}
let accepted201 = 'accepted'
try {
  results.acceptPage(many, results.queryMetadata(metadata), columns)
} catch (error) {
  accepted201 = `rejected: ${error?.message ?? 'Error'}`
}
console.log('--- 201 rows ->', accepted201)
