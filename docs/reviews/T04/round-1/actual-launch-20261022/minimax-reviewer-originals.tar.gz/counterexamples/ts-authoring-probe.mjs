// Independent counterexample probe (reviewer-authored, ignored runtime dir only).
// Compiles the reviewed draft.ts with the repo's locked TypeScript, exactly the
// way docs/iterations/T04/ssr-probe.mjs does, and evaluates the same fixed case
// list as the Python probe so both implementations can be compared.
import ts from 'typescript'
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..')
const require = createRequire(path.join(root, 'package.json'))
const compile = (source, filename) =>
  ts.transpileModule(source, {
    fileName: filename,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
      jsx: ts.JsxEmit.ReactJSX,
      esModuleInterop: true,
    },
  }).outputText
const original = { '.ts': require.extensions['.ts'] }
require.extensions['.ts'] = (mod, filename) =>
  mod._compile(compile(readFileSync(filename, 'utf8'), filename), filename)

const mod = { exports: {} }
new Function(
  'require',
  'module',
  'exports',
  compile(
    readFileSync(path.join(root, 'apps/desktop/src/renderer/src/query/draft.ts'), 'utf8'),
    path.join(root, 'apps/desktop/src/renderer/src/query/draft.ts'),
  ),
)(require, mod, mod.exports)
const draft = mod.exports
try {
} finally {
  for (const [ext, handler] of Object.entries(original)) {
    if (handler) require.extensions[ext] = handler
    else delete require.extensions[ext]
  }
}

const BASE = {
  name: 'q',
  description: '',
  sparql: 'ASK {}',
  scope: 'asserted',
  capabilityQuestion: '',
  source: 'editor',
}
const draftCase = (patch) => ({ ...BASE, ...patch })
const outcome = (fn) => {
  try {
    return { ok: true, value: fn() }
  } catch (error) {
    return { ok: false, error: error?.constructor?.name ?? 'Error' }
  }
}

const drafts = []
for (const [label, patch] of [
  ['name_plain', { name: 'q' }],
  ['name_128', { name: 'a'.repeat(128) }],
  ['name_129', { name: 'a'.repeat(129) }],
  ['name_128_plus_space', { name: 'a'.repeat(128) + ' ' }],
  ['name_space_plus_128', { name: ' ' + 'a'.repeat(128) }],
  ['name_127_plus_2space', { name: 'a'.repeat(127) + '  ' }],
  ['name_only_space', { name: ' ' }],
  ['name_empty', { name: '' }],
  ['sparql_65536', { sparql: 'a'.repeat(65536) }],
  ['sparql_65537', { sparql: 'a'.repeat(65537) }],
  ['sparql_65536_plus_space', { sparql: 'a'.repeat(65536) + ' ' }],
  ['sparql_65535_plus_2space', { sparql: 'a'.repeat(65535) + '  ' }],
  ['desc_4096', { description: 'a'.repeat(4096) }],
  ['desc_4097', { description: 'a'.repeat(4097) }],
  ['scope_bad', { scope: 'scenario' }],
  ['source_bad', { source: 'trusted' }],
  ['extra_key', { extra: 1 }],
  ['surrogate_name', { name: 'a\ud800' }],
]) {
  drafts.push({ case: label, result: outcome(() => draft.draftSchema.parse(draftCase(patch))) })
}

const terms = []
for (const [label, term] of [
  ['lit_plain', { kind: 'literal', value: 'x', language: null, datatype: null }],
  ['lit_empty', { kind: 'literal', value: '', language: null, datatype: null }],
  ['lit_del', { kind: 'literal', value: 'a\x7fb', language: null, datatype: null }],
  ['lit_nul', { kind: 'literal', value: 'a\x00b', language: null, datatype: null }],
  ['lit_quote_backslash', { kind: 'literal', value: '"\\', language: null, datatype: null }],
  ['lit_lang_mixed', { kind: 'literal', value: 'x', language: 'ZH-cn', datatype: null }],
  ['lit_lang_empty', { kind: 'literal', value: 'x', language: '', datatype: null }],
  ['lit_lang_and_dt', { kind: 'literal', value: 'x', language: 'en', datatype: 'urn:t' }],
  ['lit_dt', { kind: 'literal', value: '001', language: null, datatype: 'urn:t' }],
  ['lit_surrogate', { kind: 'literal', value: 'a\ud800', language: null, datatype: null }],
  ['lit_extra_key', { kind: 'literal', value: 'x', language: null, datatype: null, e: 1 }],
  ['iri_ok', { kind: 'iri', value: 'urn:t04:Alarm' }],
  ['iri_relative', { kind: 'iri', value: 'relative' }],
  ['iri_space', { kind: 'iri', value: 'urn:a b' }],
  ['iri_empty', { kind: 'iri', value: '' }],
  ['iri_del', { kind: 'iri', value: 'urn:a\x7f' }],
  ['iri_surrogate', { kind: 'iri', value: 'urn:a\ud800' }],
  ['iri_extra_key', { kind: 'iri', value: 'urn:a', language: null }],
]) {
  terms.push({ case: label, result: outcome(() => draft.serializeTerm(term)) })
}

const visual = []
for (const [label, value] of [
  [
    'visual_standard',
    {
      classIri: 'urn:t04:Alarm',
      fields: [{ predicate: 'urn:t04:severity', label: 's' }],
      conditions: [
        {
          predicate: 'urn:t04:status',
          operator: 'eq',
          value: { kind: 'literal', value: 'Open', language: null, datatype: null },
        },
      ],
    },
  ],
  [
    'visual_exists',
    {
      classIri: 'urn:t04:Alarm',
      fields: [],
      conditions: [{ predicate: 'urn:t04:status', operator: 'not-exists' }],
    },
  ],
  ['visual_empty_class', { classIri: '', fields: [], conditions: [] }],
]) {
  visual.push({ case: label, result: outcome(() => draft.compileVisual(value)) })
}

console.log(JSON.stringify({ drafts, terms, visual }))
