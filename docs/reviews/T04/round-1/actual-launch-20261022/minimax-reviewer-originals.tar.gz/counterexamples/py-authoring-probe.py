"""Independent counterexample probe (reviewer-authored, ignored runtime dir only).

Evaluates the Python authoring service over a fixed case list so the reviewer can
compare its accept/reject decisions with the TypeScript implementation. It writes
no source, test or acceptance file and never executes a query.
"""

import json
import sys

from ontolearn_engine.query_service import compile_visual, serialize_term, validate_draft

BASE = {
    "name": "q",
    "description": "",
    "sparql": "ASK {}",
    "scope": "asserted",
    "capabilityQuestion": "",
    "source": "editor",
}


def draft_case(patch):
    value = dict(BASE)
    value.update(patch)
    return value


def outcome(fn):
    try:
        return {"ok": True, "value": fn()}
    except Exception as exc:  # noqa: BLE001 - probe records the rejection class
        return {"ok": False, "error": type(exc).__name__}


cases = []
for label, patch in [
    ("name_plain", {"name": "q"}),
    ("name_128", {"name": "a" * 128}),
    ("name_129", {"name": "a" * 129}),
    ("name_128_plus_space", {"name": "a" * 128 + " "}),
    ("name_space_plus_128", {"name": " " + "a" * 128}),
    ("name_127_plus_2space", {"name": "a" * 127 + "  "}),
    ("name_only_space", {"name": " "}),
    ("name_empty", {"name": ""}),
    ("sparql_65536", {"sparql": "a" * 65536}),
    ("sparql_65537", {"sparql": "a" * 65537}),
    ("sparql_65536_plus_space", {"sparql": "a" * 65536 + " "}),
    ("sparql_65535_plus_2space", {"sparql": "a" * 65535 + "  "}),
    ("desc_4096", {"description": "a" * 4096}),
    ("desc_4097", {"description": "a" * 4097}),
    ("scope_bad", {"scope": "scenario"}),
    ("source_bad", {"source": "trusted"}),
    ("extra_key", {"extra": 1}),
    ("surrogate_name", {"name": "a\ud800"}),
]:
    cases.append({"case": label, "result": outcome(lambda p=patch: validate_draft(draft_case(p)))})

terms = []
for label, term in [
    ("lit_plain", {"kind": "literal", "value": "x", "language": None, "datatype": None}),
    ("lit_empty", {"kind": "literal", "value": "", "language": None, "datatype": None}),
    ("lit_del", {"kind": "literal", "value": "a\x7fb", "language": None, "datatype": None}),
    ("lit_nul", {"kind": "literal", "value": "a\x00b", "language": None, "datatype": None}),
    ("lit_quote_backslash", {"kind": "literal", "value": '"\\', "language": None, "datatype": None}),
    ("lit_lang_mixed", {"kind": "literal", "value": "x", "language": "ZH-cn", "datatype": None}),
    ("lit_lang_empty", {"kind": "literal", "value": "x", "language": "", "datatype": None}),
    ("lit_lang_and_dt", {"kind": "literal", "value": "x", "language": "en", "datatype": "urn:t"}),
    ("lit_dt", {"kind": "literal", "value": "001", "language": None, "datatype": "urn:t"}),
    ("lit_surrogate", {"kind": "literal", "value": "a\ud800", "language": None, "datatype": None}),
    ("lit_extra_key", {"kind": "literal", "value": "x", "language": None, "datatype": None, "e": 1}),
    ("iri_ok", {"kind": "iri", "value": "urn:t04:Alarm"}),
    ("iri_relative", {"kind": "iri", "value": "relative"}),
    ("iri_space", {"kind": "iri", "value": "urn:a b"}),
    ("iri_empty", {"kind": "iri", "value": ""}),
    ("iri_del", {"kind": "iri", "value": "urn:a\x7f"}),
    ("iri_surrogate", {"kind": "iri", "value": "urn:a\ud800"}),
    ("iri_extra_key", {"kind": "iri", "value": "urn:a", "language": None}),
]:
    terms.append({"case": label, "result": outcome(lambda t=term: serialize_term(t))})

visual_cases = []
for label, visual in [
    (
        "visual_standard",
        {
            "classIri": "urn:t04:Alarm",
            "fields": [{"predicate": "urn:t04:severity", "label": "s"}],
            "conditions": [
                {
                    "predicate": "urn:t04:status",
                    "operator": "eq",
                    "value": {"kind": "literal", "value": "Open", "language": None, "datatype": None},
                }
            ],
        },
    ),
    (
        "visual_exists",
        {
            "classIri": "urn:t04:Alarm",
            "fields": [],
            "conditions": [{"predicate": "urn:t04:status", "operator": "not-exists"}],
        },
    ),
    (
        "visual_empty_class",
        {"classIri": "", "fields": [], "conditions": []},
    ),
]:
    visual_cases.append({"case": label, "result": outcome(lambda v=visual: compile_visual(v))})

print(json.dumps({"drafts": cases, "terms": terms, "visual": visual_cases}, ensure_ascii=False))
sys.exit(0)
