from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root = Path.cwd()
assert root.name == "T04-query-p3-repair"
runtime = root / "test-results/t04-p3-repair"
label, argv = sys.argv[1], sys.argv[2:]
assert argv and label.replace("-", "").replace("_", "").isalnum()
raw = runtime / "raw" / (label + ".log")
assert not raw.exists(), "Preserve first execution; choose a new evidence label"
env = dict(os.environ)
env.update(npm_config_cache=str(runtime / "cache/npm"), UV_CACHE_DIR=str(runtime / "cache/uv"), TMPDIR=str(runtime / "tmp"))
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with raw.open("wb") as output:
    result = subprocess.run(argv, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
data = raw.read_bytes()
receipt = {"label": label, "argv": argv, "cwd": str(root), "startedAt": start, "finishedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exitCode": result.returncode, "raw": str(raw), "rawBytes": len(data), "rawSHA256": hashlib.sha256(data).hexdigest()}
(runtime / "metadata" / (label + ".json")).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(receipt, ensure_ascii=False))
sys.exit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
