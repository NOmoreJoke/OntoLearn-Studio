"""Independent ZCode counterexample: Python side of the D1 cross-language probe."""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "packages/engine/src"))

from ontolearn_engine.query_service.drafts import DraftError, validate_draft  # noqa: E402

edge_chars = [
    9, 10, 11, 12, 13, 28, 29, 30, 31, 32, 133, 160, 5760, 8192, 8193, 8194, 8195, 8196, 8197,
    8198, 8199, 8200, 8201, 8202, 8232, 8233, 8239, 8287, 12288, 65279,
]
non_trim = ["x", "­", "​", "⁠"]
cases = []
add = lambda field, value: cases.append((field, value))  # noqa: E731
for cp in edge_chars:
    ch = chr(cp)
    add("name", ch + "q")
    add("name", "q" + ch)
    add("name", ch + ch + ch)
    add("sparql", ch + "SELECT" + ch)
for ch in non_trim:
    add("name", ch + "q" + ch)
    add("sparql", ch + "q" + ch)
astral = "\U0001f642"
add("name", astral * 63 + "q" + astral * 63)
add("name", astral * 63 + "q")
add("name", astral * 64)
add("name", " " * 64 + astral * 32)
add("name", " " * 65 + astral * 32)
add("sparql", astral * 32767 + "q")
add("sparql", astral * 32767 + " q")
add("sparql", astral * 32768 + " ")
add("name", "\ufeff\x85\x1c\x1d\x1e\x1f" * 10 + "core" + "　  " * 10)
add("sparql", "SELECT\n" * 3 + astral + "\nWHERE" * 2)
add("name", "\ud800")
add("name", "\udfff")
add("sparql", "ok\ud800ok")

base = {
    "name": "q",
    "description": "",
    "sparql": "SELECT ?item WHERE { ?item a <urn:Class> }",
    "scope": "asserted",
    "capabilityQuestion": "",
    "source": "editor",
}
def utf16_len(value):
    return len(value.encode("utf-16-le", errors="surrogatepass")) // 2


out = []
for field, value in cases:
    payload = dict(base)
    payload[field] = value
    try:
        parsed = validate_draft(payload)
        out.append(
            {"field": field, "value": value, "valueUtf16": utf16_len(value),
             "ok": True, "normalized": parsed[field]}
        )
    except DraftError:
        out.append(
            {"field": field, "value": value, "valueUtf16": utf16_len(value),
             "ok": False}
        )
dst = ROOT / "test-results/t04-review-runtime/zcode/counterexamples/py-results.json"
dst.write_text(json.dumps(out, ensure_ascii=True, indent=1), encoding="utf-8")
print(json.dumps({"cases": len(out), "accepted": sum(1 for r in out if r["ok"]), "dst": str(dst)}))
