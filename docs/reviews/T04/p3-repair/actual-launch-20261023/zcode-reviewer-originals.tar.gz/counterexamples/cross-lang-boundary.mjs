// Independent ZCode counterexample: cross-language D1 boundary consistency probe.
// Generates its own cases (not the product fixture) and records per-case verdicts.
import ts from 'typescript'
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..')
const require = createRequire(path.join(root, 'package.json'))
const original = { '.ts': require.extensions['.ts'] }
const compile = (source, filename) =>
  ts.transpileModule(source, {
    fileName: filename,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
      esModuleInterop: true,
    },
  }).outputText
require.extensions['.ts'] = (mod, filename) =>
  mod._compile(compile(readFileSync(filename, 'utf8'), filename), filename)
let draftModule
try {
  const source = "module.exports = require('./apps/desktop/src/renderer/src/query/draft')"
  const mod = { exports: {} }
  new Function('require', 'module', 'exports', compile(source, 'probe.ts'))(require, mod, mod.exports)
  draftModule = mod.exports
} finally {
  if (original['.ts']) require.extensions['.ts'] = original['.ts']
  else delete require.extensions['.ts']
}
if (!draftModule || typeof draftModule.draftSchema?.parse !== 'function')
  throw new Error('draft module did not load')

const edgeChars = [
  9, 10, 11, 12, 13, 28, 29, 30, 31, 32, 133, 160, 5760, 8192, 8193, 8194, 8195, 8196, 8197, 8198,
  8199, 8200, 8201, 8202, 8232, 8233, 8239, 8287, 12288, 65279,
]
const nonTrim = ['x', '\u00ad', '\u200b', '\u2060'] // soft hyphen / ZWSP / word joiner: NOT edge space
const cases = []
const add = (field, value) => cases.push({ field, value })
for (const cp of edgeChars) {
  const ch = String.fromCodePoint(cp)
  add('name', ch + 'q')
  add('name', 'q' + ch)
  add('name', ch + ch + ch)
  add('sparql', ch + 'SELECT' + ch)
}
for (const ch of nonTrim) {
  add('name', ch + 'q' + ch)
  add('sparql', ch + 'q' + ch)
}
const astral = '\u{1F642}'
add('name', astral.repeat(63) + 'q' + astral.repeat(63)) // 127 units inside + 1 = 127? = 63*2+1+63*2=253 > 128 -> reject expected
add('name', astral.repeat(63) + 'q') // 63*2+1=127 <= 128 accept
add('name', astral.repeat(64)) // 128 accept
add('name', ' '.repeat(64) + astral.repeat(32)) // raw 64+64=128 accept, normalized 64 units
add('name', ' '.repeat(65) + astral.repeat(32)) // raw 129 reject
add('sparql', astral.repeat(32767) + 'q') // 65535 accept
add('sparql', astral.repeat(32767) + ' q') // 65536 accept (raw exactly), trimmed 65535
add('sparql', astral.repeat(32768) + ' ') // 65537 raw reject
add('name', '\uFEFF\u0085\u001C\u001D\u001E\u001F'.repeat(10) + 'core' + '\u3000\u205F\u202F'.repeat(10))
add('sparql', 'SELECT\n'.repeat(3) + astral + '\nWHERE'.repeat(2))
add('name', '\ud800') // lone surrogate low
add('name', '\udfff') // lone surrogate high
add('sparql', 'ok\ud800ok')

const base = {
  name: 'q',
  description: '',
  sparql: 'SELECT ?item WHERE { ?item a <urn:Class> }',
  scope: 'asserted',
  capabilityQuestion: '',
  source: 'editor',
}
const out = []
for (const c of cases) {
  const input = { ...base, [c.field]: c.value }
  let verdict
  try {
    const parsed = draftModule.draftSchema.parse(input)
    verdict = { ok: true, normalized: parsed[c.field] }
  } catch {
    verdict = { ok: false }
  }
  out.push({ field: c.field, value: c.value, valueUtf16: c.value.length, ...verdict })
}
const dst = path.join(root, 'test-results/t04-review-runtime/zcode/counterexamples/ts-results.json')
writeFileSync(dst, JSON.stringify(out, null, 1))
console.log(JSON.stringify({ cases: out.length, accepted: out.filter((r) => r.ok).length, dst }))
