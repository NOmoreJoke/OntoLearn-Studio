# 反例探针首失败记录（探针工具缺陷，非产品失败）

- 命令：`node test-results/t04-review-runtime/zcode/counterexamples/cross-lang-boundary.mjs` 与 `.venv/bin/python test-results/t04-review-runtime/zcode/counterexamples/cross-lang-boundary.py`
- 结果：
  1. TS 侧输出 `{"cases":141,"accepted":0}` —— 全部判为拒绝，原因是 harness 用 `import { draftSchema }` 经 TypeScript transpile 成 CJS 后赋给内部变量，`mod.exports` 为空对象，`draftModule.draftSchema.parse` 抛 TypeError 被 catch 误记为"拒绝"。探针缺陷，不反映产品行为。
  2. Python 侧在 lone-surrogate 用例抛 `UnicodeEncodeError: 'utf-16-le' codec can't encode character '\ud800'`（脚本在 DraftError 分支中计算 `value.encode('utf-16-le')`，Python 默认拒绝编码孤立代理项）。探针缺陷；产品 drafts.py 在 `_text` 阶段已先拒绝 lone surrogate，不会执行到编码。
- 处置：修正探针（TS 用 `module.exports = require(...)` 直接取得模块；Python 用 `errors='surrogatepass'` 计算代理项长度），重跑并比较。产品代码、产品测试、fixture 均未改动。
