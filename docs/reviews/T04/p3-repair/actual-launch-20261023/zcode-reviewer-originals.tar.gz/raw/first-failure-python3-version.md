# 首失败记录：run-review-command.py 在系统 python3 下 ImportError

- 日期：2026-10-23（本方 ZCode 审查会话）
- 命令（两条均同样失败，labels targeted-ts-zcode / targeted-python-zcode 首次尝试）：
  - `python3 docs/reviews/T04/p3-repair/launch/run-review-command.py targeted-ts-zcode npx vitest run tests/unit/t04-query-authoring.test.ts tests/unit/t04-query-results.test.ts tests/unit/t04-query-reader.test.ts`
  - `python3 docs/reviews/T04/p3-repair/launch/run-review-command.py targeted-python-zcode uv run --frozen pytest packages/engine/tests/test_query_service_authoring.py packages/engine/tests/test_query_service_approved_baseline.py -q`
- cwd：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/T04-s1-zcode-review-5070004`
- 真实退出：非 0（ImportError，工具在写 raw 之前即抛出，故无 raw 日志文件；本文件即为该首失败的原始记录）
- 失败原文（两次相同）：

```
Traceback (most recent call last):
  File "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T04-s1-zcode-review-5070004/docs/reviews/T04/p3-repair/launch/run-review-command.py", line 9, in <module>
    from datetime import UTC, datetime
ImportError: cannot import name 'UTC' from 'datetime' (/Applications/Xcode.app/Contents/Developer/Library/Frameworks/Python3.framework/Versions/3.9/lib/python3.9/datetime.py)
```

- 原因：PATH 上 `python3` 解析到 Xcode 附带 Python 3.9；`datetime.UTC` 需要 Python ≥3.11，项目要求 3.12。
- 处置：不改工具、不改产品；改用本树 `.venv/bin/python`（Python 3.12，uv sync --frozen 已建）以新 label 重跑。属环境纠正，非产品/探针失败，也不是为刷绿筛选。
