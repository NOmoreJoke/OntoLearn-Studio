// Independent reviewer probe (minimax M3.1-Flash / T04-S1 / candidate 5070004).
// Purpose: empirically determine (a) zod string .max() length semantics in the
// installed zod version, and (b) whether the TS draftSchema accepts/rejects the
// same shared fixture cases as the Python validate_draft.
// Read-only against the product tree; writes only its own JSON result next to itself.
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const here = dirname(fileURLToPath(import.meta.url))
const repo = join(here, '../../../..')
const { z } = await import(join(repo, 'node_modules/zod/index.js'))

const out = { zodVersion: 'read-from-package', semantics: {}, cases: {}, edges: {}, extra: {} }

// (a) zod .max() semantics: code points vs UTF-16 code units
const astral3 = '\u{1F642}'.repeat(3) // 3 code points, 6 UTF-16 units
const bmp4 = 'a'.repeat(4)
out.semantics = {
  zodPackageVersion: JSON.parse(
    readFileSync(join(repo, 'node_modules/zod/package.json'), 'utf8'),
  ).version,
  'max(4) accepts 3 astral chars (code-point semantics)': z.string().max(4).safeParse(astral3).success,
  'max(4) rejects 5 ascii chars': z.string().max(4).safeParse('a'.repeat(5)).success,
  'max(4) accepts 4 ascii chars': z.string().max(4).safeParse(bmp4).success,
  'max(6) accepts 3 astral chars (utf-16 semantics would also accept)':
    z.string().max(6).safeParse(astral3).success,
  'max(5) accepts 3 astral chars (utf-16 semantics would reject)':
    z.string().max(5).safeParse(astral3).success,
  'max(4) accepts 4 astral chars? (utf-16=8)': z.string().max(4).safeParse('\u{1F642}'.repeat(4))
    .success,
}

// (b) real product draft.ts behaviour on the shared fixture
const { draftSchema } = await import(
  join(repo, 'apps/desktop/src/renderer/src/query/draft.ts')
)
const boundaries = JSON.parse(
  readFileSync(join(repo, 'tests/fixtures/query/draft-boundaries.json'), 'utf8'),
)
const base = {
  name: 'q',
  description: '',
  sparql: 'SELECT ?item WHERE { ?item a <urn:Class> }',
  scope: 'asserted',
  capabilityQuestion: '',
  source: 'editor',
}
for (const entry of boundaries.cases) {
  const core = entry.unit.repeat(entry.count)
  const input = { ...base, [entry.field]: entry.prefix + core + entry.suffix }
  let accepted = false
  let normalized = null
  try {
    const parsed = draftSchema.parse(input)
    accepted = true
    normalized = parsed[entry.field]
  } catch {
    accepted = false
  }
  out.cases[entry.label] = { expected: entry.valid, tsAccepted: accepted, tsNormalizedIsCore: normalized === core }
}
// every edge code point must trim on both fields, and lone edges must be rejected
for (const cp of boundaries.trimEdgeCodePoints) {
  const edge = String.fromCodePoint(cp)
  for (const field of ['name', 'sparql']) {
    const ok = draftSchema.safeParse({ ...base, [field]: edge + 'q' + edge }).success
    const trimmed = draftSchema.safeParse({ ...base, [field]: edge + 'q' + edge })
    const rejected = !draftSchema.safeParse({ ...base, [field]: edge }).success
    const normalized =
      trimmed.success && trimmed.data[field] === 'q' ? 'q' : trimmed.success ? trimmed.data[field] : null
    out.edges[`U+${cp.toString(16).padStart(4, '0')}/${field}`] = { trimmedToQ: normalized === 'q', loneRejected: rejected }
  }
}
// lone surrogates
out.extra.loneSurrogateRejected = ['\ud800', '\udfff'].map((v) => ({
  value: v,
  rejected: !draftSchema.safeParse({ ...base, name: v }).success && !draftSchema.safeParse({ ...base, sparql: v }).success,
}))

// description / capabilityQuestion limit semantics (not part of the D1 union change)
const astralDesc = '\u{1F642}'.repeat(4096) // 4096 code points, 8192 UTF-16 units
out.extra.description4096AstralAccepted = draftSchema.safeParse({ ...base, description: astralDesc }).success
out.extra.description4097AsciiAccepted = draftSchema.safeParse({ ...base, description: 'a'.repeat(4097) })
  .success
out.extra.capabilityQuestion4096AstralAccepted = draftSchema.safeParse({
  ...base,
  capabilityQuestion: astralDesc,
}).success

writeFileSync(join(here, 'd1-parity.ts.json'), JSON.stringify(out, null, 2) + '\n')
console.log(JSON.stringify(out, null, 2))
