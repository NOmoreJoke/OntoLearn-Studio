"""Independent reviewer probe (minimax M3.1-Flash / T04-S1 / candidate 5070004).

Mirror of d1-parity.mjs on the Python side, using the same shared fixture, so the
two language implementations can be compared case-by-case instead of by count.
Read-only against the product tree; writes only its own JSON result next to itself.
"""

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
sys.path.insert(0, str(REPO / "packages/engine/src"))

from ontolearn_engine.query_service import validate_draft  # noqa: E402
from ontolearn_engine.query_service.drafts import DraftError  # noqa: E402

BASE = {
    "name": "q",
    "description": "",
    "sparql": "SELECT ?item WHERE { ?item a <urn:Class> }",
    "scope": "asserted",
    "capabilityQuestion": "",
    "source": "editor",
}

boundaries = json.loads((REPO / "tests/fixtures/query/draft-boundaries.json").read_text())

out = {"cases": {}, "edges": {}, "extra": {}}

for entry in boundaries["cases"]:
    core = entry["unit"] * entry["count"]
    value = {**BASE, entry["field"]: entry["prefix"] + core + entry["suffix"]}
    accepted = True
    normalized = None
    try:
        parsed = validate_draft(value)
        normalized = parsed[entry["field"]]
    except DraftError:
        accepted = False
    out["cases"][entry["label"]] = {
        "expected": entry["valid"],
        "pyAccepted": accepted,
        "pyNormalizedIsCore": normalized == core,
    }

for cp in boundaries["trimEdgeCodePoints"]:
    edge = chr(cp)
    for field in ("name", "sparql"):
        try:
            parsed = validate_draft({**BASE, field: edge + "q" + edge})
            trimmed_to_q = parsed[field] == "q"
        except DraftError:
            trimmed_to_q = False
        try:
            validate_draft({**BASE, field: edge})
            lone_rejected = False
        except DraftError:
            lone_rejected = True
        out["edges"][f"U+{cp:04X}/{field}"] = {
            "trimmedToQ": trimmed_to_q,
            "loneRejected": lone_rejected,
        }

def _rejected(value, field):
    try:
        validate_draft({**BASE, field: value})
        return False
    except DraftError:
        return True


astral = "\U0001F642" * 4096
out["extra"]["loneSurrogateRejected"] = [
    {
        "value": repr(v),
        "rejected": all(_rejected(v, f) for f in ("name", "sparql")),
    }
    for v in ("\ud800", "\udfff")
]


out["extra"]["description4096AstralAccepted"] = not _rejected(astral, "description")
out["extra"]["description4097AsciiAccepted"] = not _rejected("a" * 4097, "description")
out["extra"]["capabilityQuestion4096AstralAccepted"] = not _rejected(
    astral, "capabilityQuestion"
)

(HERE / "d1-parity.py.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
