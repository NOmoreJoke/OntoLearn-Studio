"""Independent reviewer probe (minimax M3.1-Flash / T04-S1 / candidate 5070004).

Strict case-by-case comparison of the TS and Python D1 boundary results.
First comparison attempt failed with KeyError('U+000a/name') because the TS side
lower-cased the hex code point and the Python side upper-cased it; this script
normalizes the key case instead of changing either product implementation.
"""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ts = json.loads((HERE / "d1-parity.ts.json").read_text())
py = json.loads((HERE / "d1-parity.py.json").read_text())

case_diffs = []
for key, a in ts["cases"].items():
    b = py["cases"][key]
    ta = (a["expected"], a["tsAccepted"], a["tsNormalizedIsCore"])
    tb = (b["expected"], b["pyAccepted"], b["pyNormalizedIsCore"])
    if ta != tb:
        case_diffs.append({"case": key, "ts": ta, "py": tb})

def normalize(key):
    head, _, tail = key.partition("/")
    return f"{head.upper()}/{tail.lower()}"


py_edges = {normalize(k): v for k, v in py["edges"].items()}

edge_diffs = []
for key, a in ts["edges"].items():
    b = py_edges[normalize(key)]
    ta = (a["trimmedToQ"], a["loneRejected"])
    tb = (b["trimmedToQ"], b["loneRejected"])
    if ta != tb:
        edge_diffs.append({"edge": key, "ts": ta, "py": tb})

extra_diffs = {}
for key, value in ts["extra"].items():
    if key == "loneSurrogateRejected":
        py_list = py["extra"][key]
        ts_list = value
        same = all(
            t["rejected"] == p["rejected"] for t, p in zip(ts_list, py_list, strict=True)
        ) and len(ts_list) == len(py_list)
        extra_diffs[key] = {"ts": ts_list, "py": py_list, "agree": same}
    else:
        extra_diffs[key] = {"ts": value, "py": py["extra"][key], "agree": value == py["extra"][key]}

report = {
    "tsCaseCount": len(ts["cases"]),
    "pyCaseCount": len(py["cases"]),
    "tsEdgeCount": len(ts["edges"]),
    "pyEdgeCount": len(py["edges"]),
    "caseDivergences": case_diffs,
    "edgeDivergences": edge_diffs,
    "extra": extra_diffs,
    "allAgree": not case_diffs and not edge_diffs and all(v["agree"] for v in extra_diffs.values()),
}
(HERE / "d1-parity.compare.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
