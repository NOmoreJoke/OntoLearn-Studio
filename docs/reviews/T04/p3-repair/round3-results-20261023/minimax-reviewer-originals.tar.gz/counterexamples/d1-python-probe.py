"""Independent D1 probe: Python side of the shared draft-boundary policy.

Reads the shared product fixture, adds reviewer-authored extra boundary cases,
and reports for every case whether validate_draft accepted it and what
normalized value it produced. No product file is modified; this only calls the
reviewed public API.
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "packages/engine/src"))

from ontolearn_engine.query_service import validate_draft  # noqa: E402
from ontolearn_engine.query_service.drafts import DraftError  # noqa: E402

FIXTURE = json.loads((ROOT / "tests/fixtures/query/draft-boundaries.json").read_text())

EDGE30 = "".join(chr(cp) for cp in FIXTURE["trimEdgeCodePoints"])
ASTRAL = "\U0001f642"  # 1 code point, 2 UTF-16 code units
INTERNAL = "a\u3000b\ufeffc\u00a0d"

EXTRA = [
    # (label, field, raw value, expected accepted?)
    ("name-129-codepoints", "name", "a" * 129, False),
    ("name-128-codepoints", "name", "a" * 128, True),
    ("name-64-astral-128-utf16", "name", ASTRAL * 64, True),
    ("name-65-astral-130-utf16", "name", ASTRAL * 65, False),
    ("name-64-astral-plus-ascii", "name", ASTRAL * 64 + "a", False),
    ("name-trailing-30-edge-space", "name", "x" + EDGE30, True),
    ("name-only-edge-space", "name", EDGE30, False),
    ("name-internal-space-preserved", "name", INTERNAL, True),
    ("name-leading-30-edge-space", "name", EDGE30 + "x", True),
    ("name-lone-surrogate-high", "name", "\ud800", False),
    ("name-lone-surrogate-low", "name", "\udc00", False),
    ("name-lone-surrogate-internal", "name", "a\ud800b", False),
    ("name-lone-surrogate-at-edge", "name", "\udfffname", False),
    ("name-astral-then-trim", "name", "\ufeff" + ASTRAL + "\ufeff", True),
    ("sparql-65537-codepoints", "sparql", "a" * 65537, False),
    ("sparql-65536-codepoints", "sparql", "a" * 65536, True),
    ("sparql-32768-astral-65536-utf16", "sparql", ASTRAL * 32768, True),
    ("sparql-32769-astral-65538-utf16", "sparql", ASTRAL * 32769, False),
    ("sparql-lone-surrogate", "sparql", "SELECT \ud800", False),
    ("sparql-trim-edge-space", "sparql", "\ufeffSELECT ?x WHERE {}\ufeff", True),
]


def draft(field, value):
    return {
        "name": "base",
        "description": "",
        "sparql": "SELECT ?item WHERE { ?item a <urn:Class> }",
        "scope": "asserted",
        "capabilityQuestion": "",
        "source": "editor",
        field: value,
    }


def run(field, value):
    try:
        return {"accepted": True, "value": validate_draft(draft(field, value))[field]}
    except DraftError:
        return {"accepted": False, "value": None}
    except Exception as error:  # unexpected exception type is itself a finding
        return {"accepted": False, "value": None, "error": type(error).__name__}


results = {}
mismatches = []

for entry in FIXTURE["cases"]:
    core = entry["unit"] * entry["count"]
    raw = entry["prefix"] + core + entry["suffix"]
    outcome = run(entry["field"], raw)
    results["fixture:" + entry["label"]] = outcome
    if outcome["accepted"] != entry["valid"]:
        mismatches.append(("fixture:" + entry["label"], entry["valid"], outcome["accepted"]))
    if entry["valid"] and outcome.get("value") != core:
        mismatches.append(("fixture-value:" + entry["label"], core, outcome.get("value")))

for label, field, value, expected in EXTRA:
    outcome = run(field, value)
    results["extra:" + label] = outcome
    if outcome["accepted"] != expected:
        mismatches.append(("extra:" + label, expected, outcome["accepted"]))

# Every one of the 30 declared edge code points must trim on both fields.
for cp in FIXTURE["trimEdgeCodePoints"]:
    edge = chr(cp)
    for field in ("name", "sparql"):
        trimmed = run(field, edge + "q" + edge)
        blank = run(field, edge)
        if not trimmed["accepted"] or trimmed.get("value") != "q":
            mismatches.append((f"edge-trim:{field}:{cp}", "q", trimmed))
        if blank["accepted"]:
            mismatches.append((f"edge-blank:{field}:{cp}", False, True))

out = Path(__file__).parent / "d1-python-results.json"
out.write_text(json.dumps(results, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
print(
    json.dumps(
        {
            "probe": "d1-python",
            "cases": len(results),
            "mismatches": mismatches,
            "output": str(out),
        },
        ensure_ascii=False,
        indent=2,
    )
)
sys.exit(1 if mismatches else 0)
