"""Independent T09 provenance verification for the T04 R3 review.

1) Recompute bytes + SHA-256 for every declared member of
   approved-t09-provenance-inputs.tar.gz (17 provenance inputs + PRD + manifest).
2) Independently rebuild the G-base graph from the ARCHIVED original bytes and
   run the archived original query plus an independently compiled query, to
   check the complete expected answer sets: A01 only, empty after Closed, and
   the deliberate wrong-semantics A02 case.

No product file is read for the rebuild except the archived originals; the
product's own copies are only compared byte-for-byte.
"""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
ARCHIVE = ROOT / "docs/reviews/T04/p3-repair/launch-r3/approved-t09-provenance-inputs.tar.gz"
SPEC = ROOT / "docs/reviews/T04/p3-repair/launch-r3/t09-provenance-files.json"
EXTRACT = ROOT / "test-results/t04-review-runtime/minimax/t09"
PRODUCT = ROOT / "tests/fixtures/query/approved-baseline"

sys.path.insert(0, str(ROOT / "packages/engine/src"))
from ontolearn_engine.query_service import compile_visual  # noqa: E402
from rdflib import Graph, Literal, URIRef  # noqa: E402

report = {"archive": {}, "members": [], "mismatches": [], "answers": {}}
archive_bytes = ARCHIVE.read_bytes()
report["archive"] = {
    "bytes": len(archive_bytes),
    "sha256": hashlib.sha256(archive_bytes).hexdigest(),
}
spec = json.loads(SPEC.read_text())
report["spec"] = {
    "sourceCommit": spec.get("sourceCommit"),
    "version": spec.get("version"),
    "onlyRuntimeConsumed": spec.get("onlyRuntimeConsumed"),
    "declaredMembers": len(spec["files"]),
}
declared = {entry["path"]: entry for entry in spec["files"]}

# 1) every declared member, recomputed from the extracted archive
for path, entry in sorted(declared.items()):
    local = EXTRACT / path
    exists = local.is_file()
    data = local.read_bytes() if exists else b""
    actual = {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest() if exists else None,
    }
    ok = exists and actual["bytes"] == entry["bytes"] and actual["sha256"] == entry["sha256"]
    report["members"].append({"path": path, "ok": ok, "actual": actual, "declared": {
        "bytes": entry["bytes"], "sha256": entry["sha256"]}})
    if not ok:
        report["mismatches"].append(path)

# product copies must be byte-identical to the archived originals
for name, archived_rel in (
    ("G-base.json", "tests/fixtures/product-baselines/G-base.json"),
    ("conventions.json", "tests/fixtures/product-baselines/conventions.json"),
    ("unclosed-high.rq", "tests/fixtures/product-baselines/unclosed-high.rq"),
    ("manifest.json", "approved-input-manifest.json"),
):
    archived = EXTRACT / archived_rel
    product = PRODUCT / name
    same = archived.is_file() and product.is_file() and archived.read_bytes() == product.read_bytes()
    report.setdefault("productCopiesIdentical", {})[name] = same
    if not same:
        report["mismatches"].append(f"product-copy:{name}")

# 2) independent answer sets, rebuilt from archived original bytes
gbase = json.loads((EXTRACT / "tests/fixtures/product-baselines/G-base.json").read_text())
original_query = (EXTRACT / "tests/fixtures/product-baselines/unclosed-high.rq").read_text()
conventions = json.loads((EXTRACT / "tests/fixtures/product-baselines/conventions.json").read_text())
namespace = conventions["namespace"]


def build_graph(closed=False):
    triples = [*gbase["ontology"], *gbase["facts"]]
    text = "\n".join(
        f"<{row['subject']}> <{row['predicate']}> {row['object']} ." for row in triples
    )
    graph = Graph().parse(data=text, format="turtle")
    if closed:
        graph.set(
            (
                URIRef("urn:ontolearn:learning:alarm/A01"),
                URIRef("urn:ontolearn:learning:status"),
                Literal("Closed"),
            )
        )
    return graph


generated = compile_visual(
    {
        "classIri": namespace + "Alarm",
        "fields": [],
        "conditions": [
            {
                "predicate": namespace + "level",
                "operator": "eq",
                "value": {
                    "kind": "literal",
                    "value": "High",
                    "language": None,
                    "datatype": None,
                },
            },
            {
                "predicate": namespace + "status",
                "operator": "eq",
                "value": {
                    "kind": "literal",
                    "value": "Open",
                    "language": None,
                    "datatype": None,
                },
            },
        ],
    }
)


def rows(graph, sparql):
    return [[str(value) for value in row] for row in graph.query(sparql)]


wrong_query = original_query.replace('"Open"', '"Closed"')
answers = {
    "original_A01": rows(build_graph(), original_query),
    "generated_A01": rows(build_graph(), generated),
    "original_after_Closed": rows(build_graph(closed=True), original_query),
    "generated_after_Closed": rows(build_graph(closed=True), generated),
    "deliberate_wrong_Closed_High": rows(build_graph(), wrong_query),
}
answers["generated_matches_original_sparql_shape"] = (
    sorted(answers["original_A01"]) == sorted(answers["generated_A01"])
)
answers["same_count_wrong_meaning_detected"] = (
    len(answers["deliberate_wrong_Closed_High"]) == len(answers["original_A01"])
    and answers["deliberate_wrong_Closed_High"] != answers["original_A01"]
)
report["answers"] = answers

expected = {
    "original_A01": [["urn:ontolearn:learning:alarm/A01"]],
    "generated_A01": [["urn:ontolearn:learning:alarm/A01"]],
    "original_after_Closed": [],
    "generated_after_Closed": [],
    "deliberate_wrong_Closed_High": [["urn:ontolearn:learning:alarm/A02"]],
}
for key, want in expected.items():
    if answers.get(key) != want:
        report["mismatches"].append(f"answer:{key}: got {answers.get(key)!r} want {want!r}")
for key in (
    "generated_matches_original_sparql_shape",
    "same_count_wrong_meaning_detected",
):
    if not answers[key]:
        report["mismatches"].append(f"assert:{key}")

out = Path(__file__).parent / "t09-provenance-results.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
print(
    json.dumps(
        {
            "membersChecked": len(report["members"]),
            "membersOk": sum(1 for m in report["members"] if m["ok"]),
            "productCopiesIdentical": report.get("productCopiesIdentical"),
            "mismatches": report["mismatches"],
            "answers": answers,
            "output": str(out),
        },
        ensure_ascii=False,
        indent=2,
    )
)
sys.exit(1 if report["mismatches"] else 0)
