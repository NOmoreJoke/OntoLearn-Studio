// Independent probe: what unit does Zod v4 `.max()` measure for strings?
// Read-only against the installed dependency; no product file is modified.
import { z } from 'zod'

const ASTRAL = '\u{1F600}' // 1 code point, 2 UTF-16 code units
const A = ASTRAL.repeat(64) // 64 code points, 128 UTF-16 units

const report = {
  zodVersion: (await import('zod/package.json', { with: { type: 'json' } })).default.version,
  astralLengthJs: A.length,
  astralCodePoints: [...A].length,
  max128Accepts64Astral: z.string().max(128).safeParse(A).success,
  max64Accepts64Astral: z.string().max(64).safeParse(A).success,
  explicitLengthRefine128: z.string().refine((s) => s.length <= 128).safeParse(A).success,
  explicitLengthRefine64: z.string().refine((s) => s.length <= 64).safeParse(A).success,
  codePointRefine128: z.string().refine((s) => [...s].length <= 128).safeParse(A).success,
}
console.log(JSON.stringify(report, null, 2))
