// Independent D1 probe: TypeScript side of the shared draft-boundary policy.
// Imports the reviewed renderer module directly; no product file is modified
// and no test selection/filters are used to reach a green result.
import { draftSchema, visualSchema } from '../../../../apps/desktop/src/renderer/src/query/draft.ts'
import { readFileSync } from 'node:fs'

const ROOT = new URL('../../../../', import.meta.url)
const FIXTURE = JSON.parse(readFileSync(new URL('tests/fixtures/query/draft-boundaries.json', ROOT), 'utf8'))

const EDGE30 =
  '\t\n\v\f\r\u001c\u001d\u001e\u001f \u0085\u00a0\u1680' +
  '\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a' +
  '\u2028\u2029\u202f\u205f\u3000\ufeff'
const ASTRAL = '\u{1F642}'

const EXTRA: { label: string; field: 'name' | 'sparql'; value: string; expected: boolean }[] = [
  { label: 'name-129-codepoints', field: 'name', value: 'a'.repeat(129), expected: false },
  { label: 'name-128-codepoints', field: 'name', value: 'a'.repeat(128), expected: true },
  { label: 'name-64-astral-128-utf16', field: 'name', value: ASTRAL.repeat(64), expected: true },
  { label: 'name-65-astral-130-utf16', field: 'name', value: ASTRAL.repeat(65), expected: false },
  { label: 'name-64-astral-plus-ascii', field: 'name', value: ASTRAL.repeat(64) + 'a', expected: false },
  { label: 'name-trailing-30-edge-space', field: 'name', value: 'x' + EDGE30, expected: true },
  { label: 'name-only-edge-space', field: 'name', value: EDGE30, expected: false },
  { label: 'name-internal-space-preserved', field: 'name', value: 'a\u3000b\ufeffc\u00a0d', expected: true },
  { label: 'name-leading-30-edge-space', field: 'name', value: EDGE30 + 'x', expected: true },
  { label: 'name-lone-surrogate-high', field: 'name', value: '\ud800', expected: false },
  { label: 'name-lone-surrogate-low', field: 'name', value: '\udc00', expected: false },
  { label: 'name-lone-surrogate-internal', field: 'name', value: 'a\ud800b', expected: false },
  { label: 'name-lone-surrogate-at-edge', field: 'name', value: '\udfffname', expected: false },
  { label: 'name-astral-then-trim', field: 'name', value: '\ufeff' + ASTRAL + '\ufeff', expected: true },
  { label: 'sparql-65537-codepoints', field: 'sparql', value: 'a'.repeat(65537), expected: false },
  { label: 'sparql-65536-codepoints', field: 'sparql', value: 'a'.repeat(65536), expected: true },
  { label: 'sparql-32768-astral-65536-utf16', field: 'sparql', value: ASTRAL.repeat(32768), expected: true },
  { label: 'sparql-32769-astral-65538-utf16', field: 'sparql', value: ASTRAL.repeat(32769), expected: false },
  { label: 'sparql-lone-surrogate', field: 'sparql', value: 'SELECT \ud800', expected: false },
  { label: 'sparql-trim-edge-space', field: 'sparql', value: '\ufeffSELECT ?x WHERE {}\ufeff', expected: true },
]

function base(field: 'name' | 'sparql', value: string) {
  return {
    name: 'base',
    description: '',
    sparql: 'SELECT ?item WHERE { ?item a <urn:Class> }',
    scope: 'asserted' as const,
    capabilityQuestion: '',
    source: 'editor' as const,
    [field]: value,
  }
}

function run(field: 'name' | 'sparql', value: string) {
  const parsed = draftSchema.safeParse(base(field, value))
  return parsed.success
    ? { accepted: true, value: parsed.data[field] }
    : { accepted: false, value: null }
}

const results: Record<string, { accepted: boolean; value: string | null }> = {}
const mismatches: unknown[] = []

for (const entry of FIXTURE.cases) {
  const core = entry.unit.repeat(entry.count)
  const raw = entry.prefix + core + entry.suffix
  const outcome = run(entry.field as 'name' | 'sparql', raw)
  results['fixture:' + entry.label] = outcome
  if (outcome.accepted !== entry.valid)
    mismatches.push(['fixture:' + entry.label, entry.valid, outcome.accepted])
  if (entry.valid && outcome.value !== core)
    mismatches.push(['fixture-value:' + entry.label, core, outcome.value])
}

for (const entry of EXTRA) {
  const outcome = run(entry.field, entry.value)
  results['extra:' + entry.label] = outcome
  if (outcome.accepted !== entry.expected)
    mismatches.push(['extra:' + entry.label, entry.expected, outcome.accepted])
}

for (const cp of FIXTURE.trimEdgeCodePoints) {
  const edge = String.fromCodePoint(cp)
  for (const field of ['name', 'sparql'] as const) {
    const trimmed = run(field, edge + 'q' + edge)
    const blank = run(field, edge)
    if (!trimmed.accepted || trimmed.value !== 'q')
      mismatches.push([`edge-trim:${field}:${cp}`, 'q', trimmed])
    if (blank.accepted) mismatches.push([`edge-blank:${field}:${cp}`, false, true])
  }
}

// Independent check of the D3/D4 visual caps that D1 must not have loosened.
const visualCaps: unknown[] = []
const baseVisual = { classIri: 'urn:Class', fields: [], conditions: [] }
if (visualSchema.safeParse({ ...baseVisual, fields: Array(16).fill({ predicate: 'urn:p', label: 'x' }) }).success !== true)
  visualCaps.push('16 fields must be accepted')
if (visualSchema.safeParse({ ...baseVisual, fields: Array(17).fill({ predicate: 'urn:p', label: 'x' }) }).success !== false)
  visualCaps.push('17 fields must be rejected')
if (visualSchema.safeParse({ ...baseVisual, conditions: Array(32).fill({ predicate: 'urn:p', operator: 'exists' }) }).success !== true)
  visualCaps.push('32 conditions must be accepted')
if (visualSchema.safeParse({ ...baseVisual, conditions: Array(33).fill({ predicate: 'urn:p', operator: 'exists' }) }).success !== false)
  visualCaps.push('33 conditions must be rejected')
if (visualSchema.safeParse({ ...baseVisual, fields: [], conditions: [] }).success !== true)
  visualCaps.push('empty arrays must stay allowed (zero-column semantics undecided)')

console.log(
  JSON.stringify(
    { probe: 'd1-ts', cases: Object.keys(results).length, mismatches, visualCaps },
    null,
    2,
  ),
)
process.exit(mismatches.length || visualCaps.length ? 1 : 0)
