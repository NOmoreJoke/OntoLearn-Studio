// Round-3 zcode independent D1 probe: run the TS draftSchema over shared cases.
import ts from 'typescript'
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..')
const require = createRequire(path.join(root, 'package.json'))
const original = { '.ts': require.extensions['.ts'] }
const compile = (source, filename) =>
  ts.transpileModule(source, {
    fileName: filename,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
      esModuleInterop: true,
    },
  }).outputText
require.extensions['.ts'] = (mod, filename) =>
  mod._compile(compile(readFileSync(filename, 'utf8'), filename), filename)
let draft
try {
  draft = require(path.join(root, 'apps/desktop/src/renderer/src/query/draft.ts'))
} finally {
  if (original['.ts']) require.extensions['.ts'] = original['.ts']
  else delete require.extensions['.ts']
}
const data = JSON.parse(
  readFileSync(new URL('./d1-cases.json', import.meta.url), 'utf-8'),
)
const base = {
  name: 'q',
  description: '',
  sparql: 'SELECT ?item WHERE { ?item a <urn:Class> }',
  scope: 'asserted',
  capabilityQuestion: '',
  source: 'editor',
}
const results = []
for (const entry of data.cases) {
  const input = { ...base, [entry.field]: entry.value }
  const parsed = draft.draftSchema.safeParse(input)
  results.push(
    parsed.success
      ? { id: entry.id, ok: true, value: parsed.data[entry.field] }
      : { id: entry.id, ok: false, value: null },
  )
}
writeFileSync(new URL('./d1-ts-results.json', import.meta.url), JSON.stringify(results))
// zod max() semantics check on this exact zod install
const { z } = require(path.join(root, 'node_modules', 'zod'))
const astral2048 = '\u{1F642}'.repeat(2048) // 2048 code points, 4096 UTF-16 units
const zodMaxCodePoints = z.string().max(4096).safeParse(astral2048).success
console.log(
  JSON.stringify({
    ts_results: results.length,
    zod_version: require(path.join(root, 'node_modules', 'zod', 'package.json')).version,
    zod_max_4096_accepts_2048_astral_cp: zodMaxCodePoints,
  }),
)
