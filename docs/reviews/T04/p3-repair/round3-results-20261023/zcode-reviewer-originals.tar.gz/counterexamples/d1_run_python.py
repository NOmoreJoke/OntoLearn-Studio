"""Round-3 zcode independent D1 probe: run the Python validator over shared cases."""
import json
import pathlib

from ontolearn_engine.query_service import validate_draft
from ontolearn_engine.query_service.drafts import DraftError

here = pathlib.Path(__file__).parent
data = json.loads((here / "d1-cases.json").read_text(encoding="utf-8"))
base = {
    "name": "q",
    "description": "",
    "sparql": "SELECT ?item WHERE { ?item a <urn:Class> }",
    "scope": "asserted",
    "capabilityQuestion": "",
    "source": "editor",
}
results = []
for case in data["cases"]:
    draft = dict(base)
    draft[case["field"]] = case["value"]
    try:
        normalized = validate_draft(draft)[case["field"]]
        results.append({"id": case["id"], "ok": True, "value": normalized})
    except DraftError:
        results.append({"id": case["id"], "ok": False, "value": None})
out = here / "d1-py-results.json"
out.write_text(json.dumps(results, ensure_ascii=True), encoding="utf-8")
print(json.dumps({"python_results": len(results), "path": str(out)}))
