"""Round-3 zcode independent D1 cross-language equivalence probe: generate cases."""
import json
import pathlib

EDGE = (
    "\t\n\v\f\r\x1c\x1d\x1e\x1f \x85\xa0\u1680"
    "\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a"
    "\u2028\u2029\u202f\u205f\u3000\ufeff"
)
assert len(EDGE) == 30

cases = []


def add(field, value, note):
    cases.append({"id": len(cases), "field": field, "value": value, "note": note})


# name/sparql raw UTF-16 boundaries with BMP and astral units
for field, base in (("name", 128), ("sparql", 65536)):
    for unit in ("a", "\U0001F642"):
        for count in range(max(0, base // 2 - 3), base // 2 + 3):
            add(field, unit * count, f"bare {field} unit={unit!r} cp={count}")
        # astral counts whose utf16 length crosses the limit
    for count in (base - 2, base - 1, base, base + 1):
        add(field, "a" * count, f"bare {field} bmp {count}")
        add(field, "a" * (count - 1) + " ", f"trailing space {count}")
        add(field, " " + "a" * (count - 1), f"leading space {count}")
        add(field, "\ufeff" + "a" * (count - 1) + "\u0085", f"edge feff/nel {count}")
# 30 edge chars both ends + bare
for i, ch in enumerate(EDGE):
    add("name", ch + "q" + ch, f"edge[{i}] U+{ord(ch):04X}")
    add("name", ch, f"edge-only[{i}] U+{ord(ch):04X}")
# interior preserved
add("name", "\ufeff\u0085a \t b\u001c ", "interior preserved")
add("sparql", "\u2028SELECT 1\u2029", "interior preserved sparql")
# lone surrogates
for s in ("\ud800", "\udfff", "a\ud800b"):
    add("name", s, "lone surrogate")
    add("sparql", s, "lone surrogate")
# description/question/literal-value max semantics (unchanged limits)
for count in (4095, 4096, 4097):
    add("description", "\U0001F642" * count, f"description astral cp={count}")
    add("capabilityQuestion", "\U0001F642" * count, f"question astral cp={count}")
add("description", "\U0001F642" * 2048, "description astral cp=2048 utf16=4096")
add("description", "a" * 4096, "description bmp 4096")
add("description", "a" * 4097, "description bmp 4097")

out = pathlib.Path(__file__).with_name("d1-cases.json")
out.write_text(json.dumps({"cases": cases}, ensure_ascii=True), encoding="utf-8")
print(json.dumps({"generated": len(cases), "path": str(out)}))
