# -*- coding: utf-8 -*-
import datetime
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path

OUT = Path(__file__).parent
BASE = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees')
ZSID = 'session_0b35de3fed06d21bd17ec25a5848c29d'
ZTURN = 'turn_2f496dde-637e-490a-85a5-b4a30abea550'
MSID = 'mvs_58e4985c72594853ac34354567ea2468'
MTURN = '8de34221-3863-486b-a4ee-8b58fe4c9833'
MFOLDER = Path('/Users/kyle/.minimax/v2/sessions/2026/10/22/21-14-13-182-session_bXZzXzU4ZTQ5ODVjNzI1OTQ4NTNhYzM0MzU0NTY3ZWEyNDY4')


def digest(b):
    return hashlib.sha256(b).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def text_content(v):
    if isinstance(v, str):
        return v
    if isinstance(v, list):
        return '\n'.join(b.get('text', '') for b in v if isinstance(b, dict) and b.get('type') == 'text')
    return ''


def receive(role, sid, turn):
    root = BASE / f'T07-{role}-review-r2-f9a1157'
    directory = OUT / role
    directory.mkdir(exist_ok=True)
    frozen_path = root / 'docs/reviews/T07/round-2-input/full-input.txt'
    frozen = frozen_path.read_bytes()
    short = (root / 'docs/reviews/T07/round-2-input/short-launch.txt').read_text().strip()
    calls = {}
    results = {}
    for filename, target in [('tool-calls.jsonl', calls), ('tool-results.jsonl', results)]:
        previous = directory / filename
        if previous.exists():
            for raw in previous.open():
                v = json.loads(raw)
                key = v['id'] if filename == 'tool-calls.jsonl' else (v['toolCallId'], digest(json.dumps(v, ensure_ascii=False).encode()))
                target[key] = v
    model_calls = []
    short_capture = directory / 'actual-short-launch.txt'
    first_short = short_capture.read_text().strip() if short_capture.exists() else None
    attachment = None
    initial_capture = directory / 'initial-attachment-numbered.txt'
    initial_numbered = initial_capture.read_text() if initial_capture.exists() else None
    native_model_scalars = []
    latest_public_text = None

    if role == 'zcode':
        source = Path(f'/Users/kyle/.zcode/cli/rollout/model-io-{sid}.jsonl')
        for raw in source.open():
            try:
                d = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if d.get('sessionId') != sid or d.get('turnId') != turn or d.get('querySource') != 'main_turn':
                continue
            model_calls.append({k: d.get(k) for k in ('requestId', 'attempt', 'model', 'startedAt', 'completedAt', 'querySource')})
            if d.get('response', {}).get('text'):
                latest_public_text = d['response']['text']
            for c in d.get('response', {}).get('toolCalls', []):
                calls[c['id']] = {'id': c['id'], 'name': c['name'], 'arguments': c.get('input')}
            for m in d.get('request', {}).get('messages', []):
                if m.get('role') == 'tool':
                    result = {k: m.get(k) for k in ('toolCallId', 'toolName', 'isError', 'content')}
                    key = (m.get('toolCallId'), digest(json.dumps(result, ensure_ascii=False).encode()))
                    results[key] = result
                s = text_content(m.get('content'))
                if s.startswith('T07-S1 R2 full independent engineering review.') and first_short is None:
                    first_short = s.strip()
                if initial_numbered is None:
                    marker = 'Called the Read tool with the following input: ' + json.dumps({'file_path': str(frozen_path)}, ensure_ascii=False, separators=(',', ':'))
                    offset = s.find(marker)
                    if offset >= 0:
                        # Retain only contiguous numbered attachment lines, never surrounding system text.
                        numbered = []
                        started = False
                        for line in s[offset + len(marker):].split('\n'):
                            match = re.match(r'^(\d+)\t(.*)$', line)
                            if match:
                                started = True
                                numbered.append(line)
                            elif started:
                                break
                        if numbered:
                            initial_numbered = '\n'.join(numbered)
                            (directory / 'initial-attachment-numbered.txt').write_text(initial_numbered)
    else:
        source = MFOLDER / 'messages.jsonl'
        for raw in source.read_text().splitlines():
            d = json.loads(raw)
            if d.get('turn_id') != turn:
                continue
            m = d.get('message', {})
            if m.get('role') == 'assistant':
                scalar = {k: m.get(k) for k in ('model', 'provider', 'api') if k in m}
                if scalar and scalar not in native_model_scalars:
                    native_model_scalars.append(scalar)
                public = text_content(m.get('content'))
                if public:
                    latest_public_text = public
            if m.get('role') == 'user':
                s = text_content(m.get('content'))
                pos = s.find('T07-S1 R2 full independent engineering review.')
                if pos >= 0 and first_short is None:
                    # The actual three-paragraph launch ends with this literal sentence.
                    end_marker = 'Current Chinese rules at the front govern; exact old input suffix is history only.'
                    end = s.find(end_marker, pos)
                    if end >= 0:
                        first_short = s[pos:end + len(end_marker)].strip()
                for tag in re.findall(r'<attachment\b[^>]*name="full-input.txt"[^>]*>', s):
                    match = re.search(r'path="([^"]+)"', tag)
                    if match:
                        asset_path = Path(match.group(1))
                        asset_bytes = asset_path.read_bytes()
                        (directory / 'official-attachment-original.txt').write_bytes(asset_bytes)
                        attachment = {'explicitOriginalUserAttachmentPath': str(asset_path), 'bytes': len(asset_bytes), 'sha256': digest(asset_bytes), 'equalsFrozen': asset_bytes == frozen}
            content = m.get('content', [])
            if isinstance(content, list):
                for b in content:
                    if isinstance(b, dict) and b.get('type') == 'toolCall':
                        calls[b['id']] = {k: b.get(k) for k in ('id', 'name', 'arguments')}
            if m.get('toolCallId'):
                details = m.get('details', {})
                # Public file read and process evidence only; omit reminder/header/thinking/env context.
                result = {k: m.get(k) for k in ('toolCallId', 'toolName', 'isError', 'timestamp')}
                result['content'] = text_content(m.get('content'))
                result['details'] = {k: details[k] for k in ('textFile', 'execution', 'output', 'processOutput', 'status') if k in details}
                results[(m['toolCallId'], digest(json.dumps(result, ensure_ascii=False).encode()))] = result

    for filename, values in [('tool-calls.jsonl', calls.values()), ('tool-results.jsonl', results.values())]:
        with (directory / filename).open('w') as f:
            for value in values:
                f.write(json.dumps(value, ensure_ascii=False) + '\n')
    if first_short is not None:
        (directory / 'actual-short-launch.txt').write_text(first_short + '\n')

    lines = {}
    conflicts = []
    chunks = []

    def add_numbered(text, call_id):
        parsed = []
        for line in text.split('\n'):
            match = re.match(r'^\s*(\d+)(?:\t|→)(.*)$', line)
            if match:
                parsed.append((int(match.group(1)), match.group(2)))
        add(parsed, call_id)

    def add(parsed, call_id):
        for number, text in parsed:
            if number in lines and lines[number] != text:
                conflicts.append({'line': number, 'callId': call_id})
            else:
                lines[number] = text
        if parsed:
            chunks.append({'sourceCallId': call_id, 'first': parsed[0][0], 'last': parsed[-1][0], 'actualLines': len(parsed)})

    if initial_numbered:
        add_numbered(initial_numbered, 'official-initial-attachment-auto-read')
    for result in results.values():
        cid = result['toolCallId']
        call = calls.get(cid, {})
        args = call.get('arguments') or {}
        if not isinstance(args, dict):
            continue
        path = args.get('file_path', args.get('path'))
        if path != str(frozen_path):
            continue
        if str(call.get('name', '')).lower() != 'read':
            continue
        if role == 'zcode':
            add_numbered(result.get('content', ''), cid)
        else:
            t = result.get('details', {}).get('textFile', {})
            if t.get('path') == str(frozen_path):
                # Coverage is the actual public numbered return. Structured details
                # remain evidence, but cannot supply an omitted visible blank line.
                add_numbered(result.get('content', ''), cid)

    maximum = max(lines) if lines else 0
    holes = [i for i in range(1, maximum + 1) if i not in lines]
    rebuilt = None
    if maximum and not holes and not conflicts:
        # Join actual numbered/Read-returned text; expected bytes are comparison only.
        rebuilt = '\n'.join(lines[i] for i in range(1, maximum + 1)).encode()
        (directory / 'actual-input-reconstructed.txt').write_bytes(rebuilt)
    report = root / f'docs/reviews/T07/round-2/{"zcode-glm53" if role == "zcode" else "minimax-m31flash"}.md'
    report_meta = {'path': str(report), 'exists': report.exists()}
    if report.exists():
        b = report.read_bytes()
        (directory / 'report-snapshot.md').write_bytes(b)
        (directory / ('report-version-' + digest(b) + '.md')).write_bytes(b)
        report_meta.update(bytes=len(b), sha256=digest(b))
    receipt = Path(str(root) + '.runtime/metadata/operator-identity-receipt.json')
    summary = {'sessionId': sid, 'originalTurnId': turn, 'source': str(source), 'snapshotAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'originalShortLaunchMatchesFrozenAfterOuterWhitespace': None if first_short is None else first_short == short, 'modelCallCount': len(model_calls), 'modelCalls': model_calls, 'toolCallCount': len(calls), 'toolResultVariantCount': len(results), 'attachmentOriginal': attachment, 'actualInputReading': {'chunks': chunks, 'first': min(lines) if lines else None, 'last': maximum, 'holes': holes, 'conflicts': conflicts, 'rebuiltBytes': len(rebuilt) if rebuilt is not None else None, 'rebuiltSHA256': digest(rebuilt) if rebuilt is not None else None, 'equalsFrozen': rebuilt == frozen if rebuilt is not None else False, 'expectedUsedToFillBytes': False}, 'operatorReceipt': {'path': str(receipt), 'bytes': receipt.stat().st_size, 'sha256': digest(receipt.read_bytes())}, 'report': report_meta, 'officialTerminal': None}
    summary['nativeModelScalars'] = native_model_scalars
    summary['sourceCurrentBytes'] = source.stat().st_size
    gap_path = directory / 'attachment-and-compaction-gap.json'
    if gap_path.exists():
        summary['earlierOriginalAttachmentAndCompactionGap'] = json.loads(gap_path.read_text())
    if role == 'minimax':
        conn = sqlite3.connect('file:/Users/kyle/.minimax/v2/sqlite/runtime-state.sqlite?mode=ro', uri=True, timeout=1)
        conn.execute('PRAGMA query_only=ON')
        summary['officialTurnFourColumns'] = conn.execute('SELECT session_id,turn_id,terminal_outcome,updated_at_ms FROM local_runtime_session_agent_state WHERE session_id=? AND turn_id=?', (sid, turn)).fetchall()
        summary['officialSessionFourColumns'] = conn.execute('SELECT session_id,status,workspace_dir,project_workspace_dir FROM local_runtime_sessions WHERE session_id=?', (sid,)).fetchall()
        conn.close()
        rows = summary['officialTurnFourColumns']
        if len(rows) == 1 and rows[0][2] is not None:
            summary['officialTerminal'] = rows[0][2]
    else:
        events = []
        p = Path('/Users/kyle/.zcode/cli/log/zcode-2026-10-23.jsonl')
        for raw in p.open():
            if sid not in raw or turn not in raw:
                continue
            d = json.loads(raw)
            if d.get('sessionId') == sid and d.get('turnId') == turn:
                event = str(d.get('event', ''))
                if event in ('turn.started', 'turn.completed', 'turn.failed'):
                    events.append({k: d.get(k) for k in ('timestamp', 'event', 'sessionId', 'turnId', 'status')})
        summary['officialMinimalTurnEvents'] = events
        terminal = [e for e in events if e['event'] in ('turn.completed', 'turn.failed')]
        if terminal:
            summary['officialTerminal'] = terminal[-1]
    if summary['officialTerminal'] is not None and latest_public_text:
        (directory / 'terminal-public-last-answer.txt').write_text(latest_public_text)
    write_json(directory / 'receiving-summary.json', summary)
    snapshots = directory / 'snapshots'
    snapshots.mkdir(exist_ok=True)
    write_json(snapshots / (summary['snapshotAtUTC'].replace(':', '-') + '.json'), summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in ('modelCalls', 'officialMinimalTurnEvents', 'actualInputReading')}, ensure_ascii=False))
    print(json.dumps({'role': role, 'actualInputReading': {k: v for k, v in summary['actualInputReading'].items() if k != 'chunks'}, 'chunks': len(chunks), 'ownOfficialEventCount': len(summary.get('officialMinimalTurnEvents', []))}, ensure_ascii=False))


selected = sys.argv[1:] or ['zcode', 'minimax']
if 'zcode' in selected:
    receive('zcode', ZSID, ZTURN)
if 'minimax' in selected:
    receive('minimax', MSID, MTURN)
