# C01 四路径修复：own依赖复用与普通执行准备说明

2026-10-23。本件及同目录 `environment-plan.json` **只有metadata与静态计划**；没有复制依赖、安装、改venv、跑工具版本/formatter/linter/typecheck/test/uv/worker/receiver/产品或GUI。产品两文件已停写；本轮唯一新增两份计划。root为唯一实际准备/runner/执行者，C02 GUI无关。

## 已确认的可复用条件

自有来源 `.worktrees/I06-native-location-N0`，目标 `.worktrees/I06-C01-service-repair-20261023`。七份package/lock/Python/workspace包配置实际逐字相等（六份既定项加engine包pyproject），bytes/SHA见JSON。来源node_modules/.venv本身均真实目录；元数据读取时目标两目录尚不存在，不因此授权覆盖随后由root准备的目录。

node_modules共51条内部symlink，全部相对路径且解析在来源树内。`@ontolearn/contracts -> ../../packages/contracts`、`@ontolearn/desktop -> ../../apps/desktop`和`.bin`相对链接独立复制保留后自然绑定到目标树。应独立字节复制或真正独立CoW副本，不能symlink整目录、共享硬链接/可变cache或借reviewer环境；N0不改。没有检查或运行Electron二进制，也无此需要。

## venv不能原封不动就执行

`pyvenv.cfg`显示CPython3.12.14、home `/opt/homebrew/opt/python@3.12/bin`、非system-site-packages；这是文件记录，不是运行版本结果。python链接到该已知Homebrew解释器，可保留已核的系统工具路径；独立venv自身必须在新树。

真正必修是 `_editable_impl_ontolearn_engine.pth`：当前96B、SHA `a817394baeb67357e59adbe80b190377477726d726d64f55d97070d7493ab259`，内容为N0绝对`packages/engine/src`。复制后只改这个确切旧root为新root；不能靠PYTHONPATH掩盖，原worker和task-runtime使用Python `-I`，真实editable绑定必须相同。其它无旧root的`.pth`（_virtualenv、distutils）保持原字节。

此外editable `direct_url.json`为N0的file URL；pytest/py.test、ontolearn-engine、PyInstaller/RDF工具等console shebang及activate文本含旧root。JSON列全观察清单。root应仅在新复制的venv内替换这些文本中的确切旧root，保留mode；direct_url按新engine包URI更新，保持editable=true。无需运行activation，也不要对二进制或所有site-packages做全局替换。未用到的打包entrypoint文本一致性修正不授权执行打包。

对改写过的已安装文件，更新所属dist-info/RECORD的对应hash/size（不填RECORD自hash、不改无关记录）；pytest两入口、engine入口/.pth/direct_url已有真实RECORD条目。跳过复制pycache/pyc和可变工具cache，避免旧路径编译缓存。上述都属root未来对own复制环境的绑定准备，本轮未执行。

## 精确子进程env

JSON内 `runtimeEnvironment`是完整替换env，非host overlay；HOME/TMPDIR/XDG/npm配置/cache/uv环境均指本任务自有outputs或新树，不能修改宿主HOME/CODEX_HOME或global配置。PATH顺序为目标node_modules/.bin、目标.venv/bin、`/Users/kyle/.local/bin`（避免既有uv PATH问题），再已知系统工具目录。

UV_NO_SYNC=1、UV_OFFLINE=1、UV_PYTHON_DOWNLOADS=never、npm offline/ignore-scripts、Electron skip download明确保留；PYTHONPATH仅新树源。没有ROOT_SOURCE_PATH/ONTOLEARN_TEST_ENGINE/项目授权/fixture/native/HMR/loader/凭据/proxy继承。`runtimeEnvironment`的规范编码算法与SHA可供runner绑定；本轮不另造env或空配置文件。root未来建立mode0700的own home/tmp/cache与mode0600空npm配置。

node `/usr/local/bin/node`、npm `/usr/local/bin/npm`、uv `/Users/kyle/.local/bin/uv`及Homebrew python只做regular/symlink/执行位元数据核对，未运行。UV cache无需借N0或reviewer缓存；复用完成后的普通命令不应触发同步/下载。复用有真实不兼容时由root按原票选择fresh setup，不让review任务自动安装或fallback网络。

## 命令与capture

票6465B／`73b70587ff0a1301ab9ecba6ccf56ccd3fc96c4b452650175d2c6ed5b49d2612`的原门不变：作者先冻结四路径及protected源向量，非作者审实际delta后再执行。尤其MF02新test即使untracked也必须显式纳入向量；不能只hash Git tracked files漏掉它。当前两MF02文件未在本计划读取/冒填最终hash。

拟顺序为三条精确unit文件各一次（本树node+本树vitest入口），再原 `npm run check`、`npm run verify:sources`；argv、cwd、独占claim、分流raw、receipt、source before/after路径与时限均在JSON。check再次跑完整既有单测是票内原行为，不是偷偷追加专项。任何首失败停后续依赖命令，保全原件；经批准修复再绑定新向量/非作者delta及相应用例重跑，不删除claim或覆盖首失败。

参考旧operator `run-check-once.py`只借鉴O_EXCL claim、精确全env与stdout/stderr分离。**不能直接照搬旧SID/turn/127退出叙述，也不能沿用其无显式PID/期限/源向量的subprocess.run。** 新runner需Popen后立即记录实际child PID/自身PID与句柄，单调operational deadline（target300s/check600s/verify120s），UTC起止、实际exit/signal/launch error、流bytes/SHA和完整before/after源向量。deadline不当物理性能/资源担保；只按原已批准runner方式处理自己保留的实际句柄，不做进程名/组/他方PID清理或global发现。后代终态未知须显式记录并停后续，不用父退出声称全drain。

原普通check包含自有临时SQLite/coordinator/worker、合成HTTPS/openssl以及原OS memory guard测试；safeStorage仍double。没有e2e/Electron/native/addon/builder/wholeH/真实provider、用户库或OS凭据授权。MF01/ZN1及两指定新审/CI/远端门均不因本计划关闭。主线后续实际准备与运行收据须绑定新候选的实际runtime HEAD+working bytes，不能把后来commit倒贴运行。
