from pathlib import Path
import os,sys,json,hashlib,shutil,stat,csv,io,base64,datetime
O=Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_I06_C01_service_repair')
S=O/'setup'
SRC=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I06-native-location-N0')
DST=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I06-C01-service-repair-20261023')
def sha(b): return hashlib.sha256(b).hexdigest()
def write(path,b):
 fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f: f.write(b)
def dump(name,obj):
 p=S/name; write(p,(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()); return pin(p)
def pin(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def expected(p,e):
 r=pin(p); assert r['bytes']==e['bytes'] and r['sha256']==e['sha256'],r; return r
planpath=O/'environment-plan.json'
expected(planpath,{'bytes':42657,'sha256':'67e6f93b148cd904eb566ae1be42f4fe59c990ce62ba4a83bc2240406cabdb27'})
plan=json.loads(planpath.read_bytes())
expected(O/'environment-preparation-notes.md',{'bytes':5948,'sha256':'421e4fe2d2ec063ff99547d975f4c43c43c8b274365b52c4eb9dc8984a530bb4'})
ticket=Path('/Users/kyle/Documents/工作/知爻/本体/iteration-control/2026-10-21-weekly-release/.private/I06-C01-four-path-service-repair-and-ordinary-ticket-20261023.json')
expected(ticket,{'bytes':6465,'sha256':'73b70587ff0a1301ab9ecba6ccf56ccd3fc96c4b452650175d2c6ed5b49d2612'})
assert Path.cwd()==DST
actual_environment=dict(os.environ)
expected_environment=plan['runtimeEnvironment']
observed_addition={k:v for k,v in actual_environment.items() if k not in expected_environment}
assert observed_addition in ({}, {'__CF_USER_TEXT_ENCODING':'0x1F5:0x0:0x52'}), ('unexpected child environment additions',observed_addition)
assert {k:v for k,v in actual_environment.items() if k not in observed_addition}==expected_environment, 'changed fixed environment'
dump('setup-child-environment-observed.json',{'passedEnvironment':expected_environment,'observedChildEnvironment':actual_environment,'observedAddition':observed_addition,'classification':'Darwin/Python child observed addition; not absorbed into passed/runtime environment'})
os.umask(0o077)
compat=[]
for e in plan['observedCompatibility']:
 compat.append({'relativePath':e['relativePath'],'source':expected(SRC/e['relativePath'],e),'destination':expected(DST/e['relativePath'],e)})
protected=json.loads((O/'source-before-edits.json').read_bytes())
paths=sorted(set([x['path'] for x in protected['entries']]+['tests/unit/i06-mf02-preview-cleanup.test.ts']))
def sourcevector(): return [dict(relativePath=p,**pin(DST/p)) for p in paths]
before=sourcevector(); beforepin=dump('protected-source-before.json',before)
for name in ['node_modules','.venv']: assert not os.path.lexists(str(DST/name)), 'destination exists: '+name
skipnames={'__pycache__','.cache','.pytest_cache','.ruff_cache','.mypy_cache','.vite','.vite-temp','.vitest'}
def ignored(name): return name in skipnames or name.endswith(('.pyc','.pyo'))
def ignore(directory,names): return [n for n in names if ignored(n)]
def inventory(root):
 rows=[]; skipped=[]
 def visit(p,rel):
  st=p.lstat(); mode=stat.S_IMODE(st.st_mode)
  row={'relativePath':rel,'mode':mode,'device':st.st_dev,'inode':st.st_ino}
  if stat.S_ISLNK(st.st_mode): row.update(type='symlink',target=os.readlink(str(p)))
  elif stat.S_ISDIR(st.st_mode):
   row['type']='directory'; rows.append(row)
   for child in sorted(p.iterdir(),key=lambda x:x.name):
    r=child.name if rel=='.' else rel+'/'+child.name
    if ignored(child.name): skipped.append(r)
    else: visit(child,r)
   return
  elif stat.S_ISREG(st.st_mode):
   b=p.read_bytes(); row.update(type='file',bytes=len(b),sha256=sha(b),nlink=st.st_nlink)
  else: raise RuntimeError('special file: '+str(p))
  rows.append(row)
 visit(root,'.'); return {'entries':rows,'skipped':skipped}
def comparable(inv):
 return [{k:v for k,v in r.items() if k not in {'device','inode','nlink'}} for r in inv['entries']]
src_before={n:inventory(SRC/n) for n in ['node_modules','.venv']}
srcpin=dump('dependency-source-before.json',src_before)
actual_links={r['relativePath']:r['target'] for r in src_before['node_modules']['entries'] if r['type']=='symlink'}
assert actual_links=={e['relativePath']:e['target'] for e in plan['nodeDependencyReuse']['observedSymlinks']}, 'source node links changed'
for n in ['node_modules','.venv']:
 print('copy-start',n,flush=True)
 shutil.copytree(str(SRC/n),str(DST/n),symlinks=True,copy_function=shutil.copy2,ignore=ignore)
 print('copy-end',n,flush=True)
copied={n:inventory(DST/n) for n in ['node_modules','.venv']}
for n in copied:
 assert comparable(copied[n])==comparable(src_before[n]), 'copy byte/mode/link mismatch '+n
 for a,b in zip(src_before[n]['entries'],copied[n]['entries']):
  if a['type']!='symlink': assert (a['device'],a['inode'])!=(b['device'],b['inode']), 'shared inode '+n+'/'+a['relativePath']
copy_pin=dump('dependency-copy-before-binding.json',copied)
venv=DST/'.venv'; py=plan['pythonDependencyReuse']; changes=[]
expected(venv/'pyvenv.cfg',py['pyvenvCfg'])
def change(rel,e,old,new,count=1):
 p=venv/rel; expected(p,e); b=p.read_bytes(); assert b.count(old)==count,(rel,b.count(old))
 oldmode=stat.S_IMODE(p.stat().st_mode); after=b.replace(old,new)
 p.write_bytes(after); assert stat.S_IMODE(p.stat().st_mode)==oldmode
 changes.append({'relativePath':rel,'before':{'bytes':len(b),'sha256':sha(b)},'after':pin(p),'mode':oldmode})
for e in py['oldRootTextScripts']:
 change(e['relativePath'],e,str(SRC).encode(),str(DST).encode(),e['oldRootOccurrences'])
for e in py['pthFiles']:
 if e['action'].startswith('Replace'): change(e['relativePath'],e,str(SRC).encode(),str(DST).encode())
 else: expected(venv/e['relativePath'],e)
direct=py['editableDirectUrl']; rel=str(Path(direct['source']['path']).relative_to(SRC/'.venv'))
change(rel,direct['source'],direct['parsed']['url'].encode(),direct['replacementUrl'].encode())
assert json.loads((venv/rel).read_bytes())==dict(direct['parsed'],url=direct['replacementUrl'])
changed_paths={str((venv/c['relativePath']).resolve()):c for c in changes}
site=venv/'lib/python3.12/site-packages'; records=[]; matched=set()
for record in sorted(site.glob('*.dist-info/RECORD')):
 original=record.read_bytes(); lines=original.decode().splitlines(keepends=True); newlines=[]; affected=[]
 for line in lines:
  row=next(csv.reader([line])); assert len(row)==3,(str(record),row)
  resolved=(site/row[0]).resolve()
  if str(resolved) in changed_paths:
   assert resolved.is_relative_to(venv), 'record path escapes own venv'
   b=resolved.read_bytes(); oldrow=list(row)
   row[1]='sha256='+base64.urlsafe_b64encode(hashlib.sha256(b).digest()).decode().rstrip('='); row[2]=str(len(b))
   ending='\r\n' if line.endswith('\r\n') else '\n' if line.endswith('\n') else ''
   stream=io.StringIO(newline=''); csv.writer(stream,lineterminator=ending).writerow(row); newlines.append(stream.getvalue())
   affected.append({'path':row[0],'before':oldrow,'after':row}); matched.add(str(resolved))
  else: newlines.append(line)
 if affected:
  new=''.join(newlines).encode(); oldmode=stat.S_IMODE(record.stat().st_mode); record.write_bytes(new); assert stat.S_IMODE(record.stat().st_mode)==oldmode
  records.append({'relativePath':str(record.relative_to(venv)),'before':{'bytes':len(original),'sha256':sha(original)},'after':pin(record),'rows':affected})
unmatched=[c['relativePath'] for c in changes if str((venv/c['relativePath']).resolve()) not in matched]
assert set(unmatched)=={'bin/activate','bin/activate.bat','bin/activate.csh','bin/activate.fish','bin/activate.nu'},unmatched
bindingpin=dump('binding-before-after.json',{'exactOldRoot':str(SRC),'exactNewRoot':str(DST),'changes':changes,'recordRepairs':records,'untrackedActivationMetadata':unmatched})
env=plan['runtimeEnvironment']
for name in ['home','tmp','config','cache','xdg-cache','xdg-config','xdg-data']:
 (O/name).mkdir(mode=0o700)
for name in ['npm','uv']: (O/'cache'/name).mkdir(mode=0o700)
for k in ['NPM_CONFIG_USERCONFIG','NPM_CONFIG_GLOBALCONFIG']: write(Path(env[k]),b'')
envb=(json.dumps(env,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
assert len(envb)==plan['canonicalEnvironmentEncoding']['bytes'] and sha(envb)==plan['canonicalEnvironmentEncoding']['sha256']
write(O/'runtime-environment.json',envb)
final={n:inventory(DST/n) for n in ['node_modules','.venv']}; finalpin=dump('dependency-destination-final.json',final)
# Explicit link verification does not load target modules/interpreters.
for r in final['node_modules']['entries']:
 if r['type']=='symlink':
  p=DST/'node_modules'/r['relativePath']; assert not os.path.isabs(r['target']); assert p.resolve().is_relative_to(DST); assert p.exists(),str(p)
allowed={c['relativePath'] for c in changes}|{r['relativePath'] for r in records}
originalrows={r['relativePath']:r for r in copied['.venv']['entries']}
for r in final['.venv']['entries']:
 old=originalrows[r['relativePath']]
 if r['relativePath'] not in allowed:
  assert {k:v for k,v in r.items() if k not in {'device','inode','nlink'}}=={k:v for k,v in old.items() if k not in {'device','inode','nlink'}},r['relativePath']
src_after={n:inventory(SRC/n) for n in ['node_modules','.venv']}
assert src_after==src_before,'source dependencies changed'
after=sourcevector(); assert after==before,'protected source changed during setup'
for e in plan['observedCompatibility']: expected(SRC/e['relativePath'],e); expected(DST/e['relativePath'],e)
afterpin=dump('protected-source-after.json',after); sourceafterpin=dump('dependency-source-after.json',src_after)
result={'kind':'independent-own-dependency-copy-and-binding','result':'prepared','productCommandsRun':False,'installationOrDownloadRun':False,'setupPID':os.getpid(),'sourceRoot':str(SRC),'destinationRoot':str(DST),'compatibility':compat,'protectedSourceCount':len(before),'protectedSourceUnchanged':True,'sourceDependencyUnchanged':True,'independentNonSymlinkInodes':True,'nodeSymlinks':len(actual_links),'venvTextChanges':len(changes),'recordFilesChanged':len(records),'recordRowsChanged':sum(len(x['rows']) for x in records),'runtimeEnvironment':pin(O/'runtime-environment.json'),'manifests':{'protectedBefore':beforepin,'protectedAfter':afterpin,'sourceBefore':srcpin,'sourceAfter':sourceafterpin,'copyBeforeBinding':copy_pin,'destinationFinal':finalpin,'bindings':bindingpin},'counts':{n:{t:sum(r['type']==t for r in final[n]['entries']) for t in ['file','directory','symlink']} for n in final},'omissionPolicy':sorted(skipnames)+['*.pyc','*.pyo'],'notProven':['tool execution','tests','build','native loading','GUI','complete production admission']}
resultpin=dump('setup-result.json',result)
print(json.dumps({'result':'prepared','manifest':resultpin,'nodeSymlinks':len(actual_links),'venvTextChanges':len(changes),'recordFilesChanged':len(records)},ensure_ascii=False),flush=True)
