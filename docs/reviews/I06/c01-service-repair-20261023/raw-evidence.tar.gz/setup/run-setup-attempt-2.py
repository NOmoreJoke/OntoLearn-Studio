from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,time
O=Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_I06_C01_service_repair'); S=O/'setup'
plan=json.loads((O/'environment-plan.json').read_bytes()); env=plan['runtimeEnvironment']; cwd=plan['newWorktree']
if not isinstance(cwd,str): cwd='/Users/kyle/Documents/工作/知爻/本体/.worktrees/I06-C01-service-repair-20261023'
argv=['/opt/homebrew/Cellar/python@3.12/3.12.14/Frameworks/Python.framework/Versions/3.12/bin/python3.12','-I','-S','-B',str(S/'prepare-dependencies.py')]
def pin(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,obj):
 fd=os.open(str(S/name),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
 with os.fdopen(fd,'w') as f: json.dump(obj,f,ensure_ascii=False,sort_keys=True,indent=2); f.write('\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); mono=time.monotonic()
base={'kind':'setup-only-process-receipt','argv':argv,'cwd':cwd,'environmentMode':'fullReplacement','environment':env,'runtimeCanonicalEnvSHA256':plan['canonicalEnvironmentEncoding']['sha256'],'runnerPID':os.getpid(),'startUTC':start,'script':pin(S/'prepare-dependencies.py'),'runner':pin(Path(__file__)),'plan':pin(O/'environment-plan.json'),'productCommandsRun':False}
write('attempt-2.claim.json',base)
outfd=os.open(str(S/'attempt-2.stdout.log'),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600); errfd=os.open(str(S/'attempt-2.stderr.log'),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
child=None; code=None; error=None
try:
 with os.fdopen(outfd,'wb') as out,os.fdopen(errfd,'wb') as err:
  child=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,shell=False)
  write('attempt-2.started.json',dict(base,actualChildPID=child.pid,actualChildHandle='retained subprocess.Popen instance in runner'))
  code=child.wait()
except BaseException as exc:
 error={'type':type(exc).__name__,'message':str(exc)}
receipt=dict(base,actualChildPID=child.pid if child else None,exitCode=code,launchOrWaitError=error,endUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-mono,stdout=pin(S/'attempt-2.stdout.log'),stderr=pin(S/'attempt-2.stderr.log'),setupResult=pin(S/'setup-result.json') if (S/'setup-result.json').exists() else None)
write('attempt-2.receipt.json',receipt)
print(json.dumps({'receipt':pin(S/'attempt-2.receipt.json'),'actualChildPID':receipt['actualChildPID'],'exitCode':code,'error':error},ensure_ascii=False))
sys.exit(code if code is not None and code>=0 else 1)
