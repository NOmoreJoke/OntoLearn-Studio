"""Bounded local capture adapted from the prior exact-command receipt pattern.

No process discovery, group signals, foreign PID cleanup, or inherited environment.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def digest(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


plan = json.loads((HERE / "runtime-plan.json").read_text())
command = next(item for item in plan["commands"] if item["id"] == sys.argv[1])
root = Path(plan["cwd"])
env_path = HERE / "runtime-environment.json"
env_bytes = env_path.read_bytes()
env = json.loads(env_bytes)
assert env == plan["environment"]
assert digest(HERE / "implementation-ticket.original.json")["sha256"] == plan["ticketSHA256"]
assert env["UV_NO_SYNC"] == env["UV_OFFLINE"] == "1"
assert env["HOME"] == str(HERE / "home")
assert env["UV_PROJECT_ENVIRONMENT"] == str(root / ".venv")
assert env["PATH"].split(":")[:3] == [str(root / "node_modules/.bin"), str(root / ".venv/bin"), "/Users/kyle/.local/bin"]


def source_vector():
    original = json.loads((HERE / "source-before-edits.json").read_text())
    names = [entry["path"] for entry in original["entries"]]
    names.append("tests/unit/i06-mf02-preview-cleanup.test.ts")
    entries = [{"path": name, **digest(root / name)} for name in sorted(set(names))]
    head = subprocess.check_output(["/usr/bin/git", "rev-parse", "HEAD"], cwd=root, env=env, text=True).strip()
    return {"runtimeHEAD": head, "entries": entries}


for dependency in command.get("dependsOn", []):
    previous = json.loads((HERE / "raw" / dependency / "attempt-001.receipt.json").read_text())
    assert previous["exitCode"] == 0 and previous["launchOrCaptureError"] is None
    assert previous["sourceUnchanged"] is True

before = source_vector()
if command.get("requiresRuntimeFreeze", False):
    frozen = json.loads((HERE / "source-freeze.json").read_text())
    assert before == frozen["sourceVector"]
    for review in frozen["independentReviews"]:
        assert digest(review["path"]) == {"bytes": review["bytes"], "sha256": review["sha256"]}

raw = HERE / "raw" / command["id"]
raw.mkdir(parents=True, exist_ok=True)
claim = raw / "attempt-001.claim"
fd = os.open(str(claim), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
os.write(fd, b"single exact attempt claimed; retain after any failure\n")
os.close(fd)
write_new(raw / "attempt-001.source-before.json", before)
write_new(raw / "attempt-001.environment.json", env)
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
child = None
exit_code = None
error = None
timed_out = False
cleanup = []
try:
    with (raw / "attempt-001.stdout").open("xb") as stdout, (raw / "attempt-001.stderr").open("xb") as stderr:
        child = subprocess.Popen(command["argv"], cwd=root, env=env, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL)
        write_new(raw / "attempt-001.started.json", {"argv": command["argv"], "cwd": str(root), "wrapperPID": os.getpid(), "actualChildPID": child.pid, "startUTC": start, "environmentSHA256": hashlib.sha256(env_bytes).hexdigest(), "operationalWallMs": command["wallMs"]})
        try:
            exit_code = child.wait(timeout=command["wallMs"] / 1000)
        except subprocess.TimeoutExpired:
            timed_out = True
            error = "operational deadline exceeded; exact retained Popen child only"
            child.terminate()
            cleanup.append("terminate exact retained child handle")
            try:
                exit_code = child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                cleanup.append("kill exact retained child handle")
                exit_code = child.wait(timeout=10)
except Exception as failure:
    error = repr(failure)
    try:
        if child is not None:
            exit_code = child.poll()
            if exit_code is None:
                child.terminate()
                cleanup.append("capture failure: terminate exact retained child handle")
                exit_code = child.wait(timeout=10)
    except Exception as cleanup_error:
        error += "; exact child cleanup state UNKNOWN: " + repr(cleanup_error)
capture_errors = []
try:
    after = source_vector()
except Exception as after_error:
    after = {"state": "UNKNOWN", "captureError": repr(after_error)}
    capture_errors.append({"stage": "source-after-read", "error": repr(after_error)})
try:
    write_new(raw / "attempt-001.source-after.json", after)
except Exception as after_write_error:
    capture_errors.append({"stage": "source-after-write", "error": repr(after_write_error)})
receipt = {"commandId": command["id"], "argv": command["argv"], "cwd": str(root), "runtimeHEADBefore": before["runtimeHEAD"], "runtimeHEADAfter": after.get("runtimeHEAD", "UNKNOWN"), "wrapperPID": os.getpid(), "actualChildPID": child.pid if child else None, "startUTC": start, "endUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(), "durationSeconds": round(time.monotonic() - t0, 3), "operationalWallMs": command["wallMs"], "exitCode": exit_code, "launchOrCaptureError": error, "timedOut": timed_out, "retainedHandleCleanup": cleanup, "descendantState": "not independently discovered; no global drain claim", "environmentMode": "complete replacement", "environmentFile": str(env_path), "environmentSHA256": hashlib.sha256(env_bytes).hexdigest(), "sourceUnchanged": before == after, "initialFailureRetained": True}
for name in ["stdout", "stderr"]:
    path = raw / ("attempt-001." + name)
    try:
        receipt[name] = {"path": str(path), **digest(path)} if path.exists() else {"path": str(path), "state": "NOT_CREATED"}
        if not path.exists():
            capture_errors.append({"stage": name + "-missing", "error": "expected separate stream file was not created"})
    except Exception as stream_error:
        receipt[name] = {"path": str(path), "state": "UNKNOWN"}
        capture_errors.append({"stage": name + "-digest", "error": repr(stream_error)})
receipt["runtimeHEADAfter"] = after.get("runtimeHEAD", "UNKNOWN")
receipt["captureErrors"] = capture_errors
if capture_errors:
    receipt["launchOrCaptureError"] = error or "post-child capture failed; see captureErrors"
try:
    write_new(raw / "attempt-001.receipt.json", receipt)
except Exception as receipt_write_error:
    receipt["captureErrors"].append({"stage": "terminal-receipt-write", "error": repr(receipt_write_error)})
    receipt["launchOrCaptureError"] = "terminal receipt file not confirmed; stdout fallback only"
print(json.dumps(receipt, ensure_ascii=False))
sys.exit(0 if exit_code == 0 and receipt["launchOrCaptureError"] is None and (before == after or command.get("allowsFormattingOnly", False)) else 1)
