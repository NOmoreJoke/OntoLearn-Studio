import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tokenize

ROOT = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-input-generator-style')
EVIDENCE = ROOT / 'docs/reviews/I05/input-generator-style'
BASE = '513db0056f312342a6791e2d4c7842f3726581f2'
PRODUCT = 'scripts/generate-i05-source-package-inputs.py'

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def dump(node):
    return ast.dump(node, include_attributes=False)

old_raw = subprocess.run(['git', 'show', BASE + ':' + PRODUCT], cwd=ROOT, check=True, capture_output=True).stdout
new_raw = (EVIDENCE / 'proposal.py.raw').read_bytes()
assert identity(old_raw) == {'bytes': 60354, 'sha256': 'e58dd4efd1c64952b6555b98c65271fc7e82d7b99b198d848d69f5a7c9dcde0b'}
assert identity(new_raw) == {'bytes': 75633, 'sha256': 'c51a1a7f3085e79958022deda95d8a08792f3a95f7c4f1fb171d56196f3d2d26'}
assert (ROOT / PRODUCT).read_bytes() == old_raw
assert (ROOT / 'build/input-generator-style/proposal.py').read_bytes() == new_raw
old = ast.parse(old_raw)
new = ast.parse(new_raw)
normalized = copy.deepcopy(new)

def top(tree, name):
    found = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
    assert len(found) == 1
    return found[0]

old_i = top(old, 'I')
new_i = top(normalized, 'iri_term')
new_i.name = 'I'
assert dump(new_i) == dump(old_i)
parents = {child: parent for parent in ast.walk(normalized) for child in ast.iter_child_nodes(parent)}
uses = [n for n in ast.walk(normalized) if isinstance(n, ast.Name) and n.id == 'iri_term']
assert len(uses) == 26
assert all(isinstance(parents[n], ast.Call) and parents[n].func is n and isinstance(n.ctx, ast.Load) for n in uses)
for n in uses:
    n.id = 'I'

old_records = top(old, 'add_records')
new_records = top(normalized, 'add_records')
old_lambda = [(i, n) for i, n in enumerate(old_records.body) if isinstance(n, ast.Assign) and isinstance(n.value, ast.Lambda)]
assert len(old_lambda) == 1
index, assignment = old_lambda[0]
assert len(assignment.targets) == 1 and isinstance(assignment.targets[0], ast.Name) and assignment.targets[0].id == 'iri'
local = new_records.body[index]
assert isinstance(local, ast.FunctionDef) and local.name == 'iri'
assert not local.decorator_list and local.returns is None and local.type_comment is None and not local.type_params
assert dump(local.args) == dump(assignment.value.args)
assert len(local.body) == 1 and isinstance(local.body[0], ast.Return)
assert dump(local.body[0].value) == dump(assignment.value.body)
local_parents = {child: parent for parent in ast.walk(new_records) for child in ast.iter_child_nodes(parent)}
local_uses = [n for n in ast.walk(new_records) if isinstance(n, ast.Name) and n.id == 'iri']
assert local_uses and all(isinstance(local_parents[n], ast.Call) and local_parents[n].func is n for n in local_uses)
new_records.body[index] = copy.deepcopy(assignment)

old_qv = top(old, 'add_original_qv')
new_qv = top(normalized, 'add_original_qv')
cases_uses = [n for n in ast.walk(old_qv) if isinstance(n, ast.Name) and n.id == 'cases']
assert len(cases_uses) == 1 and isinstance(cases_uses[0].ctx, ast.Store)
assignments = [(i, n) for i, n in enumerate(old_qv.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'cases' for t in n.targets)]
assert len(assignments) == 1
index, assignment = assignments[0]
expr = new_qv.body[index]
assert isinstance(expr, ast.Expr) and dump(expr.value) == dump(assignment.value)
assert dump(assignment.value) == "Call(func=Name(id='json_source', ctx=Load()), args=[Name(id='path', ctx=Load())], keywords=[])"
new_qv.body[index] = copy.deepcopy(assignment)

old_path = [(i, n) for i, n in enumerate(old.body) if isinstance(n, ast.ImportFrom) and n.module == 'pathlib']
new_path = [(i, n) for i, n in enumerate(normalized.body) if isinstance(n, ast.ImportFrom) and n.module == 'pathlib']
assert len(old_path) == len(new_path) == 1
assert dump(old_path[0][1]) == dump(new_path[0][1])
normalized.body.insert(old_path[0][0], normalized.body.pop(new_path[0][0]))
assert dump(old) == dump(normalized)
comments = lambda raw: [t.string for t in tokenize.tokenize(io.BytesIO(raw).readline) if t.type == tokenize.COMMENT]
assert comments(old_raw) == comments(new_raw) and len(comments(new_raw)) == 15

patch_raw = (EVIDENCE / 'proposal.patch').read_bytes()
patch_lines = patch_raw.decode().splitlines(keepends=True)
assert patch_lines[:2] == ['--- a/' + PRODUCT + '\n', '+++ b/' + PRODUCT + '\n']
old_lines = old_raw.decode().splitlines(keepends=True)
cursor = 0
rebuilt = []
line_index = 2
hunks = 0
while line_index < len(patch_lines):
    match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n', patch_lines[line_index])
    assert match, patch_lines[line_index]
    old_start, old_count, new_start, new_count = [int(v) if v is not None else 1 for v in match.groups()]
    rebuilt.extend(old_lines[cursor:old_start-1])
    cursor = old_start-1
    assert len(rebuilt) == new_start-1
    consumed = produced = 0
    line_index += 1
    while line_index < len(patch_lines) and not patch_lines[line_index].startswith('@@ '):
        line = patch_lines[line_index]
        assert line[0] in ' +-'
        if line[0] in ' -':
            assert old_lines[cursor] == line[1:]
            cursor += 1
            consumed += 1
        if line[0] in ' +':
            rebuilt.append(line[1:])
            produced += 1
        line_index += 1
    assert (consumed, produced) == (old_count, new_count)
    hunks += 1
rebuilt.extend(old_lines[cursor:])
assert ''.join(rebuilt).encode() == new_raw

receipts = {}
for prefix in ['baseline-ruff-01', 'proposal-ruff-01', 'proposal-ruff-02', 'proposal-format-check-01']:
    raw = (EVIDENCE / (prefix + '.json')).read_bytes()
    receipt = json.loads(raw)
    streams = {}
    for name, described in receipt['streams'].items():
        actual = (EVIDENCE / described['path']).read_bytes()
        assert identity(actual) == {'bytes': described['bytes'], 'sha256': described['sha256']}
        streams[name] = actual.decode()
    receipts[prefix] = {'receipt': identity(raw), 'argv': receipt['argv'], 'startedUtc': receipt['startedUtc'], 'endedUtc': receipt['endedUtc'], 'exitCode': receipt['exitCode'], 'streams': streams}
assert receipts['proposal-ruff-02']['exitCode'] == 0
assert receipts['proposal-ruff-02']['streams'] == {'stdout': '[]', 'stderr': ''}
assert receipts['proposal-format-check-01']['exitCode'] == 0
assert receipts['proposal-format-check-01']['streams'] == {'stdout': '1 file already formatted\n', 'stderr': ''}
baseline_findings = json.loads(receipts['baseline-ruff-01']['streams']['stdout'])
finding_counts = {code: sum(row['code'] == code for row in baseline_findings) for code in sorted({row['code'] for row in baseline_findings})}
assert finding_counts == {'E501': 174, 'E731': 1, 'E743': 1, 'F841': 1, 'I001': 1}
proposal_first = json.loads(receipts['proposal-ruff-01']['streams']['stdout'])
result = {
    'format': 'independent-I05-generator-proposal-static-review/1',
    'base': BASE, 'productPath': PRODUCT,
    'old': identity(old_raw), 'proposal': identity(new_raw), 'patch': identity(patch_raw),
    'proposalLinesFullyRendered': 2043, 'baselineLinesFullyRendered': 786,
    'wholeAstEqualsOldAfterFourConstrainedReversals': True,
    'reversals': ['26 direct-call Name uses and one helper definition iri_term -> I', 'add_records local single-Return def -> same-args same-expression lambda; no escaping callable uses', 'add_original_qv Expr -> unused cases assignment with exact same RHS retained', 'same pathlib import moved to baseline index'],
    'unchangedComments': 15, 'patchFullyParsedAndRebuiltProposal': True, 'patchHunks': hunks,
    'allOtherAstFieldsExact': True, 'productStillBaseline': True,
    'baselineRuffCounts': finding_counts,
    'proposalFirstRuffCount': len(proposal_first),
    'actualReceiptChecks': receipts,
    'reviewerExecutedGeneratorOrRuffOrProduct': False,
    'runtimeGoldenStatus': 'pending actual old/new generation evidence; no static claim of runtime success',
    'verdict': 'no-static-blocker; limited pass for proposal only'
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
