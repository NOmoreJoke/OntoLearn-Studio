import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-input-generator-style')
EVIDENCE = ROOT / 'docs/reviews/I05/input-generator-style'
BASE = '513db0056f312342a6791e2d4c7842f3726581f2'
PRODUCT = 'scripts/generate-i05-source-package-inputs.py'
OLD = ROOT.parent / 'I05-input-generator-golden-old'
NEW = ROOT.parent / 'I05-input-generator-golden-new'

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

archive_map_raw = (EVIDENCE / 'lossless-archive-map.json').read_bytes()
archive_map = json.loads(archive_map_raw)
archive_lookup = {}
for entry in archive_map['entries']:
    compressed = (EVIDENCE / entry['archivePath']).read_bytes()
    assert identity(compressed) == {'bytes': entry['archiveBytes'], 'sha256': entry['archiveSha256']}
    assert compressed[4:8] == b'\0\0\0\0'
    uncompressed = gzip.decompress(compressed)
    assert identity(uncompressed) == {'bytes': entry['uncompressedBytes'], 'sha256': entry['uncompressedSha256']}
    assert uncompressed == Path(entry['originalPreservedAt']).read_bytes()
    archive_lookup[entry['logicalPath']] = uncompressed

def evidence_raw(name):
    return archive_lookup[name] if name in archive_lookup else (EVIDENCE / name).read_bytes()

def git(root, *args):
    p = subprocess.run(['git', *args], cwd=root, capture_output=True)
    assert p.returncode == 0 and p.stderr == b'', (args, p.returncode, p.stderr)
    return p.stdout

old_script = git(ROOT, 'show', BASE + ':' + PRODUCT)
proposal = evidence_raw('proposal.py.raw')
assert (ROOT / PRODUCT).read_bytes() == proposal == (NEW / PRODUCT).read_bytes()
assert (OLD / PRODUCT).read_bytes() == old_script
assert identity(proposal) == {'bytes': 75633, 'sha256': 'c51a1a7f3085e79958022deda95d8a08792f3a95f7c4f1fb171d56196f3d2d26'}
assert identity(old_script) == {'bytes': 60354, 'sha256': 'e58dd4efd1c64952b6555b98c65271fc7e82d7b99b198d848d69f5a7c9dcde0b'}
statuses = []
for root in (OLD, NEW):
    assert git(root, 'rev-parse', 'HEAD').decode().strip() == BASE
    symbolic = subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=root, capture_output=True)
    assert symbolic.returncode == 1 and symbolic.stdout == symbolic.stderr == b''
    rules = (root / 'AGENTS.md').read_bytes()
    assert identity(rules) == {'bytes': 15147, 'sha256': 'de15f6ce13795bb26fbf9807130f475fcac1e16be142bee62d70058056a5c8c4'}
    statuses.append({'root': str(root), 'head': BASE, 'detached': True, 'trackedStatus': git(root, 'status', '--porcelain', '--untracked-files=no').decode()})

receipts = {}
streams = {}
for prefix in ('golden-old-01', 'golden-new-01', 'applied-ruff-01', 'applied-format-check-01'):
    raw = (EVIDENCE / (prefix + '.json')).read_bytes()
    r = json.loads(raw)
    assert r['exitCode'] == 0
    assert datetime.datetime.fromisoformat(r['startedUtc']) < datetime.datetime.fromisoformat(r['endedUtc'])
    checked = {}
    for name, desc in r['streams'].items():
        stream = evidence_raw(desc['path'])
        assert identity(stream) == {'bytes': desc['bytes'], 'sha256': desc['sha256']}
        checked[name] = identity(stream)
        streams[prefix, name] = stream
    receipts[prefix] = {'receipt': identity(raw), 'argv': r['argv'], 'cwd': r['cwd'], 'startedUtc': r['startedUtc'], 'endedUtc': r['endedUtc'], 'exitCode': r['exitCode'], 'streams': checked}
    if prefix.startswith('golden'):
        expected_root = OLD if prefix == 'golden-old-01' else NEW
        assert r['cwd'] == str(expected_root)
        assert r['argv'] == ['/Users/kyle/.local/share/uv/python/cpython-3.12-macos-aarch64-none/bin/python3.12', PRODUCT]
        assert r['environmentOverrides']['PYTHONDONTWRITEBYTECODE'] == '1'
        assert json.loads(streams[prefix, 'stdout'])['mode'] == 'generate'
    assert streams[prefix, 'stderr'] == b''
assert streams['golden-old-01', 'stdout'] == streams['golden-new-01', 'stdout']
assert identity(streams['golden-new-01', 'stdout']) == {'bytes': 970, 'sha256': '4c7c73c8ec5c42979cf6998a47d84b82d85acade27bd2487d862045e6c18a456'}
assert streams['applied-ruff-01', 'stdout'] == b'[]'
assert streams['applied-format-check-01', 'stdout'] == b'1 file already formatted\n'

assets = []
for name, expected in (
    ('manifest', {'bytes': 21202, 'sha256': '0b91c1a9366d170b5614d94c20006054a5a959be235e0f46cb150cf32335193a'}),
    ('inputs', {'bytes': 8205267, 'sha256': '47c66ffe18613eb8cc1af6365dcfc9d866821f22c48f96d9f44725f8f7c59eaa'}),
):
    path = 'packages/engine/src/ontolearn_engine/probe_inputs/i05-source-package-parity-' + name + '.json'
    original = git(ROOT, 'show', BASE + ':' + path)
    assert identity(original) == expected
    assert original == (ROOT / path).read_bytes() == (OLD / path).read_bytes() == (NEW / path).read_bytes()
    assets.append({'path': path, **expected, 'fixed513AuthorOldNewExactBytesEqual': True})
    if name == 'manifest':
        manifest = json.loads(original)
    else:
        inputs = json.loads(original)
assert manifest['versions']['supplierRef'] == '6891a5842302859a531cf82767c5a482417bc274'
assert manifest['counts']['observations'] == 417 and manifest['counts']['datasets'] == 320
assert len(inputs['observations']) == 417 and len(inputs['datasets']) == 320
assert json.loads(streams['golden-new-01', 'stdout'])['counts'] == manifest['counts']

audit_path = 'docs/reviews/I05/source-package-probe-source/inputs-source-manifest.json'
report_path = 'docs/reviews/I05/source-package-probe-source/input-generation-report.md'
old_audit_raw = (OLD / audit_path).read_bytes()
new_audit_raw = (NEW / audit_path).read_bytes()
old_audit = json.loads(old_audit_raw)
new_audit = json.loads(new_audit_raw)
assert old_audit['generator'] == {'path': PRODUCT, **identity(old_script)}
assert new_audit['generator'] == {'path': PRODUCT, **identity(proposal)}
old_gen = old_audit.pop('generator')
new_gen = new_audit.pop('generator')
assert old_audit == new_audit
assert old_audit_raw == git(ROOT, 'show', BASE + ':' + audit_path) == (ROOT / audit_path).read_bytes()
old_report = (OLD / report_path).read_bytes()
new_report = (NEW / report_path).read_bytes()
assert old_report == new_report == git(ROOT, 'show', BASE + ':' + report_path) == (ROOT / report_path).read_bytes()

print(json.dumps({
    'format': 'independent-I05-generator-applied-evidence-review/1',
    'productEqualsApprovedProposal': True, 'approvedProposal': identity(proposal),
    'controlledTrees': statuses, 'receipts': receipts, 'assets': assets,
    'supplierRef': manifest['versions']['supplierRef'], 'observations': 417, 'datasets': 320,
    'stdoutOldNewExactBytesEqual': True,
    'oldAudit': identity(old_audit_raw), 'newAudit': identity(new_audit_raw),
    'oldAuditGenerator': old_gen, 'newAuditGenerator': new_gen,
    'auditAllOtherFieldsEqual': True,
    'reportOldNewFixedAuthorExactBytesEqual': True, 'report': identity(old_report),
    'losslessArchiveMap': identity(archive_map_raw),
    'allArchiveEntriesVerified': len(archive_lookup),
    'allArchivesEqualPreservedOriginalBytesAndDeclaredHashes': True,
    'reviewerExecutedGeneratorRuffFormatterOrProduct': False,
    'checkModeExecuted': False,
    'verdict': 'pass for applied generator style and actual two-runtime-JSON golden reproduction; no product or business execution claim'
}, ensure_ascii=False, sort_keys=True, indent=2))
