import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-input-generator-style/docs/reviews/I05/input-generator-style')

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

raw = (ROOT / 'lossless-archive-map.json').read_bytes()
mapping = json.loads(raw)
assert len(mapping['entries']) == 35
records = []
for entry in mapping['entries']:
    archive = (ROOT / entry['archivePath']).read_bytes()
    assert identity(archive) == {'bytes': entry['archiveBytes'], 'sha256': entry['archiveSha256']}
    assert archive[4:8] == b'\0\0\0\0'
    restored = gzip.decompress(archive)
    assert identity(restored) == {'bytes': entry['uncompressedBytes'], 'sha256': entry['uncompressedSha256']}
    assert restored == Path(entry['originalPreservedAt']).read_bytes()
    records.append({'logicalPath': entry['logicalPath'], 'archivePath': entry['archivePath'], 'restored': identity(restored), 'exactBytesEqualPreservedOriginal': True})
expected_additions = {'author-tools/apply-and-golden-new.py', 'author-tools/applied-verify.py', 'author-tools/archive-evidence.py'}
assert {r['logicalPath'] for r in records[32:]} == expected_additions
print(json.dumps({'format': 'I05-independent-final-archive-addendum/1', 'map': identity(raw), 'entriesVerified': 35, 'threeAddedRunnerSourcesFullyReadButNotExecuted': sorted(expected_additions), 'allArchivesExactBytesEqualPreservedOriginal': True, 'entries': records}, ensure_ascii=False, sort_keys=True, indent=2))
