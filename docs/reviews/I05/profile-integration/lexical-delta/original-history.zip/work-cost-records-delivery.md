# P1 native identity / issuer costs / records 私有适配交接

仅在独立树 I05-profile-lexical 的 semantic_turtle.py 修改，未提交，未改集成树。新文件 32796B，SHA256 `c05ddd263dc33bf3ee3f27dd2e1048c6094f7dd13ed911d76e3862cc7252d5f0`。原950767版本及其报告/静态清单原字节保留于 `build/profile-lexical/pre-work-cost-records/`。以下是代码与 stdlib 静态证据，未运行产品/pytest，不能替代 root 的真实专项或 oracle。

## 已完成接口与冻结

`ProfileTermContext.work_costs() -> tuple[int,int,int]`：只返回私有 issuer 登记的 `(preparation_work, validation_work, maximum_lookup_work)`。方法只调用 O(1) `_require_context`，没有遍历 value/source，没有接受 caller 自报预算。三个字段均由真实 len/count 和固定整数系数计算；context 公共字段没有可注入 cost/tag。完整验证仍由 validate_graph 执行，不能以拿到 costs 代替验证。

`_validate_value` 对 TermInput 四个原生 str/None 字段、SourceRecord 四个原生字段逐项 `is`。source 对象本身也须是原对象。新建等内容字符串替换不再被完整字符串 equality 放行，source 长 text 不再在每次验证/lookup 中做等内容比较。对同一原生对象的重复赋值没有可观察内容/身份变化，不声称监视 Python 赋值语句。真正 RDF node 身份仍核对 canonical tuple，允许 plain/xsd:string 与语言大小写的同 term，raw/source 原字段本身仍冻结。

新增 `profile_graph_from_records(records, *, disabled_rule_ids=()) -> (Graph, ProfileTermContext)`：外层必须 exact tuple，每 record 是 exact 三元 tuple，每项是唯一 canonical class 的 exact TermInput。字面量 caller 依旧通过唯一 `decode_profile_term(N3)`，IRI 可明确以实际 IRI 输入构造；TermInput 是输入数据，不是自报认证 token。本函数核 native scalar/source 形状、UTF8 term/来源上限，按原 lexical/datatype/language 构造 `normalize=False` 的真实 RDF node，逐项 `_ProfileSink.capture(node, originalTermInput)`，再做真实 RDF 位置/有限词表/IRI 门和 Graph.add、issuer 发行。

所以重复事实可被 RDF Graph 正常去重，但全部原输入 occurrence/各自 SourceRecord 仍保留。source/span 缺失保持 None，不构造合成 Turtle、不把合成文本塞入每个 term、不删已知 source 规避上限。不调用 parse_value，不产生 producer/expected/第二 matcher；profile 值仍由 core 的唯一 entryBudget 验证。

来源 byte 早门在 issuer 对每个唯一 SourceRecord 各检查一次：每 native field 实际 UTF8≤65536；同一对象后续 occurrence 只核四字段 identity。该唯一 UTF8 扫描的真实上界额外计入 preparation_work，未伪称零成本。它不替代 T05 对每 occurrence 的实际 parse/encode/输入池收费，也不改变该原收费。SourceRecord 的 reference/digest/revision/text 是 caller 给定上下文，不保证来源真实性。

## 精确成本合同

令 T 为实际 graph triples，N 为捕获 occurrences（terms 值列表总长度同为 N，重复原对象仍逐 occurrence 计）；

- 每项 `w_i = 256 + 8 * sum(len(field) for field in (kind, lexical_form, datatype_iri, language_raw) if field is not None)`。
- 每个实际不同 SourceRecord 的一次 UTF8 早门 `q_s = 64 + 4 * sum(len(field) for field in (reference,digest,revision,text) if field is not None)`。
- 正常新发行 `P = 128 + 8*T + 64*N + 2*sum(w_i) + sum(q_s)`。
- 完整验证 `V = 64 + 8*T + 8*N + 2*sum(w_i)`。
- 最大已发行记录 lookup `L = max(32, all w_i)`；空图 L=32。没有把 16384 最大合法 IRI 常量罚到每个 known-term lookup。

固定项覆盖额外字段/native/source identity 检查、快照/索引/occurrence metadata、实际 RDF term identity 与 language lower 的处理；term 长度项涵盖这些身份核验所需的字段字符操作。source 长内容只在一次 issuer byte 早门 q_s 中计，完整验证/lookup 只对其原生对象 identity 做固定次数检查。

binder 实际执行旧 validate_graph 和重新发行，新 context 的 P 按 `P_new_own + P_old + V_old` 登记，V/L 来自新的真实记录；重复 binder 累计真实准备链，不抹掉旧准备费用。没有第二 Budget 或用户可填的预算字段。

root/core 仍须在其同一个 graph1M池一次预扣 P+V；每次 term_input 前再扣 L，并额外按真实调用 term 扣 `32 + 8 * _term_characters(term)`（root 已固定的 caller 合同），覆盖实际 node/key/hash/未命中 IRI 语法扫描。未命中仅真实 URIRef→source=None，无虚构 occurrence。Turtle parsing/结构化 record 构造、图匹配、T05 parse/encode 原有收费，以及直接 Graph fallback 稳定排序的既有预扣，不由这份“额外 issuer/一致性”成本冒名覆盖。该 tuple 是保守确定性计费表，不是 CPU 时间/性能保证。

## 实际核验和待验

`python3 build/profile-lexical/static-check.py` 实际 exit0。只使用 stdlib AST/compile，不执行编译后的产品代码；四个 legacy 定义 AST 等于固定 C4；本树其它存在的12项授权输入SHA不变；行长≤100；没有 Budget/parse_value 调用或 package 根懒导入。

本树未使用 root 已安装环境，未 import 产品、未跑 pytest/完整check/GUI/打包。待 root 在其真实固定依赖下核：等内容新字符串与各 source 字段篡改、O(1) work_costs/精确tuple/binder累加、真实 G-base/多来源 records oracle、位置/词表/IRI与strict N3前门、全部支持 lexical/calendar、预算边界及 legacy。所有运行结论由实际执行 owner 记录，本报告不继承其784项通过为亲测。
