# P1 集成成本 / records-source 有界静态复核

结论：在下述实际源码与已批准七机制组合中，没有发现新的字段变异绕过或 records 来源丢弃路径；P+V、L+实际 term 字符费用已真实接线，profile→RDF 构造均经预扣包装。有限静态复核可通过，保留 issuer 准备后记账边界；原 entry call 粒度缺口已由本轮 root delta 关闭，不能外推整个流水线逐操作抢占、运行验收或性能结论。

本轮只读 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-profile-integration`，仅在审查者自有 lexical 树 ignored build 写报告。未改任何产品，未 import/执行产品、pytest、环境/锁/GUI/容器。没有采用 API/restore/selected 新提案。

## 实际绑定

集成树为 `feature/I05-profile-integration`，有授权 WIP，不当作已固定产品 commit。首读检查点为：

- `packages/engine/src/ontolearn_engine/semantic.py`，52421B，SHA256 `a0cb3d358b0d08d99ae29f6d432a64de9457b5f9f26c231a421f1f9d6337f719`。
- `packages/engine/src/ontolearn_engine/semantic_turtle.py`，32824B，SHA256 `c4a943df443e5379ab38d00d0fc588a8097c68dd9ca60a4f1b1bd0da381a1534`。首读时 stdlib AST 逐项与自树 c05ddd 交接源相同；其后 root 在本轮审查中追加真实 raw shape 前门和 entry 严格相位修复，见后文新绑定，不能把首读检查点冒充最终字节。
- 实际全文读 `T05-profile-iri-fix-root-closure-and-I05-consumption.md.raw`、`T05-profile-iri-approved-seven-inputs.json.raw`，并逐项读取七源码 bytes/hash，与批准组合全部相同。六个模块仍旧固定1e3；唯一新 terms 来自 `dbb6b36e9259aa79a1fd908b5cfede3064f0c074`，6176B，SHA256 `218c4790e9b35236e393407b5b4e0207890d46fe3ea48a9a69e26aa08ddba1d1`。不采用未授权330f/API。

我最初按旧本树1e3机制指出 NBSP minimum-IRI 拒绝，与实际集成组合不符；经 root 提醒后已实际核新 terms:87–102，仅 ord<0xA0 的 whitespace 被拒。该观察撤回，不列当前缺陷，也不要求重复 consumer-gap 门。root 随后新增的端到端 NBSP 测试可静态读到，但未由我运行。

## 成本真实接线

`semantic.py:656–748`：先核真实 Graph/Memory 与实际 term 输入长度；无 context 时为 fallback 的3N排序按最大真实字段宽预扣。随后 exact context 类型检查，调用 O(1) `work_costs`，先扣 P+V，再执行完整 `validate_graph`。没有每个 term 调整默认机制池；唯一 entry Budget 在同函数中创建一次；最新相位绑定见下文。

`semantic.py:885–889`：唯一实际取值包装 `actual_term` 在调用 context.term_input 前扣 `lookup_work + 32 + 8*_term_characters(term)`。所有 BindingMatch 的 actual_when 和实际 binding 都经这个包装；没有遗留未计费的 context.term_input 调用。L 只由实际发行值求最大，不以规范16k常量罚所有短项。

`semantic_turtle.py:323–325` 的 work_costs 只 `_require_context` 和 registry 固定 tuple 索引；该检查为常数次引用比较，没有遍历 terms/source/occurrences。costs 不来自可填 context 字段或 caller 自报数值。

词法 issuer 的实际计数与交接公式一致：每 occurrence 对应一个 map value 列表项，重复 TermInput 对象仍按 occurrence 计。w、q、P、V、L 的整数系数由源码确定；binder 在真实完整验证后重新发行，并把旧 P+旧 V 加入新 P，没有清掉准备链。SourceRecord byte 早门每个实际唯一 source 对象一次，不是每次 lookup 重扫其长 text；其 q_s 仅进入 P，完整验证/lookup 仍四字段逐 is 固定成本。

`semantic.py:769–781` 将实际 profile TermInput/Variable 构造前字符费用放在 `_profile_as_term`，唯一底层 `_profile_term` 调用在该包装内。实际 when patterns、成功head、evidence when 重建和 advisory chain warnings 都经此包装；没有找到绕过它的 profile→RDF 构造。字符串源 metadata 不参与 RDF node 构造，仍由 T05 自己验证/编码计费。

保守过收边界：L 是整个发行 context 中最大真实记录的成本，所以一个很长但未匹配的真实 term 也可抬高全部短 term lookup 费用；这比逐项真实费用更保守，但符合本次明确最大值合同，未发现16k无条件罚所有项的实现。不得据此宣称所有合法规模/性能通过。

## records/N3/source 与 mutation

`semantic_turtle.py:760–813`：records 外层/每三元组为 exact tuple；每项经 canonical exact TermInput/SourceRecord 与原生字段检查，IRI 强门、literal normalize=False 构造后捕获原 TermInput，再核真实 RDF 位置/有限词表，加入同一真实 Graph。literal 调用方合同仍是唯一严格 `decode_profile_term`；该入口不是 source/producer 认证，不声称能识别任意 Python 调用者伪造的真实世界来源。

每项原 TermInput 都进入 capture，所以 graph 对重复事实去重不删除 source occurrences。plain/xsd:string 的实际 node 可归同 term，raw lexical/datatype/lang/source 仍在其 original value；没有合成 Turtle、猜 span 或删 source 来过限。严格 N3 decoder 的固定单三元组和 n3 字节相等前提保持；此轮只静态复核，未独立跑注入矩阵。

`semantic.py:726–745` 对实际相关 graph term 的全部 occurrence 调 T05 parse_value；parser-only prefix 不是 graph fact，明确过滤。`semantic.py:1072–1083` 又逐条输出完整 termSources（原 value、ordinal、span）。实际 BindingMatch 的 `context.term_input` 只选首个原值/来源，全部来源保存在 termSources；这不等于每条 provenance 都成为所有匹配的 proof 路径，不应把完整 source occurrence 保全说成穷尽证明。

完整 validate_graph 扫 map 和全部 occurrence；value 当前四个原生字段及 source 四字段分别对发行快照逐 is，不能以等内容新字符串替换通过。SourceRecord 引用也锁定，metadata ordinal/span/term/value 指向均核原记录。按需 term_input 只核匹配 value 的 id 索引与实际 node 身份；原1→2路径会在完整校验或按需校验拒绝。未命中 literal 不被构造为新可信值；只有实际闭包 URIRef 可 source=None 构造。没有发现无需修改私有 registry 即可绕过这些检查的新静态路径。

这不是 Python 进程内恶意代码隔离沙箱；任意改模块私有 registry、并发改变对象/全局代码的能力不由该 dataclass 一致性合同隔离。本轮没有证明任意并发TOCTOU安全，也不将其视作已支持消费模型。

## 本轮 root delta 与仍保留边界

初稿审查期间 source readback 的 lexical AST 等价断言真实 exit1，原因是 root 在活动WIP中追加 `_profile_record_node`，不是七机制漂移或产品执行失败。初稿原bytes与首读失败说明分别保留，未把失败抹为首轮通过。

root 新 `_profile_graph` 在所有 Graph结构、IRI、全部相关 entry_values 准备/追加费用完成后，才一次创建 `Budget(ProfileLimits(work=MAX_WORK-meter.work, output_bytes=0))`。连续 parse_value 阶段没有其它 graph debit，只 finally 合并真实 delta。因此每call前 helper可用work与graph当前余额保持一致，T05本身逐操作先扣能阻止上一版“单call先超graph余额后拒绝”的静态路径。没有改T05，没有每term重开预算，没有恢复默认1M新池；input_bytes仍同一个entry实例累计。图后续复制/闭包费用继续从原graph meter扣，未占用/丢弃 entry 真实未用额度。

本轮静态关闭仅针对该相位一致性，不声称CPU抢占或整个入口可中断。P仍是 issuer 完成快照及唯一source UTF8早门后登记，reason再记账。发行准备受显式输入/分配边界约束，不能声称P先于整个issuer动作预扣；work_costs为O(1)不等于准备为O(1)。

新raw records形状前门明确将普通wrong type/None kind/lexical/datatype/lang/source映射为RDF_TERM_INVALID，与已发行ctx破坏的Internal边界分开。我另向root指出：若exact dataclass通过object.__delattr__丢slot，当前直接属性访问可能先抛AttributeError；这是raw畸形对象分类边界，不是已发行ctx绕过，正常canonical构造没有该状态。终读已实际看到 root 用 try/except AttributeError 将整个 raw shape 访问包住并固定 RDF_TERM_INVALID，该静态分类边界关闭；本轮仍未运行这个反例。

最终读回绑定（新相位/shape前门，替代上方首读检查点的通过归属）：

- semantic.py：52609B，SHA256 `5a3a53fc79928a7aa7de280a8477541db4053ec9b2bec489bf28a2ad4e935549`。
- semantic_turtle.py：33916B，SHA256 `4180feb9d0c775669b65338e1cfb37a8d5bb7f3ce155b4804dd53a43efad5214`。与自树c05比较，唯一AST变化定义为root新增raw shape前门的 `_profile_record_node`；成本/issuer/records主路径定义均未变。
- stdlib AST 附加检查实际 exit0：work_costs 无循环/comprehension；entry_values 连续parse循环唯一 graph debit 在 try.finally 的delta合并；七模块仍全部与新批准manifest相同。不是运行验证。

## 实际证据与限制

实际命令均为 git/status、sed/rg 只读、stdlib Path/hashlib/json/AST 解析与源码AST等价比较；没有产品 import/测试运行。静态读到 root 的 mutation（lexical/source 两项）和 NBSP 图测试定义，不当作运行证据。只读过08/09/10执行记录，均真实exit1且未timeout；未把这些过程记录归为当前全部正确/错误的独立验收，也未重新解释旧输出为新产品通过。

root 另告知最新 fullinput 78完整上下文 success、4个E5不完整fragment资源拒绝、1缺失输入 not-executed；本轮不重审其完整 oracle，也不将该口头/消息结果写成我的亲跑。完整运行记录/source绑定、oracle期望独立性和未覆盖项由其实际执行owner另封存。

本报告仅确认当前有界成本/records/source/mutation接线；不是父P1、正式I05、selected、source真实性、source/包、目标平台或完整资源验收的批准。
