import ast
import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
relative = 'packages/engine/src/ontolearn_engine/semantic_turtle.py'
path = root / relative
raw = path.read_bytes()
text = raw.decode()
tree = ast.parse(text, filename=relative)
compile(text, relative, 'exec')  # compile only: never eval, exec, import or load code
old = subprocess.check_output(['git', 'show', '523c478d5f39671c4ac7c1ea6997e51d3047d58e:' + relative])
old_tree = ast.parse(old)
legacy = {}
for node in old_tree.body:
    if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
        current = next(item for item in tree.body if isinstance(item, type(node)) and item.name == node.name)
        legacy[node.name] = ast.dump(node, include_attributes=False) == ast.dump(current, include_attributes=False)
assert all(legacy.values())
long_lines = [(i, len(line)) for i, line in enumerate(text.splitlines(), 1) if len(line) > 100]
assert not long_lines, long_lines
calls = [node.func.id for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
assert 'parse_value' not in calls
assert 'Budget' not in calls
lazy_quality = []
for node in ast.walk(tree):
    if isinstance(node, ast.ImportFrom) and node.module and '.quality' in node.module:
        assert node.module == 'ontolearn_engine.quality.rule_profile'
        lazy_quality.append({'line': node.lineno, 'module': node.module, 'names': [item.name for item in node.names]})
assert not any(isinstance(node, ast.ImportFrom) and node.module and '.quality' in node.module for node in tree.body)
control = Path('/Users/kyle/Documents/工作/知爻/本体/iteration-control/2026-10-21-weekly-release')
fixed = json.loads((control / 'I05-profile-P1-fixed-inputs.json').read_text())
unchanged = []
for item in fixed['inputs']:
    candidate = root / item['path']
    if candidate.is_file() and item['path'] != relative:
        actual = hashlib.sha256(candidate.read_bytes()).hexdigest()
        assert actual == item['sha256'], (item['path'], actual)
        unchanged.append({'path': item['path'], 'sha256': actual})
authority = control / 'I05-profile-P1-implementation-authorization.md'
report = {
    'kind': 'stdlib static parse/compile and immutable-source readback only; no product execution',
    'root': str(root),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'file': relative,
    'bytes': len(raw),
    'sha256': hashlib.sha256(raw).hexdigest(),
    'lines': len(text.splitlines()),
    'legacyDefinitionsAstEqual': legacy,
    'lineLength100': True,
    'mechanismBudgetOrParseValueCall': False,
    'qualityImportsLocalOnly': lazy_quality,
    'unchangedPresentAuthorizedInputs': unchanged,
    'AGENTS': {'sha256': hashlib.sha256((root/'AGENTS.md').read_bytes()).hexdigest()},
    'authorization': {'path': str(authority), 'bytes': authority.stat().st_size, 'sha256': hashlib.sha256(authority.read_bytes()).hexdigest()},
    'status': subprocess.check_output(['git', 'status', '--short'], text=True),
}
output = root/'build/profile-lexical/static-check.json'
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
