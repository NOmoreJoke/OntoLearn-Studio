# P1 profile 词法文件交接（仅静态证据）

已完成唯一授权文件 `packages/engine/src/ontolearn_engine/semantic_turtle.py`，未提交。实际树为 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-profile-lexical`，分支 `feature/I05-profile-lexical`，HEAD `5f910b52c69d86a1076b2032e5d3c63e715947f3`。目标文件 22857B，SHA256 `07ca1d36ec995d8ae6b9362403618a86b5131ad1a1b4a7d0ea3a171d5cc60bf9`。此交付不是运行通过或 P1 验收。

## 实际接口

- `validate_profile_iri(text) -> str`：有界、scheme 必需且允许 fragment 的 RFC3987 IRI 语法门；返回原字符串，不做规范化、IDNA、DNS、网络或 scheme-specific 合法性声明。
- `parse_profile_graph(text, *, base_uri, source=None) -> (Graph, ProfileTermContext)`：只走 Turtle 内存解析，显式有效 base 解析相对引用；保留 RDF 位置/有限词表/外联拒绝。捕获裸 numeric 原 token、typed literal 的 decoded lexical/datatype、原 language 字段、IRI 与 Turtle `a` 的解析事件；先保留 `TermInput` 再应用局部 string canonicalization。未用 `.ill_typed` / `.toPython` 裁掉 profile 值域。
- `profile_context_for_graph(graph, *, disabled_rule_ids=())`：仅实际 Graph+Memory；无法恢复 pre-Graph raw/source，明确 unavailable。先有界捕获，再按 `(kind, lexical_form, datatype_iri or '', language_raw or '')` 排序，使无 source 的 ordinal 与 alias 首选稳定；不是原文顺序或位置。
- `bind_profile_disabled_rules(context, disabled_rule_ids)`：核实受控 context 后签发新 context，不修改原 context。ID 有界、唯一、排序；是否为真实已知规则由 core 核。
- `decode_profile_term(text) -> TermInput`：独立单 canonical N3 URI/literal 解码；唯一固定三元组、固定 subject/predicate 和 `term.n3()==text` 共同拒注入/尾随/额外语法，保原 literal 字段，不猜 source/span。该前门尚未实际运行验证。

`ProfileTermContext` 是 frozen 本地一致性载体，不是 producer/source 授权：`graph`、只读 `terms`（canonical RDF term→全部原 `TermInput` 的 tuple）、`occurrences`、`disabled_rule_ids`、`_triples`。`ProfileTermOccurrence` 字段为 `term/value/ordinal/span`，`span` 始终 None。`validate_graph` 核实际已签发类型、原 Graph 对象和快照；`term_input` 仅返回首个值，core 必须另核全部相关 occurrences，不能以首值替代完整 raw/source。

## 计费与集成责任

本文件不创建机制 `Budget`，不调用 `parse_value`，不签发 `ProfileValue`；语法可解析不等于 profile 值校验通过。固定机制的真实 `parse_value` 及图入口共享 Budget 由计算层唯一负责，不重复建立每 term 预算。

独立分配早门：text≤1MiB、triple≤100000、occurrence≤300000、每 lexical/datatype/lang UTF8≤16384、全部捕获 scalar UTF8 合计≤262144；提供的 source text/reference/revision≤65536，digest/text 若提供须与实际文本一致。SourceRecord 的 reference/revision 仅 caller context。数值原 token 在宿主 int/Decimal 转换前截获；typed literal 构造仍由 RDFLib 执行，但保留 normalize=False 的实际字段，忽略其 host value 判断。

core 仍须在 fallback 前从其同一 graph work pool 预扣上述至多 3N occurrences 的稳定排序和字段比较成本。本文件的分配早门不冒充执行预算；此跨文件责任已单独通知 root/core owner，未声称已联验。

RFC3987 允许部分 Unicode 空白（例如 U+00A0）作为 `ucschar`；固定机制的 `iri_minimum` 额外拒 `isspace`。已报告并经 root/core 明确：本文件保持真实 IRI 语法，core 独占合法但未支持的 `UNSUPPORTED_PROFILE_IRI` consumer gap 门；语法非法仍 `ABSOLUTE_IRI_REQUIRED`。没有收窄规范、修改七机制或改变 eq policy。

采用依据：[RDF 1.1 Concepts §3.2](https://www.w3.org/TR/2014/REC-rdf11-concepts-20140225/#section-IRIs)、[RFC3987 §2.2](https://www.rfc-editor.org/rfc/rfc3987#section-2.2)。前者允许 fragment，因此没有误套 fragment-free `absolute-IRI` 产生式。IPv6 只用 stdlib 文法解析且拒 zone；IPvFuture、authority、Unicode ranges、percent escapes 与 query private ranges 均在本地有界扫描，不解引用。

## 实际核验

命令：`python3 build/profile-lexical/static-check.py`。只执行 stdlib 脚本，对目标做 `ast.parse` 和 `compile(..., 'exec')` 编译；没有 exec/eval、产品 import 或模块执行。结果 exit0，保存 `static-check.json` 与 stdout。

- `canonical_string`、`LexicalSink`、`LexicalSinkParser`、`parse_graph` 四个旧定义与固定 C4 `523c478d5f39671c4ac7c1ea6997e51d3047d58e` 的 AST 完全相同。此为静态行为保留依据，不是旧套件运行通过。
- 所有行≤100字符；没有机制 Budget/parse_value 调用；三个 quality import 均为函数内部 canonical `quality.rule_profile`，未调用包根懒导出。
- 本树存在的其余 12 个授权输入（包括固定七机制、四个其他 C4 source、5f resources）逐 SHA 等于 root 32 项清单；缺失条目未凭空登记采用。
- AGENTS SHA `78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759`；授权8756B/SHA `ae99f6f95666737939d2b701f962c1854864db447ba0d8c7663757615f460c6d`。保护 guidance 未写/stage。
- 实际只读核对了固定 RDFLib7.6 notation3 源码的 parser/sink 回调、numeric 与 `a` 特殊路径；未把其缓存环境当运行环境。

## 未验与下一步

固定 T03 依赖未交，按授权不运行项目、不借 C4 venv。不声称 Ruff、pytest、完整 check、运行/打包/GUI/native 或性能通过；未运行任何这些命令。需 root 集成此唯一文件，与 core 的真实单图预算、IRI consumer gap、严格 N3 caller 联验，再由独立 reviewer 审实现。完整 numeric/date/year0/>9999、language/raw/source 多 occurrence、IRI 合法/非法矩阵、Graph deterministic context、伪造/修改 context、source mismatch、注入、预算边界和 legacy 回归仍待真实依赖环境测试。
