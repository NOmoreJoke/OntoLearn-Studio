import subprocess,time,json,os,sys
from pathlib import Path
root=Path.cwd(); out=root/'build/profile-evidence'; start=time.monotonic(); name=sys.argv[1]
cmd=['uv','run','--frozen','python','-m','ontolearn_engine.semantic_profile_probe']
env=dict(os.environ,UV_CACHE_DIR=str(root/'build/profile-uv-cache'))
try:
 p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 result={'command':cmd,'exitCode':p.returncode,'hardTimeoutSeconds':120,'timedOut':False}; stdout,stderr=p.stdout,p.stderr
except subprocess.TimeoutExpired as e:
 result={'command':cmd,'exitCode':None,'hardTimeoutSeconds':120,'timedOut':True}; stdout,stderr=e.stdout or b'',e.stderr or b''
(out/(name+'.json')).write_bytes(stdout); (out/(name+'.stderr')).write_bytes(stderr)
result['elapsedSeconds']=time.monotonic()-start
(out/(name+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result)); print(stderr.decode()[:1000])
if stdout:
 d=json.loads(stdout); from collections import Counter; print(Counter(c['status'] for c in d['cases'])); print([(c['caseId'],c.get('diagnostic'),c.get('reason')) for c in d['cases'] if c['status']!='success'])
