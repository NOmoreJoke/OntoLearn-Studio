"""One fixed-input P1 computation probe, shared by source and packaged entrypoints.

This is a finite preparation case, not the full independent acceptance oracle.
No Store, Job, public capability, expected output or given-binding evaluator.
"""

import hashlib
import importlib
import importlib.metadata
import json
import sys
import time
from pathlib import Path

INPUT_SHA256 = "17f0e06989a67d8603d55b7437594297b6572e8cb9b859952f61304f9e79387c"
INPUT_BYTES = 2492
INPUT_CAP = 1_048_576
DEADLINE_SECONDS = 120
MODULES = (
    "ontolearn_engine.quality",
    *(
        "ontolearn_engine.quality." + name
        for name in (
            "rule_profile",
            "rule_terms",
            "rule_numbers",
            "rule_calendar",
            "rule_comparator",
            "rule_firing",
        )
    ),
)


def _asset():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "provenance/i05/profile-probe-inputs.json"
    return Path(__file__).resolve().parents[4] / "docs/iterations/I05/profile-probe-inputs.json"


def _load_inputs():
    # One exact locator; no package -> checkout or user-directory fallback.
    with _asset().open("rb") as stream:
        raw = stream.read(INPUT_CAP + 1)
    if len(raw) != INPUT_BYTES or hashlib.sha256(raw).hexdigest() != INPUT_SHA256:
        raise ValueError("PROFILE_PROBE_INPUT_INVALID")
    value = json.loads(raw)
    if (
        set(value) != {"format", "source", "cases"}
        or value["format"] != "i05-profile-probe-inputs/1"
        or len(value["cases"]) != 1
        or value["source"]["expectedIncluded"] is not False
    ):
        raise ValueError("PROFILE_PROBE_INPUT_INVALID")
    return value


def _construct_case(case):
    """Project only fixture input fields into actual RDF text and RuleSpec.

    input_when is a concrete input graph, not a matcher result. Comparisons and
    heads come only from definition. No expected or input_binding is consulted.
    """
    from rdflib import RDF, RDFS, Literal, URIRef

    from ontolearn_engine.quality.rule_firing import Comparison, RuleSpec, Triple, Variable
    from ontolearn_engine.quality.rule_profile import XSD, SourceRecord, TermInput

    def source(value):
        return None if value is None else SourceRecord(**value)

    def term(value):
        if type(value) is str:
            return Variable(value) if value.startswith("?") else TermInput("iri", value)
        if "kind" in value:
            return TermInput(
                value["kind"],
                value["lexical_form"],
                value["datatype_iri"],
                value["language_raw"],
                source(value["source"]),
            )
        datatype = value["type"]
        return TermInput("literal", value["lexical"], XSD + datatype)

    def n3(value):
        item = term(value)
        if type(item) is not TermInput:
            raise ValueError("PROFILE_PROBE_INPUT_INVALID")
        if item.kind == "iri":
            return URIRef(item.lexical_form).n3()
        return Literal(
            item.lexical_form, datatype=item.datatype_iri, lang=item.language_raw, normalize=False
        ).n3()

    lines = []
    for key, declaration in (
        ("classes", str(RDFS.Class)),
        ("object_properties", "http://www.w3.org/2002/07/owl#ObjectProperty"),
        ("data_properties", "http://www.w3.org/2002/07/owl#DatatypeProperty"),
    ):
        for value in case["catalog"][key]:
            lines.append(f"<{value}> <{RDF.type}> <{declaration}> .")
    for triple in case["input_when"]:
        lines.append(" ".join(n3(triple[key]) for key in ("subject", "predicate", "object")) + " .")
    definition = case["definition"]
    spec = RuleSpec(
        definition["rule_id"],
        tuple(Triple(*(term(item) for item in row)) for row in definition["when"]),
        tuple(
            Comparison(term(left), op, term(right)) for left, op, right in definition["comparisons"]
        ),
        tuple(Triple(*(term(item) for item in row)) for row in definition["heads"]),
        source(definition["source"]),
        definition["revision"],
        definition["definition_digest"],
        definition["policy"],
    )
    return "\n".join(lines) + "\n", (spec,)


def _identities():
    from ontolearn_engine.resources import resource_manifest

    modules = []
    for name in MODULES:
        module = importlib.import_module(name)
        if module.__name__ != name or module.__spec__.name != name:
            raise ValueError("PROFILE_PROBE_MODULE_INVALID")
        path = Path(module.__file__)
        # A frozen archive's pyc is not the approved source's .py byte domain.
        source_hash = (
            hashlib.sha256(path.read_bytes()).hexdigest()
            if not getattr(sys, "frozen", False) and path.suffix == ".py"
            else None
        )
        modules.append({"module": name, "sourceSha256": source_hash})
    return {
        "frozen": bool(getattr(sys, "frozen", False)),
        "modules": modules,
        "distributions": {
            name: importlib.metadata.version(name)
            for name in (
                "rdflib",
                "pyshacl",
                "pyparsing",
                "owlrl",
                "html5rdf",
                "prettytable",
                "wcwidth",
                "packaging",
            )
        },
        "resources": resource_manifest(),
    }


def main(argv=None):
    """Source: no arguments. Packaged dispatcher calls main([]) after its flag."""
    args = sys.argv[1:] if argv is None else argv
    if type(args) is not list or args:
        sys.stderr.write("PROFILE_PROBE_ARGUMENTS_INVALID\n")
        return 2
    started = time.monotonic()
    try:
        from ontolearn_engine.resources import CONTRACT, ROOT
        from ontolearn_engine.semantic_execution import (
            ProfileExecutionFault,
            _profile_json_bytes,
            execute_profile,
        )

        inputs = _load_inputs()
        output = []
        failed = False
        for case in inputs["cases"]:
            text, rules = _construct_case(case)
            try:
                result = execute_profile(
                    text,
                    rules,
                    source_reference="asset:i05/profile-probe-inputs.json",
                    source_revision=INPUT_SHA256,
                    error_catalog=CONTRACT.ERROR_CATALOG,
                    error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
                )
                output.append({"caseId": case["caseId"], "status": "success", "result": result})
            except ProfileExecutionFault as error:
                failed = True
                output.append(
                    {
                        "caseId": case["caseId"],
                        "status": "failure",
                        "error": error.error,
                        "diagnostic": error.diagnostic,
                    }
                )
            if time.monotonic() - started > DEADLINE_SECONDS:
                raise ValueError("PROFILE_PROBE_TIME_LIMIT")
        report = {
            "format": "i05-profile-probe/1",
            "scope": "finite-preparation-case",
            "acceptanceOracleCompared": False,
            "collectionComplete": True,
            "inputSha256": INPUT_SHA256,
            "inputBytes": INPUT_BYTES,
            "cases": output,
            "identity": _identities(),
            "limits": {
                "inputBytes": INPUT_CAP,
                "cases": 1,
                "deadlineSeconds": DEADLINE_SECONDS,
                "deadlineEnforcement": "boundary-check; caller must enforce hard process timeout",
            },
        }
        encoded = _profile_json_bytes(report)
        if time.monotonic() - started > DEADLINE_SECONDS:
            raise ValueError("PROFILE_PROBE_TIME_LIMIT")
        sys.stdout.write(encoded.decode("utf-8") + "\n")
        return 1 if failed else 0
    except Exception:
        sys.stderr.write("PROFILE_PROBE_FAILED\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
