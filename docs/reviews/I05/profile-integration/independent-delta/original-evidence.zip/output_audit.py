from pathlib import Path
import json,hashlib,collections
H=Path(__file__).resolve().parent;R=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-profile-integration');P=R/'build/profile-evidence/13-full-input-probe.json'
raw=P.read_bytes();d=json.loads(raw);asset=json.loads((H/'source/docs/iterations/I05/profile-probe-inputs.json').read_bytes())
enc=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(d['cases'])==len(asset['mathInputs'])==83
assert d['collectionComplete']is True and d['acceptanceOracleCompared']is False
assert d['inputSha256']==sha((H/'source/docs/iterations/I05/profile-probe-inputs.json').read_bytes())
counts=collections.Counter();failed=[];rows=0;original=0;sources=0

def ptr(v,p):
 assert p.startswith('#/')
 for key in p[2:].split('/'):
  key=key.replace('~1','/').replace('~0','~');v=v[int(key)]if isinstance(v,list)else v[key]
 return v

def sourcecheck(v):
 global sources
 if isinstance(v,dict):
  if v.get('recordType')=='SourceRecord':
   assert v['digest']==d['inputSha256']
   origin=ptr(asset,v['reference'])
   if v['text']is not None:assert origin==v['text']
   sources+=1
  for item in v.values():sourcecheck(item)
 elif isinstance(v,list):
  for item in v:sourcecheck(item)

for c,a in zip(d['cases'],asset['mathInputs'],strict=True):
 assert c['caseId']==a['id'] and c['inputProjectionJsonSha256']==a['inputProjectionJsonSha256']
 assert c['sourceRefs']==a['sourceRefs'] and c['fullOriginalInputContext']==a['input']['fullOriginalInputContext']
 counts[c['status']]+=1
 if c['status']=='success':
  r=c['result'];p=r['payload'];assert sha(enc(p))==r['jsonPayloadDigest'];assert sha(enc(r['rows']))==r['rowsDigest'];assert json.loads(''.join(x[0]for x in r['rows']))==p
  rows+=len(r['rows']);sourcecheck(p)
  for b in p['reasoning']['mechanismBatches']:
   if b['originalMatches']is not None:original+=len(b['originalMatches'])
 else:failed.append({k:c[k]for k in c if k in ['caseId','status','reason','error','diagnostic']})
result={'path':str(P),'bytes':len(raw),'sha256':sha(raw),'caseStatusCounts':dict(counts),'nonSuccess':failed,'successCompletePayloadAndRowsHashesVerified':counts['success'],'sourceRecordPointerDigestAndOptionalTextVerified':sources,'originalMatchRecordsRetainedAcrossSuccesses':original,'rowsVerified':rows,'oracleCompared':False,'runtimeModuleBinding':'seven mechanism hashes observed in report; full current WIP source binding remains root sealing responsibility'}
(H/'output-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
