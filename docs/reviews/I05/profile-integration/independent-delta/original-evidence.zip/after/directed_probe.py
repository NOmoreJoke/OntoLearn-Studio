from pathlib import Path
import sys,json,importlib.metadata,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE/'source'
sys.path.insert(0,str(ROOT/'packages/engine/src'))
from ontolearn_engine.semantic_execution import execute_profile,execute_profile_records,ProfileExecutionFault
from ontolearn_engine.quality.rule_profile import TermInput,SourceRecord,PROFILE,XSD
from ontolearn_engine.quality.rule_firing import RuleSpec,Triple,Variable
from ontolearn_engine.semantic_turtle import parse_profile_graph
from ontolearn_engine.semantic import reason
from rdflib import Literal
errors={'error_catalog':json.loads((ROOT/'packages/contracts/v2/errors.json').read_bytes()),'error_schema':json.loads((ROOT/'packages/contracts/v2/schema.json').read_bytes())}
print(json.dumps({'python':sys.version,'executable':sys.executable,'packages':{x:importlib.metadata.version(x)for x in ['rdflib','pyshacl','pyparsing']},'lock':hashlib.sha256((ROOT/'uv.lock').read_bytes()).hexdigest()}))
def capture(name,run):
 try:
  result=run();out={'name':name,'status':'success','resultRules':result.get('rules') if isinstance(result,dict)else None}
 except ProfileExecutionFault as e:out={'name':name,'status':'failure','error':e.error,'diagnostic':e.diagnostic}
 except Exception as e:out={'name':name,'status':'exception','type':type(e).__name__,'code':getattr(e,'code',None),'classification':getattr(e,'classification',None)}
 print(json.dumps(out,ensure_ascii=True))
for name,text in [('catalogConflict','<urn:p> a <http://www.w3.org/2002/07/owl#ObjectProperty>, <http://www.w3.org/2002/07/owl#DatatypeProperty> .'),('langStringNoLanguage','<urn:s> <urn:p> "x"^^<http://www.w3.org/1999/02/22-rdf-syntax-ns#langString> .')]:
 capture(name,lambda text=text:execute_profile(text,**errors))
for field in ['source_reference','source_revision']:
 capture(field+'Surrogate',lambda field=field:execute_profile('',**{field:'\ud800'},**errors))
text='<urn:p> a <http://www.w3.org/2002/07/owl#DatatypeProperty> . <urn:q> a <http://www.w3.org/2002/07/owl#DatatypeProperty> . <urn:u> <urn:p> "1"^^<http://www.w3.org/2001/XMLSchema#integer> .'
spec=RuleSpec('r',(Triple(TermInput('iri','urn:u'),TermInput('iri','urn:p'),Variable('?v')),),(),(Triple(TermInput('iri','urn:u'),TermInput('iri','urn:q'),Variable('?v')),))
for target in ['lexical','source']:
 graph,ctx=parse_profile_graph(text,base_uri='urn:probe:')
 value=next(i.value for i in ctx.occurrences if i.value.kind=='literal')
 if target=='lexical':object.__setattr__(value,'lexical_form','2')
 else:object.__setattr__(value.source,'digest','changed')
 capture('contextMutation-'+target,lambda:reason(graph,(spec,),profile=PROFILE,term_context=ctx))
source=SourceRecord(reference='urn:probe:source',text='x'*65536)
records=tuple((TermInput('iri',f'urn:s:{i}',source=source),TermInput('iri','urn:p',source=source),TermInput('literal','x',source=source))for i in range(9))
capture('structured-input-projection-budget',lambda:execute_profile_records(records,**errors))
for name,value in [('badKind',TermInput('wrong','x')),('wrongRecordType','x'),('iriWithDatatype',TermInput('iri','urn:o',datatype_iri='urn:type'))]:
 record=((TermInput('iri','urn:s'),TermInput('iri','urn:p'),value),)
 capture('structured-'+name,lambda record=record:execute_profile_records(record,**errors))
