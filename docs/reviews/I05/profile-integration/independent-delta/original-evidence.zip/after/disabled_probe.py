exec(open(__file__.replace('disabled_probe.py','directed_probe.py')).read().split("for name,text in ")[0])
for name,values in [('wrong_type',42),('duplicate',('r','r')),('bad_unicode',('\ud800',))]:
 capture('records-disabled-'+name,lambda values=values:execute_profile_records((),disabled_rule_ids=values,**errors))
 capture('text-disabled-'+name,lambda values=values:execute_profile('',disabled_rule_ids=values,**errors))
