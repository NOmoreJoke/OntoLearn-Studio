exec(open(__file__.replace('false_match_probe.py','directed_probe.py')).read().split("for name,text in ")[0])
text='<urn:p> a <http://www.w3.org/2002/07/owl#DatatypeProperty> . <urn:q> a <http://www.w3.org/2002/07/owl#DatatypeProperty> . <urn:u> <urn:p> 1,2,3 .'
from ontolearn_engine.quality.rule_firing import Comparison
spec=RuleSpec('r',(Triple(TermInput('iri','urn:u'),TermInput('iri','urn:p'),Variable('?v')),),(Comparison(Variable('?v'),'gt',TermInput('literal','2',XSD+'integer')),),(Triple(TermInput('iri','urn:u'),TermInput('iri','urn:q'),Variable('?v')),))
g,ctx=parse_profile_graph(text,base_uri='urn:probe:')
r=reason(g,(spec,),profile=PROFILE,term_context=ctx);child=r['mechanismBatches'][0]
assert type(child['originalMatches'])is tuple
assert sorted(dict(m.bindings)['?v'].lexical_form for m in child['originalMatches'])==['1','2','3']
assert len(child['batch'].firings)==1
assert child['batch'].firings[0].heads[0].triple.object.lexical_form=='3'
assert len({ref for m in child['originalMatches'] for refs in m.proof_leaves for ref in refs})==3
p=execute_profile(text,(spec,),**errors)
restored=json.loads(''.join(row[0]for row in p['rows']))
assert restored==p['payload']
enc=json.dumps(restored,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
assert hashlib.sha256(enc).hexdigest()==p['jsonPayloadDigest']
assert len(restored['reasoning']['mechanismBatches'][0]['originalMatches'])==3
print(json.dumps({'scope':'3 actual matches, 2 false, 1 true; complete payload/rows identity','originalBindings':[dict(m.bindings)['?v'].lexical_form for m in child['originalMatches']],'firingCount':len(child['batch'].firings),'uniqueProofLeaves':3,'rowsRoundTripEqual':True,'payloadDigestVerified':True,'completeJsonPayload':p['payload']},ensure_ascii=True))
