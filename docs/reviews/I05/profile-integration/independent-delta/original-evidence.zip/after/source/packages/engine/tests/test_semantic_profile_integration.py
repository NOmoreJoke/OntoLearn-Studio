"""Real graph matching with fixed T05 input/expected, not prefilled bindings."""

import hashlib
import json
from dataclasses import replace
from pathlib import Path

import pytest
from ontolearn_engine.quality.rule_firing import Comparison, Triple, Variable
from ontolearn_engine.quality.rule_profile import OPS, PROFILE, XSD, TermInput
from ontolearn_engine.semantic import reason
from ontolearn_engine.semantic_profile_probe import _construct_case
from ontolearn_engine.semantic_turtle import parse_profile_graph

ROOT = Path(__file__).resolve().parents[3]
FIXTURES = ROOT / "tests/fixtures/quality/profile-v1"


def fixed_case():
    fixture = json.loads((FIXTURES / "firing-cases.json").read_bytes())
    text, rules = _construct_case(fixture)
    graph, context = parse_profile_graph(text, base_uri="urn:profile-test:")
    return fixture, graph, context, rules


def compute(graph, context, rules):
    return reason(graph, rules, profile=PROFILE, term_context=context)


def test_actual_graph_join_and_all_heads_from_fixed_oracle():
    fixture, graph, context, rules = fixed_case()
    result = compute(graph, context, rules)
    assert result["semanticsVersion"] == "i05-finite-7"
    (firing,) = result["firingGroups"]
    assert [head.index for head in firing.heads] == fixture["expected"]["head_indices"]
    assert [c.index for c in firing.comparisons] == fixture["expected"]["comparison_indices"]
    for head, expected in zip(firing.heads, fixture["expected"]["heads"], strict=True):
        assert head.triple.subject.lexical_form == expected[0]
        assert head.triple.predicate.lexical_form == expected[1]
        assert head.triple.object.lexical_form == expected[2]["lexical"]
        assert head.triple.object.datatype_iri == XSD + expected[2]["type"]
    assert len(result["rules"]) == fixture["expected"]["unique_facts"]
    assert firing.when[0].object.lexical_form == fixture["value"]
    assert firing.basis
    assert len(firing.proof_leaves) == len(firing.when)
    batch = result["mechanismBatches"][0]["batch"]
    assert hashlib.sha256(batch.payload).hexdigest() == batch.digest


@pytest.mark.parametrize("operator_index", range(6))
def test_fixed_numeric_operator_columns_through_graph(operator_index):
    matrix = json.loads((FIXTURES / "comparison-matrix.json").read_bytes())
    _, graph, context, rules = fixed_case()
    # Fixture graph carries 2; compare actual variable to 2, consuming the
    # independently authored threshold-two middle row for all six operators.
    comparison = Comparison(
        Variable("?v"), OPS[operator_index], TermInput("literal", "2", XSD + "integer")
    )
    spec = replace(rules[0], comparisons=(comparison,))
    result = compute(graph, context, (spec,))
    assert bool(result["firingGroups"]) is matrix["threshold_two_signatures"][1][operator_index]


def test_rule_save_order_does_not_change_allocations_or_actual_facts():
    _, graph, context, rules = fixed_case()
    a, b = replace(rules[0], rule_id="a"), replace(rules[0], rule_id="z")
    first = compute(graph, context, (a, b))
    second = compute(graph, context, (b, a))
    assert first["rules"] == second["rules"]
    assert first["firingGroups"] == second["firingGroups"]
    assert {item["ruleId"]: item["budgetLimits"] for item in first["mechanismBatches"]} == {
        item["ruleId"]: item["budgetLimits"] for item in second["mechanismBatches"]
    }


def test_no_custom_feedback_into_same_rule_pass():
    _, graph, context, rules = fixed_case()
    next_rule = replace(
        rules[0],
        rule_id="next",
        when=(Triple(Variable("?s"), TermInput("iri", "urn:out"), Variable("?v")),),
    )
    result = compute(graph, context, (rules[0], next_rule))
    assert [group.rule_id for group in result["firingGroups"]] == [rules[0].rule_id]


def _comparison_graph(left, right, operator):
    """New test-input projection; expected classifications remain T05's table."""
    from ontolearn_engine.quality.rule_firing import RuleSpec
    from rdflib import RDF, Literal, URIRef

    predicate_kind = "ObjectProperty" if left.kind == "iri" else "DatatypeProperty"
    obj = (
        URIRef(left.lexical_form)
        if left.kind == "iri"
        else Literal(
            left.lexical_form, datatype=left.datatype_iri, lang=left.language_raw, normalize=False
        )
    )
    text = (
        "<urn:C> a <http://www.w3.org/2000/01/rdf-schema#Class> . "
        "<urn:value> a <http://www.w3.org/2002/07/owl#" + predicate_kind + "> . "
        "<urn:a> <urn:value> " + obj.n3() + " ."
    )
    graph, context = parse_profile_graph(text, base_uri="urn:matrix-test:")
    spec = RuleSpec(
        "matrix-input",
        (Triple(Variable("?s"), TermInput("iri", "urn:value"), Variable("?v")),),
        (Comparison(Variable("?v"), operator, right),),
        (Triple(Variable("?s"), TermInput("iri", str(RDF.type)), TermInput("iri", "urn:C")),),
    )
    return graph, context, (spec,)


def _domain_input(domain, *, right=False):
    value = "2" if right else "1"
    if domain == "I":
        return TermInput("iri", "urn:matrix:" + value)
    if domain == "L":
        return TermInput("literal", value, None, "en")
    if domain == "B":
        return TermInput("literal", "true" if right else "false", XSD + "boolean")
    if domain in ("Dz", "Dl", "Tz", "Tl"):
        lexical = "1970-01-0" + value
        if domain.startswith("T"):
            lexical += "T00:00:00"
        if domain.endswith("z"):
            lexical += "Z"
        return TermInput(
            "literal", lexical, XSD + ("dateTime" if domain.startswith("T") else "date")
        )
    return TermInput("literal", value, XSD + ("integer" if domain == "N" else "string"))


_MATRIX = json.loads((FIXTURES / "comparison-matrix.json").read_bytes())


@pytest.mark.parametrize(
    "left_index,right_index,operator_index",
    [(a, b, c) for a in range(9) for b in range(9) for c in range(6)],
)
def test_fixed_nine_domain_classifications_via_actual_graph(
    left_index, right_index, operator_index
):
    from ontolearn_engine.semantic import ProfileReasonError

    left = _domain_input(_MATRIX["domains"][left_index])
    right = _domain_input(_MATRIX["domains"][right_index], right=True)
    graph, context, rules = _comparison_graph(left, right, OPS[operator_index])
    classification = _MATRIX["cells"][left_index][right_index][operator_index]
    if classification == "E3":
        with pytest.raises(ProfileReasonError) as caught:
            compute(graph, context, rules)
        assert caught.value.code == "RULE_COMPARISON_TYPE_MISMATCH"
    else:
        assert classification == "V"
        result = compute(graph, context, rules)
        assert bool(result["firingGroups"]) is _MATRIX["one_vs_two"][operator_index]


@pytest.mark.parametrize(
    "left_index,right_index,operator_index",
    [(a, b, c) for a in range(6) for b in range(6) for c in range(6)],
)
def test_fixed_six_numeric_type_matrix_via_actual_graph(left_index, right_index, operator_index):
    left = TermInput("literal", "1", XSD + _MATRIX["numeric_types"][left_index])
    right = TermInput("literal", "2", XSD + _MATRIX["numeric_types"][right_index])
    graph, context, rules = _comparison_graph(left, right, OPS[operator_index])
    assert _MATRIX["numeric_cells"][left_index * 6 + right_index][operator_index] == "V"
    assert (
        bool(compute(graph, context, rules)["firingGroups"])
        is _MATRIX["one_vs_two"][operator_index]
    )


def test_exact_original_false_matches_and_true_proofs_are_retained():
    _, graph, context, rules = fixed_case()
    true_result = compute(graph, context, rules)
    (child,) = true_result["mechanismBatches"]
    (original_match,) = child["originalMatches"]
    (firing,) = child["batch"].firings
    assert firing.when is original_match.when
    assert firing.proof_leaves is original_match.proof_leaves
    assert child["definitions"][0] is rules[0]
    assert child["catalog"] is true_result["catalog"]
    assert child["limits"].bindings == 1024
    false_spec = replace(
        rules[0],
        comparisons=(Comparison(Variable("?v"), "gt", TermInput("literal", "3", XSD + "integer")),),
    )
    (false_child,) = compute(graph, context, (false_spec,))["mechanismBatches"]
    assert false_child["batch"].firings == ()
    (false_match,) = false_child["originalMatches"]
    assert dict(false_match.bindings)["?v"].lexical_form == "2"
    assert false_match.proof_leaves


def test_disabled_and_empty_definition_children_have_distinct_real_state():
    from ontolearn_engine.semantic_turtle import bind_profile_disabled_rules

    _, graph, context, rules = fixed_case()
    disabled = bind_profile_disabled_rules(context, (rules[0].rule_id,))
    (child,) = compute(graph, disabled, rules)["mechanismBatches"]
    assert child["disabled"] is True
    assert child["originalMatches"] is None and child["batch"] is None
    assert child["definitions"] == rules
    (empty,) = compute(graph, context, ())["mechanismBatches"]
    assert empty["disabled"] is False
    assert empty["definitions"] == () and empty["originalMatches"] == ()
    assert empty["batch"].firings == ()
