from pathlib import Path
import hashlib,json,collections
H=Path(__file__).resolve().parent
R=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-profile-integration')
d=json.loads((H/'source/docs/iterations/I05/profile-probe-inputs.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
cache={};source_records=[];unexpected=[];defs=[]
def ptr(v,p):
 for key in p.lstrip('/').split('/') if p else []:
  key=key.replace('~1','/').replace('~0','~');v=v[int(key)]if isinstance(v,list)else v[key]
 return v
def source(v,path):
 p=v['path']
 if p not in cache:
  raw=(R/p).read_bytes();cache[p]=(sha(raw),json.loads(raw)if p.endswith('.json')else None)
 if cache[p][0]!=v['sha256']:raise AssertionError(('source_hash',path,p))
 if 'pointer'in v:
  if cache[p][1]is None:
   assert v['pointer']=='' and p.endswith('.csv')
   if 'physicalLine'in v:assert type(v['physicalLine'])is int and 1<=v['physicalLine']<=len((R/p).read_bytes().splitlines())
   original=None
  else:original=ptr(cache[p][1],v['pointer'])
 else:original=None
 source_records.append(path)
 return original
def walk(v,path=''):
 if isinstance(v,dict):
  if {'path','sha256'}<=set(v):source(v,path)
  for k,x in v.items():
   if 'expect'in k.lower()and k!='expectedIncluded':unexpected.append(path+'/'+k)
   walk(x,path+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,path+'/'+str(i))
walk(d)
assert not unexpected,unexpected
for c in d['mathInputs']:
 assert sha(encode(c['input']))==c['inputProjectionJsonSha256'],c['id']
 for definition in c['input']['definitions']:
  original=source(definition['source'],c['id']+'/definition')
  actual=sha(encode(original));assert actual==definition['definitionJsonValueSha256'],(c['id'],actual)
  defs.append(c['id']+':'+definition['rule_id'])
result={'assetBytes':len((H/'source/docs/iterations/I05/profile-probe-inputs.json').read_bytes()),'assetSha256':sha((H/'source/docs/iterations/I05/profile-probe-inputs.json').read_bytes()),'cases':len(d['mathInputs']),'inputProjectionHashesVerified':len(d['mathInputs']),'sourceHashAndPointersVerified':len(source_records),'uniqueSourceFiles':len(cache),'definitionOriginalJsonHashesVerified':len(defs),'unexpectedExpectedKeys':unexpected,'incompleteFullContexts':[c['id']for c in d['mathInputs']if not c['input']['fullOriginalInputContext']],'notExecuted':[c['id']for c in d['mathInputs']if not c['eligibleStandaloneMathInput']],'scope':'input/source/hash inspection only; no oracle output comparison'}
(H/'asset-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
