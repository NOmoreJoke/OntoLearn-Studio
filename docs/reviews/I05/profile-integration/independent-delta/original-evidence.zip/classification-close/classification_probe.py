exec(open(__file__.replace('classification_probe.py','directed_probe.py')).read().split("for name,text in ")[0])
from ontolearn_engine import semantic_execution

def expect(name,run,reason,resource):
 try:run()
 except ProfileExecutionFault as e:
  assert e.diagnostic['classification']=='resource' and e.diagnostic['reason']==reason
  assert e.error['code']=='RESOURCE_LIMIT' and e.error['params']=={'resource':resource}
  print(json.dumps({'name':name,'error':e.error,'diagnostic':e.diagnostic},ensure_ascii=True))
 else:raise AssertionError(name)
expect('text-resource',lambda:execute_profile('x'*1048577,**errors),'TEXT_INPUT_LIMIT','semanticInput')
source=SourceRecord(text='x'*65536)
records=tuple((TermInput('iri',f'urn:s:{i}',source=source),TermInput('iri','urn:p',source=source),TermInput('literal','x',source=source))for i in range(9))
expect('structured-resource',lambda:execute_profile_records(records,**errors),'GRAPH_INPUT_LIMIT','semanticInput')
old=semantic_execution.MAX_OUTPUT_BYTES
try:
 semantic_execution.MAX_OUTPUT_BYTES=64
 expect('actual-output-resource-with-directed-local-limit',lambda:execute_profile('',**errors),'PROJECTION_RESULT_LIMIT','semanticResult')
finally:semantic_execution.MAX_OUTPUT_BYTES=old
