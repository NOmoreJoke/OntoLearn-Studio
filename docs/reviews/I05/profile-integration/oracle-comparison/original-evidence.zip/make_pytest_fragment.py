from pathlib import Path
import ast
base=Path('build/profile-input-projection')
checker=ast.parse((base/'oracle-comparison/compare_oracle.py').read_text())
projection=ast.parse((base/'project_inputs.py').read_text())
# Include only pure source-IR formatting, not the projection CLI/operation folder.
translators=[node for node in projection.body if isinstance(node,ast.FunctionDef)and node.name in ('triple','definition')]
for node in ast.walk(ast.Module(body=translators,type_ignores=[])):
    if isinstance(node,ast.Name)and node.id=='digest':node.id='sha'
body=[]
for node in checker.body:
    if isinstance(node,ast.Import):
        node.names=[alias for alias in node.names if alias.name not in ('argparse','importlib.util')]
        if not node.names:continue
    if isinstance(node,ast.FunctionDef)and node.name=='main':continue
    if isinstance(node,ast.If)and isinstance(node.test,ast.Compare):continue
    body.append(node)
body.extend(translators)
extra='''
import pytest

class InputProjection:
    definition = staticmethod(definition)

@pytest.fixture(scope="session")
def collection():
    # One actual collection shared by both tests. No ignored scripts or old raw.
    # The producer never receives expected. This fixture is an external consumer.
    from ontolearn_engine import semantic_profile_probe as producer
    from ontolearn_engine.resources import CONTRACT, ROOT
    from ontolearn_engine.semantic_execution import ProfileExecutionFault, execute_profile_records
    repo = Path(__file__).resolve().parents[3]
    asset = repo / "docs/iterations/I05/profile-probe-inputs.json"
    oracle_path = repo / "tests/fixtures/quality/real-executor-acceptance-inputs.json"
    asset_sha = "6c6ffc3a1a57d1817583c0a71d24e2847cc5d2d673848878c6e6e72dfe6c39de"
    projection = load(asset, asset_sha)
    assert sha(canonical(projection)) == "06e88e2df13d3fc07f781195a0c125b80a9906f5a79e13a4c58508f2ce8cec08"
    assert producer.INPUT_SHA256 == asset_sha
    assert len(projection["mathInputs"]) == 83
    oracle = load(oracle_path, ORACLE_SHA)
    triples, mappings, coverage = model(oracle, projection, InputProjection)
    schema = load(ROOT / "v2/schema.json")
    records = []
    for index, sample in enumerate(projection["mathInputs"]):
        record = {"caseId": sample["id"],
                  "inputProjectionJsonSha256": sample["inputProjectionJsonSha256"]}
        if not sample["eligibleStandaloneMathInput"]:
            record.update(status="not-executed", reason="ORIGINAL_INPUT_CONTEXT_INCOMPLETE")
        else:
            actual_records, rules, disabled = producer._construct_records(sample, index)
            try:
                result = execute_profile_records(actual_records, rules,
                    disabled_rule_ids=disabled, error_catalog=CONTRACT.ERROR_CATALOG,
                    error_schema=schema)
                record.update(status="success", result=result)
            except ProfileExecutionFault as error:
                record.update(status="failure", error=error.error, diagnostic=error.diagnostic)
        records.append(record)
    report = {"format": "i05-profile-probe/2", "inputSha256": asset_sha,
              "inputBytes": asset.stat().st_size, "cases": records,
              "collectionOrigin": "pytest actual execute_profile_records, not probe subprocess",
              "lifecycleExecuted": False, "overallProbeSuccess": False}
    config = {"executionInputSha256": asset_sha, "executionInputBytes": asset.stat().st_size,
              "sourceStyle": "short-no-revision", "sameInputJsonValuesVerified": True}
    compared = compare_actual(report, projection, oracle, triples, mappings, config)
    return {"report": report, "compared": compared, "coverage": coverage,
            "oracle": oracle, "projection": projection}


def test_fixed_oracle_all_78_complete_mathematical_outputs(collection):
    # Green means the 78 successful mathematical outputs match their complete
    # observable oracle. It is not all-83/probe/E1/P2/Store success.
    data = collection
    compared = data["compared"]
    assert compared["statusCounts"] == {
        "math-observable-fields-pass": 78, "not-executed": 1, "failure": 4}
    expected_ids = {s["id"] for s in data["projection"]["mathInputs"]
                    if s["eligibleStandaloneMathInput"] and
                    not s["id"].startswith("E.5:event-fragment:")}
    successful = [c for c in compared["cases"] if c["status"] == "math-observable-fields-pass"]
    assert {c["mathInputId"] for c in successful} == expected_ids
    graph_ids = {g for c in successful for g in c["exactInputValueGraphs"]}
    assert len(graph_ids) == 49
    match_refs = {m for g in graph_ids for m in data["oracle"]["graphs"][g]["matchRefs"]}
    assert len(match_refs) == 24
    assert sum(data["oracle"]["matches"][m]["accepted"] for m in match_refs) == 15
    assert sum(not data["oracle"]["matches"][m]["accepted"] for m in match_refs) == 9
    assert {w for g in graph_ids for w in data["oracle"]["graphs"][g]["rdfsWitnessRefs"]} == {"R04-equipment"}
    assert not compared["falseComparisonEvidenceClaim"]
    assert not compared["lifecycleChecked"]
    assert not compared["fullI05OrE1OrP2Passed"]


def test_fixed_oracle_four_resource_failures_and_unavailable_context_are_not_skipped(collection):
    records = {c["caseId"]: c for c in collection["report"]["cases"]}
    expected = {
        "E.5:event-fragment:round:1": ("RULE_INPUT_BUDGET", "R-risk", "semanticInput"),
        "E.5:event-fragment:round:2": ("RULE_INPUT_BUDGET", "R-risk", "semanticInput"),
        "E.5:event-fragment:round:3": ("WORK_LIMIT", None, "semanticWork"),
        "E.5:event-fragment:round:4": ("WORK_LIMIT", None, "semanticWork"),
    }
    assert {key for key,value in records.items() if value["status"] == "failure"} == set(expected)
    for key,(reason,rule_id,resource) in expected.items():
        record = records[key]
        assert record["error"] == {"code": "RESOURCE_LIMIT", "messageKey": "resource.limitExceeded",
                                   "params": {"resource": resource}, "retryable": False}
        assert record["diagnostic"] == {"reason": reason, "classification": "resource",
                                        "location": None, "ruleId": rule_id}
        assert "result" not in record
    missing = records["transfer:repair"]
    assert missing == {"caseId": "transfer:repair",
                       "inputProjectionJsonSha256": next(s["inputProjectionJsonSha256"] for s in collection["projection"]["mathInputs"] if s["id"] == "transfer:repair"),
                       "status": "not-executed", "reason": "ORIGINAL_INPUT_CONTEXT_INCOMPLETE"}
    assert len(records) == 83
    assert sum(c["status"] == "success" for c in records.values()) == 78
    assert collection["report"]["overallProbeSuccess"] is False
    # The real CLI is separately exercised by root and must still exit 1. This
    # test asserts the known partial/resource contract; no skip or false green
    # all-probe-success flag replaces those four failed computations.
'''
body.extend(ast.parse(extra).body)
# Every top-level binding except the public test names receives a private prefix.
bindings=set()
for node in body:
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)):bindings.add(node.name)
    elif isinstance(node,ast.Assign):
        bindings.update(t.id for t in node.targets if isinstance(t,ast.Name))
    elif isinstance(node,ast.Import):
        bindings.update(a.asname or a.name.split('.')[0] for a in node.names)
    elif isinstance(node,ast.ImportFrom):bindings.update(a.asname or a.name for a in node.names)
names={name:'_i05_oracle_'+name for name in bindings if not name.startswith('test_')}
class PrivateNames(ast.NodeTransformer):
    def visit_Name(self,node):
        node.id=names.get(node.id,node.id);return node
    def visit_arg(self,node):
        node.arg=names.get(node.arg,node.arg);return node
    def visit_FunctionDef(self,node):
        node.name=names.get(node.name,node.name);return self.generic_visit(node)
    def visit_ClassDef(self,node):
        node.name=names.get(node.name,node.name);return self.generic_visit(node)
    def visit_Import(self,node):
        for alias in node.names:
            old=alias.asname or alias.name.split('.')[0]
            alias.asname=names.get(old,old)
        return node
    def visit_ImportFrom(self,node):
        for alias in node.names:
            old=alias.asname or alias.name
            alias.asname=names.get(old,old)
        return node
module=ast.fix_missing_locations(PrivateNames().visit(ast.Module(body=body,type_ignores=[])))
text='# Suggested append-only TEST fragment; not installed or executed by this agent.\n# All expected data remains in the test consumer; producer receives fixed inputs only.\n'+ast.unparse(module)+'\n'
# Class attribute is intentionally the module interface required by model().
text=text.replace('_i05_oracle_definition = staticmethod(_i05_oracle_definition)','definition = staticmethod(_i05_oracle_definition)')
path=base/'oracle-comparison/pytest_append_fragment.py';path.write_text(text)
ast.parse(text);compile(text,str(path),'exec')
print(path, len(text.encode()))
