from pathlib import Path
p=Path('build/profile-input-projection/oracle-comparison/compare_oracle.py')
s=p.read_text()
s=s.replace("record['notObservable']=['false when-bindings and false comparison traces (API retains accepted firings only)',", "record['notObservable']=['false ComparisonEvidence is absent; originalMatches carries actual false binding/when/proof only',")
s=s.replace("'all accepted comparison operand terms/operator/boolean','all head indices/occurrences',", "'all accepted comparison operand terms/operator/boolean','all original true/false match bindings/when/proof','all head indices/occurrences',")
s=s.replace("def check_result(result,sample,index,graph,oracle,triples):", "def check_result(result,sample,index,graph,oracle,triples,config):")
s=s.replace("    by_rule={v['rule_id']:v for v in sample['input']['definitions']}\n", '''    expected_evidence=[]
    for i,firing in enumerate(expected):
        for head_index,value in firing['heads']:
            expected_evidence.append((firing['ruleId'],i,head_index,value,firing['when'],firing['basis']))
    actual_evidence=[(e['rule'],integer(e['firingIndex']),integer(e['headIndex']),n3triple(e['result']),
                      tuple(n3triple(t)for t in e['inputs']),frozenset(leaves[k]for k in e['basis']))for e in r['evidence']]
    if actual_evidence!=expected_evidence:raise ValueError('ALL_HEAD_EVIDENCE_OCCURRENCES')
    by_rule={v['rule_id']:v for v in sample['input']['definitions']}
    if len(r['definitions'])!=len(by_rule):raise ValueError('DEFINITION_RECORD_COUNT')
    def op(value):
        return ('var',value['name'])if value.get('recordType')=='Variable'else term(value)
    def expected_op(value,iri=False):
        if value.startswith('?'):return ('var',value)
        return ('iri',value,'','')if iri else n3key(value)
    for actual_def,definition in zip(r['definitions'],sample['input']['definitions']):
        if actual_def.get('recordType')!='RuleSpec' or actual_def['rule_id']!=definition['rule_id'] or actual_def['revision']!=definition['revision'] or actual_def['definition_digest']!=definition['definitionJsonValueSha256'] or actual_def['policy']!=PROFILE:raise ValueError('ACTUAL_ORIGINAL_DEFINITION_IDENTITY')
        for field in ('when','heads'):
            expected_rows=[tuple(expected_op(row[k],iri=k!='object')for k in ('subject','predicate','object'))for row in definition[field]]
            actual_rows=[tuple(op(row[k])for k in ('subject','predicate','object'))for row in actual_def[field]]
            if actual_rows!=expected_rows:raise ValueError('DEFINITION_ORDERED_ROWS')
        expected_comps=[(expected_op(c['left']),c['operator'],expected_op(c['right']))for c in definition['comparisons']]
        actual_comps=[(op(c['left']),c['operator'],op(c['right']))for c in actual_def['comparisons']]
        if actual_comps!=expected_comps:raise ValueError('DEFINITION_ORDERED_COMPARISONS')
''')
s=s.replace("        if expected_disabled:\n            if batch is not None:raise ValueError('DISABLED_EVALUATED_BATCH')", '''        originals=item['originalMatches']
        if expected_disabled:
            if originals is not None:raise ValueError('DISABLED_ORIGINAL_MATCHES')
            if batch is not None:raise ValueError('DISABLED_EVALUATED_BATCH')''')
s=s.replace("        if batch.get('recordType')!='PreparedFiringBatch'", '''        expected_originals=[]
        for ref in graph['matchRefs']:
            match=oracle['matches'][ref]
            if match['ruleId']==rule_id:
                f=expected_firing(match,graph,oracle,triples)
                expected_originals.append({k:f[k]for k in ('ruleId','bindings','when','proof')})
        actual_originals=[]
        for m in originals:
            if m.get('recordType')!='BindingMatch':raise ValueError('ORIGINAL_MATCH_RECORD')
            actual_originals.append({'ruleId':m['rule_id'],'bindings':tuple((k,term(v))for k,v in m['bindings']),
                                     'when':tuple(record_triple(t)for t in m['when']),
                                     'proof':tuple(frozenset(leaves[k]for k in refs)for refs in m['proof_leaves'])})
        if sorted(actual_originals,key=firing_sort_key)!=sorted(expected_originals,key=firing_sort_key):raise ValueError('ALL_TRUE_FALSE_ORIGINAL_MATCHES')
        ordinal=next(i for i,d in enumerate(sample['input']['definitions'])if d['rule_id']==rule_id)
        if integer(item['definitionOrdinal'])!=ordinal:raise ValueError('ORIGINAL_DEFINITION_ORDINAL')
        if item['definitions']!=[r['definitions'][ordinal]]or item['catalog']!=r['catalog']or item['limits']!=item['budgetLimits']:raise ValueError('MATCH_CARRIER_FULL_CONTEXT')
        if batch.get('recordType')!='PreparedFiringBatch' ''')
s=s.replace("'falseExpectedMatchesNotTraceObservable':sum(not oracle['matches'][k]['accepted']for k in graph['matchRefs']),", "'falseOriginalMatchesCompared':sum(not oracle['matches'][k]['accepted']for k in graph['matchRefs']),\n            'falseComparisonEvidenceAvailable':False,")
s=s.replace("source['digest']!=INPUT_SHA or source['revision']!=sample['inputProjectionJsonSha256']", "source['digest']!=config['executionInputSha256'] or source['revision']!=(None if config['sourceStyle']=='short-no-revision'else sample['inputProjectionJsonSha256'])")
s=s.replace("pointer='asset:i05/profile-probe-inputs.json#/mathInputs/'", "pointer=(''if config['sourceStyle']=='short-no-revision'else'asset:i05/profile-probe-inputs.json')+'#/mathInputs/'")
s=s.replace("def compare_actual(actual,projection,oracle,triples,mappings):", "def compare_actual(actual,projection,oracle,triples,mappings,config):")
s=s.replace("actual.get('inputSha256')!=INPUT_SHA", "actual.get('inputSha256')!=config['executionInputSha256']")
s=s.replace("check_result(record['result'],sample,index,oracle['graphs'][graph_id],oracle,triples)", "check_result(record['result'],sample,index,oracle['graphs'][graph_id],oracle,triples,config)")
s=s.replace("'inputSha256':INPUT_SHA,'cases':outputs", "'inputSha256':INPUT_SHA,'executionInput':config,'cases':outputs")
s=s.replace("'completeAll40MatchTraceClaim':False", "'completeAll40MatchTraceClaim':False,'originalTrueFalseMatchCarrierCompared':True,'falseComparisonEvidenceClaim':False")
s=s.replace("parser.add_argument('--actual');parser.add_argument('--comparison-out');args=parser.parse_args()", "parser.add_argument('--actual');parser.add_argument('--comparison-out');parser.add_argument('--executed-input-asset');parser.add_argument('--source-style',choices=('short-no-revision','asset-revision'),default='short-no-revision');args=parser.parse_args()")
s=s.replace("    if args.actual:\n", '''    if args.actual:
        config={'executionInputSha256':INPUT_SHA,'executionInputBytes':Path(args.inputs).stat().st_size,
                'sourceStyle':args.source_style,'sameInputJsonValuesVerified':True}
        if args.executed_input_asset:
            if load(args.executed_input_asset)!=projection:raise ValueError('EXECUTED_INPUT_JSON_VALUES_DIFFER')
            config['executionInputSha256']=sha(Path(args.executed_input_asset).read_bytes())
            config['executionInputBytes']=Path(args.executed_input_asset).stat().st_size
''')
s=s.replace("compare_actual(load(args.actual),projection,oracle,triples,mappings)", "compare_actual(load(args.actual),projection,oracle,triples,mappings,config)")
p.write_text(s)
