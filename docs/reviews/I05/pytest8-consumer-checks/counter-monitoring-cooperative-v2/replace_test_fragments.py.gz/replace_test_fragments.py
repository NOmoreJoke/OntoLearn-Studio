"""Static text assembly of the two independently reviewed test fixes."""
import ast
import hashlib
from pathlib import Path
OUT = Path(__file__).resolve().parent
p = OUT / 'tests.append.proposed.txt'
raw = (OUT.parent/'cooperative-v1/tests.append.proposed.txt').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'e9a6357773c63e13d90833cbbe6ff57628f3e87afe530a007da05acf79baf7bc'
s = raw.decode()
tree = ast.parse(s)
replacements = {
    'test_monitor_disabled_target_requires_zero_then_start': '''def test_monitor_disabled_target_requires_zero_then_start(probe, clear_first):
    monitor = sys.monitoring

    def target():
        return None

    def other():
        return None

    seen = []

    def disabling(code, offset):
        seen.append(code)
        return monitor.DISABLE

    lease = _MonitorTestLease(monitor)
    try:
        lease.acquire("unit-disable-history")
        assert monitor.get_events(2) == 0
        assert monitor.get_local_events(2, target.__code__) == 0
        lease.install_callback(monitor.events.PY_START, disabling)
        lease.set_local_from_zero(target.__code__, monitor.events.PY_START)
        target()
        monitor.set_local_events(2, target.__code__, monitor.events.PY_START)
        target()
        assert len(seen) == 1, "same declared mask must not restart DISABLE"
        if clear_first:
            lease.restore_local(target.__code__)
        lease.restore_callback(monitor.events.PY_START)
        lease.release()
        counter = probe.CallCounter(*_counter_targets(target, other))
        if clear_first:
            with counter:
                target()
                target()
            assert counter.counts == {"reason": 2, "validator": 0}
            assert counter.counts_complete is True
        else:
            with pytest.raises(probe.ProbeFault) as caught:
                counter.__enter__()
            assert caught.value.code == "PROFILE_HOOK_ALREADY_PRESENT"
            assert counter.counts_complete is False
            assert monitor.get_local_events(2, target.__code__) == monitor.events.PY_START
    finally:
        lease.cleanup()
''',
    'test_monitor_unknown_code_masks_and_other_event_callback_are_preserved': '''def test_monitor_unknown_code_masks_and_other_event_callback_are_preserved(probe):
    monitor = sys.monitoring

    def reason():
        return None

    def run():
        return None

    def unrelated():
        return None

    returned = []

    def foreign_return(code, offset, value):
        returned.append(code)

    lease = _MonitorTestLease(monitor)
    foreign_mask = monitor.events.PY_START | monitor.events.PY_RETURN
    try:
        lease.acquire("unit-unrelated-residue")
        assert monitor.get_events(2) == 0
        assert monitor.get_local_events(2, unrelated.__code__) == 0
        lease.install_callback(monitor.events.PY_RETURN, foreign_return)
        lease.set_local_from_zero(unrelated.__code__, foreign_mask)
        lease.release()
        counter = probe.CallCounter(*_counter_targets(reason, run))
        with counter:
            unrelated()
            reason()
        assert counter.counts == {"reason": 1, "validator": 0}
        assert counter.counts_complete is True
        assert returned == [unrelated.__code__]
        assert monitor.get_local_events(2, unrelated.__code__) == foreign_mask
    finally:
        # Pending own edits survive release. Even a failed assertion above must
        # reacquire the free name and undo them, or fail without taking quarantine.
        lease.cleanup()
''',
}
lines = s.splitlines(keepends=True)
for node in sorted((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in replacements), key=lambda n:n.lineno, reverse=True):
    lines[node.lineno-1:node.end_lineno] = [replacements[node.name].rstrip()+'\n']
s = ''.join(lines)
marker = '@pytest.mark.parametrize("clear_first", [False, True])'
assert s.count(marker) == 1
s = s.replace(marker, (OUT/'test-lease.proposed.txt').read_text().rstrip()+'\n\n\n'+marker, 1)
ast.parse(s)
p.write_text(s)
