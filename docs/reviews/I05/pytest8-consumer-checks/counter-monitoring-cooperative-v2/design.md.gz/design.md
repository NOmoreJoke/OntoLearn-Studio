# Cooperative-v2：未应用、待独立复核

结论：在已澄清的合作式工程域内，可以提出 PROFILER_ID=2、仅为两个真实目标申请 local PY_START 的最窄替代方案。常量为 `sys.monitoring.PROFILER_ID`。方案承认 callback exchange 的短暂替换，也承认历史 unknown-code local mask 会让本 callback 收到其他 code 事件；不声称释放槽干净、不声称全解释器只触发两个 code。交付为精确未应用 patch，尚未获得实施或运行票，不能把静态可行性当成已验证的事件投递或性能收益。

本目录修复 cooperative-v1 独审 F1/F2 的真实测试资源恢复缺陷，计数器主体与 probe 完整候选逐字节保持 v1。v1 全 11 成员、manifest 及 independent-r1 原件不改。此合作方案补充并取代原 design.md 的“任意 free 槽必须先完全证明 clean”工程域；原 11051 字节文档和原五成员 manifest 保留为历史，不改写。固定前像是 `4bb99d99620811766df38d7e29346e3174f82c8c`，probe 102749B/2996deca…、tests 76628B/d7947f3e…，与 553a 固定字节相同。未读取或改写后继 T03 WIP。本补丁只增加 `_thread` import、替换 CallCounter、收紧 collector finally 中计数导出；业务 callable、417 inventory、120 秒、64 MiB、观察项均不变。

## 已查官方 3.12 事实

[3.12 monitoring 文档](https://docs.python.org/3.12/library/sys.monitoring.html) 和 [v3.12.12 固定文档](https://github.com/python/cpython/blob/v3.12.12/Doc/library/sys.monitoring.rst)：monitoring 属于解释器；PY_START 为开始执行 Python 函数的事件，callback 参数为 code/offset；local 与 global 启用相加；注册返回旧 callback。PROFILER_ID 为 2，使用中的 ID 申请会拒绝。3.12 的 free_tool_id 仅释放名字，既不清 callback 也不清 events。不能用 3.14 的 clear/free 变更解释 3.12。

[sys.setprofile 文档](https://docs.python.org/3.12/library/sys.html#sys.setprofile) 明确 profile 属于线程；[_thread.get_ident 文档](https://docs.python.org/3.12/library/_thread.html#_thread.get_ident) 返回当前线程标识，可在线程结束后复用。新类在 owner 活着的 with 范围缓存该标识，回调先过滤当前线程，再做两个独立 identity if，保持旧的当前线程计数。标识不会被当作跨线程或跨生命周期的永久身份。

[v3.12.12 instrumentation.c](https://github.com/python/cpython/blob/v3.12.12/Python/instrumentation.c) 精确检查点：1715–1717 相同 local mask 直接返回；1719 写 mask 后，1724 的重 instrument 仍可失败；1518–1553 计算新增 bit 并对精确 code 指令 add_tools；1843–1849 先 audit，成功后才交换 callback；1782–1790 free 仅清 name。789–807/895–896 的 tracing guard 避免递归监控 callback 本身。新增 bit 的静态路径支持下述正例，不代替运行验证。

[code.h 固定 flags](https://github.com/python/cpython/blob/v3.12.12/Include/cpython/code.h#L166-L178) 给出 0x20/0x80/0x200。候选只接收 CodeType 且无这些 generator/coroutine/async-generator flags；不把 PY_RESUME 当首次 call。固定 ownsemantic.py reason 1247–1258 与 own .venv pyshacl 0.30.1 validator.py run 175–324 经原目录 AST 收据静态确认均为无 decorator、无 yield、无 async 的普通同步函数；没有 import/执行它们。

## 所有权与准入边界

只申请已释放的 ID2；不接管 active name，不换 ID，不遍历其他 code，不调用 restart_events，不向 caller 索取 clean bit。名字是正常合作场景的协调标识，不是抵抗同解释器恶意代码的 owner token。合作域要求本方持有名字期间其他组件不主动复用 ID2。持久 callback/目标 mask/global mask/name 意外变化会拒绝可靠结果；跨快照发生又恢复的 ABA、恶意 audit hook 连续干预不在可证明保证内，不能宣称绝对隔离。

准入次序：拒绝 existing sys.getprofile 非 None；记录 owner ident；get_tool 非 None 拒绝；公开 use_tool_id 申请；global mask 必须 0；两个目标的 local mask 必须各为 0；对 PY_START 做一次 callback exchange。返回旧值非 None 时，立即经统一回滚恢复该实际旧对象并拒绝，不启用目标 mask。审计拒绝发生在交换前，因此 entry 的 register 抛异常时不能谎称已经换上 callback。其他 event callback 与 unknown-code local mask 不读、不清、不要求不存在。

两个目标只用 `reason_code is validator_code` 去重，形成一或二元素 tuple。不能用 set/dict 去重，因为 CodeType 存在结构相等但 identity 不同的情况。相同 code 的双角色只装一次 local 事件，callback 的两个 if 各增一次；别名保留 code 身份；同名无关函数忽略。ordinary nested/recursive entries 按实际入口累计，无期望零跳过。

## 生命周期与失败

1. NEW：内部 counts_complete=False；字典保留 reason/validator 零。缓存一次稳定 bound callback 对象供注册和 `is` 比较。
2. RESERVED：只获 ID2 name，尚未改变 masks/callback。global 或目标 local 残留拒绝时释放本方 name，不清残留。
3. ADMITTED/EXCHANGED：确认读到的 global/目标均 0；交换 PY_START 并保存旧 callback。旧非 None 时恢复旧对象、释放 name、拒绝。
4. ARMING：每个 identity code 在 set_local_events **之前**加入 attempted。设置后读回要求 PY_START；任何部分失败都清理 attempted，不遗漏 setter 已写 mask 后失败的情况。
5. ACTIVE：owner thread 的真实 code 入口累计；其他线程立即返回 None。回调所有 BaseException 都标内部失败；普通异常改为私有 ProbeFault(INTERNAL_ERROR) 并链接原因，KBI/SystemExit 在 callback 当场保持原类传播；退出时已记录的 callback failure 会使 __exit__ 改为私有 INTERNAL_ERROR，不能声称最终外层异常仍为原类。setup 的 KBI 在清理成功时按原类传播。即便 getter 在另一线程失败、即便业务 catch 住 callback 异常，最终也不得导出可靠零。
6. CLEANING：先 active=False；确认 name 仍属本方；检查 owner/profile/global 完整性；只处理 attempted code，预期 PY_START 清 0，已为 0 在 ACTIVE 后视为完整性失败，其他 mask 保留并隔离 reservation。对已装 callback 注册 prior，返回值必须 `is` 缓存 callback；若找到其他实际对象，立即恢复它，报私有失败，不能重新安装本方覆盖它。恢复或 audit 再失败则报告失败并保留 reservation，不声称恢复成功。其他 callback/mask 不清。
7. CLEAN/COMPLETE：free 前再核 name/global/attempted masks；只有确认自己的改动已撤销才释放本方 name。业务异常正常 unwind、零调用、正常调用均可置 counts_complete=True。callback 曾失败时即使资源清理成功仍 False，且 __exit__ 报 INTERNAL_ERROR。资源未确认清理的路径保留 name 隔离并失败，需要后续人工/独立受控处置，不能在同一运行偷偷换 ID 再试。

清理会尝试余下已确认拥有的步骤，记录首个异常并通过私有失败传播，既不静默吞掉，也不把 incoming 异常字符串写入观察。setup 的普通 TypeError 也包成 ProbeFault，避免 collector 的 shacl missing-keywords TypeError 业务拒绝分支误接。已存在的 collector 私有 harness-or-unknown 路径会终止 failed；本补丁不增加业务拒绝类别。

同一实例嵌套会在改变 owner/previous 前拒绝，外层仍继续；不同实例通过 occupied ID 拒绝。重复顺序使用延续旧字典累计语义，重新建立内部完整性状态。正常 cleanup 不设置 sys.setprofile，所以原 None 保持；若外部后来装 profile，不替它回滚，只判计数无效并清理自己的资源。

## DISABLE 的正、反例和拒绝规则

反例：历史 callback 对目标返回 DISABLE，但 declared target local mask 仍为 PY_START。重复设置相同 PY_START 走 1715–1717 早返，不会重新启用。即便 get_tool(None)、旧 callback 已清，仍必须在目标 local 非零准入检查拒绝；绝不先清这个不属于我们的状态再继续。

正例：历史 owner 已显式清目标 local 为 0、global 为 0，再释放 name/旧 callback。本方申请成功后 0→PY_START 引入新 bit，静态源路径对这一个真实 code 的 RESUME 入口 add_tools/reinstrument；不依赖全局 restart。两种路径均已写未来真实 API 单元（`test_monitor_disabled_target_requires_zero_then_start` 的 False/True 两值），现在只做 AST 检查，尚未验证 seen/counter 实际结果。

## 其他观察者与代码/PYZ 身份

unknown-code local PY_START 残留会被新注册 callback 接收，但 identity if 不增计数，返回 None 也不会 DISABLE 它；因此不能宣称整解释器只激活两个位置。其他 event callback 保持原对象、原 mask；它们已有的行为或异常不会被本方清理。它们不使我们的 code identity 双角色判断错计；如果本方 callback 自身失败则一律 INTERNAL_ERROR。合作域不允许其他组件在本方 live name 期间改本方 callback/mask。

目标取自已加载真实 semantic.reason.__code__/Validator.run.__code__；不根据文件名、函数名、预期 count、源码与 PYZ 路径猜替身，不替换业务 callable，不重编译业务。源码与 PYZ 都需在各自正常加载后取真实 code 身份；监控内部可能改变 adaptive instrumentation，而公共 co_code 由 [codeobject.c 1433–1469](https://github.com/python/cpython/blob/v3.12.12/Objects/codeobject.c#L1433-L1469) 去优化取得。不能由这个源码事实提前宣称所有 loader fingerprint/PYZ 集成通过。将来的有限测试必须保留既有 code identity/loader fingerprint 断言，并核 entry/exit 前后公开 fingerprint 一致。

## 导出与测试替身

active 时 counts 仍是原字典，scope stage 读法不变。scopeStages 保留既有故障前的部分 stage delta；callback 失败后其中可为部分值或零。top-level callCounts=None 与 terminal failed 表示完整计数无效，scopeStages 只能作为故障前的部分诊断，不可解释为完整可靠计数；不修改业务 stage 读法或添加验收项。collector finally 仅在 `getattr(counter, "counts_complete", False) is True` 时导出字典，其他已创建无效 counter 导出 None。未执行声明分支原零与 instrumentation=False 原 None 保留。counts_complete 是只读 property，来源为内部状态，不是 caller clean bit。

固定 tests 未找到 FakeCounter 定义；新的 EntryFailureCounter 测试刻意无完整性标记，证明旧接口不会被当可靠零。若后继自有 fault test 引入 FakeCounter，只有确实模拟成功完整生命周期的替身才能提供 True；失败替身不得凭接口兼容填 True。补丁没有降低现有 normal/rejection 计数断言。

## 交付与放行条件

probe/test proposed.py 是便于字节审查的完整候选；两个 unapplied.patch 为精确应用域；assemble_static.py 只从固定 Git blob 拼接，静态 AST 标准化比较证明 probe 类之外只有 import 与 export guard 改动；static-receipt.json 固定前后字节与摘要。unit-plan.md 列有限未来执行项。原始文件和原 manifest 摘要将在新 manifest 收据校验，未对产品应用或执行候选代码。

当前只有静态证据，无 monitoring 实验、线程、pytest、产品、PYZ、benchmark 或 OS/H/RSS 实验。收益未知且不量化。必须先完成独立审查，修正具体反例，再由 root 决定实施和有限 unit 运行票；不扩大原预算，不删 417，不恢复 full_run。

## v2 针对独审 F1/F2 的修复

v1 [独审报告](../cooperative-v1/independent-r1/report.md) 的主体 Limited Static Pass 不等于运行放行。两处真实 API unit 原先先 exchange 再 assert None，且 free 后失败可能跳过 finally；v2 用测试专属 _MonitorTestLease 把“仍有自有残留”与“当前是否持有 reservation”分离。

- 成功 exchange 后保存真实 previous 对象；旧非 None 立即恢复再失败，绝不继续制造 clean 历史。audit 在 mutation 前失败时不登记并不清 callback。
- 前置 global/local 断言失败时未登记任何 callback/local 改动，finally 仅释放本方刚获 name。local 在 setter 前登记，以覆盖写 mask 后失败。
- release 仅撤销当前名字，不丢弃本测试已造的 local/callback 登记。成功或断言失败一律 finally；pending 存在且实际 name free 才重新公开申请 cleanup name，按精确登记撤销。active owner/counter quarantine 不接管，不清未知状态。
- callback 恢复若实际对象不是登记的 ours，恢复实际对象并 quarantine；local 非本方预期 mask 不清；恢复失败保留本方 reservation 并使有限进程失败，不能宣称清理完成。

本版本新增一个测试辅助类、仅修改上述两个真实 test 函数；保持21个新增函数/34参数case，加原四个为38case。辅助类没有被执行，没有增加产品 API。root 绑定获票 CPython3.12.12/pytest 环境后，才可按 unit-plan 的精确选择串行运行，--maxfail=1 只是停止上限，不代替资源恢复修复。
