# 有限 unit 放行计划（全部待运行）

本目录仅字节/AST解析，下面不是测试结果。cooperative-v2 针对独审 F1/F2 采用登记真实旧 callback 与分离 pending/owned 的 lease 辅助类；这两处修复须先获同独审复核。实施前先对 fixed 4bb/2996/d794 的两份 unapplied.patch 做独审；独审若给出具体错计或不可恢复反例，先修新固定件，不直接运行。

未来票限 CPython 3.12.12 单进程、串行执行选定 unit；不启动 product process，不 full_run、不 benchmark、不改变120/64MiB/417。新增 tests.append 中含一条真实 threading.Thread，仅用于证明 interpreter-wide 投递在本方 owner 过滤后不计 worker；除此之外无新线程。状态替身 _CounterMonitor 的测试不证明 CPython 真实事件；真实 monitor 测试不把未知历史 state 清干净后再偷偷继续。实际ID2被合法活动owner占用就保留失败证据，不换ID、不自动clear、不skip。

选取新增 `test_monitor_` 全部测试函数（AST收据给出函数数/参数展开数），加原有四个有限检查：

- test_call_counter_counts_real_code_identity_and_restores_hook：真实 canonical reason alias、同名无关、真实Validator.run。
- test_call_counter_existing_hook_fails_without_overwriting_it。
- test_call_counter_restores_hook_on_real_policy_rejection。
- test_imported_probe_classes_have_only_canonical_module_identity。

不得让该选择带入 full_run/b1_selector_runs module fixtures。新增 canonical fingerprint 和 invalid-entry collector 测试会使用 canonical 装载 fixture；invalid-entry 在第一个业务 dispatch **之前**故障并终止，只证明 JSONL observation callCounts=None/terminal failed，不能称完成417产品流。

必要覆盖映射：

| 条件 | 未应用单元 |
| --- | --- |
| 两个不同 code、结构 equal 但 identity 不同、same-code 双角色、alias | distinct_equal_codes_and_same_code_roles + 原真实 alias unit |
| zero 必须完整退出才可导出；业务异常正常 unwind仍完整 | zero_is_complete_only_after_normal_exit；owner_thread_real_delivery_and_business_exception；原真实policy拒绝unit |
| owner与worker真实投递；非owner getter/增量异常不得掩盖 | owner_thread_real_delivery_and_business_exception；other_owner_callback_is_ignored…；callback_failure…；callback_increment_failure… |
| recursive/nested入口；同一实例嵌套不破坏外层；不同实例拒绝occupied | recursive_real_entries_and_distinct_nested_counter；same_instance_nested_rejection… |
| activeID/global/target residual 拒绝，不清残留、不fallback | foreign_occupancy_or_masks_are_not_cleared 三参数 |
| residual PY_START callback exchange后恢复并拒绝；cache callback identity | residual_callback_is_restored_and_rejected；same_instance_nested… |
| audit-before-exchange失败；第1/第2 setter mask已写后失败 | audit_rejection_precedes_exchange；partial_setup_rolls_back… 两参数 |
| cleanup期间callback、mask0、foreignmask、global持久变更 | persistent_changes_fail_without_blind_restore 四参数 |
| cleanup audit阻止撤销：保留reservation，不可靠0 | cleanup_audit_failure_retains_reservation_and_invalid_counts |
| DISABLE declared非0拒绝；同mask不重启；0→PY_START重启目标 | disabled_target_requires_zero_then_start False/True 两参数，真实 API，两个结果均必须验证 |
| unknown其他code mask +其他event callback原样保留，ours只忽略unknown | unknown_code_masks_and_other_event_callback_are_preserved，真实 API |
| 私有setup/callback TypeError不进业务missing-keyword拒绝；无flag失败替身None | partial_setup…/callback…内部code断言；invalid_entry_exports_none_and_terminal_failed |
| canonical对象 identity、公共 fingerprint entry/exit一致 | canonical_code_objects_and_public_fingerprints_survive，及原canonical模块identityunit |

新增剩余故障组 remaining_cleanup_faults 五参数已编码 name 被改、不改外来 profile、clear setter 异常、free 异常、恢复 foreign callback 再次 audit 失败；rejects_nonordinary_targets 三参数覆盖 generator/coroutine/async-generator；setup_keyboard_interrupt 覆盖非普通异常回滚并传播。SystemExit/回调 KBI 尚未单独编码，行为仅有静态分支依据，不能称已验证。

真实源码与PYZ loader identity还须后续原本授权的打包验收验证；当前有限unit仅覆盖来源树canonical入口与公共codefingerprint，不能扩大为PYZ通过或性能票。若监控本身事件投递未通过，立即停止，不降断言、不把0替代None、不恢复sys.setprofile fallback。

## 获票后唯一有限命令（尚未执行）

从 fixed 4bb 主树 cwd 执行，python 必须由 root 绑定到获票 CPython3.12.12 且具有获准 pytest 的解释器。当前没有 collect-only 结果；25 个选定函数/38 个参数展开 case 是静态 AST 推导。

```sh
python -B -m pytest packages/engine/tests/test_semantic_source_package_probe.py --maxfail=1 -k '(test_monitor_ or test_call_counter_counts_real_code_identity_and_restores_hook or test_call_counter_existing_hook_fails_without_overwriting_it or test_call_counter_restores_hook_on_real_policy_rejection or test_imported_probe_classes_have_only_canonical_module_identity)'
```

不添加 xdist（不传 -n，不用线程化执行器）。一处已声明 worker thread 仍仅为 owner 过滤单元。先前 callback 或 mask 的准入失败必须保持原状态并失败；counter quarantine 时不得由测试接管。恢复失败也必须失败并停止有限进程。--maxfail=1 不能修复或替代任何状态恢复。scopeStages 可保留故障前部分值；top-level None/terminal failed 时不作为完整计数证据。
