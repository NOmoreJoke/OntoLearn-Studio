# cooperative-v2 独立静态复核 r1

结论：**Limited Static Pass。v1 的 F1/F2 在本版静态关闭，未发现新增阻断；可提交 root 决定实施与既定有限 unit 运行票。** 这不是实施授权、事件真实投递通过、测试通过、性能或完整 engine Pass。计数器主体未变，未应用主树；新增21函数/34 case，加原四函数预计38 case，全部未运行。

## 固定与差异

v2 manifest 为2309B/bfad0bf97532b311e5e95a96cb0af45f51d90da6bcd95d89e5aa5b053cfe663f；14成员全部核实。v1原manifest及11成员、旧独审 report/proof/manifest 三文件均保全。主树实际 HEAD 仍4bb99d99620811766df38d7e29346e3174f82c8c；probe固定/当前102749B/2996deca33083754132bf5f4eab8d1e273161b3e5fe722a8ee96856fb5cc0d5b，tests固定/当前76628B/d7947f3e90a7226b28aada7f7b6ba0c09393d25295700da2d8ffa65e353b2f68。

v2 CallCounter.proposed.txt、probe.proposed.py、probe.unapplied.patch 与 v1逐字节相同。tests完整候选99627B/7f03018981b71382b9725e1d5a3898d483487ea8b5ef067e10a429cd208622d9。独立 AST 比较：仅新增 _MonitorTestLease，并改 disabled_target_requires_zero_then_start 与 unknown_code_masks_and_other_event_callback_are_preserved 两函数，其他顶层 AST 节点逐项不变；helper片段与完整候选内类AST一致。完整 tests 等于固定旧字节+原新增imports+本版append，两份patch精确等于固定前像至完整候选的byte diff。文档design/unit-plan、helper、两实际test、delta assembler/fix-proof均完整只读；未执行作者脚本。

## F1：原状态保全，静态关闭

lease.acquire 先确认 name free 再申请，只有use成功才登记name。global/local前置断言失败时，locals/callbacks登记为空，cleanup只释放本方名字，不清从未由本测试修改的callback/mask。occupied slot在use前断言失败且pending为空，cleanup不碰活动资源。

install_callback 在真实register成功返回后保存(event, ours, previous)；旧previous非None立即restore_callback，恢复精确旧对象、从待恢复列表移除，再pytest.fail拒绝。finally仅释放本方名字，不再以None覆盖旧对象。真实audit在exchange前抛错时尚未登记，cleanup不假称装过callback。这个顺序符合此前固定v3.12.12官方源码审查，不以释放名字证明callback干净。

restore_callback 要求实际被替换对象 is ours；若不是，尝试还原实际对象并quarantine，不free。不确定还原或audit再次失败会使测试失败并保留reservation；不声称恢复成功。没有新增链式fallback、换ID或清未知event。

## F2：release后失败仍清自己，静态关闭

release只清当前reservation name，locals/callbacks待恢复账本保留。unknown-code测试成功或任一计数/delivery/mask断言失败均进入同一finally；name为空但pending存在时，cleanup只在get_tool实际free后公开重新申请cleanup name，再撤销登记的unrelated mask与PY_RETURN callback。原先2253至2263之间断言失败跳过恢复的路径已消除。

DISABLE False分支保留历史非零mask登记，counter按预期拒绝并释放后由lease清本测试残留；True分支先restore_local、restore_callback清登记，释放后再测0→PY_START。若counter进入quarantine或ID被活动owner占用，lease不接管；有pending时acquire失败并保留现场，无pending时返回也不会触碰counter资源，原测试异常仍令运行失败。--maxfail=1保证不继续其他单元，不能解释成现场已恢复。

set_local_from_zero 在getter确认0之后、setter之前登记(code, mask)，覆盖setter写后失败；cleanup读到0或本方mask才恢复，foreign mask不清，恢复后读回0才移账。清理异常记录后会尝试其余仍获确认的步骤；只要任何恢复失败就不release并抛失败。若quarantined已置位，_owns禁止后继不确定改动。正常空账本且已获本方name可以释放；无需要求任意未知其他code-local完整枚举。

以上为静态控制流证明，尚无helper异常路径真实API执行结果，也没有新增对任意same-process恶意抢占、ABA或持续audit干预的安全保证。name仍仅是合作协调标识。

## 文档与有限命令

KBI已准确区分：callback当场保留原异常类，随后exit因永久callback_failure可转为私有INTERNAL_ERROR；setup KBI在成功回滚后保留原类。scopeStages明确为故障前部分诊断；top-level None/failed terminal不能被读成各层可靠完整计数。无预期修改、计数降级或验收外扩。

unit-plan保留精确文件、选择表达式、--maxfail=1和禁xdist。21个新增函数/34展开case与原四函数预计25函数/38 case，由AST推导；本版选定函数签名与既有fixture闭包未变，不带入full_run/b1_selector_runs模块fixture。invalid-entry仍在首次业务dispatch前失败，并非417产品流完成。未来命令须由root绑定获票CPython3.12.12且有获准pytest的解释器，从主树cwd串行执行：

```sh
python -B -m pytest packages/engine/tests/test_semantic_source_package_probe.py --maxfail=1 -k '(test_monitor_ or test_call_counter_counts_real_code_identity_and_restores_hook or test_call_counter_existing_hook_fails_without_overwriting_it or test_call_counter_restores_hook_on_real_policy_rejection or test_imported_probe_classes_have_only_canonical_module_identity)'
```

本轮没有API、线程、产品import/collector、pytest/collect-only、formatter、benchmark、OS实验，也没有主树或旧报告修改。主体v1有限静态结论沿用；真实DISABLE正反例、owner过滤、递归、部分失败清理、code fingerprint、PYZ/native、性能预算和完整工程仍待相应获票验证。当前只将本提案静态阻断关闭，不给真实集成Pass。详细实际文件哈希及独立AST结果见proof.json。
