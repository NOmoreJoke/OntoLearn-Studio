from pathlib import Path
import ast
import hashlib
import json

R = Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_i05_deadline_static_attribution')
W = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-pytest8-supplier-integration')
d = json.loads((R / 'analysis.json').read_text())
a, b = d['streams']
assert a['records'] == 220 and a['observationCount'] == 218
assert a['completedIdCount'] == 218 and a['unstartedIdCount'] == 199
assert a['terminal']['firstFailure'] == {'api': 'semantic_profile_restore.restore_profile_result', 'code': 'COLLECTION_DEADLINE', 'id': 'fullview/profile-76', 'stage': 'restore/result'}
assert b['records'] == 188 and b['observationCount'] == 186
assert b['terminal']['firstFailure'] == {'api': 'semantic_profile_restore.restore_profile_explanation_result', 'code': 'INTERNAL_ERROR', 'id': 'dag/type', 'stage': 'restore/result'}
assert a['profileContextFacts']['eligibleTrue'] == 82
assert a['profileContextFacts']['eligibleFalse'] == 1
assert a['profileContextFacts']['matchedSourceCaseIds'] == 83
assert a['profileContextFacts']['profileCheckedExecuteCalls'] == 82
assert d['comparablePrefix']['count'] == 185
assert d['comparablePrefix']['sameProjectionAll'] and d['comparablePrefix']['sameCallCountsAll']
assert [x['id'] for x in d['comparablePrefix']['rows'] if not x['sameResultCanonicalBytes']] == ['b1-semantic/1x', 'b1-semantic/10x']
u = sum(x['checkedIntervalUnionSeconds'] for x in a['familyGroups'].values())
o = sum(x['outsideCheckedIntervalSeconds'] for x in a['familyGroups'].values())
assert abs(u + o - a['observationsSeconds']) < 1e-8
source = Path(d['sourceIdentity']['path'])
raw = source.read_bytes()
assert len(raw) == d['sourceIdentity']['bytes'] and hashlib.sha256(raw).hexdigest() == d['sourceIdentity']['sha256']
text = raw.decode()
lines = text.splitlines(keepends=True)
excerpts = []
for row in d['relatedSourceRanges']:
    if row['name'] == 'run_fixed_suite':
        spans = [(2395, 2420), (2460, 2512), (2559, 2610)]
    else:
        spans = [(row['start'], row['end'])]
    for lo, hi in spans:
        excerpts.append(f"\n--- {source} {lo}-{hi} ({row['name']}) ---\n" + ''.join(lines[lo-1:hi]))
(R / 'source-excerpts.txt').write_text(''.join(excerpts))
verification = {'format': 'I05-deadline-static-final-check/1', 'actualProductRun': False, 'jsonReadback': True, 'sourceUnchanged': True, 'sharedIntervalsCheckedUnionSeconds': u, 'sharedObservationOutsideCheckedSeconds': o, 'sharedElapsedOutsideObservationSeconds': a['elapsedMinusObservationSeconds'], 'contextDomainVerified': 'header.contexts.mathInputContexts', 'comparePrefixVerified': 185, 'nonEqualResultIds': ['b1-semantic/1x', 'b1-semantic/10x'], 'limitsKept': {'deadlineSeconds': 120, 'reportCapBytes': 67108864}, 'reportArithmeticCorrectionBeforeFreeze': 'Initial author table manually transcribed union/outside values incorrectly; corrected to computed 117.698376/1.560553 before manifest freeze; analysis.json and original raw never changed.'}
(R / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
rows = []
for p in sorted(R.iterdir()):
    if p.is_file() and p.name != 'manifest.json':
        z = p.read_bytes()
        rows.append({'path': str(p), 'bytes': len(z), 'sha256': hashlib.sha256(z).hexdigest()})
manifest = {'format': 'I05-deadline-static-attribution-manifest/1', 'members': rows, 'selfExcluded': True}
(R / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
for x in rows:
    z = Path(x['path']).read_bytes()
    assert len(z) == x['bytes'] and hashlib.sha256(z).hexdigest() == x['sha256']
print(json.dumps({'members': len(rows), 'report': next(x for x in rows if x['path'].endswith('/report.md')), 'manifestBytes': (R / 'manifest.json').stat().st_size, 'manifestSha256': hashlib.sha256((R / 'manifest.json').read_bytes()).hexdigest(), 'arithmeticVerified': True, 'sourceUnchanged': True}, ensure_ascii=False))
