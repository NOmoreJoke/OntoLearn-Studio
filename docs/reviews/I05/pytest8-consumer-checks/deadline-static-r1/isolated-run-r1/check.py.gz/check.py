from pathlib import Path
import collections
import datetime
import hashlib
import json
import os
import xml.etree.ElementTree as ET

W = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-pytest8-supplier-integration')
R = Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_i05_deadline_static_attribution/isolated-run-r1')
P = W / 'docs/reviews/I05/pytest8-consumer-checks'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def ident(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def union(attempts):
    xs = sorted((x['start'], x['end']) for x in attempts)
    total = 0.0
    if not xs:
        return total
    lo, hi = xs[0]
    for a, b in xs[1:]:
        if a <= hi:
            hi = max(hi, b)
        else:
            total += hi - lo
            lo, hi = a, b
    return total + hi - lo

receipt_path = P / 'isolated-full-run-01.json'
rb = receipt_path.read_bytes()
d = json.loads(rb)
assert len(rb) == 9751 and sha(rb) == '173bf6bda55fdaa6cbc34e36fc94e6ba4667224f4a502ad3708b3fdbbd131da7'
assert d['exitCode'] == 1 and d['boundSourceBytesUnchangedDuringRun'] is True
assert d['planSHA256'] == 'de0d708ff9677d49ca9fcdc5425641c13445be574eb037168622d92792477687'
expected_argv = ['uv', 'run', '--frozen', 'pytest', 'packages/engine/tests/test_semantic_source_package_probe.py::test_full_jsonl_is_complete_inventory_not_self_signed_equivalence', '--basetemp=build/i05-pytest8/isolated-full-run-01', '--junitxml=build/i05-pytest8/isolated-full-run-01.junit.xml', '--tb=short']
assert d['argv'] == expected_argv
bindings = []
assert len(d['beforeFiles']) == 40
assert len({x['path'] for x in d['beforeFiles']}) == 40
for x in d['beforeFiles']:
    p = W / x['path']
    z = p.read_bytes()
    assert len(z) == x['bytes'] and sha(z) == x['sha256'], x['path']
    bindings.append({**x, 'currentEqualsRecordedBefore': True})
current_checked_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
stream_checks = []
for name, x in d['streams'].items():
    p = P / x['path']
    z = p.read_bytes()
    assert len(z) == x['bytes'] and sha(z) == x['sha256']
    (R / p.name).write_bytes(z)
    stream_checks.append(x)
(R / 'execution-receipt.json.raw').write_bytes(rb)
jp = W / d['junit']['path']
jb = jp.read_bytes()
assert len(jb) == 732 and sha(jb) == 'af21ef1ec6fb27b3f023a3d417bdef8361798796804d0cdba6a2facc13eac720'
(R / 'junit.xml.raw').write_bytes(jb)
j = ET.fromstring(jb)
suites = list(j.iter('testsuite'))
assert len(suites) == 1 and suites[0].get('tests') == '1' and suites[0].get('failures') == '1' and suites[0].get('errors') == '0' and suites[0].get('skipped') == '0'
cases = list(j.iter('testcase'))
assert len(cases) == 1 and cases[0].get('name') == 'test_full_jsonl_is_complete_inventory_not_self_signed_equivalence'
p = W / 'build/i05-pytest8/isolated-full-run-01/semantic-full-v1-diagnostic0/observations.jsonl'
b = p.read_bytes()
assert len(b) == 46185358 and sha(b) == '169f9223141912fb2e53878119de82f1c343c3b1fc6df859688f25ae25fc418b'
lines = b.splitlines()
rows = [json.loads(x) for x in lines]
assert len(rows) == 383
h, t = rows[0], rows[-1]
obs = rows[1:-1]
assert h['type'] == 'header' and t['type'] == 'terminal' and all(x['type'] == 'observation' for x in obs)
assert len(obs) == 381 and len(t['completedIds']) == 381 and len(t['unstartedIds']) == 36
assert len(h['fullInventory']) == 417 and h['fullInventory'] == h['selectedInventory']
assert [x['id'] for x in obs] == t['completedIds'] == h['selectedInventory'][:381]
assert t['unstartedIds'] == h['selectedInventory'][381:]
assert t['collectionComplete'] is False and t['fullSuiteCollectionComplete'] is False
assert t['firstFailure'] == {'api': 'semantic.validate_shacl_text', 'code': 'COLLECTION_DEADLINE', 'id': 'utc-date/public-budget-43460', 'stage': 'shacl-text/validate'}
assert h['limits']['cooperativeBoundaryDeadlineSeconds'] == 120 and h['limits']['reportBytes'] == 67108864
assert h['limits']['deadlineIncludesPreflight'] is True
last = obs[-1]
assert last['id'] == t['firstFailure']['id'] and last['error']['code'] == 'COLLECTION_DEADLINE'
assert last['diagnostic']['classification'] == 'cooperative-boundary-stop'
a = last['stageAttempts'][-1]
assert a['api'] == 'semantic.validate_shacl_text' and a['stage'] == 'shacl-text/validate' and a['returned'] is True
families = collections.defaultdict(lambda: {'count': 0, 'observationSeconds': 0.0, 'checkedIntervalUnionSeconds': 0.0, 'lineBytes': 0})
apis = collections.defaultdict(lambda: {'attempts': 0, 'elapsedNs': 0, 'returned': 0})
per = []
for line, x in zip(lines[1:-1], obs):
    duration = x['end'] - x['start']
    u = union(x['stageAttempts'])
    z = families[x['family']]
    z['count'] += 1
    z['observationSeconds'] += duration
    z['checkedIntervalUnionSeconds'] += u
    z['lineBytes'] += len(line) + 1
    per.append({'id': x['id'], 'family': x['family'], 'status': x['status'], 'observationSeconds': duration, 'checkedIntervalUnionSeconds': u, 'outsideCheckedIntervalSeconds': duration - u, 'lineBytes': len(line) + 1, 'attempts': len(x['stageAttempts'])})
    for s in x['stageAttempts']:
        z = apis[s['api']]
        z['attempts'] += 1
        z['elapsedNs'] += s['elapsedNs']
        z['returned'] += bool(s['returned'])
observed_seconds = sum(x['observationSeconds'] for x in per)
checked_seconds = sum(x['checkedIntervalUnionSeconds'] for x in per)
protected = {'report.md': (11489, 'd1721735491bb0568a16b6cadb09d45e13cba4f4d583abead078515ee31c3b05'), 'manifest.json': (3818, 'e5a1fb10960669f8197dc5a8449dd40882b73a9a122c90f2e5448d018f3ea6ce'), 'plan-delta-r1/manifest.json': (1126, '63236117185e6b3fa2aebdde7885943405dd37b8306f444d5a798f95b555de25')}
for n, (size, sh) in protected.items():
    z = (R.parent / n).read_bytes()
    assert len(z) == size and sha(z) == sh
result = {'format': 'I05-isolated-once-actual-run-independent-review/1', 'receiptIdentity': ident(receipt_path), 'argvMatchesExactOneNodePlan': True, 'actualExitCode': d['exitCode'], 'recordedStartUtc': d['startedUtc'], 'recordedEndUtc': d['endedUtc'], 'recordedLauncherSeconds': d['elapsedSeconds'], 'managedWindowAsRecordedNotHostIdleProof': d['managedWindow'], 'bindingsCheckedAtUtc': current_checked_at, 'bindingCount': len(bindings), 'currentBindings': bindings, 'pythonIdentityAsRecorded': d['pythonIdentity'], 'streamChecks': stream_checks, 'junitIdentity': ident(jp), 'junitSuite': suites[0].attrib, 'singleCase': cases[0].attrib, 'jsonlIdentity': ident(p), 'recordCount': len(rows), 'observations': len(obs), 'completed': len(t['completedIds']), 'unstarted': len(t['unstartedIds']), 'unstartedIds': t['unstartedIds'], 'firstFailure': t['firstFailure'], 'terminalElapsedSeconds': t['elapsedSeconds'], 'terminalState': t['state'], 'observationSeconds': observed_seconds, 'checkedIntervalUnionSeconds': checked_seconds, 'outsideCheckedWithinObservationSeconds': observed_seconds - checked_seconds, 'elapsedOutsideObservationSeconds': t['elapsedSeconds'] - observed_seconds, 'families': dict(families), 'apiTotalsSorted': sorted(({'api': k, **v} for k, v in apis.items()), key=lambda x: x['elapsedNs'], reverse=True), 'lastObservation': {k: last.get(k) for k in ['id', 'status', 'start', 'end', 'stage', 'api', 'error', 'diagnostic']}, 'lastAttempts': last['stageAttempts'], 'lastCallReturnedBeforeBudgetCheck': True, 'fixedLimits': h['limits'], 'reportCapNotTriggered': len(b) < 67108864 and t['firstFailure']['code'] != 'OUTPUT_REPORT_LIMIT', 'parentSaysCpuReleasedNotIndependentlyObserved': True, 'productionExecutedByReviewer': False, 'repeatRun': False, 'oldReportsAndManifestsUnchanged': protected, 'noCausalLoadOrPerformanceClaim': True, 'futureSelectiveMonitoringPreapproved': False}
(R / 'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(R / 'per-observation.json').write_text(json.dumps(per, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checkedBindings': len(bindings), 'checkedAtUtc': current_checked_at, 'keyBindings': [x for x in bindings if x['path'] in ['packages/engine/src/ontolearn_engine/semantic_source_package_probe.py', 'packages/engine/tests/test_semantic_source_package_probe.py', 'pyproject.toml']], 'records': len(rows), 'observations': len(obs), 'unstarted': len(t['unstartedIds']), 'terminalElapsedSeconds': t['elapsedSeconds'], 'observationSeconds': observed_seconds, 'checkedIntervalUnionSeconds': checked_seconds, 'outsideCheckedWithinObservationSeconds': observed_seconds - checked_seconds, 'elapsedOutsideObservationSeconds': t['elapsedSeconds'] - observed_seconds, 'lastAttempts': last['stageAttempts'], 'unstartedIds': t['unstartedIds']}, ensure_ascii=False))
