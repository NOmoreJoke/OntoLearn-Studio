from pathlib import Path
import ast
import collections
import hashlib
import json
import sys

W = Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-pytest8-supplier-integration')
OUT = Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_i05_deadline_static_attribution')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def enc(v):
    return json.dumps(v, ensure_ascii=True, allow_nan=False, sort_keys=True, separators=(',', ':')).encode('ascii')

def identity(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def union_seconds(attempts):
    intervals = sorted((a['start'], a['end']) for a in attempts)
    total = 0.0
    if not intervals:
        return total
    begin, end = intervals[0]
    for lo, hi in intervals[1:]:
        if lo <= end:
            end = max(end, hi)
        else:
            total += end - begin
            begin, end = lo, hi
    return total + end - begin

def analyze(name, relative):
    p = W / relative
    raw = p.read_bytes()
    lines = raw.splitlines()
    rows = [json.loads(l) for l in lines]
    assert rows[0]['type'] == 'header' and rows[-1]['type'] == 'terminal'
    obs = [r for r in rows if r.get('type') == 'observation']
    term = rows[-1]
    groups = collections.defaultdict(lambda: {'count': 0, 'observationSeconds': 0.0, 'checkedIntervalUnionSeconds': 0.0, 'outsideCheckedIntervalSeconds': 0.0, 'lineBytes': 0, 'stageAttempts': 0})
    apis = collections.defaultdict(lambda: {'attempts': 0, 'elapsedNs': 0, 'returned': 0})
    details = []
    for line, r in zip(lines, rows):
        if r.get('type') != 'observation':
            continue
        duration = r['end'] - r['start']
        union = union_seconds(r['stageAttempts'])
        g = groups[r['family']]
        g['count'] += 1
        g['observationSeconds'] += duration
        g['checkedIntervalUnionSeconds'] += union
        g['outsideCheckedIntervalSeconds'] += duration - union
        g['lineBytes'] += len(line) + 1
        g['stageAttempts'] += len(r['stageAttempts'])
        for a in r['stageAttempts']:
            q = apis[a['api']]
            q['attempts'] += 1
            q['elapsedNs'] += a['elapsedNs']
            q['returned'] += bool(a['returned'])
        details.append({'id': r['id'], 'family': r['family'], 'status': r['status'], 'seconds': duration, 'checkedIntervalUnionSeconds': union, 'outsideCheckedIntervalSeconds': duration - union, 'lineBytes': len(line) + 1, 'stageAttempts': len(r['stageAttempts']), 'topLevelFieldEncodedBytes': {k: len(enc(v)) for k, v in r.items()}, 'resultFieldEncodedBytes': {k: len(enc(v)) for k, v in r.get('result', {}).items()} if type(r.get('result')) is dict else {}})
    contexts = rows[0]['contexts']['mathInputContexts']
    cx = {x['id']: x for x in contexts}
    profile = [r for r in obs if r['family'] == 'profile-83']
    summary = {'name': name, 'identity': identity(p), 'records': len(rows), 'observationCount': len(obs), 'terminal': {k: term.get(k) for k in ['state', 'collectionComplete', 'elapsedSeconds', 'firstFailure']}, 'completedIdCount': len(term.get('completedIds', [])), 'unstartedIdCount': len(term.get('unstartedIds', [])), 'observationsSeconds': sum(x['seconds'] for x in details), 'elapsedMinusObservationSeconds': term['elapsedSeconds'] - sum(x['seconds'] for x in details), 'familyGroups': dict(groups), 'apiTotalsSorted': sorted(({'api': k, **v} for k, v in apis.items()), key=lambda x: x['elapsedNs'], reverse=True), 'largestLines': sorted(details, key=lambda x: x['lineBytes'], reverse=True)[:12], 'profileContextFacts': {'jsonPath': '$.header.contexts.mathInputContexts[*].eligibleStandaloneMathInput', 'contexts': len(contexts), 'eligibleTrue': sum(x['eligibleStandaloneMathInput'] is True for x in contexts), 'eligibleFalse': sum(x['eligibleStandaloneMathInput'] is False for x in contexts), 'profileObservations': len(profile), 'matchedSourceCaseIds': sum(r['sourceCaseId'] in cx for r in profile), 'statuses': dict(collections.Counter(r['status'] for r in profile)), 'profileCheckedExecuteCalls': sum(a['api'] == 'semantic_execution.execute_profile_records' for r in profile for a in r['stageAttempts'])}}
    (OUT / (name + '-per-observation.json')).write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n')
    return summary, rows, details

source = W / 'packages/engine/src/ontolearn_engine/semantic_source_package_probe.py'
test = W / 'packages/engine/tests/test_semantic_source_package_probe.py'
assert identity(source)['bytes'] == 102749 and identity(source)['sha256'] == '2996deca33083754132bf5f4eab8d1e273161b3e5fe722a8ee96856fb5cc0d5b'
assert identity(test)['bytes'] == 76535 and identity(test)['sha256'] == '5fcf853fb48f5781758bdb0893357a9687f1ce7e35d9cc9352957b7d4fcaa4c9'
a, ar, ad = analyze('shared', 'build/i05-pytest8/full-pytest-02/semantic-full-v1-diagnostic0/observations.jsonl')
assert a['identity']['bytes'] == 46483457 and a['identity']['sha256'] == 'a84bfcaa1b374fc02a8114aedfc414b2f6a36368c6b2176bd4a7397f15350a1b'
b, br, bd = analyze('producer-fault', 'build/i05-pytest8/full-pytest-02/test_r1_real_producer_capture_0/observations.jsonl')
aobs = [r for r in ar if r.get('type') == 'observation']
bobs = [r for r in br if r.get('type') == 'observation']
prefix = []
for x, y in zip(aobs, bobs):
    if x['id'] != y['id'] or x['status'] != y['status']:
        break
    prefix.append({'id': x['id'], 'sharedSeconds': x['end'] - x['start'], 'faultSeconds': y['end'] - y['start'], 'sameProjectionSha256': x['projectionSha256'] == y['projectionSha256'], 'sameResultCanonicalBytes': enc(x.get('result')) == enc(y.get('result')), 'sameCallCounts': x['callCounts'] == y['callCounts']})
module_ast = ast.parse(source.read_text())
functions = []
for node in module_ast.body:
    if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in {'CollectionBoundary', 'CallCounter', 'JSONLWriter', '_catalog', '_dispatch', '_production_observation', '_partial_outputs', '_partial_value', '_install_audit_observer', 'run_fixed_suite', '_original_profile_inputs'}:
        functions.append({'name': node.name, 'start': node.lineno, 'end': node.end_lineno})
summary = {'format': 'I05-existing-stream-deadline-static-attribution/1', 'productExecution': False, 'sourceIdentity': identity(source), 'testIdentity': identity(test), 'agentRulesIdentity': identity(W / 'AGENTS.md'), 'streams': [a, b], 'comparablePrefix': {'count': len(prefix), 'rows': prefix, 'profile83SharedSeconds': sum(x['sharedSeconds'] for x in prefix if x['id'].startswith('profile-83/')), 'profile83FaultSeconds': sum(x['faultSeconds'] for x in prefix if x['id'].startswith('profile-83/')), 'sameProjectionAll': all(x['sameProjectionSha256'] for x in prefix), 'sameResultAll': all(x['sameResultCanonicalBytes'] for x in prefix), 'sameCallCountsAll': all(x['sameCallCounts'] for x in prefix)}, 'relatedSourceRanges': functions, 'preservedConditions': {'deadlineSeconds': 120, 'reportCap': 67108864, 'droppedObservations': False, 'inputMutation': False}, 'timingDomain': 'existing instrumented wall-clock intervals; inclusive API totals are not uninstrumented benchmark or CPU attribution', 'concurrency': 'parent supplied T01 StageB started 18:58 UTC overlapping; no process evidence read and no causal attribution'}
(OUT / 'analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'shared': {'records': a['records'], 'observations': a['observationCount'], 'elapsed': a['terminal']['elapsedSeconds'], 'sumObservationSeconds': a['observationsSeconds'], 'outsideObservationSeconds': a['elapsedMinusObservationSeconds'], 'profileFacts': a['profileContextFacts']}, 'producerFault': {'identity': b['identity'], 'records': b['records'], 'observations': b['observationCount'], 'elapsed': b['terminal']['elapsedSeconds'], 'failure': b['terminal']['firstFailure']}, 'prefixCount': len(prefix), 'profilePrefixSeconds': [summary['comparablePrefix']['profile83SharedSeconds'], summary['comparablePrefix']['profile83FaultSeconds']], 'prefixResultsEqual': summary['comparablePrefix']['sameResultAll']}, ensure_ascii=False))
