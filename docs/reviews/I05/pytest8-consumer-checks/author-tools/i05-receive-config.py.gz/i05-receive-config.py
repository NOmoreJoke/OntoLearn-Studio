from pathlib import Path
import subprocess,json,hashlib
r=Path('/Users/kyle/Documents/工作/知爻/本体');w=r/'.worktrees/I05-pytest8-supplier-integration';src=r/'.worktrees/T01-I05-exact-config-20261023';ref='a909afc369c143071025a55bc788abde0b9f40f5';base='513db0056f312342a6791e2d4c7842f3726581f2'
def g(*a):return subprocess.check_output(['git','-C',str(w),*a])
assert g('rev-parse',ref+'^').decode().strip()==base
assert set(g('diff','--name-only',base,ref).decode().splitlines())=={'.prettierignore','pyproject.toml'}
checks=[]
for p,n,h in [('pyproject.toml',1453,'4bb20cf970a09b2948cf1b9d41ad93496b25f5c01a3f2b277426ea75798879c0'),('.prettierignore',756,'9b0af2a98f9c134d14722225fd313b32a90cff83eb1373f0581a766d5ae454d0')]:
 assert (w/p).read_bytes()==g('show',base+':'+p)
 b=g('show',ref+':'+p);assert b==(src/p).read_bytes() and len(b)==n and hashlib.sha256(b).hexdigest()==h;checks.append({'path':p,'bytes':n,'sha256':h})
report=r/'outputs/20261022_review_backlog/T01-I05-exact-config-20261023/independent-review.md.raw';b=report.read_bytes();assert len(b)==7407 and hashlib.sha256(b).hexdigest()=='54e98f536d2c6b5f0584c4c9204d6f0a062146d577b3b77a9b6b38954655fcb0'
for x in checks:(w/x['path']).write_bytes(g('show',ref+':'+x['path']))
d=w/'docs/reviews/I05/pytest8-consumer-checks';(d/'t01-config-independent-review.md.raw').write_bytes(b)
(d/'t01-config-reception.json').write_text(json.dumps({'supplierRef':ref,'base':base,'exactTwoConfigFiles':checks,'fullDiffAndIndependentReportRead':True,'independentReport':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'generatorExcepted':False,'frozenAssetsModified':False,'indexEmpty':not g('diff','--cached','--name-only'),'role':'limited historical exceptions; not semantic repair'},ensure_ascii=False,indent=2)+'\n');print('two precise configurations received and report identity verified')
