from pathlib import Path
import os,subprocess,json,hashlib,datetime,time
w=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-pytest8-supplier-integration');r=w/'docs/reviews/I05/pytest8-consumer-checks';label='fullcheck-02'
assert not (r/(label+'.json')).exists() and not (r/(label+'.running.json')).exists()
paths=['AGENTS.md','pyproject.toml','.prettierignore','package.json','package-lock.json','uv.lock','packages/engine/pyproject.toml','scripts/build-engine.mjs','scripts/generate-i05-source-package-inputs.py','packages/engine/src/ontolearn_engine/semantic.py','packages/engine/src/ontolearn_engine/semantic_source_package_probe.py','packages/engine/tests/test_semantic_source_package_probe.py']
files=[]
for p in paths:
 b=(w/p).read_bytes();files.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
env=os.environ.copy();over={'PYTHONDONTWRITEBYTECODE':'1','UV_CACHE_DIR':str(w/'build/i05-pytest8/uv-cache'),'UV_LINK_MODE':'copy','RUFF_CACHE_DIR':str(w/'build/i05-pytest8/ruff-cache'),'TMPDIR':str(w/'build/i05-pytest8/tmp'),'PYTEST_ADDOPTS':'--basetemp=build/i05-pytest8/fullcheck-02 --junitxml=build/i05-pytest8/fullcheck-02.junit.xml'};env.update(over)
argv=['npm','run','check'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic();rec={'argv':argv,'cwd':str(w),'startedUtc':start,'environmentOverrides':over,'beforeFiles':files,'head':subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip()}
with (r/(label+'.stdout.raw')).open('xb') as out,(r/(label+'.stderr.raw')).open('xb') as err:
 p=subprocess.Popen(argv,cwd=w,env=env,stdout=out,stderr=err);rec['ownedLauncherPid']=p.pid;(r/(label+'.running.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');code=p.wait()
rec.update(endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-begin,exitCode=code,streams={})
for n in ['stdout','stderr']:
 p=r/(label+'.'+n+'.raw');b=p.read_bytes();rec['streams'][n]={'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rec['boundSourceBytesUnchangedDuringRun']=all((w/x['path']).stat().st_size==x['bytes'] and hashlib.sha256((w/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in files)
j=w/'build/i05-pytest8/fullcheck-02.junit.xml'
if j.exists():
 b=j.read_bytes();rec['junit']={'path':str(j.relative_to(w)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(r/(label+'.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rec,ensure_ascii=False))
raise SystemExit(code)
