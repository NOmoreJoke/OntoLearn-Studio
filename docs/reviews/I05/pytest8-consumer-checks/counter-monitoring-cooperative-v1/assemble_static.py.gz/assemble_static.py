"""Author-time stdlib byte/AST assembly only. Does not import candidate modules."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2] / '.worktrees/I05-pytest8-supplier-integration'
BASE = '4bb99d99620811766df38d7e29346e3174f82c8c'
FILES = {
    'probe': ('packages/engine/src/ontolearn_engine/semantic_source_package_probe.py', 102749, '2996deca33083754132bf5f4eab8d1e273161b3e5fe722a8ee96856fb5cc0d5b'),
    'tests': ('packages/engine/tests/test_semantic_source_package_probe.py', 76628, 'd7947f3e90a7226b28aada7f7b6ba0c09393d25295700da2d8ffa65e353b2f68'),
}
receipt = {'baseCommit': BASE, 'execution': 'stdlib bytes/hash/AST only; proposed code and tests not executed', 'files': {}}
for role, (path, size, digest) in FILES.items():
    raw = subprocess.check_output(['git', '-C', str(REPO), 'show', f'{BASE}:{path}'])
    assert len(raw) == size and hashlib.sha256(raw).hexdigest() == digest
    source = raw.decode()
    if role == 'probe':
        tree = ast.parse(source)
        node = next(item for item in tree.body if isinstance(item, ast.ClassDef) and item.name == 'CallCounter')
        lines = source.splitlines(keepends=True)
        old = ''.join(lines[node.lineno - 1:node.end_lineno])
        replacement = (OUT / 'CallCounter.proposed.txt').read_text().rstrip() + '\n'
        proposed = source.replace(old, replacement, 1).replace('import base64\n', 'import _thread\nimport base64\n', 1)
        prior = 'dict(counter.counts) if counter is not None else None'
        assert proposed.count(prior) == 1
        proposed = proposed.replace(prior, 'dict(counter.counts)\n                    if counter is not None and getattr(counter, "counts_complete", False) is True\n                    else None', 1)
        before_top = [(type(n).__name__, getattr(n, 'name', None), ast.dump(n, include_attributes=False)) for n in tree.body if not (isinstance(n, ast.ClassDef) and n.name == 'CallCounter')]
        after_tree = ast.parse(proposed)
        # Outside the class, only the import and collector export expression change.
        modified = [n for n in after_tree.body if not (isinstance(n, ast.ClassDef) and n.name == 'CallCounter')]
        assert len(modified) == len(before_top) + 1
        old_export = ast.parse(prior, mode='eval').body
        new_export = ast.parse('dict(counter.counts) if counter is not None and getattr(counter, \"counts_complete\", False) is True else None', mode='eval').body
        class Normalize(ast.NodeTransformer):
            replacements = 0
            def visit_ClassDef(self, item):
                return ast.Pass() if item.name == 'CallCounter' else self.generic_visit(item)
            def visit_Import(self, item):
                return None if [part.name for part in item.names] == ['_thread'] else item
            def visit_IfExp(self, item):
                if ast.dump(item) == ast.dump(new_export):
                    self.replacements += 1
                    return old_export
                return self.generic_visit(item)
        normalizer = Normalize()
        normalized_after = normalizer.visit(after_tree)
        assert normalizer.replacements == 1
        normalized_before = Normalize().visit(tree)
        assert ast.dump(normalized_before) == ast.dump(normalized_after)
    else:
        proposed = source.replace('import sys\n', 'import sys\nimport threading\nimport types\n', 1) + (OUT / 'tests.append.proposed.txt').read_text()
    ast.parse(proposed)
    candidate = proposed.encode()
    (OUT / f'{role}.proposed.py').write_bytes(candidate)
    patch = ''.join(difflib.unified_diff(source.splitlines(keepends=True), proposed.splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path))
    (OUT / f'{role}.unapplied.patch').write_text(patch)
    receipt['files'][role] = {'path': path, 'beforeBytes': size, 'beforeSha256': digest, 'proposedBytes': len(candidate), 'proposedSha256': hashlib.sha256(candidate).hexdigest(), 'ASTParsed': True}
(OUT / 'static-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))
