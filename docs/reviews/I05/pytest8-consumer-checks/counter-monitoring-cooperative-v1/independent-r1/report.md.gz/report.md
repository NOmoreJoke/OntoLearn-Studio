# cooperative-v1 独立静态审查 r1

结论：**计数器主体在 root 已澄清的合作域内获得 Limited Static Pass；当前完整提案需修复两处真实 API 单元隔离缺陷，再固定新件审查。现件不具备有限 unit 直接运行放行条件。** 没有实际 monitoring、线程或 pytest 结果。两个具体缺陷在测试恢复路径，不以任意未知槽状态不可枚举为阻断，也不否认经公开申请与有限 callback exchange 的合作方案。

## 固定身份与实际审查

2026-10-23，独立逐字审读 design.md、unit-plan.md、CallCounter.proposed.txt、两份精确 patch、追加测试，以及 assembler/source/receipt；完整候选用独立字节重建与 AST 比较，未执行作者 assembler 或候选。固定 manifest 为 1842B/3faae250576dafa862e506735f56bb4bd164e70ba867f454c23953d5c3cc95f3，11 成员全部逐字节核符。

实际 HEAD 为 4bb99d99620811766df38d7e29346e3174f82c8c。probe 当前与固定 Git blob 均为 102749B/2996deca33083754132bf5f4eab8d1e273161b3e5fe722a8ee96856fb5cc0d5b；tests 均为 76628B/d7947f3e90a7226b28aada7f7b6ba0c09393d25295700da2d8ffa65e353b2f68。完整候选分别为 109381B/fb60b0b45c977d2d7e4134b23f170bc144b28d41ccf1af3338b5502477152e3f、96545B/697aa37be4590951a6a0d7a328de416f49baf8320a6b80bf657c07de9e5825ed。两 patch 精确等于固定前像至完整候选的 unified byte diff。

独立 AST 归一化确认：probe 类外仅新增 _thread import 与一处 finally 导出完整性 guard；tests 等于完整旧字节加 threading/types imports 及原样 append。无业务 callable、expected、417、预算、selector、固定资产、frozen guard、canonical pin 或身份检查修改。完整逐项字节收据见 proof.json。

## 阻断现件运行的两个具体缺陷

**F1 [P1] 真实单元会丢失释放槽原有 callback；失败清理还可能撤销从未由本测试改变的状态。** 位置为 tests.proposed.py:2168、2196–2199 与 2251、2267–2270。`assert register_callback(..., ours) is None` 已经先交换，再断言。合作域允许释放 name 后残留 callback：若 ID2 free、global/新 target local 均 0、PY_START 原对象为 foreign，则 DISABLE 单元第2168行已换入 disabling，断言抛出；finally 以 None 撤销而没有保存/恢复 foreign，最后释放 name。PY_RETURN 残留对应第2251行同样成立。这不需要恶意接管或 ABA，正是已承认的正常历史残留。

更早的 global/local 前置断言失败时，测试尚未装自己的 callback，finally 仍无条件 register None；若目标 mask 原有非零，还会无条件清零。get_tool(None) 与 acquired=True 只证明此时获名字，不能证明拥有这些先前状态。修正必须记录精确已改资源：保存 register 返回对象；旧非 None 立即恢复并失败，不能继续造 DISABLE 历史或伪装 clean；只有本方实际设过的 local/callback 才撤销。前置断言失败仅释放本方 name，保存原残留。它不要求查其他 events 或 all-code-local。

**F2 [P1] unknown-code 单元释放名字后到重新申请之间发生失败，finally 跳过本测试残留清理。** 第2253–2254行 free 后 owned=False；第2259行 count、2260行完整性、2261行 delivery 或2262行 mask 任一断言失败，均跳到 finally，第2267行 false，留下本测试新设 unrelated local(PY_START|PY_RETURN) 与 foreign_return。例：被测计数器有真实漏计，退出已正常 free，count 断言失败；本测试留下回调/事件，后续单元就在污染环境运行。这是测试错误时最需要清理的路径，不能只保护成功路径。

修正应把“当前持有哪个 reservation”与“仍有本方需要恢复的历史残留”分开记录；在 finally 若 name 确认 free，公开重新申请本测试 cleanup name 后撤销确知自己创建的 unrelated mask、恢复确知 prior callback；若已有不确定 owner 或 counter quarantine，保留证据并停止，不清别人状态。异常/断言失败不可跳过回滚；回滚本身失败要使本次有限运行失败并停止，不能以成功清理作结。

`--maxfail=1` 是必要隔离上限，防失败后继续执行其他单元；它不能恢复丢失的 foreign callback，也不能补齐本测试跳过的恢复。因此不能只改命令就把 F1/F2 判为已修。

## 主体路径的静态评价与边界

稳定 bound callback 在构造时缓存，注册与恢复使用同一对象 identity；目标用 `is` 去重，两个 distinct-but-equal CodeType 不被集合合并；same-code 双角色保留两个独立 if。owner ident 存于 with 生命周期内，其他线程只过滤不加数；普通同步函数 flags 0x2A0 排除 generator/coroutine/async-generator，符合 [v3.12.12 code.h](https://github.com/python/cpython/blob/v3.12.12/Include/cpython/code.h#L166-L178)。递归实际入口累计，alias 仍取真实 code。未证明所有解释器事件仅发生在这两个 code，也不量化性能。

申请前 existing profile、occupied name 拒绝；申请后 global/两个 target local 非零拒绝并保存原残留。PY_START exchange 的旧对象非 None 经统一回滚恢复再拒绝，未启用目标 mask；其他 events callback/unknown-code masks 不清、不遍历，已有观察器可继续存在。此范围没有发现由它们单独造成双 identity 错计的静态反例；监控 callback 内递归监控受解释器 tracing guard 抑制，不能把 callback 自身内部调用扩张为无限域计数保证。工具 name 是合作协调约定，不是抵抗任意同进程接管的令牌。

每个 setter 前先登记 attempted；set 后要求读回精确 PY_START。普通 setup/callback TypeError 包为私有 ProbeFault，避免 collector missing-keyword 业务分类误接；callback 任一 BaseException 设置永久 _callback_failed，即使 body catch 也使退出完整性失败。setup KBI 在清理成功后保留传播；callback KBI/SystemExit 当场传播，但退出会因已记录 callback failure 变成私有完整性失败，不可声称最终外层异常仍原类。cleanup 记录首个异常、试其余已确认步骤，遇 restore/mask/global 不确定性保留 reservation，不 blind free；这与文档“清理私有失败”分工相符。

cleanup 发现 actual callback 不是缓存对象时先尝试恢复实际 foreign，再拒绝并 quarantine；audit 阻止交换发生在真实 mutation 之前。目标 mask 被改成0会判无效；外国 mask 不清；外来 profile 不回滚。callback 曾失败后，完整性不能由资源最终干净而重新变 True。本轮未见主体常态计数/可靠0绕过。

collector finally 仅内部 counts_complete 严格 True 时导出 top-level dict，否则 None；真实零需要已完整退出。业务异常但监控完整正常清理可以保留真实计数，进入失败无 flag 的替身必须 None；未执行原零、instrumentation=False 原 None 不变。**scopeStages 保留既有部分 stage delta，只是 partial diagnostic；top-level None + failed terminal 绝不表示各层计数可靠。** 这按当前验收边界记录，不扩大为另一个必改项。

## 官方3.12.12与 DISABLE 的正反例

本轮只读重核固定官方源：free 只释放 name，register 返回被替换 callback，审计先于交换；set_local 相同 mask 直接返回，mask 写入后重 instrument 可能失败。对应 [instrumentation.c](https://github.com/python/cpython/blob/v3.12.12/Python/instrumentation.c#L1699-L1853)；free 不清 callback/events 的公开约定见 [固定版本文档](https://github.com/python/cpython/blob/v3.12.12/Doc/library/sys.monitoring.rst#L43-L74)。

静态反例成立：旧 callback 返回 DISABLE，但 declared target mask 仍 PY_START；相同 mask 重设早返，不能复活。候选准入非零拒绝，未清别人的 target。静态正例成立：历史 owner 已完成0，再由本方0→PY_START产生新增 bit，精确 target 重 instrument；不用 restart_events，也不需清其他 code。两真实参数单元的预期与这个源码关系一致，**运行结果仍未知**；F1/F2 修复前不能把其 finally 称安全清理。

DISABLE 测试在 counter cleanup quarantine 后 acquired=False，且 name 非 free 时跳过清理：这时不越权接管是正确的失败隔离选择，不是强迫它擦除不确定 state。必须让该失败直接终止有限进程；不能默认 pytest 后续用例会继续且无污染。`--maxfail=1` 应写入正式计划，保留失败原流，待外部按确切所有权另行处置。

## 未来有限命令与证据级别

新增21函数/34参数展开 case，加原四函数预计38 case；独立 AST fixture 参数闭包只有 probe/canonical/real_resources 与内置 monkeypatch、参数值，没有 full_run/b1_selector_runs module fixtures。invalid-entry unit 虽调用 full-v1 suite 入口，但替身在 __enter__ 拒绝、首次业务 dispatch 前终止；不能称产品417验证。未 collect-only，也未启动此入口。

**先修 F1/F2、固定新 manifest、复核后，再由 root 发实施/运行票。** root 绑定 CPython3.12.12 且已具 pytest 的解释器后，建议从主树 cwd 串行执行下列精确选择；这里的 python 必须解析到该获票解释器，无解释器或收集结果的现成证明：

```sh
python -B -m pytest packages/engine/tests/test_semantic_source_package_probe.py --maxfail=1 -k '(test_monitor_ or test_call_counter_counts_real_code_identity_and_restores_hook or test_call_counter_existing_hook_fails_without_overwriting_it or test_call_counter_restores_hook_on_real_policy_rejection or test_imported_probe_classes_have_only_canonical_module_identity)'
```

不加 xdist/线程化执行器，不运行其他测试文件、不运行 full_run/B1/benchmark/完整检查。实际 worker thread 仅为已声明单元；单位测试仍涉及真实 canonical resources/import，不是纯状态机证明。后续真实投递、正常及失败清理、fingerprint、PYZ/native、性能/120秒预算均未验证；源码主体实现尚未应用。完整 engine 不能据此称 Pass。旧报告及作者材料保持原字节，只有本 independent-r1 目录新写。
