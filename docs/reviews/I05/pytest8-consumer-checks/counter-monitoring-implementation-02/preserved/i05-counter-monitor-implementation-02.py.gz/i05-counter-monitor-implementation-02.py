import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/kyle/Documents/工作/知爻/本体')
TICKET_PATH = ROOT / 'iteration-control/2026-10-21-weekly-release/.private/I05-counter-cooperative-v2-finite-implementation-ticket-20261023.json'
TICKET_SHA = '58e100ba45a2c8e6cfa56c05e9e6b04853840838e9075809b62a21db6fac97a3'
assert hashlib.sha256(TICKET_PATH.read_bytes()).hexdigest() == TICKET_SHA
TICKET = json.loads(TICKET_PATH.read_bytes())
REPO = Path(TICKET['cwd'])
PROPOSAL = Path(TICKET['proposalManifest']['path']).parent
OUT = REPO / 'docs/reviews/I05/pytest8-consumer-checks/counter-monitoring-implementation-02'
assert not OUT.exists()
OUT.mkdir()
ENV = os.environ.copy()
ENV.update(TICKET['environmentOverlay'])
COMMANDS = []
RECEIPT = {'format': 'I05-counter-monitor-implementation/1', 'ticketPath': str(TICKET_PATH), 'ticketSha256': TICKET_SHA, 'cwd': str(REPO), 'baseHEAD': TICKET['baseHEAD'], 'environmentOverlay': TICKET['environmentOverlay'], 'commands': COMMANDS, 'actualPytestRun': False, 'status': 'preflight'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(RECEIPT, ensure_ascii=False, indent=2) + '\n')

def identity(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)}

def astsha(raw):
    return sha(ast.dump(ast.parse(raw), include_attributes=False).encode())

def run(label, argv):
    stdout_path = OUT / (label + '.stdout.raw')
    stderr_path = OUT / (label + '.stderr.raw')
    row = {'label': label, 'argv': argv, 'cwd': str(REPO), 'environmentOverlay': TICKET['environmentOverlay'], 'startUTC': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    COMMANDS.append(row)
    start = time.monotonic()
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=REPO, env=ENV, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        save()
        print(json.dumps({'label': label, 'pid': child.pid, 'state': 'running'}), flush=True)
        row['exitCode'] = child.wait()
    row['endUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row['elapsedSeconds'] = time.monotonic() - start
    row['stdout'] = identity(stdout_path)
    row['stderr'] = identity(stderr_path)
    save()
    print(json.dumps({'label': label, 'exitCode': row['exitCode'], 'elapsedSeconds': row['elapsedSeconds']}), flush=True)
    if row['exitCode']:
        RECEIPT['status'] = 'stopped-command-failure'
        RECEIPT['firstFailure'] = label
        save()
        raise SystemExit(1)
    return row

try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == TICKET['baseHEAD']
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=REPO)
    manifest_raw = (PROPOSAL / 'manifest.json').read_bytes()
    assert sha(manifest_raw) == TICKET['proposalManifest']['sha256']
    for row in json.loads(manifest_raw)['members']:
        b = (PROPOSAL / row['path']).read_bytes()
        assert (len(b), sha(b)) == (row['bytes'], row['sha256'])
    reception = TICKET['rootStaticReception']
    b = Path(reception['path']).read_bytes()
    assert (len(b), sha(b)) == (reception['bytes'], reception['sha256'])
    interpreter = (REPO / '.venv/bin/python').resolve(strict=True)
    assert str(interpreter) == TICKET['interpreter']['resolved']
    assert sha(interpreter.read_bytes()) == TICKET['interpreter']['sha256']
    RECEIPT['interpreter'] = identity(interpreter)
    RECEIPT['venvConfig'] = identity(REPO / '.venv/pyvenv.cfg')
    RECEIPT['ruff'] = identity(Path(TICKET['ruffExecutable']))
    paths = TICKET['onlyProductPaths']
    before = {}
    for role, path in zip(['probe', 'tests'], paths, strict=True):
        raw = (REPO / path).read_bytes()
        fixed = subprocess.check_output(['git', 'show', TICKET['baseHEAD'] + ':' + path], cwd=REPO)
        assert raw == fixed
        before[path] = {**identity(REPO / path), 'ASTSha256': astsha(raw)}
    protected = ['AGENTS.md', 'pyproject.toml', '.prettierignore', 'uv.lock', 'packages/engine/pyproject.toml', 'scripts/build-engine.mjs', 'packages/engine/entrypoint.py', 'packages/engine/src/ontolearn_engine/semantic.py', 'packages/engine/src/ontolearn_engine/semantic_build_provenance.py', 'packages/engine/tests/test_semantic_build_provenance.py', 'docs/reviews/T03/i05-m08-provenance-20261023/private-contract-v1.json', 'scripts/generate-i05-source-package-inputs.py', 'packages/contracts/src/index.ts', 'apps/desktop/src/preload/index.ts']
    protected_before = {path: identity(REPO / path) for path in protected}
    RECEIPT['beforeFiles'] = before
    RECEIPT['protectedBeforeFiles'] = protected_before
    patches = [PROPOSAL / 'probe.unapplied.patch', PROPOSAL / 'tests.unapplied.patch']
    for path, expected in zip(patches, TICKET['patchSHA256'], strict=True):
        assert sha(path.read_bytes()) == expected
    RECEIPT['status'] = 'preflight-verified'
    save()
    run('01-apply-check', ['git', 'apply', '--check', *map(str, patches)])
    run('02-apply', ['git', 'apply', *map(str, patches)])
    proposed_ast = {}
    for role, path in zip(['probe', 'tests'], paths, strict=True):
        raw = (REPO / path).read_bytes()
        assert raw == (PROPOSAL / (role + '.proposed.py')).read_bytes()
        proposed_ast[path] = astsha(raw)
    RECEIPT['appliedExactProposal'] = True
    RECEIPT['appliedFiles'] = {path: {**identity(REPO / path), 'ASTSha256': proposed_ast[path]} for path in paths}
    save()
    run('03-format', [TICKET['ruffExecutable'], 'format', *paths])
    for path in paths:
        assert astsha((REPO / path).read_bytes()) == proposed_ast[path], path
    RECEIPT['formatASTIdentical'] = True
    RECEIPT['formattedFiles'] = {path: {**identity(REPO / path), 'ASTSha256': astsha((REPO / path).read_bytes())} for path in paths}
    save()
    run('04-ruff-check', [TICKET['ruffExecutable'], 'check', *paths])
    run('05-format-check', [TICKET['ruffExecutable'], 'format', '--check', *paths])
    assert not (REPO / 'build/i05-pytest8/monitor-units-01').exists()
    assert not (REPO / 'build/i05-pytest8/monitor-units-01.junit.xml').exists()
    RECEIPT['actualPytestRun'] = True
    save()
    run('06-monitor-units', TICKET['pytestArgv'])
    RECEIPT['status'] = 'finite-command-passed'
except BaseException as error:
    RECEIPT["launcherException"] = {"class": type(error).__name__, "message": str(error)}
    if RECEIPT["status"] not in ("stopped-command-failure", "finite-command-passed"):
        RECEIPT["status"] = "stopped-launcher-failure"
    save()
    raise
finally:
    if 'paths' in globals():
        RECEIPT['afterFiles'] = {path: {**identity(REPO / path), 'ASTSha256': astsha((REPO / path).read_bytes())} for path in paths}
    if 'protected_before' in globals():
        after = {path: identity(REPO / path) for path in protected}
        RECEIPT['protectedAfterFiles'] = after
        RECEIPT['protectedFilesUnchanged'] = after == protected_before
    junit = REPO / 'build/i05-pytest8/monitor-units-01.junit.xml'
    if junit.exists():
        RECEIPT['junit'] = identity(junit)
    save()
    print(json.dumps({'status': RECEIPT['status'], 'receipt': str(OUT / 'receipt.json'), 'actualPytestRun': RECEIPT['actualPytestRun']}), flush=True)
