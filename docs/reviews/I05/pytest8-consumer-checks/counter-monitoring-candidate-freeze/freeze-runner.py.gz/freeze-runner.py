import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
ROOT = Path('/Users/kyle/Documents/工作/知爻/本体')
REPO = ROOT / '.worktrees/I05-pytest8-supplier-integration'
OUT = REPO / 'docs/reviews/I05/pytest8-consumer-checks/counter-monitoring-candidate-freeze'
assert not OUT.exists()
OUT.mkdir()
BASE = '4bb99d99620811766df38d7e29346e3174f82c8c'
EXPECTED = {'packages/engine/src/ontolearn_engine/semantic_source_package_probe.py': '63a6b4a6ead4e05fe28b3384c0e1f70455039533763a5c4b585809704ce41d18', 'packages/engine/tests/test_semantic_source_package_probe.py': '0185e7b0bc7d6aa8c301e10a8847547706be39cfff05971c8df3f27c8d2b333a'}
R = {'format': 'I05-counter-two-product-freeze/1', 'baseHEAD': BASE, 'commands': [], 'independentReportSha256': '1651d1209baa470f547b134e002022c4e8b53d484f5582c34bbfe37565565766', 'overall': 'NotPass; only finite38 gate passed', 'noPush': True}
def sha(b): return hashlib.sha256(b).hexdigest()
def save(): (OUT / 'receipt.json').write_text(json.dumps(R, ensure_ascii=False, indent=2) + '\n')
def run(label, argv):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    row = {'label': label, 'argv': argv, 'cwd': str(REPO), 'startUTC': start, 'endUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': result.returncode}
    for stream in ['stdout', 'stderr']:
        data = getattr(result, stream);p = OUT / (label + '.' + stream + '.raw');p.write_bytes(data);row[stream] = {'path': p.name, 'bytes': len(data), 'sha256': sha(data)}
    R['commands'].append(row);save();assert result.returncode == 0, (label, result.stderr.decode())
    return result.stdout
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=REPO)
for path, digest in EXPECTED.items(): assert sha((REPO/path).read_bytes()) == digest
assert sha((REPO/'AGENTS.md').read_bytes()) == 'de15f6ce13795bb26fbf9807130f475fcac1e16be142bee62d70058056a5c8c4'
report = ROOT/'outputs/20261023_i05_counter_monitoring_design/actual-implementation-r1/report.md';assert sha(report.read_bytes()) == R['independentReportSha256']
run('01-stage-exact-two', ['git', 'add', '--', *EXPECTED])
assert set(run('02-cached-paths', ['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == set(EXPECTED)
run('03-cached-check', ['git', 'diff', '--cached', '--check'])
run('04-commit', ['git', 'commit', '-m', 'fix(engine): count real entries with local monitoring'])
commit = run('05-read-head', ['git', 'rev-parse', 'HEAD']).decode().strip()
assert set(run('06-commit-paths', ['git', 'show', '--format=', '--name-only', commit]).decode().splitlines()) == set(EXPECTED)
assert run('07-index-empty', ['git', 'diff', '--cached', '--name-only']) == b''
assert subprocess.check_output(['git', 'rev-parse', commit+'^'],cwd=REPO,text=True).strip()==BASE
for path,digest in EXPECTED.items(): assert sha(subprocess.check_output(['git','show',commit+':'+path],cwd=REPO))==digest
R['commit'] = commit;R['productSHA256'] = EXPECTED;R['AGENTSNotStaged'] = True;R['indexEmpty'] = True;R['status'] = 'exact-two-product-committed';save();print(json.dumps({'commit': commit, 'receipt': str(OUT/'receipt.json'), 'status': R['status']}))
