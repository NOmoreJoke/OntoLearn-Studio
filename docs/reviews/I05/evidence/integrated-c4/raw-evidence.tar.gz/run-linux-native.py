from pathlib import Path
import json,subprocess,time
out=Path(__file__).resolve().parent
container="ontolearn-i05-isolated-20261021-v2"
subprocess.run(["docker","exec",container,"sh","-c","chown root:root /i05/node_modules/electron/dist/chrome-sandbox /i05/release/linux-arm64-unpacked/chrome-sandbox && chmod 4755 /i05/node_modules/electron/dist/chrome-sandbox /i05/release/linux-arm64-unpacked/chrome-sandbox && stat -c '%U:%G %a %n' /i05/node_modules/electron/dist/chrome-sandbox /i05/release/linux-arm64-unpacked/chrome-sandbox"],check=True,stdout=(out/"linux-native-sandbox.txt").open("wb"),stderr=subprocess.STDOUT)
base=["docker","exec","-u","node","-w","/i05","-e","HOME=/i05-home","-e","UV_CACHE_DIR=/i05-cache/uv","-e","npm_config_cache=/i05-cache/npm","-e","I05_SEMANTIC_E2E=1","-e","I05_NATIVE_ISOLATED=1"]
records=[]
for mode in ("source","packaged"):
 env=["-e","PLAYWRIGHT_JSON_OUTPUT_FILE=/i05/build/i05-c4-native-"+mode+".json"]
 if mode=="packaged":env += ["-e","ONTOLEARN_PACKAGED_EXECUTABLE=/i05/release/linux-arm64-unpacked/@ontolearndesktop"]
 body="openbox > /i05/build/i05-c4-openbox-"+mode+".txt 2>&1 & manager=$!; trap 'kill $manager 2>/dev/null || true' EXIT; npx playwright test tests/e2e/i05-semantics.spec.ts --reporter=list,json --output=test-results/i05-c4-"+mode
 argv=base+env+[container,"xvfb-run","-a","-s","-screen 0 1280x1024x24","sh","-c",body]
 start=time.monotonic()
 with (out/("linux-native-"+mode+".txt")).open("wb") as log: r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 row={"mode":mode,"argv":argv,"exitCode":r.returncode,"wallSeconds":time.monotonic()-start};records.append(row);(out/"linux-native-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(row),flush=True)
 for src,dest in [("/i05/build/i05-c4-native-"+mode+".json","linux-native-"+mode+"-report.json"),("/i05/test-results/i05-c4-"+mode,"linux-native-"+mode+"-raw"),("/i05/build/i05-c4-openbox-"+mode+".txt","linux-native-"+mode+"-openbox.txt")]:
  subprocess.run(["docker","cp",container+":"+src,str(out/dest)],check=True)
 if r.returncode: raise SystemExit(r.returncode)
