from pathlib import Path
import hashlib,io,json,tarfile
from datetime import datetime
root=Path.cwd();source=root/'build/i05-integrated/c4';out=root/'docs/reviews/I05/evidence/integrated-c4';out.mkdir(exist_ok=False,parents=True);sha=lambda b:hashlib.sha256(b).hexdigest();rows=[];excluded=[]
for p in sorted(source.rglob('*')):
 if not p.is_file():continue
 name=p.relative_to(source).as_posix();reason=None
 if name=='source-export.tar.gz':reason='Derived source transport, original1238 members independently recovered and byte-compared to fixed40c Git/protected guideline; exact gzip wrapper not embedded. See source-recovery-from-git.json.'
 elif name.startswith('binary-inputs/'):reason='Copied actual executable binary, remains local/actual release; full SHA and actual seven compiled modules checked in bundled-code-verification.json. No binary embedded.'
 elif p.name.endswith(('.sqlite','.sqlite-wal','.sqlite-shm','.db','.db-wal','.db-shm','.writer-lock','.pyc')) or '__pycache__' in p.parts:reason='Runtime synthetic SQLite/locks or interpreter cache, excluded by evidence policy.'
 b=p.read_bytes()
 if reason:excluded.append({'originalPath':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b),'reason':reason});continue
 rows.append((name,b,p))
process=root/'build/seal-i05-c4-evidence.py';rows.append(('process/seal-i05-c4-evidence.py',process.read_bytes(),process))
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for n,b,p in rows:
  ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o644;ti.mtime=int(p.stat().st_mtime);tf.addfile(ti,io.BytesIO(b))
with tarfile.open(archive) as tf:
 assert [m.name for m in tf.getmembers()]==[n for n,b,p in rows]
 for m,(n,b,p) in zip(tf.getmembers(),rows):assert tf.extractfile(m).read()==b
index=[{'member':n,'originalPath':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)} for n,b,p in rows]
x={'createdAt':datetime.now().astimezone().isoformat(),'productHead':'1a79731091e671c497824c94e12dae34a4e8609b','productAndTestsHead':'40c18ea1b9ce4fef9a5235718fd7e622e2d06cc4','executionInputCount':205,'sourceArchiveMemberCount':1238,'archive':'raw-evidence.tar.gz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'memberCount':len(rows),'uncompressedBytes':sum(len(b) for n,b,p in rows),'allMembersReadBackVerified':True,'scope':'All actual C4 check/source/old+new package/string-stdio/C4/B1/native raw, all independent string regressions/prototype/implementation review/fullpayload/first failures and scripts. Source/package/independent run attribution and v1/v2 fixture distinctions preserved. Complete raw retained here because no actual CI artifact yet. Existing C1/C2/C3 originals unchanged.','notIncluded':'All actual synthetic SQLite/WAL/SHM/lock/environment/cache, binaries/app and derived source transport excluded explicitly below. No nested portable archive containing SQLite. Full input specs/seed metadata/original hashes and complete actual output retained; regenerate a fresh seed for future replay, no promise to reconstruct original SQLite bytes.42 of independent44 files and192 of202stdio source artifacts included, exact original manifests + inclusion/exclusion receipts retained; two deterministic Git tar originals actually rebuilt and byte-compared.','excluded':excluded,'members':index}
(out/'manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
(out/'internal-review.md.raw').write_bytes((source/'internal-review/report.md').read_bytes())
print(json.dumps({k:v for k,v in x.items() if k not in ['members','excluded']},ensure_ascii=False));print('excluded',len(excluded))
