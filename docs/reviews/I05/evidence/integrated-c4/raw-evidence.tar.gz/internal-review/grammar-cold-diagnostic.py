import json
from pathlib import Path
from rdflib import Graph
from rdflib.plugins.sparql import parser,operators
from ontolearn_engine.semantic_query import prepare_lexical_query
from ontolearn_engine.semantic import query

def snapshot():
 seen={};pending=[parser.Query]
 while pending:
  p=pending.pop()
  if id(p) in seen:continue
  seen[id(p)]=(tuple(map(id,p.parseAction)),tuple(map(id,p.recurse())))
  pending.extend(p.recurse())
 return seen
before=snapshot();prepare_lexical_query('SELECT ?v WHERE { BIND(STRDT("x",<http://www.w3.org/2001/XMLSchema#string>) AS ?v) }');prepared=snapshot();query(Graph(),'SELECT ?v WHERE { BIND(STRDT("x",<http://www.w3.org/2001/XMLSchema#string>) AS ?v) }');after=snapshot()
print(json.dumps({'beforeCount':len(before),'afterPrepareCount':len(prepared),'afterQueryCount':len(after),'prepareChanged':before!=prepared,'queryChangedFromPrepare':prepared!=after,'trueFilterVarsKeys':list(vars(operators.TrueFilter))}))
