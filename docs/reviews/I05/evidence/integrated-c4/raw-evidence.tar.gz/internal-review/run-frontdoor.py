from pathlib import Path
import subprocess,os,json,time
b=Path(__file__).resolve().parent;own=b.parents[1];out=[]
for mode,src,py in [('old5',own/'build/c3-independent/source-69598f3',own/'build/c3-independent/source-69598f3/.venv/bin/python'),('worker6',b/'source-1a79731',b/'source-1a79731/.venv/bin/python'),('stdio6',b/'source-1a79731',b/'source-1a79731/.venv/bin/python')]:
 env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')};env['PYTHONDONTWRITEBYTECODE']='1';cmd=[str(py),'-B',str(b/'frontdoor.py'),str(src),str(b),mode];start=time.monotonic();p=subprocess.run(cmd,cwd=b,env=env,capture_output=True,timeout=120)
 (b/(mode+'.stdout.txt')).write_bytes(p.stdout);(b/(mode+'.stderr.txt')).write_bytes(p.stderr);out.append({'mode':mode,'command':cmd,'exit':p.returncode,'elapsed':time.monotonic()-start});(b/'frontdoor-commands.json').write_text(json.dumps(out,indent=2)+'\n');print(mode,p.returncode,p.stdout.decode(),p.stderr.decode());assert p.returncode==0
