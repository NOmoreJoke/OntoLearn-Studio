import json,sys,copy,hashlib
from pathlib import Path
from uuid import uuid4
source=Path(sys.argv[1]).resolve();base=Path(sys.argv[2]).resolve();mode=sys.argv[3]
sys.path.insert(0,str(source/'packages/engine/tests'))
from test_semantic_lexical_runtime import DirectWorker,completed,parameters
from test_resident_runtime import Session
from ontolearn_engine import semantic
from ontolearn_engine.resources import CONTRACT,IMPLEMENTATION,LIMITS
from ontolearn_engine.job_store import JobStore,JobFault
from ontolearn_engine.storage import digest
from rdflib import RDF,XSD
uid=lambda:str(uuid4());TYPE=str(RDF.type);XS=str(XSD.string);plain='"x"';typed=f'"x"^^<{XS}>'
subjects=['urn:both','urn:plain','urn:typed']
facts=[[s,TYPE,'<urn:All>'] for s in subjects]+[['urn:both',TYPE,'<urn:Both>']]+[[s,'urn:p',plain] for s in subjects]+[['urn:language','urn:lang','"x"@en'],['urn:number','urn:n',f'"1"^^<{XSD.integer}>']]
queries={'projection':f'SELECT ?s ?o (DATATYPE(?o) AS ?d) (sameTerm(?o,{typed}) AS ?same) WHERE {{ ?s <urn:p> ?o }}','typedAsk':f'ASK {{ <urn:plain> <urn:p> {typed} }}','plainAsk':'ASK { <urn:typed> <urn:p> "x" }','typedJoin':f'SELECT ?s WHERE {{ VALUES ?v {{ {typed} }} ?s <urn:p> ?v }}'}
expressions=[f'STRDT("x",<{XS}>)',f'STR({typed})',f'CONCAT("",{typed})',f'SUBSTR(STRDT("xy",<{XS}>),1,1)',f'REPLACE(STRDT("a",<{XS}>),"a","x")',f'LCASE(STRDT("X",<{XS}>))']
for i,e in enumerate(expressions):queries[f'runtime{i}']=f'SELECT ?s WHERE {{ BIND({e} AS ?v) ?s <urn:p> ?v FILTER(sameTerm(?v,"x")) }}'
def shape(i,target,clause):return f'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:S-{i}> a sh:NodeShape; sh:targetClass <urn:{target}>; sh:property <urn:P-{i}> . <urn:P-{i}> sh:path <urn:p>; {clause} .'
shapes={'datatype':shape('dt','All',f'sh:datatype <{XS}>'),'inPlain':shape('ip','All','sh:in ("x")'),'inTyped':shape('it','All',f'sh:in ({typed})'),'max1':shape('mx','Both','sh:maxCount 1'),'min2':shape('mn','Both','sh:minCount 2')}
rules=[{'layer':'rule','id':n,'value':{'enabled':True,'when':[['?s','<urn:p>',t]],'then':['?s',f'<urn:{n}>','<urn:yes>']}} for n,t in [('plain-matched',plain),('typed-matched',typed)]]+ [{'layer':'rule','id':n,'value':{'enabled':True,'when':[['<urn:both>',f'<{TYPE}>','<urn:Both>']],'then':['<urn:both>','<urn:p>',t]}} for n,t in [('emit-plain',plain),('emit-typed',typed)]]
definitions=[{'layer':'ontology','id':'empty','value':{'triples':[]}},*rules,*[{'layer':'query','id':n,'value':{'text':t}} for n,t in queries.items()],*[{'layer':'constraint','id':n,'value':{'enabled':True,'turtle':t}} for n,t in shapes.items()]]
assert Path(semantic.__file__).resolve()==source/'packages/engine/src/ontolearn_engine/semantic.py'
db=base/(mode+'.sqlite');s=JobStore(db,contract=CONTRACT);s.create_project('strings');project=s.public_project('strings');s.commit('strings',0,uid(),uid(),definitions=definitions,manual=[{'id':digest(t),'subject':t[0],'predicate':t[1],'object':t[2]} for t in facts]);original=s.state('strings');s.close()
backend=Session(db,[project],test_mode=False) if mode=='stdio6' else DirectWorker(db,project);records=[]
try:
 requests=[('reasoning.execute','all'),*[('query.execute',n) for n in list(queries)[:4]],*[('validation.execute',n) for n in shapes]]
 for cap,n in requests:records.append(completed(backend,parameters(project,cap,n)))
 rid=records[0]['metadata']['resultId']
 for n in ['max1','min2']:records.append(completed(backend,parameters(project,'validation.execute',n,derived=rid)))
 if mode!='old5':
  for n in list(queries)[4:]:records.append(completed(backend,parameters(project,'query.execute',n)))
finally:backend.close()
s=JobStore(db,contract=CONTRACT)
for record in records:
 m,p=s.semantic_result(project,record['metadata']['resultId']);assert m==record['metadata'];record['payload']=p;assert s.result(m['resultId'])['payload']==record['rows'];assert m['implementation']==IMPLEMENTATION
assert s.state('strings')==original;s.close()
if mode!='old5':
 rs=records[0]['payload']['reasoning'];expected=[]
 for name in ['emit-plain','emit-typed','plain-matched','typed-matched']:
  for sub in ['urn:both'] if name.startswith('emit') else subjects:
   fact=[f'<{sub}>',f'<{TYPE}>','<urn:Both>'] if name.startswith('emit') else [f'<{sub}>','<urn:p>',plain]
   result=['<urn:both>','<urn:p>',plain] if name.startswith('emit') else [f'<{sub}>',f'<urn:{name}>','<urn:yes>']
   expected.append({'rule':name,'result':result,'inputs':[fact],'basis':[fact]})
 oracle={'rdfs':[],'rdfsEvidence':[],'rules':sorted([list(t) for t in {tuple(e['result']) for e in expected}]),'evidence':expected,'warnings':['RULE_CHAIN_UNSUPPORTED:plain-matched','RULE_CHAIN_UNSUPPORTED:typed-matched']};assert rs==oracle and len(rs['rules'])==7 and len(rs['evidence'])==8
 expectedrows=[[f'<{s}>'] for s in subjects]
 assert records[2]['payload']['query']=={'type':'ASK','value':True} and records[3]['payload']['query']=={'type':'ASK','value':True}
 assert records[4]['payload']['query']=={'type':'SELECT','variables':['s'],'rows':expectedrows}
 projection=records[1]['payload']['query'];assert projection=={'type':'SELECT','variables':['s','o','d','same'],'rows':[[f'<{s}>',plain,f'<{XS}>','"true"^^<http://www.w3.org/2001/XMLSchema#boolean>'] for s in subjects]}
 for i,r in enumerate(records[5:12],5):
  report=r['payload']['report'];assert report['conforms']==(r['request']['definitionId']!='min2'),(i,report)
  if r['request']['definitionId']=='min2':assert report['violations']==[{'focus':'<urn:both>','path':'<urn:p>','constraint':'<http://www.w3.org/ns/shacl#MinCountConstraintComponent>','sourceShape':'<urn:P-mn>','value':None,'severity':'<http://www.w3.org/ns/shacl#Violation>'}]
  else:assert report['violations']==[]
 for r in records[12:]:assert r['payload']['query']=={'type':'SELECT','variables':['s'],'rows':expectedrows}
 assert all(r['payload']['executionSemanticsVersion']=='i05-finite-6' for r in records)
else:
 assert records[2]['payload']['query']['value'] is False and records[11]['payload']['report']['conforms'] is True
(base/(mode+'-complete.json')).write_text(json.dumps({'mode':mode,'source':str(source),'implementation':IMPLEMENTATION,'originalState':original,'records':records,'authorityStateUnchanged':True},ensure_ascii=False,indent=2)+'\n')
if mode=='worker6':
 old=json.loads((base/'old5-complete.json').read_text());oldrecord=old['records'][0];p=oldrecord['metadata']['projectId'];oldrid=oldrecord['metadata']['resultId'];b=DirectWorker(base/'old5.sqlite',p);checks=[]
 try:
  assert b.call('result.get',{'projectId':p,'resultId':oldrid})==oldrecord['metadata']
  for historical in [False,True]:
   request=parameters(p,'query.execute','typedJoin',derived=oldrid,snapshot=oldrecord['metadata']['inputSnapshotId'] if historical else None)
   error=b.call('semantic.start',request);assert error=={'code':'IDENTITY_CONFLICT','messageKey':'operation.identityConflict','params':{},'retryable':False};checks.append({'historical':historical,'error':error})
  meta,payload=b.store.semantic_result(p,oldrid);assert meta==oldrecord['metadata'] and payload==oldrecord['payload'] and b.store.result(oldrid)['payload']==oldrecord['rows'];assert b.store.state('strings')==old['originalState']
 finally:b.close()
 s=JobStore(db,contract=CONTRACT);consumer=records[10]['job'];input_=copy.deepcopy(consumer['input'])
 for field,value in [('engineVersion','999.0.0'),('executionSemanticsVersion','i05-finite-5'),('dependencyLockHash','0'*64)]:
  changed={**IMPLEMENTATION,field:value}
  try:s.create_job(project,uid(),'validation.execute',input_,None,changed,LIMITS)
  except JobFault as e:assert e.code=='IDENTITY_CONFLICT';checks.append({'alteredConsumerField':field,'code':e.code})
  else:raise AssertionError('different whole implementation accepted')
 assert s.state('strings')==original;s.close();(base/'history-identity.json').write_text(json.dumps({'oldMetadataPayloadRowsUnchanged':True,'oldFinite5AuthenticReadable':True,'newImplementation':IMPLEMENTATION,'checks':checks},indent=2)+'\n')
print(json.dumps({'mode':mode,'actualCompletedJobs':len(records),'implementation':IMPLEMENTATION,'authorityUnchanged':True}))
