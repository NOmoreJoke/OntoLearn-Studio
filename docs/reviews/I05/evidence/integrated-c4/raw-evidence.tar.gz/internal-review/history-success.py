import json,sys
from pathlib import Path
b=Path(__file__).resolve().parent;src=b/'source-1a79731';sys.path.insert(0,str(src/'packages/engine/tests'))
from test_semantic_lexical_runtime import DirectWorker,completed,parameters
from ontolearn_engine.storage import canonical,digest
old=json.loads((b/'old5-complete.json').read_text());oldr=old['records'][0]
backend=DirectWorker(b/'old5.sqlite',oldr['metadata']['projectId'])
try:
 raw=backend.store._db.execute('SELECT payload,payload_hash,rows_hash FROM semantic_payloads WHERE result=?',(oldr['metadata']['resultId'],)).fetchone()
 assert raw[0].encode('utf-8')==canonical(oldr['payload']).encode('utf-8') and raw[1]==digest(oldr['payload']) and raw[2]==digest(oldr['rows'])
 oldbytes={'canonicalPayloadUtf8MatchesOriginalReceipt':True,'payloadHash':raw[1],'rowsHash':raw[2]}
finally:backend.close()
new=json.loads((b/'worker6-complete.json').read_text());reasoning=new['records'][0];p=reasoning['metadata']['projectId'];backend=DirectWorker(b/'worker6.sqlite',p);records=[];snapshot=reasoning['metadata']['inputSnapshotId']
try:
 for cap,name in [('query.execute','typedJoin'),('validation.execute','max1')]:
  record=completed(backend,parameters(p,cap,name,derived=reasoning['metadata']['resultId'],snapshot=snapshot));meta,payload=backend.store.semantic_result(p,record['metadata']['resultId']);assert meta==record['metadata'] and payload['inputSelection']=='historical' and payload['selectedResultIds']==[reasoning['metadata']['resultId']];record['payload']=payload;records.append(record)
 assert records[0]['payload']['query']=={'type':'SELECT','variables':['s'],'rows':[['<urn:both>'],['<urn:plain>'],['<urn:typed>']]};assert records[1]['payload']['report']=={'conforms':True,'violations':[]};assert backend.store.state('strings')==new['originalState']
finally:backend.close()
(b/'history-success.json').write_text(json.dumps({'oldOriginalPayloadRowsBytesAndHashes':oldbytes,'newHistoricalCompletedJobs':2,'records':records},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'newHistoricalCompletedJobs':2,'oldPayloadBytesVerified':True}))
