import json,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from rdflib import Graph,Literal,URIRef,Variable,XSD
import rdflib
from rdflib.plugins.sparql import parser,operators
from ontolearn_engine.semantic import query,reason,Rule,parse_turtle
from ontolearn_engine.semantic_query import prepare_lexical_query
from ontolearn_engine.semantic_execution import _term
from ontolearn_engine.semantic_offline import SemanticError
from ontolearn_engine import semantic_scopes as scopes
base=Path(__file__).resolve().parent;XS=str(XSD.string);true='"true"^^<http://www.w3.org/2001/XMLSchema#boolean>'
g=Graph();s,p=URIRef('urn:s'),URIRef('urn:p');g.add((s,p,Literal('x')));g.add((s,p,Literal('x',datatype=XSD.string,normalize=False)));original=set(g)
constructors=[f'STRDT("x",<{XS}>)',f'STR("x"^^<{XS}>)',f'CONCAT("",STRDT("x",<{XS}>))',f'SUBSTR(STRDT("xy",<{XS}>),1,1)',f'REPLACE(STRDT("a",<{XS}>),"a","x")',f'UCASE(STRDT("x",<{XS}>))',f'LCASE(STRDT("X",<{XS}>))',f'STRBEFORE(STRDT("xy",<{XS}>),"y")',f'STRAFTER(STRDT("yx",<{XS}>),"y")',f'ENCODE_FOR_URI(STRDT("x",<{XS}>))',f'IF(true,STRDT("x",<{XS}>),1/0)',f'COALESCE(1/0,STRDT("x",<{XS}>))']
cases=[]
for e in constructors:
 expected='"X"' if e.startswith('UCASE') else '"x"';text=f'SELECT ?v (sameTerm(?v,{expected}) AS ?same) WHERE {{ BIND({e} AS ?v) }}';cases.append((text,{'type':'SELECT','variables':['v','same'],'rows':[[expected,true]]}))
cases += [('SELECT ?s ?z WHERE { ?s <urn:p> ?v OPTIONAL { ?s <urn:missing> ?z } }',{'type':'SELECT','variables':['s','z'],'rows':[['<urn:s>',None]]}),('SELECT ?s WHERE { ?s <urn:p> ?v FILTER(1/0) }',{'type':'SELECT','variables':['s'],'rows':[]}),('SELECT ?v WHERE { BIND(1/0 AS ?v) }',{'type':'SELECT','variables':['v'],'rows':[]}),('SELECT ?v WHERE { BIND(COALESCE(?missing,"x") AS ?v) }',{'type':'SELECT','variables':['v'],'rows':[['"x"']]}), (f'SELECT DISTINCT ?v WHERE {{ VALUES ?v {{ "x" "x"^^<{XS}> }} }}',{'type':'SELECT','variables':['v'],'rows':[['"x"']]})]
def state():
 nodes=[];seen=set();pending=[parser.Query]
 while pending:
  n=pending.pop()
  if id(n) in seen:continue
  seen.add(id(n));nodes.append((id(n),type(n).__name__,n.customName,n.resultsName,n.debug,tuple(id(a) for a in n.parseAction)));pending.extend(n.recurse())
 return {'grammar':sorted(nodes),'trueFilterVars':dict(vars(operators.TrueFilter)),'normalize':rdflib.NORMALIZE_LITERALS}
records=[]
for phase in ['cold','external-global-warm']:
 if phase!='cold':list(Graph().query('SELECT ?x WHERE { VALUES ?x { 1 } OPTIONAL { ?x <urn:p> ?z } }'))
 before=state()
 for text,expected in cases:
  actual=query(g,text);assert actual==expected,(phase,text,actual,expected);records.append({'phase':phase,'text':text,'actual':actual})
 with ThreadPoolExecutor(max_workers=3) as pool:
  concurrent=list(pool.map(lambda case:query(g,case[0]),cases[:6]))
 assert concurrent==[c[1] for c in cases[:6]]
 after=state()
 if before!=after:
  (base/'global-state-difference.json').write_text(json.dumps({'phase':phase,'before':before,'after':after},default=repr,indent=2)+'\n')
 assert before==after,'process global mutation'
 for i in range(2):
  q=prepare_lexical_query('SELECT ?s WHERE { ?s <urn:p> ?o OPTIONAL { ?s <urn:missing> ?z } }')
  def walk(x):
   if isinstance(x,dict):
    for v in x.values():yield v;yield from walk(v)
   elif isinstance(x,(list,tuple)):
    for v in x:yield v;yield from walk(v)
  filters=[x for x in walk(q.algebra) if getattr(x,'name',None)=='TrueFilter'];assert filters and all(x is not operators.TrueFilter for x in filters)
  assert before==state()
assert set(g)==original
lexicals=['','x','quote" slash\\','line\nnext','你好','é','e\u0301','\U00010000']
for value in lexicals:
 a,b=Literal(value,normalize=False),Literal(value,datatype=XSD.string,normalize=False);parsed=parse_turtle(f'<urn:s> <urn:p> {a.n3()}, {b.n3()} .');assert set(parsed)=={(s,p,a)} and _term(b.n3())==a
for invalid in ['"x" ', '"x"^^xsd:string','"\\u0078"','"x" . <urn:bad> <urn:p> "y"']:
 try:_term(invalid)
 except SemanticError as e:assert e.code=='RDF_TERM_INVALID'
 else:raise AssertionError(invalid)
controls=parse_turtle(f'<urn:s> <urn:p> "01"^^<{XSD.integer}>, "1"^^<{XSD.integer}>, "x"@en, "x"@EN, "x"@en-US, "x", "x"^^<{XS}> .');assert len(controls)==5
rules=(Rule('a',((s,p,Literal('x',datatype=XSD.string,normalize=False)),),(s,URIRef('urn:out'),Literal('x',datatype=XSD.string,normalize=False))),)
generated=scopes.prepare_validation_scope(g,Graph(),include_derived=True,rules=rules);payload=json.loads(json.dumps(generated.reasoning_result));saved=copy=json.loads(json.dumps(payload));old=scopes.reason
try:
 scopes.reason=lambda *a,**k:(_ for _ in ()).throw(AssertionError('selected recomputation'))
 selected=scopes.project_validation_scope(g,Graph(),include_derived=True,rules=rules,reasoning_result=payload,reasoning_source=generated.provenance['reasoningSource']);assert selected.reasoning_result is payload and payload==saved
finally:scopes.reason=old
assert set(g)==original
out={'cases':records,'phases':2,'additionalConcurrentQueries':12,'privateTrueFilterChecks':4,'processGlobalStateUnchanged':True,'rawGraphUnchanged':True,'lexicalCases':lexicals,'strictNegativeCases':4,'numericLanguageControlGraphSize':len(controls),'selectedNoRecompute':True,'selectedReasoning':payload,'selectedProvenance':selected.provenance}
(base/'pure-query-probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['cases','selectedReasoning','selectedProvenance','lexicalCases']},indent=2))
