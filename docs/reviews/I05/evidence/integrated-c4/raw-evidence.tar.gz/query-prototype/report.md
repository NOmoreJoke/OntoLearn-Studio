# C3 query 字符串身份：局部 Expr callback 方案研究

结论：在 RDFLib 7.6.0、现 C3 允许的 SELECT/ASK＋COUNT 范围，**每次私有 prepared query 的完整常量规范化＋每个私有 Expr 实例原 `_evalfn` 结果规范化**，可在保持原求值路径的同时覆盖 STRDT/STR/CONCAT 等构造后进入 sameTerm、BIND/join、VALUES、DISTINCT 和 COUNT 的字符串身份。必须额外处理 **VALUES 的普通 dict** 与 **OPTIONAL 的全局 TrueFilter Expr 单例**。仅常量规范化或最终结果规范化不够；直接包装所有 Expr 而不复制 TrueFilter 会污染库内单例。

本轮仅独立 prototype，不是主线/Store/worker/包内验收。未修改主树、产品源、依赖文件、global parser/Expr类方法/operators函数/CUSTOM_EVALS 或公共契约；旧 v1 在单独 Python 进程内确实改到了全局 TrueFilter 实例 callback，其漏检及原件完整保留，后续推荐以 fresh-process v2 结果为准。没有将 TA 的比较政策/多 heads 混入当前字符串修复。

## 1. 固定来源与实际运行

- 固定 C3 query 源：`b04569032e94c093e42b7fdc9fcd890df0e832e4:packages/engine/src/ontolearn_engine/semantic_query.py`，只读提取为本目录 `semantic_query_c3.py`，3809 bytes，SHA `5fbe2e8a08f81d7230e2c69c3380d1234df4ed7d14f8c3eef3669a935bf59d8a`。其保留数字词法/相邻正负 token 的私有 grammar clone 不变。
- 独立原环境：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-execution/.venv/bin/python`，实际 RDFLib **7.6.0**、pyparsing **3.3.3**。没有同步/升级/写入库源文件。
- 实际只读库路径：本树 `.venv/lib/python3.12/site-packages/rdflib/plugins/sparql/` 下 `parserutils.py`、`algebra.py`、`operators.py`、`evaluate.py`、`evalutils.py`、`aggregates.py`。所有以下行号属于实际安装7.6.0文件，不拿最新版文档替代固定库。
- graph 由原型手工建立，仅两个真实 RDFLib triples：`urn:s urn:p plain a` 与 `urn:s urn:n integer lexical 01`，不读 Store/用户项目，不伪造 semantic payload。它明确满足**输入图已采用S1 plain表示**的前提；query层方案不代替主线 graph/selected 的字符串身份修复。
- 正式修正版运行命令（新 shell 启动新 Python 进程，exit 0）：

```sh
cd /Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-execution
PYTHONPATH=packages/engine/src .venv/bin/python build/query-string-instance-probe/probe.py > build/query-string-instance-probe/output.json 2> build/query-string-instance-probe/stderr.txt
PYTHONPATH=packages/engine/src .venv/bin/python build/query-string-instance-probe/error_probe.py > build/query-string-instance-probe/error-output.json 2> build/query-string-instance-probe/error-stderr.txt
PYTHONPATH=packages/engine/src .venv/bin/python build/query-string-instance-probe/v1_singleton_audit.py > build/query-string-instance-probe/v1-singleton-audit.json 2> build/query-string-instance-probe/v1-singleton-stderr.txt
```

以上 stderr 全为0 bytes。小型原型按27个query分别运行 `default`、`constants`、`local` 三模式；raw stdout含全部查询观测及每次wrapper/VALUES/TrueFilter计数。未运行产品测试/应用/GUI/网络，未改任何 Store/worker；未量化性能或容量。

## 2. 求值路径与最小实现

### 2.1 规范化仅限同一字符串抽象term

无语言 Literal，datatype为None或XSD.string，采用S1 plain内部表示，**取 `str(literal)` 原解码文本，`Literal(..., normalize=False)`，不用 `Literal(existing_literal)`**，否则现库构造分支会继承旧datatype。None已是plain，可原对象返回作快路径；仅XSD.string实际重建即可。所有语言literal、IRI、Variable、数值/日期literal、SPARQLError及其他对象原样返回。不会trim/NFC/casefold/值化数值，也不改 STRDT 对其他datatype的原库行为。

推荐同主线term helper复用唯一转换函数；query只调用它，不造第二种S身份。不能只对SELECT最后输出替换，因为sameTerm/join/DISTINCT/COUNT已在输出前比较或散列。

### 2.2 完整 walk prepared.algebra 的数据，不使用库 traverse 冒充全覆盖

在 `translateQuery()` 完成之后做本地walker：Literal→上面term函数；CompValue/Expr→按raw `OrderedDict.items()`遍历所有字段；普通dict→递归values；list/tuple递归；`_vars`等set按原成员保留/本地重建。用seen/memo避免对同一Expr二次包装。不要通过 `.expr`/`get` 等带 `ctx` 的接口求值后再遍历，也不去碰函数globals或parser grammar。

关键实证：`algebra.py:400–429` 的 `_traverse()` 只识别list/ParseResults、tuple、CompValue，**不递归普通dict**；`:603–620 translateValues()` 生成 `list[dict[Variable,term]]`，而 `evaluate.py:255–268 evalValues()` 直接把这些值放binding。故只用 `algebra.traverse(prepared.algebra, visitPost=...)` 会漏 VALUES。原型明确覆盖普通dict，`VALUES ?v { "a" "a"^^xsd:string }` 的DISTINCT从两行变一行。UNDEF是库sentinel Python str，不是Literal，原样保留。

### 2.3 对每个私有 Expr 的原 bound `_evalfn` 做返回值包装

库 `parserutils.py:207–227`：Expr构造时 `MethodType(evalfn,self)`；`Expr.eval(ctx)` 负责把 `self.ctx=ctx`、调用 `_evalfn(ctx)`、只捕获 SPARQLError 并返回该对象、最后 `ctx=None`。最小wrapper只做：

```python
original = expr._evalfn   # already bound to this expr
def result(ctx, _original=original):
    return canonical_string_term(_original(ctx))
expr._evalfn = result
```

不要替换Expr.eval方法，不自己 catch/转译异常，不重新绑定原callback到别的self；closure default参数必须固定每个original，避免循环末项capture。建议在安装时校验 callable、`original.__self__ is expr` 及 callable `__func__`（7.6已知布局），布局不符安全Internal，不静默跳过。新的plain函数存实例属性，不需要再MethodType；原boundcallback仍用原Expr的ctx，嵌套 `_value/value()` 继续经每个孩子的Expr.eval。

prepare语法错误仍用原INVALID_QUERY；**本地拓扑/隔离/包装不变量失败应在语法catch之外**成为Internal，不能把私有API漂移报用户语法错误。主线已有外联/函数/aggregate/排序/form guard完全保留，wrapper不新增支持/白名单。

### 2.4 必须先把 operators.TrueFilter 替换为本地 Expr

库 `operators.py:987` 定义模块级 `TrueFilter=Expr(...)`；`algebra.py:38` 导入同一对象，`:362` 无自身FILTER的OPTIONAL直接把它置入LeftJoin。它不来自私有grammar parse的fresh Expr。直接改其 `_evalfn` 是单例修改，且其原Expr.ctx也是共享状态。

在walker处理CompValue/seen之前按 **identity `value is operators.TrueFilter`** 判断（或同一algebra.TrueFilter别名），先验证原boundcallback的self/func，再用原 `__func__` 新建 `Expr(value.name, original.__func__, **raw_fields)`；复制/遍历其已有字段，再进入seen/普通wrapper。不要仅按名字clone任意caller节点，不是deepcopy整个prepared Query（库CompValue重建/绑定有私有坑）；不要保留原boundcallback指向全局self。只跳过TrueFilter包装虽不会改callback，却仍留下它的共享ctx，推荐新本地实例。

主线root已回报采取本地Expr分支；本报告未读该未提交实现，不能替代其自身回归/隔离验证。

## 3. 为什么可覆盖binding、nested、COUNT，而没有改全局 evaluator

- parser `Comp.postParse()`（parserutils.py:249–257）对有evalfn的解析节点每次新建Expr；operators `not_()` / `and_()`（:971–984）也新建Expr。translate阶段生成的Expr已在最终algebra里，包的是它的实例callback；不用改parser.evalfn、operators函数或CUSTOM_EVALS。
- `evalutils._eval():118–137`：Literal/IRI原样，Expr→Expr.eval，Variable查binding。`parserutils.value():74–91` 的nested Expr也走Expr.eval。故STRDT返回在被父sameTerm/CONCAT等消费前已经canonical；IF/COALESCE的分支/错误流程仍原函数，不预先求值所有孩子。
- `evaluate.evalExtend():124–138` 经 `_eval` 取BIND结果再merge；SPARQLError原处理为不绑定，不改。`evalBGP():78–121` 用binding和图term匹配，`evalJoin()/evalLazyJoin():141–165`、VALUES直接binding merge：来自canonical graph、常量和Expr的字符串均plain，后续term匹配可一致。
- `Builtin_sameTerm()`（operators.py:565–568）仍 `a==b`，现在两边实际使用同一string抽象表示。STRDT/CONCAT/STR/REPLACE/SUBSTR/STRLANG等仍原库函数，修改只在实例Expr返回边界。
- `evalDistinct():559–569` 直接散列FrozenBindings；canonical必须发生在此之前。`evalAggregateJoin():462–493` 的group key也经 `_eval`，COUNT accumulator（aggregates.py:61–98）每项经 `_eval(expr,row)`；DISTINCT输入seen的字符串已规范。COUNT(DISTINCT*)直接whole-row，VALUES/graph/BIND来源已canonical。COUNT最终是integer，**不是Expr输出，但不需要字符串规范化**。
- 现C3只允COUNT。GROUP_CONCAT/SAMPLE/MIN/MAX等被原能力guard拒绝，某些aggregate确会绕Expr直接在accumulator生成literal；本方案**不保证未来开放这类aggregate的字符串终值已被覆盖**，不能以wrapper方案擅自开放它们，也不缩现有COUNT功能。自定义Function/cast等当前被原guard拒绝，不因prototype可调用库就声称产品新增支持。
- 原始graph或initBindings若仍含显式string而不canonical，单靠query Expr无法修全部Variable通路；产品调用当前没有任意外部initBindings接口，输入图/scopes仍须由本次最小字符串修复统一处理。prototype只验证该前提下query这一个缺口。

## 4. 真实观测（完整明细在output.json，非产品通过数）

| 观测query/行为 | default / 仅常量 | 完整local v2 |
| --- | --- | --- |
| 固定typed-string BGP/VALUES→plain图匹配 | false / true | true |
| BIND(STRDT("a",xsd:string))→BGP | false / false | true |
| nested CONCAT(STRDT...)→sameTerm plain | false / false | true |
| CONCAT结果→VALUES plain join | 空 / 空 | 一行plain a |
| UNION两种字符串构造→DISTINCT | 两行 / 两行 | 一行plain a |
| COUNT(DISTINCT ?v) 与 COUNT(DISTINCT IF(...STRDT...)) | 2 / 2 | 1 |
| COUNT(DISTINCT *)、VALUES DISTINCT 两种静态字符串写法 | 2/两行 / 1/一行 | 1/一行 |
| STR→typed-string sameTerm | false / true | true |
| IF/COALESCE包含未采用或错误分支 | 身份仍错 | true，保持原分支求值/错误处理 |
| FILTER(1/0) | false / false | false |
| BIND(1/0 AS ?bad) | bad unbound | bad仍unbound，另STRDT变量plain |
| OPTIONAL未匹配/匹配 | 原unbound/匹配结构保持 | 结构保持、字符串plain，匹配TrueFilter副本可执行 |
| NOT EXISTS内nested字符串、subselect BIND→外层BGP | false / false | true |
| 数字01/1 pattern、typed numeric01、VALUES数字 | 保留01与1区别 | 完全相同lexical输出与三行multiset |
| CONCAT语言@en、string对@en | ab@en；sameTerm false | 同原结果，language literal直接同对象返回 |
| STRLANG(STRDT(...string),en)、REPLACE/SUBSTR→sameTerm | false / false | true |

error-output.json 的补充独立边界：callback返回SPARQLError和抛SPARQLError均由原Expr.eval返回**同一个**错误对象；callback抛ValueError仍抛**同一个**异常对象，未误变SPARQLError/False；三者回调均见原ctx，结束ctx均None。数值literal、language literal调用canonical均返回同对象；非string datatype没有重建/规范化。

## 5. 全新进程隔离检查与v1漏检纠正

- v1原件：`probe-v1.py` / `output-v1.json` / `stderr-v1.txt`。v1初始globals检查涵盖Expr.eval、Builtin_STRDT、parser.Query、CUSTOM_EVALS、NORMALIZE，但漏了TrueFilter实例callback。其 `globals_identity_unchanged=true` **不能作为完整无污染证明**。
- fresh `v1_singleton_audit.py` 实际只运行一条OPTIONAL，`prototype_v1_mutated_truefilter_callback=true`，明确确认缺陷；进程退出未写库文件。这个反例原始stdout保留，未改成v1通过。
- v2在另一个全新Python进程运行，未继承v1变更。`truefilter_evalfn_identity_unchanged=true`；原列所有globals identity也未变；补充 `_CUSTOM_FUNCTIONS` registry检查未变，不用CUSTOM_EVALS或custom function注册。
- 两份独立prepared的Expr ID安装前共享 **1** 个，实际恰为TrueFilter；安装后共享 **0**。四份prepared（OPTIONAL两份、NOT EXISTS、COUNT expression）包含CompValue/Expr/list/dict/tuple/set的children两两6组交集均 **0**。
- runtime枚举operators/algebra/parser/parserutils四模块级Expr：只有operators.TrueFilter及algebra.TrueFilter（同一对象别名）；parser/parserutils没有模块级Expr。结合 `Comp.postParse`/`and_`/`not_`静态创建点，未发现该固定范围另一个共享Expr。**这不证明任意未来依赖/任意新语法没有共享节点**；主线宜锁定版本并设相应隔离回归。
- 两线程、每项各自fresh prepared，3轮default/local交错ASK结果始终 `false,true,false,true,false,true`；无相互污染。**不支持把同一个prepared Query对象跨线程/任务复用**，因为Expr.ctx本身是可变的；不要引入全局prepared缓存。库自身parser缓存等默认内部行为未逐字节审计，本检查证明的是上述明确对象、回调和真实query输出，不声称库没有任何内部状态。

## 6. 交付及实施限制

建议主线只在既有 `semantic_query.py` 安装本地prepared-normalizer（共享term函数从现获准`semantic_turtle.py`引入），保持numeric grammar、原guard和真实SemanticError分类；输入图/definition/selected的字符串身份由已授权本次修复路径完成。不能改依赖、global NORMALIZE/parser/evaluator/CUSTOM_EVALS、Store/worker或公共schema；不引入规则比较profile、日期/数值新政策或多heads。

此方案依赖 `_evalfn` 的boundmethod与CompValue raw布局，属**锁版本的私有API适配**。应在安装阶段做精确不变量检查，内部失败不可报INVALID_QUERY；TrueFilter身份/回调未变、不同prepared无共享mutable children、VALUES/嵌套/COUNT及错误ctx回归均须纳入主线真实新候选验证。拓扑walker复杂度随prepared节点数，回调多一次固定字符串检查；本轮没有基准，**不量化性能/内存改进或证明预算满足**。不因小原型通过关闭源码完整check、12 worker已知反例、包内、指定同版双审/CI/父验收。

## 7. 原件路径与哈希

全部在自有ignored目录：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-execution/build/query-string-instance-probe/`，无产品提交。文件完整SHA/bytes另存 `manifest.json`（报告写完后生成，不自包含report hash循环）：

- `semantic_query_c3.py`：固定输入源快照，仅供prototype。
- `probe-v1.py`、`output-v1.json`、`stderr-v1.txt`：首次probe及漏单例检查结果，原字节保留。
- `probe.py`、`output.json`、`stderr.txt`：fresh修正版27×三模式、隔离/原词法/error-context完整stdout。
- `error_probe.py`、`error-output.json`、`error-stderr.txt`：返回/抛SPARQLError及未知异常的独立边界。
- `v1_singleton_audit.py`、`v1-singleton-audit.json`、`v1-singleton-stderr.txt`：fresh确认首版污染TrueFilter的负证据。

报告与所有脚本仅为建议/研究证据；主线实际代码由root负责，本稿没有提交或修改其候选。
