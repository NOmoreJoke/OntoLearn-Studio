"""Fresh-process diagnostic preserving the initial prototype's missed singleton defect."""
import importlib.util
import json
from pathlib import Path
from rdflib.plugins.sparql import operators

path = Path(__file__).with_name("probe-v1.py")
spec = importlib.util.spec_from_file_location("probe_v1_fresh", path)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
before = operators.TrueFilter._evalfn
answer = old.run(old.CASES["optional_unbound"], "local")
print(json.dumps({
    "fresh_interpreter": True,
    "prototype_v1_mutated_truefilter_callback": operators.TrueFilter._evalfn is not before,
    "old_global_audit_did_not_cover_this_object": True,
    "answer": answer,
}, sort_keys=True, indent=2))
