"""Isolated RDFLib 7.6 instance-only query prototype; no Store/app or dependency edits."""
import concurrent.futures
import hashlib
import importlib.util
import json
import itertools
from collections import OrderedDict
from pathlib import Path

import rdflib
from rdflib import Graph, Literal, URIRef, Variable, XSD
from rdflib.plugins.sparql import CUSTOM_EVALS, algebra, operators, parser, parserutils
from rdflib.plugins.sparql.parserutils import CompValue, Expr
from rdflib.plugins.sparql.sparql import SPARQLError

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("fixed_c3_query", HERE / "semantic_query_c3.py")
fixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixed)


def canonical(value):
    if isinstance(value, Literal) and not value.language and value.datatype in (None, XSD.string):
        return Literal(str(value), normalize=False)
    return value


def install(query, wrap=True):
    seen = set()
    stats = {"expressions": 0, "constants": 0, "dicts": 0, "truefilter_clones": 0}

    def visit(value):
        if isinstance(value, Literal):
            result = canonical(value)
            stats["constants"] += result.datatype != value.datatype
            return result
        if isinstance(value, CompValue):
            # RDFLib OPTIONAL without FILTER inserts a module-level shared Expr.
            # Give this one its own bound self before touching fields/evalfn.
            if value is operators.TrueFilter:
                original = value._evalfn
                value = Expr(value.name, original.__func__, **dict(OrderedDict.items(value)))
                stats["truefilter_clones"] += 1
            if id(value) in seen:
                return value
            seen.add(id(value))
            for key, item in list(OrderedDict.items(value)):
                value[key] = visit(item)
            if isinstance(value, Expr) and wrap:
                original = value._evalfn
                if not callable(original):
                    raise RuntimeError("UNPROVED_EXPR_EVALFN")

                def result(ctx, _original=original):
                    return canonical(_original(ctx))

                value._evalfn = result
                stats["expressions"] += 1
            return value
        if isinstance(value, dict):
            stats["dicts"] += 1
            return {key: visit(item) for key, item in value.items()}
        if isinstance(value, list):
            return [visit(item) for item in value]
        if isinstance(value, tuple):
            return tuple(visit(item) for item in value)
        if isinstance(value, set):
            return {visit(item) for item in value}
        return value

    query.algebra = visit(query.algebra)
    return stats


PREFIX = "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> "
GRAPH = Graph()
GRAPH.add((URIRef("urn:s"), URIRef("urn:p"), Literal("a", normalize=False)))
GRAPH.add((URIRef("urn:s"), URIRef("urn:n"), Literal("01", datatype=XSD.integer, normalize=False)))
CASES = {
    "constant_bgp": 'ASK { <urn:s> <urn:p> "a"^^xsd:string }',
    "constant_values": 'ASK { VALUES ?v { "a"^^xsd:string } <urn:s> <urn:p> ?v }',
    "bind_strdt_bgp": 'ASK { BIND(STRDT("a",xsd:string) AS ?v) <urn:s> <urn:p> ?v }',
    "nested_strdt_sameterm": 'ASK { FILTER(sameTerm(CONCAT(STRDT("a",xsd:string),STRDT("",xsd:string)),"a")) }',
    "str_then_sameterm": 'ASK { FILTER(sameTerm(STR(<urn:a>),"urn:a"^^xsd:string)) }',
    "concat_then_values_join": 'SELECT ?v WHERE { { BIND(CONCAT(STRDT("a",xsd:string),STRDT("",xsd:string)) AS ?v) } VALUES ?v { "a" } }',
    "distinct_union": 'SELECT DISTINCT ?v WHERE { { BIND(STRDT("a",xsd:string) AS ?v) } UNION { BIND("a" AS ?v) } }',
    "count_distinct_var": 'SELECT (COUNT(DISTINCT ?v) AS ?n) WHERE { { BIND(STRDT("a",xsd:string) AS ?v) } UNION { BIND("a" AS ?v) } }',
    "count_distinct_expr": 'SELECT (COUNT(DISTINCT IF(?i=1, STRDT("a",xsd:string),"a")) AS ?n) WHERE { VALUES ?i { 1 2 } }',
    "count_star_distinct": 'SELECT (COUNT(DISTINCT *) AS ?n) WHERE { VALUES ?v { "a" "a"^^xsd:string } }',
    "values_distinct": 'SELECT DISTINCT ?v WHERE { VALUES ?v { "a" "a"^^xsd:string } }',
    "coalesce_error": 'ASK { FILTER(sameTerm(COALESCE(1/0, STRDT("a",xsd:string)),"a")) }',
    "if_lazy_error": 'ASK { FILTER(sameTerm(IF(true, STRDT("a",xsd:string),1/0),"a")) }',
    "optional_unbound": 'SELECT ?v ?x WHERE { BIND(STRDT("a",xsd:string) AS ?v) OPTIONAL { <urn:absent> <urn:p> ?x } }',
    "optional_matched": 'SELECT ?v ?x WHERE { BIND(STRDT("a",xsd:string) AS ?v) OPTIONAL { <urn:s> <urn:p> ?x } }',
    "bind_error_unbound": 'SELECT ?bad ?v WHERE { BIND(1/0 AS ?bad) BIND(STRDT("a",xsd:string) AS ?v) }',
    "filter_error": 'ASK { FILTER(1/0) }',
    "not_exists_nested": 'ASK { FILTER NOT EXISTS { BIND(STRDT("a",xsd:string) AS ?v) FILTER(!sameTerm(?v,"a")) } }',
    "numeric_lexical": 'ASK { <urn:s> <urn:n> ?n FILTER(sameTerm(?n,01)) FILTER(!sameTerm(?n,1)) }',
    "numeric_typed_lexical": 'ASK { <urn:s> <urn:n> "01"^^xsd:integer }',
    "numeric_values": 'SELECT ?n WHERE { VALUES ?n { 01 1 "01"^^xsd:integer } }',
    "lang_preserved": 'SELECT ?v WHERE { BIND(CONCAT("a"@en,"b"@en) AS ?v) }',
    "lang_vs_string": 'ASK { FILTER(sameTerm(STRDT("a",xsd:string),"a"@en)) }',
    "strlang_with_strdt": 'ASK { FILTER(sameTerm(STRLANG(STRDT("a",xsd:string),"en"),"a"@en)) }',
    "replace_nested": 'ASK { FILTER(sameTerm(REPLACE(STRDT("ab",xsd:string),"b",""),"a")) }',
    "substring_nested": 'ASK { FILTER(sameTerm(SUBSTR(STRDT("ab",xsd:string),1,1),"a")) }',
    "subselect_bind": 'ASK { { SELECT ?v WHERE { BIND(STRDT("a",xsd:string) AS ?v) } } <urn:s> <urn:p> ?v }',
}


def run(text, mode):
    query = fixed.prepare_lexical_query(PREFIX + text)
    stats = install(query, wrap=(mode == "local")) if mode != "default" else None
    result = GRAPH.query(query, use_store_provided=False)
    if result.type == "ASK":
        return {"ask": bool(result.askAnswer), "stats": stats}
    rows = [[None if term is None else term.n3() for term in row] for row in result]
    return {"vars": [str(v) for v in result.vars], "rows": sorted(rows, key=repr), "stats": stats}


def main():
    globals_before = (Expr.eval, operators.Builtin_STRDT, parser.Query, tuple(CUSTOM_EVALS.items()), rdflib.NORMALIZE_LITERALS)
    truefilter_eval_before = operators.TrueFilter._evalfn
    results = {}
    for name, text in CASES.items():
        results[name] = {mode: run(text, mode) for mode in ("default", "constants", "local")}
    # A tiny concurrency check: every task owns one prepared query and its Expr state.
    work = [(CASES["bind_strdt_bgp"], mode) for _ in range(3) for mode in ("default", "local")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        parallel = list(pool.map(lambda task: run(*task)["ask"], work))
    # Preserve SPARQLError object identity and Expr context cleanup at the wrapper boundary.
    error = SPARQLError("private-test-marker")
    seen_ctx = []
    def produce(expr, ctx):
        seen_ctx.append(expr.ctx is ctx)
        raise error
    expr = Expr("ProbeError", produce)
    holder = type("Holder", (), {})()
    holder.algebra = CompValue("Probe", expr=expr)
    install(holder)
    returned = expr.eval({Variable("v"): Literal("a")})
    def expr_ids(query):
        ids, seen, pending = set(), set(), [query.algebra]
        while pending:
            value = pending.pop()
            if id(value) in seen:
                continue
            seen.add(id(value))
            if isinstance(value, Expr):
                ids.add(id(value))
            if isinstance(value, CompValue):
                pending.extend(v for _, v in OrderedDict.items(value))
            elif isinstance(value, dict):
                pending.extend(value.values())
            elif isinstance(value, (list, tuple, set)):
                pending.extend(value)
        return ids
    queries = [fixed.prepare_lexical_query(PREFIX + CASES["optional_matched"]) for _ in range(2)]
    shared_before = expr_ids(queries[0]) & expr_ids(queries[1])
    for query in queries:
        install(query)
    shared_after = expr_ids(queries[0]) & expr_ids(queries[1])
    def mutable_ids(query):
        seen, pending = set(), [query.algebra]
        while pending:
            value = pending.pop()
            if not isinstance(value, (CompValue, dict, list, tuple, set)) or id(value) in seen:
                continue
            seen.add(id(value))
            if isinstance(value, CompValue):
                pending.extend(v for _,v in OrderedDict.items(value))
            elif isinstance(value, dict):
                pending.extend(value.values())
            else:
                pending.extend(value)
        return seen
    audit_queries = [fixed.prepare_lexical_query(PREFIX + CASES[name]) for name in (
        "optional_matched", "optional_matched", "not_exists_nested", "count_distinct_expr"
    )]
    for query in audit_queries:
        install(query)
    mutable_intersections = [len(mutable_ids(a) & mutable_ids(b)) for a,b in itertools.combinations(audit_queries,2)]
    global_expr_inventory = {
        module.__name__: sorted(name for name,value in vars(module).items() if isinstance(value, Expr))
        for module in (operators, algebra, parser, parserutils)
    }
    numeric = Literal("01", datatype=XSD.integer, normalize=False)
    language = Literal("a", lang="en")
    globals_after = (Expr.eval, operators.Builtin_STRDT, parser.Query, tuple(CUSTOM_EVALS.items()), rdflib.NORMALIZE_LITERALS)
    payload = {
        "rdflib": rdflib.__version__,
        "prototype_only": True,
        "source_sha256": hashlib.sha256((HERE / "semantic_query_c3.py").read_bytes()).hexdigest(),
        "cases": results,
        "parallel_modes": [mode for _, mode in work],
        "parallel_ask": parallel,
        "globals_identity_unchanged": all(a is b for a,b in zip(globals_before[:3],globals_after[:3])) and globals_before[3:] == globals_after[3:],
        "truefilter_evalfn_identity_unchanged": operators.TrueFilter._evalfn is truefilter_eval_before,
        "two_prepared_expr_shared_before": len(shared_before),
        "two_prepared_expr_shared_before_is_truefilter": shared_before == {id(operators.TrueFilter)},
        "two_prepared_expr_shared_after": len(shared_after),
        "four_prepared_child_intersections_including_containers": mutable_intersections,
        "global_expr_inventory": global_expr_inventory,
        "numeric_canonical_same_object": canonical(numeric) is numeric,
        "language_canonical_same_object": canonical(language) is language,
        "error_object_same": returned is error,
        "error_context_seen": seen_ctx,
        "error_context_cleared": expr.ctx is None,
        "graph_terms_after": sorted(t[2].n3() for t in GRAPH),
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
