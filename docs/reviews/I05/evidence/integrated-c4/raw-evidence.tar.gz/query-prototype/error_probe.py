"""Tiny callback-boundary follow-up; no graph, query cache, or dependency mutation."""
import json
from probe import install
from rdflib.plugins.sparql import operators
from rdflib.plugins.sparql.parserutils import CompValue, Expr
from rdflib.plugins.sparql.sparql import SPARQLError

custom_before = tuple(operators._CUSTOM_FUNCTIONS.items())
true_before = operators.TrueFilter._evalfn
result = {}
for case in ("return_sparql_error", "raise_sparql_error", "raise_unknown_error"):
    marker = SPARQLError(case) if case != "raise_unknown_error" else ValueError(case)
    ctx = {}
    seen = []
    def callback(expr, actual_ctx):
        seen.append(expr.ctx is actual_ctx and actual_ctx is ctx)
        if case.startswith("return"):
            return marker
        raise marker
    expr = Expr("BoundaryProbe", callback)
    holder = type("Holder", (), {})()
    holder.algebra = CompValue("Holder", expr=expr)
    install(holder)
    try:
        returned = expr.eval(ctx)
        same = returned is marker
        raised = False
    except Exception as caught:
        same = caught is marker
        raised = True
    result[case] = {"same_error_object": same, "raised": raised, "ctx_seen": seen, "ctx_cleared": expr.ctx is None}
result["custom_function_registry_unchanged"] = tuple(operators._CUSTOM_FUNCTIONS.items()) == custom_before
result["truefilter_evalfn_unchanged"] = operators.TrueFilter._evalfn is true_before
print(json.dumps(result, sort_keys=True, indent=2))
