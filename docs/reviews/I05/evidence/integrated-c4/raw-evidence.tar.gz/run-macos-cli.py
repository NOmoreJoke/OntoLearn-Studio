from pathlib import Path
import subprocess,json,time
out=Path(__file__).resolve().parent
engine=str(Path("release/mac-arm64/OntoLearn Studio.app/Contents/Resources/engine/ontolearn-engine").resolve())
commands=[
 ("macos-runtime",["uv","run","--frozen","python","scripts/verify-i05-runtime.py",engine,str(out/"macos-runtime")]),
 ("macos-i04-package",["uv","run","--frozen","python","scripts/verify-i04-package.py",engine,str(out/"macos-i04-package")]),
 ("macos-parity",["uv","run","--frozen","python","scripts/verify-i05.py","--packaged",engine,"--output",str(out/"macos-parity")])
]
records=[]
for name,argv in commands:
 start=time.monotonic()
 with (out/(name+".txt")).open("wb") as log: result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 row={"name":name,"argv":argv,"exitCode":result.returncode,"wallSeconds":time.monotonic()-start};records.append(row);(out/"macos-cli-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(row),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
