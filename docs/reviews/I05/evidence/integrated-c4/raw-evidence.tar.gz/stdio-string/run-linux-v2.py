from pathlib import Path
import json,subprocess,time
out=Path(__file__).resolve().parent;container="ontolearn-i05-isolated-20261021-v2"
old=json.loads((out/"old-expected-implementation.json").read_text())["implementation"]
base=["docker","exec","-u","node","-w","/i05","-e","HOME=/i05-home","-e","UV_CACHE_DIR=/i05-cache/uv",container,"uv","run","--frozen","python","build/i05-c4-string-stdio/run_string_stdio_v2.py","--repo","/i05","--seed-dir","build/i05-c4-string-stdio/fixture-v2"]
runs=[("linux-old-c3-v2","/i05/c3-frozen-3289-release/linux-arm64-unpacked/resources/engine/ontolearn-engine",1),("linux-source-v2",None,0),("linux-packaged-v2","/i05/release/linux-arm64-unpacked/resources/engine/ontolearn-engine",0)]
records=[]
for name,engine,expected in runs:
 dest="build/i05-c4-string-stdio/"+name;argv=base+["--out",dest]
 if engine: argv += ["--engine",engine]
 argv += ["--expected-implementation",json.dumps(old)] if expected else ["--compare-to","build/i05-c4-string-stdio/independent-comparison-v2.json"]
 start=time.monotonic()
 with (out/(name+".stdout.txt")).open("wb") as stdout,(out/(name+".stderr.txt")).open("wb") as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr)
 subprocess.run(["docker","cp",container+":/i05/"+dest,str(out/name)],check=True)
 summary=json.loads((out/name/"summary.json").read_text());assert r.returncode==expected and summary["authenticatedRecords"]==summary["jobs"]==19
 assert (summary["status"]=="failed-semantic-oracle" and summary["oracleFailures"]) if expected else summary["status"]=="passed"
 row={"name":name,"argv":argv,"exitCode":r.returncode,"expectedExitCode":expected,"wallSeconds":time.monotonic()-start,"status":summary["status"],"observedReasoning":summary["observedReasoning"],"semanticOracleFailures":len(summary["oracleFailures"])};records.append(row);(out/"linux-v2-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(row),flush=True)
