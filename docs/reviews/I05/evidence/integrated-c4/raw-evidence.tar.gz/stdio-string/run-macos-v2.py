from pathlib import Path
import json,subprocess,time
out=Path(__file__).resolve().parent; root=Path.cwd()
old=json.loads((out/"old-expected-implementation.json").read_text())["implementation"]
base=["uv","run","--frozen","python",str(out/"run_string_stdio_v2.py"),"--repo",str(root),"--seed-dir",str(out/"fixture-v2")]
runs=[("macos-old-c3-v2",root/"build/i05-integrated/c3-preserved-release/mac-arm64/OntoLearn Studio.app/Contents/Resources/engine/ontolearn-engine",1),("macos-packaged-v2",root/"release/mac-arm64/OntoLearn Studio.app/Contents/Resources/engine/ontolearn-engine",0)]
records=[]
for name,engine,expected in runs:
 argv=base+["--out",str(out/name),"--engine",str(engine)]
 argv += ["--expected-implementation",json.dumps(old)] if expected else ["--compare-to",str(out/"independent-source-v2-01/comparison.json")]
 start=time.monotonic()
 with (out/(name+".stdout.txt")).open("wb") as stdout,(out/(name+".stderr.txt")).open("wb") as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr)
 summary=json.loads((out/name/"summary.json").read_text());assert r.returncode==expected and summary["authenticatedRecords"]==summary["jobs"]==19
 assert (summary["status"]=="failed-semantic-oracle" and summary["oracleFailures"]) if expected else summary["status"]=="passed"
 row={"name":name,"argv":argv,"exitCode":r.returncode,"expectedExitCode":expected,"wallSeconds":time.monotonic()-start,"status":summary["status"],"observedReasoning":summary["observedReasoning"],"semanticOracleFailures":len(summary["oracleFailures"])};records.append(row);(out/"macos-v2-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(row),flush=True)
