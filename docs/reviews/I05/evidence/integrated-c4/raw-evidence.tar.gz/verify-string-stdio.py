from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent/'stdio-string';sha=lambda b:hashlib.sha256(b).hexdigest(); records={}
for name in ['independent-source-01','macos-packaged','linux-source','linux-packaged','independent-source-v2-01','macos-old-c3-v2','macos-packaged-v2','linux-old-c3-v2','linux-source-v2','linux-packaged-v2']:
 directory=out/name;summary=json.loads((directory/'summary.json').read_text());runtime=json.loads((directory/'runtime.json').read_text());old='old-c3' in name;assert summary['jobs']==19
 public=sorted(directory.glob('*.public.json'));authenticated=sorted(directory.glob('*.authenticated.json'));assert len(public)==len(authenticated)==19
 total_rows=0
 for path in authenticated:
  label=path.name.removesuffix('.authenticated.json');record=json.loads(path.read_text());shown=json.loads((directory/(label+'.public.json')).read_text());assert record['metadata']==shown['metadata'];payload=record['payload'];rows=shown['rows'];total_rows+=len(rows)
  digest=lambda value:sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
  assert record['payloadHash']==digest(payload) and record['rowsHash']==digest(rows)
  assert record['metadata']['implementation']==shown['job']['implementation'];assert payload['executionSemanticsVersion']==record['metadata']['implementation']['executionSemanticsVersion']
  pieces={}
  for row in rows[1:]:
   pointer,fragment,ordinal,count=row['cells'];pieces.setdefault(pointer,[]).append((ordinal,count,fragment))
  decoded={}
  for pointer,p in pieces.items():
   assert [v[0] for v in p]==list(range(1,p[0][1]+1)) and all(v[1]==len(p) for v in p);decoded[pointer]=json.loads(''.join(v[2] for v in p))
  expected={}
  def leaves(v,p=''):
   if isinstance(v,dict) and v:
    for k,item in v.items():leaves(item,p+'/'+k.replace('~','~0').replace('/','~1'))
   elif isinstance(v,list) and v:
    for i,item in enumerate(v):leaves(item,p+'/'+str(i))
   else:expected[p]=v
  leaves(payload);assert decoded==expected
 if old:
  assert summary['status']=='failed-semantic-oracle' and summary['observedReasoning']=={'conclusions':5,'traces':5} and len(summary['oracleFailures'])==17
  assert summary['observedValidation']['max1']['conforms'] is False and summary['observedValidation']['min2']['conforms'] is True
 else: assert summary['status']=='passed'
 records[name]={'jobs':19,'fullAuthenticatedResults':19,'fullPublicRowsDecoded':total_rows,'implementation':runtime.get('expectedProducerImplementation',runtime['implementation']),'engineSha256':runtime.get('engineSha256'),'comparisonSha256':summary['comparisonSha256'],'status':summary['status'],'observedReasoning':summary.get('observedReasoning'),'observedValidation':summary.get('observedValidation'),'oracleFailures':len(summary.get('oracleFailures',[]))}
for group in [['independent-source-01','macos-packaged','linux-source','linux-packaged'],['independent-source-v2-01','macos-packaged-v2','linux-source-v2','linux-packaged-v2']]:assert len({records[n]['comparisonSha256'] for n in group})==1
result={'runs':records,'limits':'Each count belongs to this exact actual run; v1/v2 fixtures differ in fourth rule when and format, never reuse green across fixture versions. Old v2 producer triple comes from actual C3 metadata; hardcoded summary ruleConclusions7/ruleTraces8 describe oracle size, actual old observedReasoning is5/5.17 failed semantic cases share one string-identity defect, not17 independent bugs. Raw/public/authenticated records preserved in full; comparison removes only ephemeral result identifiers and validationBinding packaging, whose full bytes/hash/resources are separately checked.'}
(out/'full-readback-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({n:{'jobs':r['jobs'],'rows':r['fullPublicRowsDecoded'],'status':r['status']} for n,r in records.items()}))
