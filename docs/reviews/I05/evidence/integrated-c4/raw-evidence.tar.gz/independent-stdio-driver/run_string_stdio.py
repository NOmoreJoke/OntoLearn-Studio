"""Portable real stdio C4 driver. Only writes its own fresh output and fixture dirs."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from uuid import UUID, uuid4

from rdflib import Literal


PRODUCT = "1a79731091e671c497824c94e12dae34a4e8609b"
TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
STRING = "http://www.w3.org/2001/XMLSchema#string"
SH = "http://www.w3.org/ns/shacl#"
INTEGER = "http://www.w3.org/2001/XMLSchema#integer"
SUBJECTS = ("urn:both", "urn:plain", "urn:typed")
PLAIN, TYPED = '"x"', f'"x"^^<{STRING}>'
EDGE_TEXTS = {"empty": "", "escaped": 'quote" slash\\\nnext'}
EDGE_TERMS = {name: Literal(text, normalize=False).n3() for name, text in EDGE_TEXTS.items()}
FACTS = sorted([[f"<{s}>", "<urn:p>", PLAIN] for s in SUBJECTS] + [
    ["<urn:both>", f"<{TYPE}>", "<urn:C>"]
] + [[f"<urn:edge-{name}>", "<urn:edge>", value] for name, value in EDGE_TERMS.items()])
RULES = [
    ("01-match-plain", [["?s", "<urn:p>", PLAIN]], ["?s", "<urn:plain-match>", "<urn:yes>"]),
    ("02-match-typed", [["?s", "<urn:p>", TYPED]], ["?s", "<urn:typed-match>", "<urn:yes>"]),
    ("03-emit-plain", [["<urn:both>", "<urn:p>", PLAIN]], ["<urn:both>", "<urn:emit>", PLAIN]),
    ("04-emit-typed", [["<urn:both>", "<urn:p>", TYPED]], ["<urn:both>", "<urn:emit>", TYPED]),
]
EXPRESSIONS = {
    "STRDT": 'STRDT("x",xsd:string)',
    "STR": 'STR("x"^^xsd:string)',
    "CONCAT": 'CONCAT(STRDT("x",xsd:string),STRDT("",xsd:string))',
    "SUBSTR": 'SUBSTR(STRDT("xy",xsd:string),1,1)',
    "REPLACE": 'REPLACE(STRDT("xy",xsd:string),"y","")',
    "LCASE": 'LCASE(STRDT("X",xsd:string))',
}
PREFIX = f"PREFIX xsd: <{STRING.rsplit('#', 1)[0]}#> "
QUERIES = {
    "runtime-" + name: PREFIX + f'''SELECT ?v ?same ?s WHERE {{
        BIND({expr} AS ?v) VALUES ?v {{ "x"^^xsd:string }}
        ?s <urn:emit> ?v BIND(sameTerm(?v,"x"^^xsd:string) AS ?same) }}'''
    for name, expr in EXPRESSIONS.items()
}
QUERIES.update({
    "typed-values": PREFIX + '''SELECT DISTINCT ?v WHERE {
        VALUES ?v { "x"^^xsd:string "x" } <urn:both> <urn:emit> ?v }''',
    "same-term": PREFIX + '''ASK { <urn:both> <urn:emit> ?v
        FILTER(sameTerm(?v,"x"^^xsd:string)) }''',
    "count-runtime-distinct": PREFIX + '''SELECT (COUNT(DISTINCT ?v) AS ?count) WHERE {
        { BIND(STRDT("x",xsd:string) AS ?v) } UNION { BIND("x" AS ?v) }
        <urn:both> <urn:emit> ?v }''',
})
for edge_name, edge_text in EDGE_TEXTS.items():
    token = json.dumps(edge_text, ensure_ascii=False)
    QUERIES["edge-" + edge_name] = PREFIX + f'''SELECT DISTINCT ?v ?same WHERE {{
        BIND(STRDT({token},xsd:string) AS ?v)
        VALUES ?v {{ {token} {token}^^xsd:string }}
        <urn:edge-{edge_name}> <urn:edge> ?v
        BIND(sameTerm(?v,{token}^^xsd:string) AS ?same) }}'''
    QUERIES["edge-count-" + edge_name] = PREFIX + f'''SELECT (COUNT(DISTINCT ?v) AS ?count) WHERE {{
        {{ BIND(STRDT({token},xsd:string) AS ?v) }} UNION {{ BIND({token} AS ?v) }}
        <urn:edge-{edge_name}> <urn:edge> ?v }}'''


def shape(clause):
    return f'''@prefix sh: <{SH}> . @prefix xsd: <{STRING.rsplit('#', 1)[0]}#> .
<urn:StringShape> a sh:NodeShape; sh:targetClass <urn:C>; sh:property <urn:StringProperty> .
<urn:StringProperty> a sh:PropertyShape; sh:path <urn:emit>; {clause} .
'''


CONSTRAINTS = {
    "inTyped": {"enabled": True, "turtle": shape('sh:minCount 1; sh:in ("x"^^xsd:string)')},
    "max1": {"enabled": True, "turtle": shape("sh:maxCount 1")},
    "min2": {"enabled": True, "turtle": shape("sh:minCount 2")},
}
DEFINITIONS = [{"layer": "ontology", "id": "classes", "value": {"triples": []}}] + [
    {"layer": "rule", "id": name, "value": {"enabled": True, "when": when, "then": then}}
    for name, when, then in RULES
] + [
    {"layer": "query", "id": name, "value": {"text": text}} for name, text in QUERIES.items()
] + [
    {"layer": "constraint", "id": name, "value": value} for name, value in CONSTRAINTS.items()
]
FIXTURE_SPEC = {"format": "I05-C4-string-stdio/1", "facts": FACTS, "definitions": DEFINITIONS}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n")


def need(condition, detail):
    if not condition:
        raise AssertionError(detail)


def oracle_reasoning():
    evidence = []
    for name, predicate in (("01-match-plain", "urn:plain-match"), ("02-match-typed", "urn:typed-match")):
        for subject in SUBJECTS:
            fact = [f"<{subject}>", "<urn:p>", PLAIN]
            evidence.append({"rule": name, "result": [f"<{subject}>", f"<{predicate}>", "<urn:yes>"],
                             "inputs": [fact], "basis": [fact]})
    fact = ["<urn:both>", "<urn:p>", PLAIN]
    for name in ("03-emit-plain", "04-emit-typed"):
        evidence.append({"rule": name, "result": ["<urn:both>", "<urn:emit>", PLAIN],
                         "inputs": [fact], "basis": [fact]})
    return {"rdfs": [], "rdfsEvidence": [], "warnings": [],
            "rules": [list(t) for t in sorted({tuple(e["result"]) for e in evidence})], "evidence": evidence}


def expected_source(selected, digest, implementation):
    def term(value):
        return PLAIN if value == TYPED else value
    rules = [{"id": name, "when": [[term(t) for t in triple] for triple in when],
              "then": [term(t) for t in then]} for name, when, then in RULES] if selected else []
    return {"executionSemanticsVersion": implementation["executionSemanticsVersion"],
            "assertedInputSha256": digest(FACTS), "ontologyInputSha256": digest([]),
            "selectedRulesSha256": digest(rules)}


def expected_provenance(selected, digest, implementation):
    source = expected_source(selected, digest, implementation)
    entries = {tuple(t): [{"kind": "asserted"}] for t in FACTS}
    if selected:
        for record in oracle_reasoning()["evidence"]:
            entries.setdefault(tuple(record["result"]), []).append({
                "kind": "rule", "rule": record["rule"], "inputs": record["inputs"], "basis": record["basis"]})
    return {"scope": "asserted+selected-derived" if selected else "asserted", **source,
            "reasoningSource": dict(source) if selected else None,
            "selectedRuleIds": [r[0] for r in RULES] if selected else [], "warnings": [],
            "selectedFacts": [{"triple": list(t), "sources": entries[t]} for t in sorted(entries)],
            "derivedAxioms": [], "ontologyView": [],
            "factViewSha256": digest([list(t) for t in sorted(entries)]), "ontologyViewSha256": digest([])}


def check_display(rows, payload):
    need(rows[0]["cells"] == ["columns", "path", "value", "part", "parts"], "display columns")
    need([r["ordinal"] for r in rows] == list(range(len(rows))), "row ordinals")
    need(len({r["rowId"] for r in rows}) == len(rows), "unique row ids")
    need(all(UUID(r["rowId"]).version == 4 for r in rows), "UUIDv4 rows")
    parts = {}
    for row in rows[1:]:
        need(len(row["cells"]) <= 64, "row width")
        need(all(not isinstance(c, str) or len(c) <= 8192 for c in row["cells"]), "cell size")
        path, fragment, ordinal, count = row["cells"]
        parts.setdefault(path, []).append((ordinal, count, fragment))
    decoded = {}
    for path, fragments in parts.items():
        count = fragments[0][1]
        need([p[0] for p in fragments] == list(range(1, count + 1)), "lossless pieces")
        need(all(p[1] == count for p in fragments), "piece count")
        decoded[path] = json.loads("".join(p[2] for p in fragments))
    expected = {}
    def leaves(value, path):
        if isinstance(value, dict) and value:
            for key, item in value.items():
                leaves(item, path + "/" + key.replace("~", "~0").replace("/", "~1"))
        elif isinstance(value, list) and value:
            for index, item in enumerate(value):
                leaves(item, path + "/" + str(index))
        else:
            expected[path] = value
    leaves(payload, "")
    need(decoded == expected, "public display must include every complete payload leaf")


def source_manifest(repo, manifest):
    document = json.loads(manifest.read_text())
    need(document["productCommit"] == PRODUCT, "fixed product manifest identity")
    for relative, expected in document["files"].items():
        need(sha(repo / relative) == expected, "fixed source bytes mismatch: " + relative)
    return document


def execute(args, out):
    repo = args.repo.resolve()
    manifest = source_manifest(repo, args.product_manifest)
    import ontolearn_engine
    from ontolearn_engine.job_store import JobStore
    from ontolearn_engine.resources import CONTRACT, IMPLEMENTATION
    from ontolearn_engine.semantic import SEMANTICS_VERSION
    from ontolearn_engine.storage import digest
    need(IMPLEMENTATION["executionSemanticsVersion"] == SEMANTICS_VERSION == "i05-finite-6",
         "loaded resources and semantic versions must both be finite-6, not stale pyc")
    need(Path(ontolearn_engine.__file__).resolve().is_relative_to(repo / "packages/engine/src"),
         "host imported engine must point to fixed repo")
    sys.path.insert(0, str(repo / "packages/engine/tests"))
    from test_resident_runtime import Session
    child = json.loads(subprocess.check_output([sys.executable, "-I", "-c",
        "import json,sys,ontolearn_engine; from ontolearn_engine.resources import IMPLEMENTATION; from ontolearn_engine.semantic import SEMANTICS_VERSION; print(json.dumps({'python':sys.executable,'module':ontolearn_engine.__file__,'implementation':IMPLEMENTATION,'semanticVersion':SEMANTICS_VERSION}))"]))
    need(Path(child["module"]).resolve().is_relative_to(repo / "packages/engine/src"),
         "isolated source child module must point to fixed repo")
    need(child["implementation"] == IMPLEMENTATION and child["semanticVersion"] == "i05-finite-6", "isolated import implementation")
    engine = args.engine or os.environ.get("ONTOLEARN_TEST_ENGINE")
    if engine:
        os.environ["ONTOLEARN_TEST_ENGINE"] = str(Path(engine).resolve())
    runtime = {"productCommit": PRODUCT, "manifestSha256": sha(args.product_manifest),
               "repo": str(repo), "python": sys.executable, "prefix": sys.prefix,
               "module": ontolearn_engine.__file__, "isolatedChild": child,
               "engine": os.environ.get("ONTOLEARN_TEST_ENGINE"), "implementation": IMPLEMENTATION,
               "engineSha256": sha(engine) if engine else None}
    write(out / "runtime.json", runtime)
    seed_dir = args.seed_dir.resolve()
    if not seed_dir.exists():
        seed_dir.mkdir(parents=True)
        seed = JobStore(seed_dir / "seed.sqlite", contract=CONTRACT)
        try:
            seed.create_project("c4-string")
            project = seed.public_project("c4-string")
            seed.commit("c4-string", 0, str(uuid4()), str(uuid4()), definitions=DEFINITIONS,
                manual=[{"id": digest([s[1:-1], p[1:-1], o]), "subject": s[1:-1],
                         "predicate": p[1:-1], "object": o} for s, p, o in FACTS])
            fixture = {"spec": FIXTURE_SPEC, "specSha256": digest(FIXTURE_SPEC), "projectId": project,
                       "inputSnapshotId": seed.project_get(project)["inputSnapshotId"],
                       "originalState": seed.state("c4-string")}
        finally:
            seed.close()
        fixture["databaseSha256"] = sha(seed_dir / "seed.sqlite")
        write(seed_dir / "seed.json", fixture)
    fixture = json.loads((seed_dir / "seed.json").read_text())
    need(fixture["spec"] == FIXTURE_SPEC and fixture["specSha256"] == digest(FIXTURE_SPEC), "immutable seed spec")
    need(sha(seed_dir / "seed.sqlite") == fixture["databaseSha256"], "immutable seed database hash")
    write(out / "fixture.json", fixture)
    database = out / "run.sqlite"
    shutil.copyfile(seed_dir / "seed.sqlite", database)
    project, snapshot = fixture["projectId"], fixture["inputSnapshotId"]
    transcript = out / "calls.jsonl"
    class RecordedSession(Session):
        def call(self, method, params):
            answer = super().call(method, params)
            with transcript.open("a") as stream:
                stream.write(json.dumps({"method": method, "params": params, "response": answer}, ensure_ascii=False) + "\n")
            return answer
    backend = RecordedSession(database, [project], test_mode=False)
    records = []
    def completed(label, capability, definition, selected=None):
        request = {"projectId": project, "operationId": str(uuid4()), "capability": capability,
                   "scope": "asserted+derived" if selected else "asserted", "definitionId": definition,
                   "derivedResultId": selected, "inputSelection": "current", "inputSnapshotId": None}
        started = backend.call("semantic.start", request)
        need("jobId" in started, {"label": label, "start": started})
        job = backend.terminal(project, started["jobId"], timeout=30)
        need(job["state"] == "succeeded", {"label": label, "job": job})
        need(job["commitProgress"] == {"mode": "none"}, "no domain writes")
        metadata = backend.call("result.get", {"projectId": project, "resultId": job["resultRef"]["resultId"]})
        need(CONTRACT.validate("result", metadata), metadata)
        need(metadata["jobId"] == job["jobId"] and metadata["projectId"] == project, "producer binding")
        need(metadata["implementation"] == job["implementation"] == IMPLEMENTATION, "whole implementation")
        need(metadata["inputSnapshotId"] == job["inputSnapshotId"] == snapshot, "snapshot binding")
        need(metadata["parametersHash"] == job["parametersHash"], "accepted parameters hash")
        need(metadata["kind"] == capability.split(".")[0] and metadata["definitionId"] == definition, "definition binding")
        need(metadata["scope"] == request["scope"] and metadata["payloadStatus"] == "available", "scope/payload binding")
        need(metadata["state"] == "current" and not metadata["historicalSelectionRequired"], "accepted current result")
        binding = {"projectId": project, "resultId": metadata["resultId"], "inputSnapshotId": snapshot,
                   "scope": metadata["scope"], "parametersHash": metadata["parametersHash"], "order": "ordinal+rowId:asc"}
        rows, cursor = [], None
        while True:
            params = {"binding": binding, "pageSize": 17, "cursor": cursor}
            page = backend.call("result.page", params)
            need(page == backend.call("result.page", params), "stable repeated public page")
            need(page["binding"] == binding, "page binding")
            rows.extend(page["rows"])
            cursor = page["nextCursor"]
            if cursor is None:
                break
        record = {"label": label, "request": request, "job": job, "metadata": metadata, "rows": rows}
        records.append(record)
        write(out / (label + ".public.json"), record)
        return metadata["resultId"]
    try:
        reasoning = completed("reasoning", "reasoning.execute", "all")
        completed("asserted-negative", "query.execute", "runtime-STRDT")
        for name in QUERIES:
            completed(name, "query.execute", name, reasoning)
        completed("asserted-inTyped-negative", "validation.execute", "inTyped")
        for name in CONSTRAINTS:
            completed(name, "validation.execute", name, reasoning)
    finally:
        try:
            backend.close()
        finally:
            write(out / "notifications.json", backend.notifications)
    store = JobStore(database, contract=CONTRACT)
    comparable = {"fixtureSpecSha256": digest(FIXTURE_SPEC), "inputSnapshotId": snapshot,
                  "implementation": IMPLEMENTATION, "payloads": {}}
    try:
        for record in records:
            label, selected = record["label"], record["request"]["derivedResultId"]
            metadata, payload = store.semantic_result(project, record["metadata"]["resultId"])
            need(store.get_job(project, metadata["jobId"]) == record["job"], "durable complete job")
            need(store.result(metadata["resultId"])["payload"] == record["rows"], "persisted/public rows identical")
            check_display(record["rows"], payload)
            raw = store._db.execute("SELECT * FROM semantic_payloads WHERE result=?", (metadata["resultId"],)).fetchone()
            need(raw["payload_hash"] == digest(payload), "full authenticated payload hash")
            need(raw["rows_hash"] == digest(record["rows"]), "full authenticated rows hash")
            need(payload["inputSnapshotId"] == snapshot and payload["inputProjectRevision"] == 1, "full payload input identity")
            need(payload["executionSemanticsVersion"] == IMPLEMENTATION["executionSemanticsVersion"], "payload version")
            need(payload["selectedResultIds"] == ([selected] if selected else []), "exact existing selection")
            if label == "reasoning":
                need(payload["reasoning"] == oracle_reasoning(), "complete seven conclusions / eight traces")
                need(payload["assertedFacts"] == FACTS and payload["ontology"] == [], "S1 canonical facts / ontology")
                need(payload["source"] == expected_source(True, digest, IMPLEMENTATION), "full normalized rule/source hashes")
            else:
                need(payload["provenance"] == expected_provenance(bool(selected), digest, IMPLEMENTATION), "complete selected sources/basis")
                if payload["kind"] == "query":
                    if label == "asserted-negative":
                        expected = {"type": "SELECT", "variables": ["v", "same", "s"], "rows": []}
                    elif label.startswith("runtime-"):
                        expected = {"type": "SELECT", "variables": ["v", "same", "s"],
                                    "rows": [[PLAIN, f'"true"^^<{STRING.rsplit("#", 1)[0]}#boolean>', "<urn:both>"]]}
                    elif label == "typed-values":
                        expected = {"type": "SELECT", "variables": ["v"], "rows": [[PLAIN]]}
                    elif label == "same-term":
                        expected = {"type": "ASK", "value": True}
                    elif label in {"edge-empty", "edge-escaped"}:
                        expected = {"type": "SELECT", "variables": ["v", "same"],
                                    "rows": [[EDGE_TERMS[label.removeprefix("edge-")],
                                              f'"true"^^<{STRING.rsplit("#", 1)[0]}#boolean>']]}
                    else:
                        expected = {"type": "SELECT", "variables": ["count"], "rows": [[f'"1"^^<{INTEGER}>']]}
                    need(payload["query"] == expected, {"label": label, "actual": payload["query"], "expected": expected})
                else:
                    report = {"conforms": True, "violations": []}
                    if label in {"min2", "asserted-inTyped-negative"}:
                        report = {"conforms": False, "violations": [{"focus": "<urn:both>", "path": "<urn:emit>",
                            "constraint": f"<{SH}MinCountConstraintComponent>", "sourceShape": "<urn:StringProperty>",
                            "value": None, "severity": f"<{SH}Violation>"}]}
                    need(payload["report"] == report, {"label": label, "actual": payload["report"], "expected": report})
                    definition = record["request"]["definitionId"]
                    need(payload["constraintsHash"] == digest(CONSTRAINTS[definition]) and payload["constraintsVersion"] == 1, "constraint bytes/version")
                    binding = payload["validationBinding"]
                    need(CONTRACT.validation_projection_matches_resources(binding["projection"], binding["resources"]), "canonical resource resolver")
                    need(binding["projection"]["implementation"] == IMPLEMENTATION, "validation full implementation")
                    need(binding["projection"]["derived"]["resultId"] == selected if selected else binding["projection"]["derived"] is None, "existing producer resource")
                    expected_resources = {"assertedFacts": FACTS, "ontologyAxioms": [], "constraints": CONSTRAINTS[definition]}
                    if selected:
                        expected_resources.update(derivedFacts=oracle_reasoning()["rules"], derivedAxioms=[])
                    need({r["role"] for r in binding["resources"]} == set(expected_resources), "all content-addressed resource roles")
                    for resource in binding["resources"]:
                        row = store._db.execute("SELECT payload FROM semantic_resources WHERE project=? AND ref=?", (project, resource["ref"])).fetchone()
                        value = json.loads(row[0])
                        need(value == expected_resources[resource["role"]] and digest(value) == resource["ref"], "actual full resource bytes/hash")
            write(out / (label + ".authenticated.json"), {"metadata": metadata, "payload": payload,
                "payloadHash": raw["payload_hash"], "rowsHash": raw["rows_hash"], "rowCount": len(record["rows"])})
            # Raw complete binding/rows/metadata remain above. Only ephemeral result/job IDs
            # and binding identity packaging are excluded from cross-engine semantic comparison.
            content = {key: value for key, value in payload.items() if key != "validationBinding"}
            def replace(value):
                if isinstance(value, dict):
                    return {key: replace(item) for key, item in value.items()}
                if isinstance(value, list):
                    return [replace(item) for item in value]
                return "@existing-reasoning-result" if value == reasoning else value
            comparable["payloads"][label] = replace(content)
        need(store.state("c4-string") == fixture["originalState"], "source state unchanged")
        need(store.project_get(project)["inputSnapshotId"] == snapshot, "no domain commit during stdio")
    finally:
        store.close()
    need(sha(seed_dir / "seed.sqlite") == fixture["databaseSha256"], "immutable reusable seed retained")
    source_manifest(repo, args.product_manifest)
    write(out / "comparison.json", comparable)
    if args.compare_to:
        need(comparable == json.loads(args.compare_to.read_text()), "source/package semantic content comparison")
    summary = {"status": "passed", "productCommit": PRODUCT, "mode": "packaged" if engine else "source",
               "jobs": len(records), "ruleConclusions": 7, "ruleTraces": 8, "runtimeConstructors": list(EXPRESSIONS),
               "comparisonSha256": sha(out / "comparison.json"), "fixtureSpecSha256": digest(FIXTURE_SPEC),
               "seedDatabaseSha256": fixture["databaseSha256"], "comparisonMatched": bool(args.compare_to)}
    write(out / "summary.json", summary)
    print(json.dumps(summary, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed-dir", type=Path, required=True, help="Create once, then reuse/copy this immutable fixture for all engines")
    parser.add_argument("--product-manifest", type=Path, default=Path(__file__).with_name("product-source-manifest.json"))
    parser.add_argument("--engine", help="Optional real packaged executable; also honors ONTOLEARN_TEST_ENGINE")
    parser.add_argument("--compare-to", type=Path, help="Previous comparison.json from the same immutable seed")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    write(out / "launch.json", {"driver": str(Path(__file__).resolve()), "driverSha256": sha(__file__),
          "productCommit": PRODUCT, "repo": str(args.repo.resolve()), "python": sys.executable,
          "seedDirectory": str(args.seed_dir.resolve()), "engine": args.engine or os.environ.get("ONTOLEARN_TEST_ENGINE"),
          "comparisonInput": str(args.compare_to.resolve()) if args.compare_to else None})
    started = time.time()
    try:
        execute(args, out)
    except BaseException as error:
        failure = {"status": "failed", "errorType": type(error).__name__, "message": str(error), "elapsedSeconds": time.time() - started}
        write(out / "failure.json", failure)
        (out / "failure.traceback.txt").write_text(traceback.format_exc())
        print(json.dumps(failure, ensure_ascii=False), file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
