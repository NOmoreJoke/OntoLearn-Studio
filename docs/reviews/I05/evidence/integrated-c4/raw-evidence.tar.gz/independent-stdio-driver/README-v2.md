# C4 portable real stdio driver v2

Only the ignored driver/evidence directory is written. This is an independent source/packaged acceptance driver, not a product/test-source change or replacement for the main full check, package gates, dual review, CI or original acceptance. No GUI is used. All protocol jobs are real `test_resident_runtime.Session(..., test_mode=False)` subprocesses; that helper honors `ONTOLEARN_TEST_ENGINE`. All saved payloads come from actual JobStore records, not a pure-function substitute.

## Fixed source and local verification

- Host/fixture/product oracle source: `1a79731091e671c497824c94e12dae34a4e8609b` exported with `git archive` to a **new** directory `fixed-1a797310/`. Source has the commit archive timestamps, not reused mtime-zero source/pyc. A new independent venv and UV cache were created in this directory's sibling `venv/` and `uv-cache/`; no main-worktree venv was used, synced or modified.
- `product-source-manifest.json` pins 36 source/contract/lock/helper files from that export. `--repo` may point at a later fixed test-only commit such as `40c18ea` only while all these bytes still match. This does not certify any different product code.
- The driver requires the host import and `python -I` child import both point under `--repo/packages/engine/src`, and records their real paths and implementations. The v2 host resources and semantic versions must agree, but there is **no hardcoded finite-6 producer gate**. Primary acceptance is 19 actual jobs and full payload/rows/source/report oracles, not version printing.
- Final `run_string_stdio_v2.py` source run: `source-v2-01/`, exit 0, **19 real jobs / 19 authenticated payloads**, 7 conclusions / 8 traces, no oracle failures. Six runtime constructors, empty/escaped STRDT, VALUES/sameTerm/DISTINCT/COUNT, selected-derived and asserted negative controls, inTyped/max1/min2 all passed. inTyped and max1 conform; min2 produces the complete MinCount violation.
- v2 source comparison SHA-256: `eb51f12c63c9ea6abac3cd745aeab887ab9b0f3310071da0fe0c2c2901f8cb2b`.
- Current producer implementation copied from the **actual successful source runtime**, not invented: `implementation-current.json`. It contains engineVersion `0.1.0`, executionSemanticsVersion `i05-finite-6`, and dependencyLockHash `86dfe82d952e2c88edcfc5658f488f6e1f0d04b4ec3b1e6f5c5d3bc4f57e8b73`.

Actual independent environment setup (all logs preserved):

```sh
UV_PROJECT_ENVIRONMENT=<this-directory>/venv UV_CACHE_DIR=<this-directory>/uv-cache uv sync --frozen --all-groups --project <this-directory>/fixed-1a797310 --python <original-independent-3.12-python>
```

Actual final source command, from `/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-execution`:

```sh
build/c4-stdio-runner/venv/bin/python build/c4-stdio-runner/run_string_stdio_v2.py --repo build/c4-stdio-runner/fixed-1a797310 --out build/c4-stdio-runner/source-v2-01 --seed-dir build/c4-stdio-runner/fixture-v2 > build/c4-stdio-runner/source-v2-01.stdout.txt 2> build/c4-stdio-runner/source-v2-01.stderr.txt
```

## Same immutable input across Mac/Linux source/package

Copy the portable bundle's `fixture-v2/seed.sqlite` and `seed.json` **together**. The SQLite fixture is created through real S1 Store, closed, SHA-bound and never run directly: every invocation copies it to a new `--out/run.sqlite`. Reusing these exact seed bytes preserves project identity and inputSnapshotId across systems. It contains only this synthetic fixture, no credentials or user project data. No environment/venv/export/cache is in the portable bundle.

S1 facts are canonical plain strings, including empty and quote/backslash/newline lexical fixtures. Raw explicit xsd:string belongs to saved rule/query/shape definitions. Four rules produce the independent full oracle: two match forms each across three subjects, plus two emitting rules on the same binding. Both emitting rules use the **plain** input condition; one outputs plain and one explicit xsd:string. Thus a pre-fix engine can really emit both spellings, exposing false max1/min2 behavior. New semantics retain both traces while deduplicating one graph term. No rule chain/multi-head/new comparison policy is introduced.

Fresh Linux/source run, using its own locked venv bound to its fixed source:

```sh
<fixed-venv>/bin/python <portable>/run_string_stdio_v2.py --repo <fixed-repo> --out <new-source-output> --seed-dir <portable>/fixture-v2 --compare-to <portable>/reference-source-v2.json
```

New actual packaged engine (same command on Mac/Linux, `--out` must not already exist):

```sh
<fixed-venv>/bin/python <portable>/run_string_stdio_v2.py --repo <fixed-repo> --out <new-package-output> --seed-dir <portable>/fixture-v2 --engine <actual-packaged-engine> --compare-to <portable>/reference-source-v2.json
```

Instead of `--engine`, set `ONTOLEARN_TEST_ENGINE` to the actual executable. Session still starts that executable, no mocked worker. The host venv provides the fixed schema/helper and readback; the real package owns stdio/worker execution. Driver runtime.json records target executable hash and declared expected producer triple; actual metadata/job/fullpayload must agree. Output `comparison.json` retains all semantic payload fields except validationBinding's identity packaging and replaces the actual selected result UUID with an explicit marker; no timestamps/row UUIDs are compared. Complete original metadata/rows/bindings are retained and authenticated separately. Both provenance and content-addressed actual resource contents are checked, not merely counts.

## Old package semantic red, without spoofing its identity

Optional `--expected-implementation` takes the **complete actual old producer three-field JSON**, obtained from root's preserved old packaged run/producer declaration. Do not create it by editing resources, changing one version string, or borrowing the current source implementation. This report has not executed or authenticated root's old binary; its exact triple must come from that binary's actual preserved evidence. A new target still defaults to the host's current implementation.

```sh
<fixed-venv>/bin/python <portable>/run_string_stdio_v2.py --repo <fixed-repo> --out <new-old-package-output> --seed-dir <portable>/fixture-v2 --engine <actual-old-packaged-engine> --expected-implementation '{"engineVersion":"<actual-old>","executionSemanticsVersion":"<actual-old>","dependencyLockHash":"<actual-old>"}'
```

For old semantic negative testing **omit `--compare-to`**: the intentional old producer identity differs from the new reference. The driver does not reject finite-5 merely for being finite-5. It compares public metadata/job/payload against the supplied actual producer triple, runs the same immutable 19 jobs, saves **all 19 `.raw.json` and all 19 `.authenticated.json` records before any semantic oracle**, then evaluates each record and accumulates failures. Stored payload bytes/hash, persisted/public complete rows and hashes, original producer metadata, all binding resources and database are retained. A semantic red exits nonzero with `summary.json` status `failed-semantic-oracle`, observed conclusion/trace counts, full observed validation reports and per-label `oracleFailures`; failure.json/traceback also remain.

The old package is expected to fail the actual seven-term/eight-trace and query/report oracles; exact observed old counts/reports must be read from the real run, not predicted as evidence. Particularly, min2 may incorrectly conform with two spellings of the same RDF 1.1 string. `productCommit` in the output denotes the fixed **host/reference source** for this driver, not a claim that an old target executable was built from 1a; its actual binary hash and producer triple are separate runtime evidence. No old target identity is rewritten or re-signed.

Transport/startup/task-publication failures are not semantic oracle results. If such a failure prevents 19 jobs completing, retain the failure directory and actual process logs and report that limitation; do not call it the intended old semantic red. No actual old-package run is claimed by this independent source report.

## Preserved v1 and what changed

- `source-01/` first ran the pre-guard script, exit 0. After that run completed and **before** adding the guards, the actual script was copied to `run_string_stdio-v1.py`, SHA `875dd5d728ce9706f7b302929aaeb04b510f43319b8fcb6704619f7a8f930fbb`. This copy is preserved; the command/edit history binds it after the run, but source-01 did **not** record a launch-time driver SHA and has no launch.json. Do not describe it as an independently hash-bound start or claim later e054 bytes were the script executed in source-01.
- Loaded SEMANTICS_VERSION/resources agreement, isolated child full-implementation guards, parameters binding and launch SHA capture were then added. `run_string_stdio.py` became SHA `e054483748fe488c77eafc19f840948ac85444899b1c163ec213cf2664c9be0f`. **source-02 actually reran all 19 jobs with e054**, exit 0; its launch.json records that exact driver SHA. It also checked exact semantic content equality with source-01. This source-02 run is the frozen reusable v1 green baseline. v1 comparison SHA `74ab416cb54767e83eeea849d87eb4daadfc67ae89e5975ed6c537e984536b1f` proves equal normalized content, not equality of source-01/source-02 driver bytes.
- v1 `04-emit-typed` had a **typed input condition**. v2 changes that condition to plain so both emit rules execute even in old semantics, strengthens old max1/min2 discrimination, changes fixture spec/snapshot, adds separate producer-identity override and preserves all complete raw/authenticated results before semantic checks. v1 green evidence does **not** substitute for v2; v2 has a new seed and its own actual source green.
- v2 `source-v2-01/` separately records driver SHA `4a064f9eb14f5acad3f01b1b6ddbf314359ff5a53b09d9602cced72b787bfd95` in its launch.json and passed all 19 jobs using only fixture-v2. v1 files/seed/source records were not overwritten. No source/driver failures occurred in the local runs; setup and all first-run logs remain. Root's other package or stale-pyc failures are not claimed as this agent's experiments.

## Record layout and limits

Each new `--out` records launch driver SHA, runtime source/executable identity, fixture spec/source snapshot, calls.jsonl (real responses/pages), complete notifications, each public result, each stored semantic row and rows (`.raw.json` in v2), authenticated payload/hash/row count, independent `.oracle.json`, final comparison/summary, and the actual run database. All pages are repeated identically and validated through the existing helper; rows must be UUIDv4, stable ordinal, complete lossless JSON-pointer leaves for the entire payload, not a truncated success. The source domain state/snapshot and original immutable seed database hash must remain unchanged.

The driver may import existing tests helpers; it does not modify them or weaken their public-contract checks. These checks use the fixed current contract compatible with the preserved old protocol-2 artifact; a genuinely incompatible old schema remains a separate limitation. Current local source evidence does not claim native install, signing, GUI, production, performance, full FR-505 or any new Q6 policy. No changes were made to the earlier query prototype's fourteen raw artifacts.
