from pathlib import Path
from PyInstaller.archive.readers import CArchiveReader
import hashlib,json,marshal
root=Path.cwd();out=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();result={}
for label,engine in [('macos',root/'release/mac-arm64/OntoLearn Studio.app/Contents/Resources/engine/ontolearn-engine'),('linux',out/'binary-inputs/linux-engine'),('linuxFirstPreserved',out/'binary-inputs/linux-first-stale-engine')]:
 archive=CArchiveReader(str(engine)).open_embedded_archive('PYZ.pyz'); modules={}
 for name in ['resources','semantic','semantic_execution','semantic_query','semantic_scopes','semantic_turtle','semantic_samples']:
  actual=archive.extract('ontolearn_engine.'+name);source=root/'packages/engine/src/ontolearn_engine'/(name+'.py');expected=compile(source.read_bytes(),actual.co_filename,'exec',dont_inherit=True,optimize=0)
  assert actual==expected,(label,name)
  modules[name]={'sourceSha256':sha(source.read_bytes()),'archiveModule':'ontolearn_engine.'+name,'archiveCoFilename':actual.co_filename,'codeObjectEqualsFrozenSourceCompile':True,'archiveCodeMarshalSha256':sha(marshal.dumps(actual))}
 result[label]={'executableSha256':sha(engine.read_bytes()),'executableBytes':engine.stat().st_size,'modules':modules,'runtimeAcceptance':label!='linuxFirstPreserved'}
result['method']='Read actual PyInstaller CArchive embedded PYZ code objects without importing or running bundle; compile fixed source with archive co_filename, dont_inherit=True,optimize=0 using actual Python3.12; direct code-object equality covers nested code/constants. Source process stale pyc does not imply first package runtime identity. First preserved package not runtime-accepted; final source/package full suite and actual stdio/native tests bind only final two engines.'
(out/'bundled-code-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:{'executableSha256':v['executableSha256'],'allSevenCodeObjectsEqual':True,'runtimeAccepted':v['runtimeAcceptance']} for k,v in result.items() if isinstance(v,dict)}))
