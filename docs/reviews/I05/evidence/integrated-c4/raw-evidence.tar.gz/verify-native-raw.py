from pathlib import Path
import base64,hashlib,json,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent; records={};sha=lambda b:hashlib.sha256(b).hexdigest()
for mode in ['source','packaged']:
 report=json.loads((out/f'linux-native-{mode}-report.json').read_text()); assert report['stats']['expected']==2 and report['stats']['unexpected']==report['stats']['skipped']==report['stats']['flaky']==0
 raw=out/f'linux-native-{mode}-raw'; attachments=[];body=None
 for suite in report['suites']:
  for spec in suite['specs']:
   for test in spec['tests']:
    for result in test['results']:
     assert result['status']=='passed'
     for attachment in result.get('attachments',[]):
      if 'path' in attachment:
       relative=attachment['path'].split(f'/i05/test-results/i05-c4-{mode}/',1)[1];p=raw/relative;assert p.is_file();attachments.append({'name':attachment['name'],'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
      if attachment['name']=='i05-native-driver-log':
       body=base64.b64decode(attachment['body']);json.loads(body);(out/f'linux-native-{mode}-driver-log.json').write_bytes(body)
 assert body is not None
 evidence_file=next(raw.rglob('i05-native-verified-evidence.json')); evidence=json.loads(evidence_file.read_text()); windows=evidence['windows']; assert [w['ordinal'] for w in windows]==[1,2,3] and all(w['visible'] for w in windows)
 assert evidence['result']=='PASS' and evidence['events']==['crashed','unresponsive'];assert evidence['inspectorClosed'] is True and evidence['hangMonitorEnabled'] is True and evidence['noSandboxSwitch'] is False
 assert windows[1]['focused'] is True and windows[1]['x11Focus']['visible'] is True
 assert len(evidence['nativeDialogs'])==2 and all(d['visible'] for d in evidence['nativeDialogs'])
 assert evidence['explicitCancellation']['state']=='cancelled' and evidence['explicitCancellation']['resultRef'] is None
 first=windows[0]['snapshot'];assert len(first['results'])==3
 for window in windows:
  snap=window['snapshot'];assert snap['results']==first['results'];assert snap['view']['project']==first['view']['project'];assert snap['slowJobId']==first['slowJobId'];assert any(j['jobId']==snap['slowJobId'] and j['state']=='running' for j in snap['view']['jobs'])
  for result in snap['results']:
   assert result['metadata']['implementation']['executionSemanticsVersion']=='i05-finite-6'
 code="const f=require('fs'),c=require('crypto');let v=JSON.parse(f.readFileSync(process.argv[1]));process.stdout.write(JSON.stringify(v.windows.map(w=>c.createHash('sha256').update(JSON.stringify(w.snapshot.results)).digest('hex'))))"
 hashes=json.loads(subprocess.check_output(['node','-e',code,str(evidence_file)]));assert all(h==w['snapshot']['resultsSha256'] for h,w in zip(hashes,windows))
 records[mode]={'stats':report['stats'],'fullResultsEqualAtThreeWindows':True,'resultsSha256':hashes,'evidenceSha256':sha(evidence_file.read_bytes()),'evidencePath':str(evidence_file.relative_to(root)),'driverBytes':len(body),'driverSha256':sha(body),'attachments':attachments}
(out/'native-raw-verification.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({m:{'stats':r['stats'],'fullResultsEqualAtThreeWindows':True,'driverBytes':r['driverBytes']} for m,r in records.items()}))
