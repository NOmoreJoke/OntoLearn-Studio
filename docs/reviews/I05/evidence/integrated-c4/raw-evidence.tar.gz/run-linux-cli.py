from pathlib import Path
import subprocess,json,time
out=Path(__file__).resolve().parent
container="ontolearn-i05-isolated-20261021-v2"
base=["docker","exec","-u","node","-w","/i05","-e","HOME=/i05-home","-e","UV_CACHE_DIR=/i05-cache/uv","-e","npm_config_cache=/i05-cache/npm",container]
engine="/i05/release/linux-arm64-unpacked/resources/engine/ontolearn-engine"
commands=[
 ("linux-source-binding",["python3","-c","import json,hashlib,pathlib; x=json.load(open('/tmp/i05-c4-source-manifest.json')); mismatches=[p for p,h in x['executionInputs'].items() if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=h]; assert not mismatches,mismatches; print(json.dumps({'head':x['head'],'executionCount':len(x['executionInputs']),'allEqual':True}))"]),
 ("linux-source-affected",["uv","run","--frozen","pytest","packages/engine/tests/test_semantic_string_identity.py","packages/engine/tests/test_semantic_lexical.py","packages/engine/tests/test_semantic_scopes.py","packages/engine/tests/test_semantic_selected_projection.py","packages/engine/tests/test_semantic_execution.py","packages/engine/tests/test_semantic_rdfs_basis_determinism.py","-q"]),
 ("linux-runtime",["uv","run","--frozen","python","scripts/verify-i05-runtime.py",engine,"build/i05-c4-runtime"]),
 ("linux-i04-package",["uv","run","--frozen","python","scripts/verify-i04-package.py",engine,"build/i05-c4-i04-package"]),
 ("linux-parity",["uv","run","--frozen","python","scripts/verify-i05.py","--packaged",engine,"--output","build/i05-c4-parity"])
]
records=[]
for name,cmd in commands:
 start=time.monotonic(); argv=base+cmd
 with (out/(name+".txt")).open("wb") as log: result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 row={"name":name,"argv":argv,"exitCode":result.returncode,"wallSeconds":time.monotonic()-start};records.append(row);(out/"linux-cli-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(row),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
for name,path in [("linux-runtime","/i05/build/i05-c4-runtime"),("linux-i04-package","/i05/build/i05-c4-i04-package"),("linux-parity","/i05/build/i05-c4-parity")]:
 subprocess.run(["docker","cp",container+":"+path,str(out/name)],check=True)
