"""Short real-library probe, using only the fixed exported I05 product."""
import hashlib
import json
import os
import platform
import sys
from importlib.metadata import version
from pathlib import Path

import ontolearn_engine.semantic as semantic
from ontolearn_engine.semantic import Rule, parse_turtle, reason
from rdflib import RDF, URIRef, Variable

probe = Path(__file__).resolve().parent
export = probe / 'source'
actual_module = Path(semantic.__file__).resolve()
expected_module = export / 'packages/engine/src/ontolearn_engine/semantic.py'
assert actual_module == expected_module.resolve(), str(actual_module)
raw = (probe / 'inputs.json').read_bytes()
inputs = json.loads(raw)
rule = Rule('observe-derived-type', ((Variable('u'), RDF.type, URIRef('urn:C')),), (Variable('u'), URIRef('urn:derived'), URIRef('urn:seen')))

def sha(data):
    return hashlib.sha256(data).hexdigest()

results = {}
for name, text in inputs.items():
    graph = parse_turtle(text)
    results[name] = {
        'inputSha256': sha(text.encode('utf-8')),
        'inputTripleCount': len(graph),
        'inputTriples': sorted(tuple(t.n3() for t in triple) for triple in graph),
        'withoutRule': reason(graph),
        'withRule': reason(graph, (rule,)),
    }

record = {
    'productCommit': '26eb632f0e1210b03ac3aef4cfd71fdc4a0c5222',
    'hashSeed': os.environ['PYTHONHASHSEED'],
    'hashSentinels': {'urn:a': hash('urn:a'), 'urn:b': hash('urn:b')},
    'ignoreEnvironment': sys.flags.ignore_environment,
    'pythonExecutable': sys.executable,
    'pythonVersion': platform.python_version(),
    'semanticsVersion': semantic.SEMANTICS_VERSION,
    'moduleFile': str(actual_module),
    'semanticSha256': sha(actual_module.read_bytes()),
    'uvLockSha256': sha((export / 'uv.lock').read_bytes()),
    'inputFileSha256': sha(raw),
    'rule': {'id': rule.id, 'when': [[t.n3() for t in row] for row in rule.when], 'then': [t.n3() for t in rule.then]},
    'versions': {name: version(name) for name in ['rdflib', 'pyshacl', 'pyparsing', 'owlrl']},
    'cases': results,
}
print(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2))
