"""Execute identical input bytes under six real fresh hash-seeded processes."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

probe=Path(__file__).resolve().parent
inputs={
 'domain_three': '<urn:u> <urn:p> <urn:a> .\n<urn:u> <urn:p> <urn:b> .\n<urn:p> <http://www.w3.org/2000/01/rdf-schema#domain> <urn:C> .\n',
 'domain_four': '<urn:u> <urn:p> <urn:a> .\n<urn:u> <urn:p> <urn:b> .\n<urn:p> <http://www.w3.org/2000/01/rdf-schema#domain> <urn:C> .\n<urn:z> <urn:q> <urn:w> .\n',
 'range_four': '<urn:a> <urn:p> <urn:u> .\n<urn:b> <urn:p> <urn:u> .\n<urn:p> <http://www.w3.org/2000/01/rdf-schema#range> <urn:C> .\n<urn:z> <urn:q> <urn:w> .\n',
}
(probe/'inputs.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n')
python=probe/'source/.venv/bin/python'
records=[]
for seed in (1,2,3,5,7,11):
 env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')}
 env.update(PYTHONHASHSEED=str(seed),PYTHONDONTWRITEBYTECODE='1')
 process=subprocess.run([str(python),'-B',str(probe/'child.py')],cwd=probe/'source',env=env,capture_output=True,timeout=15)
 (probe/f'seed-{seed}.stdout.json').write_bytes(process.stdout)
 (probe/f'seed-{seed}.stderr.txt').write_bytes(process.stderr)
 assert process.returncode==0 and process.stderr==b'', (seed,process.returncode,process.stderr)
 records.append(json.loads(process.stdout))

summary={}
for case in inputs:
 rows=[]
 for record in records:
  output=record['cases'][case]
  rows.append({'seed':record['hashSeed'],
   'withoutRuleSha256':hashlib.sha256(json.dumps(output['withoutRule'],sort_keys=True).encode()).hexdigest(),
   'withRuleSha256':hashlib.sha256(json.dumps(output['withRule'],sort_keys=True).encode()).hexdigest(),
   'rdfsEvidence':output['withoutRule']['rdfsEvidence'],
   'ruleEvidence':output['withRule']['evidence']})
 summary[case]={'distinctWithoutRuleOutputs':len({x['withoutRuleSha256'] for x in rows}),
  'distinctWithRuleOutputs':len({x['withRuleSha256'] for x in rows}),'observations':rows}
report={'productCommit':records[0]['productCommit'],'inputFileSha256':records[0]['inputFileSha256'],
 'allInputFileSha256Equal':len({x['inputFileSha256'] for x in records})==1,
 'allSourceSha256Equal':len({x['semanticSha256'] for x in records})==1,
 'allLockSha256Equal':len({x['uvLockSha256'] for x in records})==1,
 'seedCount':len(records),'cases':summary,
 'limits':'Bounded read-only evidence for existing B1 determinism; no T05 comparison-policy adoption or implementation change.'}
(probe/'summary.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({case:{k:v for k,v in result.items() if k!='observations'} for case,result in summary.items()}))
