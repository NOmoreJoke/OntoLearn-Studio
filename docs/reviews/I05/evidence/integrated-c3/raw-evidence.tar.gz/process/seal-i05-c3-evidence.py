import hashlib, io, json, tarfile
from pathlib import Path
from datetime import datetime
root=Path.cwd(); src=root/'build/i05-integrated/c3'; out=root/'docs/reviews/I05/evidence/integrated-c3'; out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded=[]; included=[]
for p in sorted(src.rglob('*')):
 if not p.is_file(): continue
 rel=p.relative_to(src).as_posix()
 reason=None
 if rel=='source-export.tar.gz': reason='Derived source transport; all1182 member bytes recovered and verified against immutable b045 Git plus protected snapshot. See source-recovery-from-git.json; original gzip bytes not embedded.'
 elif rel=='internal-review/source-69598f3.tar': reason='Exact43MB transport recreated with git archive and byte-compared. Recipe and original71-artifact index included.'
 elif p.name.endswith(('.sqlite','.db','.sqlite-wal','.sqlite-shm','.db-wal','.db-shm','.writer-lock')): reason='Synthetic mutable runtime database or writer lock, excluded by evidence policy.'
 if reason:
  excluded.append({'originalPath':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'reason':reason}); continue
 b=p.read_bytes(); included.append((p,rel,b))
# Preserve the sealing program as a separate original process artifact.
p=root/'build/seal-i05-c3-evidence.py'; included.append((p,'process/seal-i05-c3-evidence.py',p.read_bytes()))
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for p,rel,b in included:
  ti=tarfile.TarInfo(rel); ti.size=len(b);ti.mtime=int(p.stat().st_mtime);ti.mode=0o644;tf.addfile(ti,io.BytesIO(b))
rows=[{'member':rel,'originalPath':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)} for p,rel,b in included]
with tarfile.open(archive,'r:gz') as tf:
 assert [m.name for m in tf.getmembers()]==[r['member'] for r in rows]
 for m,row in zip(tf.getmembers(),rows):
  b=tf.extractfile(m).read(); assert len(b)==row['bytes'] and sha(b)==row['sha256']
x={'sourceHead':'b04569032e94c093e42b7fdc9fcd890df0e832e4','productHead':'69598f30c9052a0a07f3d8e7fc4277626385678b','createdAt':datetime.now().astimezone().isoformat(),'archive':'raw-evidence.tar.gz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'memberCount':len(rows),'uncompressedBytes':sum(r['bytes'] for r in rows),'allMembersReadBackVerified':True,'scope':'All actual C3 check/source/package/stdio/C4/B1/native full raw outputs, independent red/green regression and independent C3 code/runtime review scripts/logs/fullpayloads/first failures; no replacement by hashes. Original C1/C2 retained in their prior committed archives.','notIncluded':'Runtime synthetic databases/locks and2 deterministic source transports explicitly listed below; immutable source recovery recipes and complete original manifests retained. Apps/venvs/cache remain ignored; no signed-app restoration claim.','excluded':excluded,'members':rows}
(out/'manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in x.items() if k not in ('members','excluded')},ensure_ascii=False));print('excluded',len(excluded))
