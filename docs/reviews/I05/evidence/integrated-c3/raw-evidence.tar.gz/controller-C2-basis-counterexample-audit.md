# I05 C2 完整依据跨 hash seed 反例独立审计

结论：**反例有效，固定 C2 的完整推理返回值存在跨 seed 不确定性；变化明确位于 RDFS basis 及其下游 Rule evidence basis，事实结论集合保持相同。** 这支持开发线暂停派发/推送 C2、准备新候选修复；不是两个指定模型已给出 C2 NotPass。本次只读文件、Git 固定对象及内存中的 tar 内容，没有执行 probe、产品、测试、GUI 或容器，没有读取当前 C3 dirty 实现或修改状态。

## 1. 原件及固定源码绑定

输入目录：`.worktrees/I05-semantic-validation/docs/reviews/I05/evidence/c2-basis-counterexample/`。

| 材料 | 实际字节数 | 实际 SHA-256 |
| --- | ---: | --- |
| raw-counterexample.tar.gz | 379317 | 3bf9d53d8eb7dbddc7e65d0e2ea13ae188aae2e73db8e04eddd95818c339b87e |
| tar 内原 manifest.json | 3509 | 03150ee9281f3214a1b867990ec2cdbd28e3b80f129f2a05e52d3e961221b9fc |
| finding.json | 2380 | aa96f944c9a1223835726b6b42534de731a098ffcebc72f573a0e119524093a9 |
| inputs.json | 476 | d1d6e5529dc453ce8722dac48f70ab1bb99dff92910b4367a5f35f40d9ba1970 |
| product-26eb632.tar | 2457600 | f7fef8af03daa16439cc85ea2e38abfbf2547c80380d150fafdeb101a27e5871 |
| child.py | 2139 | fc41ec0dfd642e5a7e20617b507222e48dd9baed91603ec19c885fdead83f57d |
| run.py | 2694 | 3b0c97efaf0cf887e5c1f1b40a4d43d75fa0b911891088179bef9ac7ae931703 |

外层 manifest 的 19 个成员逐项长度/hash 全部匹配：原 18 项（两脚本、finding、inputs、产品 tar、六组完整 stdout/stderr、summary）加原 manifest 自身。路径唯一、均 regular、无绝对路径或 `..`。外部 `finding.json.raw`、`inputs.json.raw` 与 tar 内原件逐字相等。原 manifest 索引其余 18 项，外层 manifest 再索引全部 19 项，未把两个 manifest 混为一个。

产品 tar 有 145 项＝128 个 regular＋17 个目录，无链接/特殊项。128 个文件逐字对应 Git `26eb632f0e1210b03ac3aef4cfd71fdc4a0c5222`，并逐字对应冻结 C2 `2e337854838191fab09c7a584f5aa73d0939557a` 的同路径。不是从后续 C3 工作区借源码。

原 manifest 的六项 sourceBinding 均重新计算符合：

| 路径 | SHA-256 |
| --- | --- |
| packages/engine/src/ontolearn_engine/semantic.py | 7a83a1236c5262578256cc01ac6c57318a3688ab2df76fefaa61fb60a6b93033 |
| packages/engine/src/ontolearn_engine/semantic_offline.py | 4897d9c6a07756d5f8ed4908b4b7a28ca96c67b2670753b74f73e41bf4b67488 |
| packages/engine/src/ontolearn_engine/semantic_query.py | 5fbe2e8a08f81d7230e2c69c3380d1234df4ed7d14f8c3eef3669a935bf59d8a |
| packages/engine/src/ontolearn_engine/semantic_turtle.py | 3bfffbd74c9de1d7aec59c07ff95072339d2f6d7bf07054c49327a5e3429c6fa |
| packages/engine/pyproject.toml | bcc8825b1f2902a66ae539e687df57e5b2554247f48a48a65215601a77958365 |
| uv.lock | 86dfe82d952e2c88edcfc5658f488f6e1f0d04b4ec3b1e6f5c5d3bc4f57e8b73 |

另外按 candidate-2.json 的 203 项 executionInputs 逐项核对 26 与 2e 两个 Git 固定对象，全部符合原 SHA。原 candidate-2.json 251215B／SHA `31bd67f0a006d3423ed3fa0494e2b36a4c9963be8d7ba6cc7ab7f124aa7e55ef`，原 full-review-input.md 43830B／SHA `5b703834fcf77c72f76b67b9ad10f392af1b18f2ed30c1dfa0fd317f34e09887` 保持。反例是追加证据，没有把原 C2 清单改写成新实现。

## 2. 六个实际进程记录的可信边界

全文读取 child/run、六份完整 stdout JSON、六份 stderr 和 summary，而非只读 finding 摘要。run.py 清除继承的全部 PYTHON* 环境项，逐进程设置 PYTHONHASHSEED=1/2/3/5/7/11，命令是固定导出目录的 `.venv/bin/python -B child.py`，没有 `-I` 或 `-E`；child 记录的 `ignoreEnvironment` 六次均为 0，`hashSentinels` 六组均不同。

child 断言实际导入 semantic 模块路径必须等于固定 source 导出路径，记录其完整 SHA 及 uv.lock SHA；六份 raw 的模块、锁、输入文件 hash 均一致。运行时记录为 Python3.12.12、RDFLib7.6.0、pySHACL0.30.1、pyparsing3.3.3、owlrl7.6.2，语义身份 `i05-finite-4`。这绑定真实导出源码及所报运行库版本；可变 `.venv` 未归档，不将其说成完整已封存运行环境镜像。

| seed | stdout 字节数 | stdout SHA-256 | hashSentinels（urn:a / urn:b） |
| --- | ---: | --- | --- |
| 1 | 9904 | 346a857ef64443e90b5d20cd33198b08503c2e9cc398243665d384c0b97a9c23 | 5398313730969664715 / 6823016663198826599 |
| 2 | 9906 | 560b8820782a3665f28b10a17751452a7cc8d9cae1c0517b0b53eece88d4132b | -3761057991054860512 / -8143233739075686886 |
| 3 | 9905 | c6a5b731e49b62034b4ce1e79592de54cbb30afbfbfbbab82ef0933708eba34e | -7763471660200559071 / 2807807482702046143 |
| 5 | 9904 | d6e5ada450e778adc9a54ebea03565d498ae4ef9d6ae6eccebb8f8c20d5075e3 | -3146140424488509234 / 609077280526444553 |
| 7 | 9905 | 3b5ca3402329cfd3a9e10aa15c9aff8e8ab3da7d21938aeec95145ede03f1fcb | -5512586027002258137 / 4295073202580591339 |
| 11 | 9904 | 2a9696c246daba559f572489a944019f4297a1ac1c134269c44012d5eb9ea926 | 803509690503204493 / -281759517721881366 |

六份 stderr 均为 0B，SHA `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`。run 在每个子进程后断言 returncode==0 且 stderr 为空，再解析 JSON；只有六次断言均通过才生成所保存 summary。**没有单独归档逐进程 returncode 数值收据**，所以零退出由冻结 driver 的断言路径及已生成 summary 支持，不冒称独立看到了未保存的 returncode 日志。本次未重跑这些命令。

每个进程对三个固定输入各调用一次 withoutRule 与 withRule，共 36 次直接真实库 reason 调用；不是六次真实 Store/worker/stdio/包内端到端执行。

## 3. 完整支持集合及差异

inputs 文件 SHA 六次同为 d1d6…；每个 case 的输入三元组集合、数量、文本 SHA 六次也相等：

| case | 输入数量 | 输入文本 SHA-256 |
| --- | ---: | --- |
| domain_three | 3 | 902a9ab4283c41e9ea6247691336776b8524b026a4eedd83d9e1100d871d5347 |
| domain_four | 4 | 706867a1760b90132d4631f67b7b2cd38ffc0f5a4a71af12af88d1bfbd034b29 |
| range_four | 4 | a49510a209add95d50f6d00c20d4a5f108aee7124fb9338548f902a48c728c8e |

以下使用标准 `rdf:`、`rdfs:` 前缀。domain_three 输入为 `u p a`、`u p b`、`p rdfs:domain C`；domain_four 只多 `z q w`。range_four 为 `a p u`、`b p u`、`p rdfs:range C`、`z q w`（所有简名均为 urn: IRI）。固定规则 `observe-derived-type` 的 when 为 `?u rdf:type C`，then 为 `?u derived seen`。

**domain 两样例的完整 basis：**

- seed 1/3/7：`{ (p rdfs:domain C), (u p b) }`。
- seed 2/5/11：`{ (p rdfs:domain C), (u p a) }`。

**range 样例的完整 basis：**

- seed 1/2/3：`{ (a p u), (p rdfs:range C) }`。
- seed 5/7/11：`{ (b p u), (p rdfs:range C) }`。

每份输出中这同一 basis 同时出现在 `withoutRule.rdfsEvidence[0].basis`、`withRule.rdfsEvidence[0].basis` 和 `withRule.evidence[0].basis`，三者逐项相等。withRule evidence 的 rule 恒为 observe-derived-type，inputs 恒为 `[(u rdf:type C)]`，result 恒为 `(u derived seen)`。不是只显示次序变化：依据中实际选择的输入事实发生替换。

独立递归比较整个 case JSON 得到：domain seed1→2 恰有下面三处差异，domain_three 与 domain_four 相同；range seed1→5 也恰有三处差异，没有隐藏的其他 case 字段差异：

| case | 完整 JSON 路径 | 左 → 右 |
| --- | --- | --- |
| domain | /withoutRule/rdfsEvidence/0/basis/1/2 | `<urn:b>` → `<urn:a>` |
| domain | /withRule/rdfsEvidence/0/basis/1/2 | `<urn:b>` → `<urn:a>` |
| domain | /withRule/evidence/0/basis/1/2 | `<urn:b>` → `<urn:a>` |
| range | /withoutRule/rdfsEvidence/0/basis/0/0 | `<urn:a>` → `<urn:b>` |
| range | /withRule/rdfsEvidence/0/basis/0/0 | `<urn:a>` → `<urn:b>` |
| range | /withRule/evidence/0/basis/0/0 | `<urn:a>` → `<urn:b>` |

三样例的 withoutRule、withRule 分别均有两种完整输出，与 summary 的 distinct 数量相符；本次重新计算各输出 hash 并核对每条 summary observation 的完整 evidence。去除 evidence/rdfsEvidence 后，六 seed 的其余 case 返回字段逐项相等：rdfs 恒为 `[(u rdf:type C)]`，withoutRule.rules/evidence 为空；withRule.rules 恒为 `[(u derived seen)]`，warnings 恒为空。不能把元记录 hashSeed/hashSentinels 的预期变化本身当产品缺陷。

## 4. 固定实现原因与生产调用范围

固定 26/C2 `semantic.py:333` 对 predicate 的 closure.triples 未排序；`:344` 对 additions 只按结论 triple 排序，相同结论的多个候选保持原先迭代次序；`:345–347` 仅在 triple 尚未进入 closure 时登记首个 proof。于是两个有效支持都推出同一 `(u rdf:type C)`，先遇到的支持成为 proofs 唯一值。最终 `:405–407` 虽排序输出 proof 内部的 triple，也不能修正先前选择的不同支持。`:391–393` 将该 proof 投影进规则 basis，解释了 RDFS 与 Rule 两层同步变化。

固定 `semantic_execution.py:396–405` 的 `reasoning.execute` 生产分支确实调用同一 `semantic.reason(facts + ontology, rules)` 并保留完整返回值；`semantic_scopes.py:298–320` 的新生成入口也调用它。该缺陷不只存在于另写的假算法中，但本次 raw 是直接库调用，**没有实际运行这两条 Store/job 生产路径六次**。既存结果选择投影走已有载荷、不重算的语义也未被本次直接调用证明或推翻。

原固定 PRD 在 75/77、FR-502（417–421）、附录 C（974/979）将确定性引擎及真实 RDFS/规则依据纳入范围；附录 G:1117 明确要求比较具体对象、事实、状态和依据，而不只数量。原 B1 计划 155–161 要求真实候选库及源包同样例。该反例足以否定当前完整返回值稳定，不能以事实集合相同消去 basis 差异；**不据此新增“枚举所有替代证明”或采用 T05 比较策略的需求**。选择合法且稳定的 witness 是可由原 owner 判断的最小修复方向，本次不代其批准实现。

## 5. 处理状态与限制

原 round-2/observed-outcome.json 绑定 C2 2e／manifest31bd，明确 actualTasksCreated=false、actualTaskHandles=[]、externalReports=[]；round-2/input-manifest.json 也记录 actualReports/actualDispatches 为空。当前文件证据中的指定 C2 审查任务为 **0**，不存在可称作指定模型 C2 NotPass 的报告。本次未操作应用或独立核验桌面任务列表。

原 C2、原 full input 与失败原件保持。owner 状态及本次指令说明新 C3 在 I05-owned semantic/resources 范围准备 finite-5 修复；本次不跟读当前 dirty、不评定 C3 修复完成、不沿用 C2 的旧绿给新版通过。后续仍需新候选独立回归、受影响完整验收、源包同版、两指定模型全新完整审查及原 CI/推送/合并门。

未发现削弱反例本身的来源或完整 JSON 缺口。保留的证据边界是：有限六 seed／三个微型输入、直接导出源码库调用、未封存可变 venv、零退出无独立数值收据。本次没有新增运行验证、包内复现、性能结论或生产数据影响实证。
