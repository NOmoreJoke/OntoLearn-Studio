# I05 C3 确定性 witness 变更独立审查

2026-10-21，独立审查任务 semantic_bridge。

**结论：本次 C3 变更范围 Pass，C2 的 RDFS / rule basis 非确定性反例已实际重新验证关闭。** 未发现本次修改的新增阻断问题。该结论绑定固定产品源 `69598f30c9052a0a07f3d8e7fc4277626385678b`；完整测试头为 `b04569032e94c093e42b7fdc9fcd890df0e832e4`，后者只新增一个测试文件，没有产品源码差异。本报告不是指定双模型外审，也不代表完整 C3 包、跨平台验收、CI、发布或 M0 完成。

原 C2 检查点与其报告保持原字节。先前签名数字 IB-1 在 26 的关闭结论不需要改写；本次后来发现的 basis 非确定性属于另一项真实阻断，不能因旧签名修复或 C2 旧测试通过而忽略。

## 1. 实际范围与规则

只读主线：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-validation`，`feature/I05-semantic-validation`。

独立环境与所有新写入：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-bridge/build/`，审查树仍为 `feature/I05-semantic-bridge`。没有修改主线源、测试、配置、依赖、文档或运行环境；没有提交、push、操作 GUI / Electron / native / HMR / CUA 或 Docker，没有更改 Goal。受保护 AGENTS dirty 未 stage、未改写。

本轮实际读回最新 AGENTS（SHA256 `78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759`）、共同开发指令（`b24c4c88404f422c5fae4bf6c01e231b678e46741250801e8100cc62a31fec39`）和 external-review-permissions（`3630cc78ad87d1833ad33102f437d9027814cb688b319c4cd3ae9a2d0fbde4f7`）。T01 / T03 / I06 已生效所有权未被接管。本次仅审原 I05 自有 semantic / resources / samples 及测试增量；没有采用未批 T05 实现、比较策略或多头输出。

依据实际读取的 PRD FR-501 / FR-502 / FR-505、附录 C 与 G.2，以及仓内 I03 inputs 中保存的 M0 B1 原文：先完成 RDFS 闭包，所有规则读取同一冻结输入，规则保存顺序不影响可观察结果，完整规则依据必须真实；RDFS 只承诺相关公理与事实，不承诺所有证明或最短证明。新 witness 策略是“确定性第一轮、按完整 direct-input key 排序选择首个有效来源”，没有扩大上述能力。

## 2. 固定源、增量与原反例读回

基线：`26eb632f0e1210b03ac3aef4cfd71fdc4a0c5222`，finite4。产品修复：`69598f30c9052a0a07f3d8e7fc4277626385678b`，finite5。最终只增测试头：`b04569032e94c093e42b7fdc9fcd890df0e832e4`。

对 695 做实际 `git archive --format=tar`，导出到本人 ignored `build/c3-independent/source-69598f3`。完整原 tar 为 43,837,440 字节，SHA256 `96269d0dbb3e89fc288b38e2468d9c40bd15c4458251a98efdded9a2a0c672e6`。最终执行后，逐项读回其 1181 个原始文件，与 tar 中字节比较，全部一致。环境与 runtime DB 属于导出后的独立临时输出，不计作源码。

| 固定文件 | SHA256 |
| --- | --- |
| `semantic.py` | `ac1a29fe1ecc6f9d3ae89c7db24f17f23d7488244c5de113b6b423190d203862` |
| `resources.py` | `66ca9f77fc664f7ccf0037d84890a2de7892481d7e8e3401ec5b51af12fb7aca` |
| `semantic_samples.py` | `af807d22e7da934c97c89c58934cbeadc9daa6c42b8087917031cc41175d7404` |
| `test_semantic_execution.py` | `945ca59117c252f19aefd5709e96cd1189f5edb19bc3ddb94e227e469d0d96bd` |
| `uv.lock` | `86dfe82d952e2c88edcfc5658f488f6e1f0d04b4ec3b1e6f5c5d3bc4f57e8b73` |
| engine `pyproject.toml` | `bcc8825b1f2902a66ae539e687df57e5b2554247f48a48a65215601a77958365` |

实际比较 695→b045 的 `packages/engine/src`，diff 为空；上述六个固定文件也与 b045 的 Git blob 一致。完整读取新增 249 行 `test_semantic_rdfs_basis_determinism.py`，9390 字节，SHA256 `0d2c33dcd5e76d7d6d745c99805399da6f3002ba7a42449899c07a82b053ef39`。该文件的 seed fixture 实际使用 fresh subprocess、没有 -I / -E 屏蔽 seed，校验模块来源 / 源码哈希 / 输入哈希；完整手写预期覆盖 domain、range、混合路径、subclass-domain ordered-input tie、diamond、多层 domain、所有规则匹配、asserted 优先和 frozen 组合。并非只比较数量或要求与第一次运行相同。本人对该新增文件做完整静态审查；其父任务已报告的 10 pass / C2 7 fail 3 pass 不冒称为本人运行。

主线 `docs/reviews/I05/evidence/c2-basis-counterexample/{manifest.json,raw-counterexample.tar.gz}` 已独立打开读取。实际验证全部 19 成员长度、名称和 SHA256，均一致，archive SHA256 `3bf9d53d8eb7dbddc7e65d0e2ea13ae188aae2e73db8e04eddd95818c339b87e`。原脚本、原输入、完整六 seed 输出和 finding 均读回；反例确实改变 `rdfsEvidence.basis`，并传到规则 `evidence.basis`，不只是静态迭代顺序担忧。结论三元组相同不能消除完整可观察输出不同的问题。

## 3. 设计与实现审查

唯一实际推理逻辑改变是在每轮 additions 的排序中，将原来只看输出 triple 的 key 改为：

```python
(_key(output), tuple(_key(t) for t in ordered_direct_inputs))
```

没有先把 inputs 当集合排序，没有按展开后 basis 排序，也没有引入全证明搜索。各模板中的 direct-input 顺序有明确含义，完整 key 维持此顺序；同输出、不同模板的输入路径可稳定比较。direct inputs 自身相同的重复候选，合并来源相同，稳定排序对最终结果不再产生可观察差异。

正确性可按轮次检查：asserted 的 proof 初值固定为其自身；一轮 additions 在 closure 修改前完整收集，所有候选只引用本轮开始时已有的 closure。已存在 triple 的 proof 不覆写。若前一轮 closure 和 proof 固定，本轮候选内容、完整排序、首个新增 witness 与其原子基础的并集也固定。因此后续轮次保持确定性，循环不会触发 proof 自我递归。后到的证明不替换已选 witness，这与“第一轮首个有效 witness”的策略一致，而非最小证明保证。

以下原不变量未变：

- RDFS 输出仍先完成闭包；所有规则仍在该冻结闭包上匹配。
- 规则循环继续按 id 排序，所有匹配继续保留 evidence；多个匹配产生同一 output，不会因本次 RDFS witness 去重而丢失规则 evidence。
- 规则输出不回流其他规则或 RDFS；warning 和现有资源上限仍有效。
- 原始 graph / Store 不被推理写回；来源仍区分 asserted / ontology / RDFS / rule。
- 数据结构与边界契约未换成 T05 的比较或多头格式。

semantic 与 resources 的 executionSemanticsVersion 同步提升为 `i05-finite-5`，执行版本测试同步；samples 增加完整 domain / range witness oracle，并实际覆盖反向插入与无关事实。没有修改锁、依赖、query / turtle helper、Store、coordinator 或共享 bridge。排序多读取固定的 direct-input key，未观察或量化性能提升，也不作容量承诺。

## 4. 本人实际独立 C2 红 / C3 绿证明

`build/c3-independent/probe-child.py` / `run-probe.py` 是本审查独立编写的短探针，没有复制 T05 实现。每个产品版本分别执行 seed 1、2、3、5、7、11 的六个真实 fresh Python 进程；命令使用 `python -B`，没有 -I / -E。每次读取实际固定源码模块并记录其路径、SHA、库版本、Python 版本和 seed。

每个 seed 有 8 个场景，每场景 forward / reverse / dedicated irrelevant-predicate 三种输入，共每版本 144 次纯真实 reason 调用，保留全部输出。domain、range 和 mixed-domain-range 使用独立手建的**完整结果对象**预期；另用一个不调用受审 reason 的简单关系闭包核查每条 retained basis 均来自原始输入并能推出其 RDFS result / rule inputs。其他场景比较完整结果及明确不变量，不把它们冒称为全手写 oracle。

| 场景 | C2 六 seed 完整输出种数 | C3 六 seed 完整输出种数 |
| --- | --- | --- |
| domain 多候选事实 | 2 | 1 |
| range 多候选事实 | 2 | 1 |
| mixed domain / range 同一结论 | 1 | 1 |
| diamond 多路径 | 1 | 1 |
| subclass cycle | 1 | 1 |
| 多轮 domain / subclass | 2 | 1 |
| asserted 结论优先 | 1 | 1 |
| 多规则 / 多匹配同输出 | 1 | 1 |

C3 三个完整手建 oracle 在全部六 seed / 三种输入顺序均通过。所有 C3 场景的完整输出在三种输入变化及跨 seed 均相同。多规则场景确实保留 3 条 evidence、只产生一个 rule output，消费规则不链式触发；asserted 结果仍使用 asserted 自身作为 basis。C2 红例按实际失败保留，不推断所有未波动场景必然原来正确或所有未来输入已被穷举。

`probe-summary.json` SHA256：`6801631a32a80633dfa9b308a070658e33c8e260979bb8bc4e0b6898f3f26480`。

## 5. 真实 Store / worker / stdio、所选结果与版本

纯 seed 探针使用本人已有独立锁定环境（RDFLib 7.6.0 / pyparsing 3.3.3 / pySHACL 0.30.1 / owlrl 7.6.2）。运行联验另在本人固定 695 导出内执行 `uv sync --frozen` 创建全新 `.venv`，实际 package editable 只指向该独立导出。旧 26 的真实 producer 另建 `old-env` 指向本人既有固定 26 导出。没有 symlink 或借用主线环境；worker 的 -I 模式也能解析到各自真正安装的固定版本。

`runtime-proof.py` 在真实 JobStore 用 `Store.commit` 创建不可变事实、domain / range 本体、规则、query 与 SHACL 定义，manual id 使用真实 digest。完成由真实 coordinator / worker 或 stdio 执行，没有伪造 job、直接 finish 或纯函数结果替代 worker。

本人实际执行结果：

- 旧 26 real worker 完成 1 个 reasoning job，真实 metadata / payload / source / rows 留存为 finite4。
- 新 695 direct-worker 与真实 stdio 各完成 4 个 job，共 8 个新 completed：各两次 reasoning、一次 selected-derived query、一次 selected-derived validation。
- 两次 reasoning 的完整 payload 相同；domain 与 range 的两个 rdfsEvidence、两个 rule evidence 的 basis 均严格匹配预期来源。
- query 完整结果恰为 `<urn:u>`、`<urn:v>`；validation 对这两个派生目标确实产生 2 项名称必填违规。
- 所有结果通过实际 `result.get` / 多页 `result.page` 验证绑定和稳定行序，回读 rows 与真实持久结果相同；metadata、payload、reasoning source 和 resource manifest 都宣告 finite5。项目权威 state 在执行前后完全相同。
- 在新 coordinator 中，旧 finite4 的真实 result 仍能 `result.get` 且通过 `semantic_result` 鉴权，metadata / payload 与旧完成时一致；它作为新 finite5 任务的 selected-derived 输入时，返回真实四字段 `IDENTITY_CONFLICT`，没有重算或重写旧 payload。这证明“真实旧 producer”与损坏 / 未知 producer 不是同一个历史事实。
- 分别把纯投影上下文的版本声明换成 finite4 与 `foreign-producer`，均明确 `REASONING_SOURCE_MISMATCH`；未知声明没有被当作已认证来源。该项不伪称产生了一个真实未知 producer。

`runtime-proof.json` 共 376649 字节，SHA256 `2346e243464f2b213764ae17ad484c76b4a6cb6eba48b974c5de627e239f0c35`。旧 producer 完整原件 `runtime-old-producer.json` 28978 字节，SHA256 `ecc0af7fd17a88452e0b70750ed3d3940bd6db975cb82ad50019db2b480e4b32`。两次最终 runtime stdout / stderr 也保留，最终 stderr 为空。

worker / stdio 是源码真实隔离进程，没有声称控制其 -I worker 的 PYTHONHASHSEED；控制 seed 的证据来自上一节不带 -I 的 fresh 纯库进程。没有用两者混淆种子实验。

## 6. 本人实际选定上下游测试与命令

在固定 695 的独立 `.venv` 实际运行：

```text
python -B -m pytest -q -p no:cacheprovider \
  packages/engine/tests/test_semantic.py \
  packages/engine/tests/test_semantic_scopes.py \
  packages/engine/tests/test_semantic_selected_projection.py \
  packages/engine/tests/test_semantic_execution.py \
  packages/engine/tests/test_semantic_runtime.py
```

**212 passed in 13.06s，exit 0。** 完整命令的绝对路径、cwd、环境归属和 elapsed 保存在 `selected-tests-command.json`；实际日志 `selected-tests.log` SHA256 `1c91574e22b49d3c0a9ceb9ea9406605e183839e4b6cdea0ac2b6130c8984687`。其中真实 suite 调用执行了 samples 新增 witness oracle，runtime 文件包括 Store / worker / stdio 及所选结果、来源和完整身份的上下游验证。

本次没有重跑无变化的 134 查询矩阵、完整 lexical suite、全仓 check、包、GUI / native。主任务的新完整 check / source / Mac 与 Linux 包工作由主任务负责，本报告不给这些未由本人执行的项目预先记绿。b045 仅增测试后，实际核对产品源码无变化，没有为此重跑本人已通过的同版独立探针。

具体实际命令另包括：`git archive 69598f30...`；固定 `git show` / `git diff 69598f30... b0456903... -- packages/engine/src`；本人独立 `uv sync --frozen --project .../source-69598f3`；`UV_PROJECT_ENVIRONMENT=.../old-env uv sync --frozen --project .../c2-review-26eb632`；fresh probe / runtime proof 脚本。没有在主线执行这些命令。

## 7. 原失败、探针修正与可恢复性

本轮探针编写期间的错误没有覆写：

1. 宿主系统 Python 的 tarfile 不支持 `filter` 参数，导出解包前即报错；改用对固定 git archive 的显式路径 / 类型校验后解包。不是产品失败。
2. 初版探针对故意作为红例的旧 C2 也断言 insertion invariance，按旧缺陷触发；调整为只对 C3 强制绿色。初版脚本和 stderr 保留。
3. 中间版所谓“无关”事实复用了一个已有 domain schema 的 predicate，实际改变了输入语义，不能要求输出不变；最终改为专用 noisePredicate。中间脚本和所有输出保留。没有因此改产品。
4. 首次选定测试命令用了无 pytest 的既有环境，`No module named pytest`，没有测试启动；随后在新固定导出内以 frozen lock 建立独立环境运行。原日志保留。
5. 初版新 runtime 在第二次 reasoning 后，选择了已被 supersede 的第一次结果作为 current 输入，现有保护正确返回 `IDENTITY_CONFLICT`。最终显式选择最新 current 结果；旧失败日志、脚本和数据库在本人 ignored 目录保留，未把它误报为产品回归。

这些修正与实际 C2 basis 非确定性红例分开记录。没有删除不利证据，也没有通过重测把旧真实反例覆盖。

本人证据根为：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-bridge/build/c3-independent/`。`artifact-manifest.json` 索引 71 份源归档、完整 JSON 输出、脚本、日志和探针修正工件，SHA256 `469dcc6ecc43cdbb400fc918f669dc582ca3419343892e9d9fdcea427077a625`。其本身与本报告独立保存，避免自引用；索引排除所有 DB / WAL / SHM、venv 与解开的源码环境，包含原始固定 git archive。运行 DB 仅留本人 ignored 环境，不应复制进仓库。

源码执行后绑定文件 `post-execution-source-binding.json` SHA256 `71cfc5d8efbf9bee963c865994c130f4018207f284ef344bf4bc9c47010daeac`，明确记录 695 / b045 的源一致性与 1181 原文件字节不变。旧 C2 归档和本轮新证据各有固定归属，本轮没有修改旧 C2 审查或证据。

## 8. 明确交接与未验边界

可将本轮问题登记为：**C3-BASIS-1 已关闭（固定 695 产品源 / b045 测试头，独立 C2 红 → C3 绿，真实 worker / stdio 与版本隔离通过）。** 没有本轮要求主任务再改的阻断意见。

此 Pass 限于本次变更的代码、独立反例、选定上下游与真实源码执行证明；六 seed / 有界样本不是所有输入的穷举。确定性结论还依赖已冻结的有限 RDF term 身份 / n3 key 和库版本边界，没有承诺完整 RDF / SPARQL 标准、全部证明、最短证明、跨版本结果相同或未测量性能。旧 C2 的其他明确限制仍保留。

新的完整候选验证、跨平台 package / B1 / native、全 Q6 与首发平台、签名 / 干净设备及正式发布门由主任务按实际结果处理。旧 C2 包或其新旧报告不能自动变成 C3 包证据；未运行的项目不记为通过。本次独立审查不能替代指定 ZCode / MiniMax 全范围新双审，不能据此提前 push / PR / 合并。
