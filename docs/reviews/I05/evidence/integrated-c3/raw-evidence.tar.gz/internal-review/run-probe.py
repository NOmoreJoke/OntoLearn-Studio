import hashlib,json,os,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent;own=base.parents[1];python=own/'build/c2-review-venv-26/bin/python'; old=own/'build/c2-review-26eb632';new=base/'source-69598f3'
summary={}
for label,source in [('C2',old),('C3',new)]:
 all_records=[]
 for seed in [1,2,3,5,7,11]:
  env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')};env.update(PYTHONHASHSEED=str(seed),PYTHONDONTWRITEBYTECODE='1')
  p=subprocess.run([str(python),'-B',str(base/'probe-child.py'),str(source)],cwd=base,env=env,capture_output=True,timeout=30)
  (base/f'{label}-seed-{seed}.stdout.json').write_bytes(p.stdout);(base/f'{label}-seed-{seed}.stderr.txt').write_bytes(p.stderr)
  assert p.returncode==0 and not p.stderr,(label,seed,p.returncode,p.stderr.decode())
  all_records.append(json.loads(p.stdout))
 summary[label]={}
 for case in all_records[0]['cases']:
  results=[r['cases'][case]['forward']['output'] for r in all_records]
  summary[label][case]={'distinctCompleteOutputs':len({json.dumps(r,sort_keys=True) for r in results}),'completeOutputHashes':[hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in results],'handOracleMatches':[r['cases'][case]['forward']['oracleMatch'] for r in all_records]}
 if label=='C3':
  assert all(v['distinctCompleteOutputs']==1 for v in summary[label].values())
  assert all(all(x is True for x in v['handOracleMatches']) for k,v in summary[label].items() if k in ['domain','range','mixed-domain-range'])
assert any(summary['C2'][k]['distinctCompleteOutputs']>1 for k in ['domain','range'])
(base/'probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({label:{case:{'distinctCompleteOutputs':v['distinctCompleteOutputs'],'handOracleMatches':v['handOracleMatches']} for case,v in cases.items()} for label,cases in summary.items()},indent=2))
