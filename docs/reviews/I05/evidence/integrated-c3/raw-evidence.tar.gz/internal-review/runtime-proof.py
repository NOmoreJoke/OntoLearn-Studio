"""Real immutable Store + coordinator + worker + stdio publication, no fake finish."""
import copy,json,sys
from pathlib import Path
from uuid import uuid4
source=Path(sys.argv[1]).resolve();base=Path(sys.argv[2]).resolve();phase=sys.argv[3]
sys.path.insert(0,str(source/'packages/engine/tests'))
from test_semantic_lexical_runtime import DirectWorker,completed,parameters
from test_resident_runtime import Session
from ontolearn_engine import semantic
from ontolearn_engine.resources import CONTRACT,IMPLEMENTATION,resource_manifest
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.storage import digest
from ontolearn_engine.semantic_scopes import project_validation_scope
from ontolearn_engine.semantic_offline import SemanticError
from rdflib import Graph,URIRef,RDF,RDFS,Variable
uid=lambda:str(uuid4()); T=str(RDF.type); D=str(RDFS.domain); R=str(RDFS.range)
triples=[['urn:u','urn:p','<urn:a>'],['urn:u','urn:p','<urn:b>'],['urn:a','urn:q','<urn:v>'],['urn:b','urn:q','<urn:v>']]
ontology=[{'subject':'urn:p','predicate':D,'object':'<urn:C>'},{'subject':'urn:q','predicate':R,'object':'<urn:C>'}]
def seed(s):
 s.create_project('basis');p=s.public_project('basis')
 s.commit('basis',0,uid(),uid(),definitions=[{'layer':'ontology','id':'classes','value':{'triples':ontology}},{'layer':'rule','id':'observe','value':{'enabled':True,'when':[['?x',f'<{T}>','<urn:C>']],'then':['?x','<urn:observed>','<urn:yes>']}},{'layer':'query','id':'types','value':{'text':'SELECT ?s WHERE { ?s a <urn:C> }'}},{'layer':'constraint','id':'names','value':{'enabled':True,'turtle':'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:S> a sh:NodeShape; sh:targetClass <urn:C>; sh:property <urn:P> . <urn:P> sh:path <urn:name>; sh:minCount 1 .'}}],manual=[{'id':digest([s,p,o]),'subject':s,'predicate':p,'object':o} for s,p,o in triples])
 return p
assert Path(semantic.__file__).resolve()==source/'packages/engine/src/ontolearn_engine/semantic.py'
if phase=='old':
 db=base/'old-producer.sqlite';s=JobStore(db,contract=CONTRACT);p=seed(s);state=s.state('basis');s.close();backend=DirectWorker(db,p)
 try:record=completed(backend,parameters(p,'reasoning.execute','all'))
 finally:backend.close()
 s=JobStore(db,contract=CONTRACT);meta,payload=s.semantic_result(p,record['metadata']['resultId']);assert s.state('basis')==state;s.close();record.update(payload=payload,resource=resource_manifest(),state=state)
 (base/'runtime-old-producer.json').write_text(json.dumps(record,indent=2)+'\n');print('actual old producer succeeded',meta['implementation']);sys.exit(0)
records=[]
for mode in ['worker','stdio']:
 db=base/f'{mode}-new.sqlite';s=JobStore(db,contract=CONTRACT);p=seed(s);state=s.state('basis');s.close();backend=DirectWorker(db,p) if mode=='worker' else Session(db,[p],test_mode=False)
 saved=[]
 try:
  for i in range(2):saved.append(completed(backend,parameters(p,'reasoning.execute','all')))
  rid=saved[-1]['metadata']['resultId']
  saved.append(completed(backend,parameters(p,'query.execute','types',derived=rid)))
  saved.append(completed(backend,parameters(p,'validation.execute','names',derived=rid)))
 finally:backend.close()
 s=JobStore(db,contract=CONTRACT)
 for record in saved:
  meta,payload=s.semantic_result(p,record['metadata']['resultId']);assert meta['implementation']==IMPLEMENTATION and payload['executionSemanticsVersion']=='i05-finite-5';assert record['rows']==s.result(meta['resultId'])['payload'];record['payload']=payload
 assert saved[0]['payload']==saved[1]['payload']
 result=saved[0]['payload']['reasoning'];n3=lambda t:[str(x) if str(x).startswith('<') else '<'+str(x)+'>' for x in t]
 expected_basis={'<urn:u>':sorted([['<urn:p>',f'<{D}>','<urn:C>'],['<urn:u>','<urn:p>','<urn:a>']]),'<urn:v>':sorted([['<urn:q>',f'<{R}>','<urn:C>'],['<urn:a>','<urn:q>','<urn:v>']])}
 assert len(result['rdfsEvidence'])==2 and len(result['evidence'])==2
 for e in result['rdfsEvidence']:assert e['basis']==expected_basis[e['result'][0]]
 for e in result['evidence']:assert e['basis']==expected_basis[e['result'][0]]
 assert saved[2]['payload']['query']=={'type':'SELECT','variables':['s'],'rows':[['<urn:u>'],['<urn:v>']]}
 assert saved[3]['payload']['report']['conforms'] is False and len(saved[3]['payload']['report']['violations'])==2
 assert saved[0]['payload']['source']['executionSemanticsVersion']==IMPLEMENTATION['executionSemanticsVersion']=='i05-finite-5'
 assert s.state('basis')==state;s.close();records.append({'mode':mode,'records':saved,'authorityStateUnchanged':True})
old=json.loads((base/'runtime-old-producer.json').read_text());p=old['metadata']['projectId'];backend=DirectWorker(base/'old-producer.sqlite',p)
try:
 current=backend.call('result.get',{'projectId':p,'resultId':old['metadata']['resultId']});assert current==old['metadata']
 before=backend.store.state('basis');identity=old['metadata']['resultId'];response=backend.call('semantic.start',parameters(p,'query.execute','types',derived=identity));assert response['code']=='IDENTITY_CONFLICT',response
 meta,payload=backend.store.semantic_result(p,identity);assert payload==old['payload'] and meta==old['metadata'] and backend.store.state('basis')==before
 compatibility={'oldResultStillAuthenticAndReadable':True,'oldImplementation':meta['implementation'],'newImplementation':IMPLEMENTATION,'selectionError':response,'oldPayloadUnmodified':True}
finally:backend.close()
facts=Graph();[facts.add((URIRef(s),URIRef(p),URIRef(o[1:-1]))) for s,p,o in triples];axioms=Graph();[axioms.add((URIRef(x['subject']),URIRef(x['predicate']),URIRef(x['object'][1:-1]))) for x in ontology]
rules=(semantic.Rule('observe',((Variable('x'),RDF.type,URIRef('urn:C')),),(Variable('x'),URIRef('urn:observed'),URIRef('urn:yes'))),)
errors={}
for v in ['i05-finite-4','foreign-producer']:
 source_identity=copy.deepcopy(records[0]['records'][0]['payload']['source']);source_identity['executionSemanticsVersion']=v
 try:project_validation_scope(facts,axioms,include_derived=True,reasoning_result=records[0]['records'][0]['payload']['reasoning'],reasoning_source=source_identity,rules=rules)
 except SemanticError as e:errors[v]=str(e);assert str(e)=='REASONING_SOURCE_MISMATCH'
 else:raise AssertionError('foreign version accepted')
out={'source':str(source),'implementation':IMPLEMENTATION,'resourceManifest':resource_manifest(),'actualCompletedNewJobs':sum(len(x['records']) for x in records),'records':records,'oldProducerCompatibility':compatibility,'declaredVersionMismatchErrors':errors}
(base/'runtime-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'actualCompletedNewJobs':out['actualCompletedNewJobs'],'oldProducerCompatibility':compatibility,'declaredVersionMismatchErrors':errors},indent=2))
