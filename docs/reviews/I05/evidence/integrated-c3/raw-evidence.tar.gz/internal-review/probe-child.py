"""Independent full-output stability and hand-built witness oracle; not T05 code."""
import hashlib,json,os,platform,sys
from pathlib import Path
from importlib.metadata import version
source=Path(sys.argv[1]).resolve();sys.path.insert(0,str(source/'packages/engine/src'))
from rdflib import Graph,Namespace,RDF,RDFS,Variable
from ontolearn_engine import semantic
from ontolearn_engine.semantic import Rule,reason
from ontolearn_engine.resources import IMPLEMENTATION
W=Namespace('urn:review:c3:'); U=Variable('u');O=Variable('o')
r=Rule('observe',((U,RDF.type,W.C),),(U,W.observed,W.yes))
row=lambda t:tuple(v.n3() for v in t)
def expected(triples,result,rule=True):
 basis=sorted(row(t) for t in triples)
 return {'rdfs':[row(result)],'rules':[row((W.u,W.observed,W.yes))] if rule else [],'warnings':[], 'rdfsEvidence':[{'result':row(result),'basis':basis}], 'evidence':[{'rule':'observe','result':row((W.u,W.observed,W.yes)),'inputs':[row(result)],'basis':basis}] if rule else []}
domain=[(W.u,W.p,W.b),(W.u,W.p,W.a),(W.p,RDFS.domain,W.C)]
range_=[(W.b,W.p,W.u),(W.a,W.p,W.u),(W.p,RDFS.range,W.C)]
mixed=[(W.u,W.p,W.a),(W.p,RDFS.domain,W.C),(W.b,W.q,W.u),(W.q,RDFS.range,W.C)]
cases={
'domain':(domain,(r,),expected([domain[1],domain[2]],(W.u,RDF.type,W.C))),
'range':(range_,(r,),expected([range_[1],range_[2]],(W.u,RDF.type,W.C))),
'mixed-domain-range':(mixed,(r,),expected(mixed[:2],(W.u,RDF.type,W.C))),
'diamond':([(W.u,RDF.type,W.A),(W.A,RDFS.subClassOf,W.B),(W.A,RDFS.subClassOf,W.C),(W.B,RDFS.subClassOf,W.D),(W.C,RDFS.subClassOf,W.D)],(r,),None),
'cycle':([(W.u,RDF.type,W.A),(W.A,RDFS.subClassOf,W.B),(W.B,RDFS.subClassOf,W.A),(W.B,RDFS.subClassOf,W.C)],(r,),None),
'multi-round-domain':([(W.u,W.p,W.b),(W.u,W.p,W.a),(W.p,RDFS.domain,W.A),(W.A,RDFS.subClassOf,W.B),(W.B,RDFS.subClassOf,W.C),(W.u,W.q,W.z),(W.q,RDFS.domain,W.B)],(r,),None),
'asserted-wins':(domain+[(W.u,RDF.type,W.C)],(r,),None),
'all-rule-matches':([(W.u,W.p,W.b),(W.u,W.p,W.a),(W.u,RDF.type,W.C)],(Rule('r1',((U,W.p,O),),(U,W.observed,W.yes)),Rule('r2',((U,W.observed,W.yes),),(U,W.later,W.yes)),Rule('r3',((U,RDF.type,W.C),),(U,W.observed,W.yes))),None),
}
def naive_closure(rows):
 c=set(rows)
 while True:
  more=set()
  for s,p,o in c:
   if p==RDFS.subClassOf:
    more.update((u,RDF.type,o) for u,v,w in c if v==RDF.type and w==s)
    more.update((s,RDFS.subClassOf,w) for u,v,w in c if u==o and v==RDFS.subClassOf)
   if p in (RDFS.domain,RDFS.range):
    more.update((u if p==RDFS.domain else w,RDF.type,o) for u,v,w in c if v==s and isinstance(u if p==RDFS.domain else w,type(W.u)))
  n=c|more
  if n==c:return c
  c=n
records={}
for name,(triples,rules,oracle) in cases.items():
 variants={}
 for order in ['forward','reverse','irrelevant']:
  ts=list(triples)
  if order=='reverse':ts.reverse()
  if order=='irrelevant':ts=list(reversed(ts+[(W.unrelated,W.noisePredicate,W.other)]))
  graph=Graph();[graph.add(t) for t in ts];out=reason(graph,rules);keyed={row(t):t for t in ts}
  # Independently validate each retained witness against a tiny relational closure.
  for e in out['rdfsEvidence']:
   basis=[keyed[tuple(t)] for t in e['basis']];assert tuple(e['result']) in {row(t) for t in naive_closure(basis)}
  for e in out['evidence']:
   basis=[keyed[tuple(t)] for t in e['basis']];closure={row(t) for t in naive_closure(basis)};assert all(tuple(t) in closure for t in e['inputs'])
  if name=='all-rule-matches':
   assert out['rdfs']==[] and out['rules']==[row((W.u,W.observed,W.yes))] and len(out['evidence'])==3 and out['warnings']==['RULE_CHAIN_UNSUPPORTED:r2']
  if name=='asserted-wins':assert out['rdfs']==[] and out['evidence'][0]['basis']==[row((W.u,RDF.type,W.C))]
  variants[order]={'output':out,'oracleMatch':None if oracle is None else out==oracle}
 if semantic.SEMANTICS_VERSION=='i05-finite-5':assert variants['forward']['output']==variants['reverse']['output']==variants['irrelevant']['output']
 records[name]=variants
assert Path(semantic.__file__).resolve()==source/'packages/engine/src/ontolearn_engine/semantic.py'
print(json.dumps({'seed':os.environ.get('PYTHONHASHSEED'),'source':str(source),'semanticVersion':semantic.SEMANTICS_VERSION,'implementation':IMPLEMENTATION,'python':platform.python_version(),'versions':{n:version(n) for n in ['rdflib','pyparsing','pyshacl','owlrl']},'semanticSha256':hashlib.sha256(Path(semantic.__file__).read_bytes()).hexdigest(),'cases':records},sort_keys=True,indent=2))
