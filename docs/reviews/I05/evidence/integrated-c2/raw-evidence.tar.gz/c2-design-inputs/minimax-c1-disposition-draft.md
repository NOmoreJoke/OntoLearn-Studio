# C1 MiniMax final report disposition plan (not implementation completion)

Source: final actual terminal report 62001ba637de4937d78f8f07c50982155940817041961259481298e5348a998b, 690 lines/93217 bytes, full old report plus all final deltas read. C1 remains NotPass. ZCode original full review still running, so no frozen product edits yet.

| Original item | Proposed C2 disposition / evidence needed |
| --- | --- |
| B-1-prime / old L-1 | Accept confirmed SHACL false-positive and false-negative defect. Preserve original source/probe/reports. Fix constraint Turtle locally without global Literal settings; quoted and bare numeric lexical identity, positive and negative exact allowed-value cases in source/package suite and actual Store/worker/selected-derived chain. Bump semantic and implementation version to finite-4. Only fresh C2 reviews can close. |
| Withdrawn rule assertion 4.2(4)3 | Reviewer explicitly withdrew it in4.4(4). Keep same-term rule positive and different-term/same-value negative tests; no numeric-equal or FR505 expansion. Retain original mistaken claim and independent counterpoint as history. |
| M-3 | Accept and fix separately at SPARQL numeric construction, not only Turtle. Local grammar clone covers numeric integer/decimal/double with signs; explicit typed SPARQL already correct. Preserve BGP/VALUES identity and ordinary numeric FILTER/arithmetic. Cover canonical1/bare01 false-positive as well as selected-derived01/bare01 false-negative. Original report's prose says only noncanonical facts reachable, but its own first matrix and actual Store raw also demonstrate canonical1 false-positive: do not narrow tests to derived-only or claim reviewer scope sentence as product fact. W3C4.1.2 directly read by developer; reviewer limitation of not obtaining it remains its own stated limitation. |
| H-1 | Keep FR505 generic comparison/single-rule multiple conclusions explicitly unimplemented, Q6-08 awaiting owner adoption/revision/rejection. No product-decision inference or new rule expression/editor. |
| M-1 | Accept precise unsupported classification within existing public category: actual locked prepared algebra node is Graph (read-only probe showed SelectQuery/Project/Graph/BGP). Plan QUERY_GRAPH_UNSUPPORTED mapped to existing UNSUPPORTED_CONSTRUCT/sparqlForm; no public contract change. Preserve higher-priority SERVICE/FROM denial even nested inside GRAPH by rejecting Graph only after full existing external-construct scan. Add actual fixed/variable GRAPH and nested SERVICE regression. No named graph support. |
| M-2 | Partially accept documentation: record actual acceptance policy and representative measured STR/langMatches/CONCAT/SUBSTR/STRLEN/IRI, explicitly non-exhaustive and not an explicit whitelist. Rejected nondeterministic/custom/aggregate set remains accurate. Final supported-function baseline still Q6 owner decision; do not invent complete semantic coverage or extend library behavior. |
| L-2 | Document productRuntime declarative vs v2Runtime actual hello methods, semantic.start business named bridge/non-agent exposure. No registry change or14-file return needed. |
| L-3 | Defer cleanup symmetry with explicit basis: nonsemantic test failRound returns immediately into process exit and main owner-monitor finally; actual semantic path already closes memory guard in finally. No demonstrated resident leak. Preserve as minor future worker cleanup, not pretend fixed. |
| L-4 | No automatic replay change: fresh operation IDs mean explicit new product actions; engine idempotency is independently tested defense. Do not add automatic writes merely to exercise that branch. Document boundary as observation. |
| O-1 | Keep whole-product6b check vs851 harness-only delta distinction and external author's independently run checks. C2 full check will cover final changed product plus harness. Correct report's six-stage shorthand by distinguishing no build run by reviewer. Do not infer full check from145-byte sealed log alone. |
| O-2 | Retain running-vs-final forbidden-job snapshots; compare final outcome/payload, not arbitrary transient sample equality. |
| O-3 | Preserve1479/1510/1511 checkpoint counts and original failures, never rewrite as one first-run success. |
| O-4 | Preserve diagnostic Linux3.11.2 vs actual packaged3.12.15 distinction. |
| O-5 | Clarify original982 export compares current protected guidance separately; dirty AGENTS differs from Git blob intentionally. Actual Docker982 comparison zero mismatches, not one failing Docker source. |
| O-6 /4.1 residue | Correct current document's historical fixture wording to content-derived fact ID/digest; old043 blob, original raw and lineage note retained. No UUID requirement. |
| B-1 | Actual CI after local validation + same-version dual Pass + disposition + push/PR, before normal merge. No current CI claim. |
| B-2 | I05 real native source/package acceptance on isolated Linux; macOS/Windows I05 native matrix remains untested, explicit Q2/platform scope. Their portable CLI/stdio CI still required. |
| B-3 | Native license exact provenance remains MacPBS3.12.12 andLinux-aarch643.12.15; other target runtimes pending, not all-platform licensing pass. |
| B-4 | Signing/clean-device/offline installation/production/capacity and Q2/Q3/Q5/Q6/Q7/Q8/Q9 choices remain owner decisions, not B1 pass. |
| B-5 | External reviewer did not run GUI/native; distinguish developer's real isolated native evidence from reviewer's readback. No Mac product GUI. |
| B-6 | Reviewer did not independently recompute all Linux container/package bytes; retain actual developer comparison provenance and limits. |

Q6-01/04/10: record actual C1 defects and the C2 fix evidence, both identity directions, not a silent capability reduction. Q6-02/03/05/06/07/08/09/11/12 retain original per-item technical facts and owner-pending decisions; literal repair does not adopt any row or complete unimplemented editing/exchange/behavior/sandbox.

All actions above are plans until actual changed source/tests/build/runtime evidence exists; formal disposition document must add actual commit/path/check evidence and full final ZCode findings before C2 freeze.
