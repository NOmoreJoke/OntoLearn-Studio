# I05 C1：规则常量项身份与值比较的范围澄清

本记录为独立只读需求/源码核对，不是运行复现、审查报告改判或阻断关闭。仅新建此总控记录；未修改功能 worktree、state 或冻结输入，未运行测试/GUI，未读取另一指定模型本轮意见。

## 固定输入

- 受审 C1：`043c20cc7934191339a8814c79666dbd2e94a62a`。
- MiniMax 固定报告：`.private/I05-C1-report-history-20261021/build/i05-integrated/c1-observations/minimax-live-74d1b77d7e1c993e8daa7bb2a6b9ee6456acf3b8701337ea2ee6a3b08ba1776f.md`；实际 SHA256 为 `74d1b77d7e1c993e8daa7bb2a6b9ee6456acf3b8701337ea2ee6a3b08ba1776f`。
- 仅核对 §4.2(4)③的规则期望归属及相关语义；①② SHACL 真阻断不在本次重审范围。报告行321称：when 的 `"01"^^xsd:integer` 应匹配事实 `"1"^^xsd:integer`，理由为“同值同项”。

## 可核验事实

1. **值相等不推出项相等。** W3C RDF 1.1 Concepts §3.3 明确：literal 的项身份取决于词法形式、datatype IRI及语言标签；其示例正是 integer 的 `"1"` 与 `"01"`，二者可指同一数值而不是同一 RDF 项。[官方规范](https://www.w3.org/TR/rdf11-concepts/#section-Graph-Literal)
2. **数值比较是另一个操作语义。** SPARQL 1.1 将 numeric `=`映射为 numeric-equal，另有 sameTerm。不能把这种数值运算无条件移植成所有 RDF 三元组模式的项身份规则，也不能把 SPARQL IN 与 SHACL sh:in 混为同一算子。[操作映射](https://www.w3.org/TR/sparql11-query/#OperatorMapping)、[sameTerm](https://www.w3.org/TR/sparql11-query/#func-sameTerm)
3. **043的规则入口保留项词法。** `semantic_execution.py:204–229` 的 `_term` 使用 `_LexicalSink`；`semantic_scopes.py:85–87`明确 `Literal(..., normalize=False)`。`semantic_execution.py:264–284` 将 when/then 常量经此入口构造。
4. **043执行的是三元组常量模式join。** `semantic.py:351–370` 将常量直接放入 `closure.triples(lookup)`，再检查共享变量绑定；没有在此实现 numeric-equal、cast或独立值比较表达式。不存在可据以推导“所有数值同值必须匹配”的新比较分支。本次未实际运行，不能声称独立复现了③。
5. **原需求未明文指定③这一期望。** 冻结PRD FR-505（435–439行）要求属性值比较等表达能力，但未定义非规范integer词法与规范词法在常量三元组模式中必须数值等价匹配；附录C受控规则行及G.2 R-01–R-06也没有该边界例。候选 `acceptance.md:17/24` 声明有界三元组模式join；`q6-candidate-differences.md:18` 将当前合取模式/等值常量/单结论与未覆盖的完整FR-505比较/多结论表达分开，后者仍待负责人处置。该未覆盖项不能被抹除，也不能反过来自动改写现有常量项身份语义。

## 应澄清的问题与C2边界

- 报告行320按RDF项身份区分 `"1"`/`"01"`，行321却以“同值同项”要求规则触发；这一理由存在可确定的概念混淆。应向原审查者澄清③究竟是在要求项匹配、显式数值比较，还是报告解析入口不一致；各自应有不同预期。
- 若候选继续承诺常量RDF项模式，至少应分别记录：完全相同项应匹配；同数值而不同项的常量模式不应仅因数值相同而被改成匹配。若要实现显式数值比较，应另定义表达、类型/异常及依据语义，作为真实受审变更，不以全局normalize/cast偷偷加入。
- SHACL允许值的词法一致性修复与规则的项身份是两个问题；修复①②不要求将所有层统一成数值相等，也不要求全局改写事实/规则词法。
- 固定报告“其余SPARQL/规则均不受影响”的影响半径结论不能据本次文字核对确认。原owner已另报告裸数字查询的影响；该事实需由owner保留自己的探针和来源，C2双方独立审查应分别判断图模式常量、显式typed literal、数值FILTER/比较与SHACL，不在这里重做或代判。

**门禁保持：** 本记录不降低MiniMax的B-1′等级、不宣布其中任一子项关闭、不恢复C1 Pass。原SHACL真阻断保留；C2实现与相关范围/回归应由两个指定模型在新同一版本完整独立判断。不得向一方披露另一方本轮意见。
