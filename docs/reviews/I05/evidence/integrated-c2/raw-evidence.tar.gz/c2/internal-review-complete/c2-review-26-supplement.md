# I05 C2 独立补审：IB-1 关闭记录

**结论：固定源码 `26eb632f0e1210b03ac3aef4cfd71fdc4a0c5222` 通过本次独立 C2 变更审查，IB-1 已实际复验关闭，未发现新增阻断。** 这是原始 Not Pass 报告的独立补充，不改写原报告，也不替代指定两模型全范围审查或最终 B1 验收。

## 固定范围与来源

- 原完整审查范围为 `043c20cc → e7a61199fcb5f38ac8f9df0e557bd9c59e207430`，再补读 `3c0b3bafcdab86159962ff3331bb161c40d349bc` 的 36 项 statement guard 测试。
- 本次实际完整读取 `3c0b3ba → 26eb632` 四文件全部 delta：`semantic_query.py`、`semantic_samples.py`、`test_semantic_lexical.py`、`test_semantic_query_tokens.py`。其他产品源码与上一报告一致，未把历史旧包当成新候选产物。
- 通过 `git archive 26eb632...` 导出到自有 ignored `build/c2-review-26eb632`；使用 `UV_PROJECT_ENVIRONMENT=<本树>/build/c2-review-venv-26 uv sync --frozen --project <固定导出>` 新建独立环境。运行不依赖主线 checkout、主线 build 或主线 `.venv`。
- 执行 worktree 仍为 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-bridge`，分支 `feature/I05-semantic-bridge`，HEAD `7b9c4677885c60a534a098b436f087702d1c1b46`；仅保护 AGENTS dirty，SHA-256 `78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759`。无 tracked 开发变更、无 stage/commit、无应用/GUI/Goal 操作。

## 修复检查

`_clone_grammar()` 先 deepcopy `parser.Query`，再遍历克隆对象替换九个 numeric Regex 的 literal action。数字依赖固定为 RDFLib 7.6.0 / pyparsing 3.3.3；九叶的三个 datatype 各三次有明确 gate，六个签名父节点只能在 memo 中找到独立 clone 才修改。

UnaryExpression 重新排序仅作用于 private clone。展开 MatchFirst 时保留具有 parseAction、resultsName 或 debug 的 wrapper；这保留了 Var 把字符串转换成 RDF Variable 的语义。冷态源 grammar 的两层嵌套和经全局 Graph.query streamline 后的结构，均可按同一无语义-wrapper规则归一到 81 alternatives：前三个 UnaryNot/UnaryPlus/UnaryMinus、后 78 个 Primary alternatives。gate 不满足时抛实现错误，位于用户语法转换的 try 之外，因此走安全 INTERNAL_ERROR，不误报用户 INVALID_QUERY。不存在盲目 flatten 82 个叶节点、丢弃 Var parseAction 的实现。

在该局部拓扑上把 Primary alternatives 前置，恢复相邻 signed numeric terminal 的最长匹配；符号与数字之间有空白或注释时，保持 unary 运算。未更换原本已拒绝 BGP/VALUES 内符号分离的六个 signed grammar，不增加无必要变更。该区分有 [W3C SPARQL 1.1 §19.8](https://www.w3.org/TR/sparql11-query/#sparqlGrammar) 的 token/grammar 依据，详见原报告。

本次增强 grammar_state 加入所有 child parser 身份，故并发隔离检查不仅观察 parseAction，还观察拓扑。共享 lexical_suite 增加 BIND 结果与 VALUES 完整结果对比、STR 的精确词法对比，避免源码与实际包的公共样例再次漏掉原反例。

## 实际运行

1. 固定导出中运行：

   `/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-bridge/build/c2-review-venv-26/bin/python -m pytest -q -p no:cacheprovider packages/engine/tests/test_semantic_lexical.py packages/engine/tests/test_semantic_query_tokens.py packages/engine/tests/test_semantic_lexical_runtime.py packages/engine/tests/test_semantic_execution.py packages/engine/tests/test_semantic_error_adapter.py`

   **488 passed in 18.54s。** 包含最终 statement guard、52 个 signed token cases、原始 lexical 身份与全局状态/线程检查、12 项真实 Store/worker/stdio 测试及安全错误适配。原始日志 `build/c2-review-26-selected-tests.log`，SHA-256 `6f386c9fa732a8efbb1ce02dc7cace582ad3cb8690bc17dbea5ca683d901d8e5`。

2. 自建独立反例矩阵 `build/c2-review-26-independent-probe.py`：**134 项全部通过**，实际分别在冷态和全局 Graph.query 已 streamline 后运行。涵盖三种 numeric datatype、正负及零词法、BIND/STR/VALUES 加 sameTerm、空格/tab/换行/注释分隔的符号、COUNT、变量过滤、DESC、合法 `++01`/`--01` 与非法 `+++01`/`-- 01`。实际 AST 明确 `-01` 为 Literal，而 `- 01` 为 UnaryMinus；Var 仍为 RDF Variable。完整预期和实际结果 `build/c2-review-26-independent-probe.json`，SHA-256 `4637659cc6fe8ae914bc4ec6093e73ae11b550ede33ddc41758ebb194f1b7ecb`。

3. 该矩阵同时实际运行共享 lexical_suite，10 数字身份案例及 4 非法 Turtle 案例通过，新增 expression/spelling 也全部通过；规范 payload SHA-256 `056e55e102fe99c59df1363376af79051bddf2adff35595f3c7bdff985db3e2a`。

4. 另建 `build/c2-review-26-real-signed-runtime.py`，使用真实 JobStore.commit、Coordinator/独立 worker 和源 stdio Session 两种路径，分别运行五个保存查询：STR(-01)、STR(+01)、STR(- 01)、VALUES+sameTerm、COUNT+变量 FILTER。**10 项全部成功**。每项均通过真实 semantic.start 受理、持久 Job 终态、result.get 和全部分页，再由 Store.semantic_result 重新认证并核对完整 query 结果、queryText、finite-4/lock 身份、原始 rows；正式项目 state 前后相同。未手造成功 Job，未调用纯计算后替代 worker 发布。原始完整 JSON `build/c2-review-26-real-signed-runtime.json`，SHA-256 `1fa6a3fbd99dcf50d63ba033943521889dfa4acb17fb2505411d2c885c7dc96b`。

## 旧记录与剩余边界

原报告 `build/c2-review-original-IB-1.md` SHA-256 仍为 `b27b6850802b15eae1de8369e4d7ae26e467c791af501808ce789021c704ff5f`；e7/3c 的原 Not Pass、AST 反例、错误 gate 与 blind82/Var 丢失的实验原始文件均保留，不被新结论覆盖。完整引用与字节哈希清单为 `build/c2-review-26-manifest.json`。

原报告两项边界观察仍保留：pinned Turtle parser 对 leading 分号的既有宽松语法；混合 RAND 与 SERVICE 时 unsupported 函数可能先于外联错误分类。这两项非本次新增回归，没有执行外联，也未在本轮宣称全面标准一致性。未来不得据本次修复推断完整 SPARQL/Turtle 标准支持。

本次未运行主线全仓 check、实际 PyInstaller/package、性能或体积测量、Linux GUI/native、外部双指定模型、CI、安装/签名或生产验证。新候选实际包与源/包相同样例、隔离原生恢复等仍由父线补齐；旧包或旧全check不覆盖该源码。

**在上述独立审查范围内 Pass，IB-1 已关闭；整个 I05/B1 是否完成仍取决于原有完整验收与外部门禁。**
