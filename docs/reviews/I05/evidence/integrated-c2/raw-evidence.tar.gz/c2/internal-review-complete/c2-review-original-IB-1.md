# I05 C2 前置独立只读审查：原始阻断报告

结论：**Not Pass，存在一项 P1 阻断 IB-1。** 该结论只针对下列固定候选，未来修复必须另出补审记录，本文件不改写为通过。

## 固定输入与隔离

- 被审路径：`/Users/kyle/Documents/工作/知爻/本体/.worktrees/I05-semantic-validation`，分支 `feature/I05-semantic-validation`。
- 产品源码 head：`e7a61199fcb5f38ac8f9df0e557bd9c59e207430`；完整差异起点 `043c20cc`；最终 guard 测试 delta：`3c0b3bafcdab86159962ff3331bb161c40d349bc`（仅追加 36 cases，产品源码同 e7）。
- 实际审查执行树：原独立 `I05-semantic-bridge`，分支同名，HEAD `7b9c4677885c60a534a098b436f087702d1c1b46`；仅保护文件 `AGENTS.md` dirty，已逐字同步最新主线指南 SHA-256 `78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759`，未 stage。
- 固定源码以 `git archive e7...` 导出至该树 `build/c2-review-e7a6119`，仅补入 3c 的追加测试。独立 `build/c2-review-venv` 通过 `uv sync --frozen --project <固定导出>` 创建；未使用、修改主线 `.venv` 或 build。
- 实际读取最新 AGENTS 与 `iteration-control/2026-10-21-weekly-release/external-review-permissions.md`，无 GUI/CUA、Electron、native、HMR、Goal 或应用操作。

## IB-1 [P1] 表达式中的无空白签名数字仍被当成一元运算，破坏 RDF term identity

位置：`packages/engine/src/ontolearn_engine/semantic_query.py` 的 `_clone_grammar()`（约 20–60 行）及 `prepare_lexical_query()`。该函数只替换数字叶和六个签名父节点的 literal action，未修复 `UnaryExpression` 先匹配符号的选择顺序。

真实执行结果：

| 输入表达式 | 实际 STR 结果 | 必须区分的语义 |
|---|---|---|
| `-01` | `"-1"` | 应为签名数字 literal 的词法 `"-01"` |
| `+01` | `"1"` | 应保留 `"+01"` |
| `- 01` | `"-1"` | 分离符号是一元数值运算，当前结果正确 |
| `+ 01` | `"1"` | 分离符号是一元数值运算，当前结果正确 |
| `-01.00` | `"-1.00"` | 应保留 `"-01.00"` |
| `+01e0` | `"1.0"` | 应保留 `"+01e0"` |

最小复现：`query(Graph(), 'SELECT (STR(-01) AS ?n) WHERE {}')`。实际 algebra 为 `Builtin_STR(UnaryMinus(Literal('01', xsd:integer)))`，证明这是 parser 选错生产式，并非界面格式化。`BIND(-01 AS ?v)` 后与 `"-01"^^xsd:integer` 做 `sameTerm` 过滤也错误地得到空结果；`VALUES ?v { -01 } FILTER(sameTerm(?v,-01))` 同样丢失本应存在的行。

规范依据已经现场读取：[W3C SPARQL 1.1 §19.8](https://www.w3.org/TR/sparql11-query/#sparqlGrammar) 的 longest-match 规则及 signed 数字内部不允许空白的注记；生产式 118/119 和 130–133、149–154 将 NumericLiteralPositive/Negative 明确列为完整数字 terminal。无空白的 `-01` 应首先成为完整 signed token；有空白的 `- 01` 才按一元运算处理。STR 返回 literal 词法见 [§17.4.2.5](https://www.w3.org/TR/sparql11-query/#func-str)。此判断不以 RDFLib 默认结果作为规范依据。

影响：正常支持的 SELECT/BIND/STR/sameTerm 查询返回错误结果，且成功状态与持久发布会使其看起来可信。BGP、VALUES 的签名数字修复和无符号表达式成功，不能覆盖这一缺口。现有 183 个 lexical cases 与 shared lexical_suite 主要覆盖 BGP/VALUES 数字、无符号表达式和真实算术，未包含这一相反预期组合。

建议验收：integer/decimal/double 的正负无空白常量应保留 token；空格、tab、注释分隔的 sign 应保持正常一元计算；SELECT/BIND/FILTER/STR/sameTerm 与 BGP/VALUES 分别验证；COUNT、ORDER BY、普通算术和全局 grammar 冷/暖/并发状态不得回退。修复需新源码候选、新相关运行与实际包验证，不沿用本候选旧包的通过。

## 其余审查结果与边界观察

1. Turtle adapter 对 `sfloat` 使用精确类型映射，避免 bool 误判；数字恢复后保留 `lines/startOfLine`，注释、CRLF 和既有错误位置测试有效。statement guard 按 emission event 计数，而非图大小，正确保留重复三元组和带属性的合法 blank-node/list 语句，拒绝 orphan subject，包括内部已产生三元组的 orphan collection。最终新增 22 合法图用手建 RDF 对照、14 非法输入测试，避免和同一 parser 一起犯错。
2. 仍有继承自 pinned parser 的宽松语法：`<urn:s> ; <urn:p> <urn:o> .` 与 `[<urn:p> <urn:o>] ; .` 会被接受。按 [Turtle grammar](https://www.w3.org/TR/turtle/#grammar-production-predicateObjectList)，predicateObjectList 的起始不能是空分号。该问题在 C1 已存在，不列为本轮新增阻断，但本次 orphan guard 不能被描述为完整 Turtle 语法一致性证明。
3. 普通 GRAPH、GRAPH 嵌套 SERVICE、FROM、子查询/EXISTS 中外联的本轮分类有效；如果同时出现 RAND 等其他 unsupported 函数，遍历仍可能先报 `UNSUPPORTED_QUERY_FUNCTION`。实际未进入查询执行或产生外联；本次结论是 GRAPH 与外联的有限优先关系，不能扩展为所有不支持结构组合均外联优先。
4. finite-4 同步于 semantic 与 resources；dependencyLockHash 变化隔离旧结果。新 helper 均通过静态直接 import 可由 PyInstaller 发现；pyparsing 固定为直接依赖 3.3.3，与锁一致。只据代码判定未发现明显打包遗漏，未将静态检查充当实际包运行。
5. 真实 Store/worker/stdio 新测试读取认证结果、完整 rows、不可变快照、投影资源、实现身份和历史选择，未以纯函数或手造成功 Job 代替 producer。source 跑通不等于 packaged/原生窗口证据。

## 真实命令与结果

- `git archive e7a6119` 固定导出；`git show 3c0...:packages/engine/tests/test_semantic_lexical.py` 补最终 guard delta。
- `UV_PROJECT_ENVIRONMENT=<本树>/build/c2-review-venv uv sync --frozen --project <本树>/build/c2-review-e7a6119`：成功，RDFLib 7.6.0 / pyparsing 3.3.3 / pySHACL 0.30.1。
- 在固定导出目录用该独立环境运行 `python -m pytest -q -p no:cacheprovider`，范围 `test_semantic_lexical.py test_semantic_lexical_runtime.py test_semantic_execution.py test_semantic_error_adapter.py`：**436 passed in 13.34s**，原始日志 `build/c2-review-tests-fixed-env.log`。这组绿测遗漏 IB-1，不能抵消反例。
- 前一次误用了原独立树旧 editable 环境，导致 12 个 runtime cases 失败（424 passed）；已明确定位为隔离环境配置错误，原日志 `build/c2-review-tests-e7a6119.log` 保留，不列为产品缺陷；修正环境后执行上述一次完整同范围复测。
- `build/c2-review-venv/bin/python` 调用共享 `semantic_samples.lexical_suite()`：10 数字身份案例、4 非法 Turtle 案例通过；规范 JSON SHA-256 `bba2061cd2ca8c647cfb5d74286a84cf053f184bc225b42632c3d718f91794cc`，原输出 `build/c2-shared-lexical-suite.json`。
- IB-1 固定候选 AST 与结果：`build/c2-IB-1-fixed-candidate.json`；补充 Turtle/GRAPH 边界探针：`build/c2-extra-boundary-probe.py/json`。
- 本地修复可行性探针仅在 ignored Python 进程中临时替换局部 clone 构造，不改 tracked 实现。所有方案输出分别保留：`c2-local-sign-probe.*`、失败的 `c2-flat-sign-probe.*`、`c2-flat-sign-probe-82.*`、`c2-flat82-filter-ast.json`、后续保留语义 action 的 `c2-safe81-sign-probe.*`。这些是方案实验，不能作为已合入产品的修复证据。

## 未验与结论

未在本次独立审查执行源码全仓 check、实际打包、新性能测量、目标平台安装、Linux GUI/native、外部指定双模型审查、CI 或生产验证。本报告没有修改主线源码/测试/配置/依赖/文档，也未替代指定双模型门禁。

**原固定候选 Not Pass：IB-1 仍打开。** 修复后的固定 commit 必须另行补审；本报告与所有原始失败/通过证据保留原字节。
