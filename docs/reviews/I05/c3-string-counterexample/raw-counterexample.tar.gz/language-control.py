"""Bounded language-case representation control, no new worker jobs or policy."""
import json
from pathlib import Path
from rdflib import URIRef,Variable
from ontolearn_engine.semantic import parse_turtle,query,reason,Rule
from ontolearn_engine.rdf_snapshot import term
p=URIRef('urn:p');subject=URIRef('urn:s')
a=parse_turtle('<urn:s> <urn:p> "x"@en .');b=parse_turtle('<urn:s> <urn:p> "x"@EN .');both=parse_turtle('<urn:s> <urn:p> "x"@en, "x"@EN .');x=next(iter(a))[2];y=next(iter(b))[2]
def desc(t):return {'lexical':str(t),'datatype':str(t.datatype) if t.datatype is not None else None,'lang':t.language,'n3':t.n3()}
r=Rule('language-match',((Variable('s'),p,y),),(Variable('s'),URIRef('urn:matched'),URIRef('urn:yes')))
out={'scope':'Only language en/EN representation and same-language identity control, pure real parse/query/reason entry; no Store/worker/stdio/package/GUI or BCP47 completeness claim.','lower':desc(x),'upper':desc(y),'termEqual':x==y,'hashEqual':hash(x)==hash(y),'combinedGraphCount':len(both),'storageTermUpperCanonical':desc(term('"x"@EN')),'queryUpperPatternAgainstLower':query(a,'ASK { <urn:s> <urn:p> "x"@EN }'),'querySameTerm':query(a,'ASK { <urn:s> <urn:p> ?o FILTER(sameTerm(?o,"x"@EN)) }'),'ruleUpperConstantAgainstLower':reason(a,(r,))}
Path('build/i05-plain-string-c3/language-control.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
