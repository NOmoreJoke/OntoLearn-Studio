"""Bounded frozen-C3 actual front-door witness; no candidate modifications."""
import hashlib,json,sys
from pathlib import Path
from uuid import uuid4
from datetime import datetime
root=Path.cwd();out=root/'build/i05-plain-string-c3';sha=lambda b:hashlib.sha256(b).hexdigest()
sys.path.insert(0,str(root/'packages/engine/tests'))
from test_semantic_lexical_runtime import DirectWorker,completed,parameters
from ontolearn_engine import semantic
from ontolearn_engine.resources import CONTRACT,IMPLEMENTATION
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.storage import digest
from rdflib import RDF,XSD
manifest=json.loads((root/'docs/reviews/I05/candidate-3.json').read_text())
assert all(sha((root/p).read_bytes())==h for p,h in manifest['executionInputs'].items())
assert Path(semantic.__file__).resolve()==root/'packages/engine/src/ontolearn_engine/semantic.py'
assert IMPLEMENTATION['executionSemanticsVersion']=='i05-finite-5'
uid=lambda:str(uuid4());typ=str(RDF.type);xs=str(XSD.string)
plain='"x"';typed=f'"x"^^<{xs}>';integer=str(XSD.integer)
facts=[['urn:plain',typ,'<urn:All>'],['urn:typed',typ,'<urn:All>'],['urn:both',typ,'<urn:All>'],['urn:both',typ,'<urn:Both>'],['urn:plain','urn:p',plain],['urn:typed','urn:p',typed],['urn:both','urn:p',plain],['urn:both','urn:p',typed],['urn:language','urn:lang','"x"@en'],['urn:number','urn:n',f'"01"^^<{integer}>'],['urn:number','urn:n',f'"1"^^<{integer}>']]
turtle='\n'.join(f'<{s}> <{p}> {o} .' for s,p,o in facts)+'\n';(out/'input.ttl').write_text(turtle)
def term(t):
 return {'pythonType':type(t).__name__,'lexical':str(t),'datatype':str(t.datatype) if getattr(t,'datatype',None) is not None else None,'lang':getattr(t,'language',None),'n3':t.n3()}
g=semantic.parse_turtle(turtle);all_terms=[{'triple':[s.n3(),p.n3(),o.n3()],'object':term(o)} for s,p,o in sorted(g,key=semantic._key)]
small={}
for name,tok in [('plain',plain),('typed',typed),('language','"x"@en'),('integer01',f'"01"^^<{integer}>'),('integer1',f'"1"^^<{integer}>')]:
 one=semantic.parse_turtle(f'<urn:s> <urn:p> {tok} .');small[name]=next(iter(one))[2]
parsing={'inputStatementCount':len(facts),'graphTripleCount':len(g),'terms':all_terms,'representations':{k:term(v) for k,v in small.items()},'plainTypedTermEqual':small['plain']==small['typed'],'plainTypedValueEq':small['plain'].eq(small['typed']),'numeric01And1TermEqual':small['integer01']==small['integer1']}
queries={'projection':'SELECT ?s ?o (DATATYPE(?o) AS ?datatype) (LANG(?o) AS ?lang) (sameTerm(?o, '+typed+') AS ?sameTyped) WHERE { ?s <urn:p> ?o }','plain-data-typed-pattern':f'ASK {{ <urn:plain> <urn:p> {typed} }}','typed-data-plain-pattern':f'ASK {{ <urn:typed> <urn:p> {plain} }}','typed-values-join':f'SELECT ?s WHERE {{ ?s <urn:p> ?o . VALUES ?o {{ {typed} }} }}'}
def shape(identity,target,clause):
 return '@prefix sh: <http://www.w3.org/ns/shacl#> . '+f'<urn:S-{identity}> a sh:NodeShape; sh:targetClass <urn:{target}>; sh:property <urn:P-{identity}> . <urn:P-{identity}> sh:path <urn:p>; {clause} .'
shapes={'datatype':shape('dt','All',f'sh:datatype <{xs}>'),'in-plain':shape('ip','All',f'sh:in ({plain})'),'in-typed':shape('it','All',f'sh:in ({typed})'),'max-one':shape('mx','Both','sh:maxCount 1'),'min-two':shape('mn','Both','sh:minCount 2')}
rules=[{'layer':'rule','id':name,'value':{'enabled':True,'when':[['?s','<urn:p>',token]],'then':['?s',f'<urn:{name}>','<urn:yes>']}} for name,token in [('plain-matched',plain),('typed-matched',typed)]]
definitions=[{'layer':'ontology','id':'empty','value':{'triples':[]}},*rules,*[{'layer':'query','id':i,'value':{'text':q}} for i,q in queries.items()],*[{'layer':'constraint','id':i,'value':{'enabled':True,'turtle':s}} for i,s in shapes.items()]]
store_facts=[f for f in facts if f[2]!=f'"01"^^<{integer}>']
inputs={'facts':facts,'storeFacts':store_facts,'storePreparationCorrection':'First Store.commit attempt had zero worker jobs: numeric01 control violated existing canonical manual-fact rule. Keep numeric01/1 only as explicit pure-parse control; persistent frontdoor uses canonical numeric1 only. Original failure/script/input/DB retained. No candidate modification.','definitions':definitions,'queries':queries,'shapes':shapes,'expectedRdf11Witness':{'plainTypedSameTerm':True,'graphTripleCount':10,'numericDistinctObjectCount':2,'queryPProjectionRowCount':3,'bothCrossPatternAsk':True,'typedValuesJoinSubjects':['<urn:both>','<urn:plain>','<urn:typed>'],'ruleResultsPerConstant':3,'datatypeConforms':True,'inPlainConforms':True,'inTypedConforms':True,'maxOneConforms':True,'minTwoConforms':False},'scope':'Only same lexical x plain/xsd:string. Language/numeric rows are representation/no-collapse controls. No new T05 comparator.'};(out/'inputs.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n');(out/'parse-witness.json').write_text(json.dumps(parsing,ensure_ascii=False,indent=2)+'\n')
db=out/'frontdoor-v2.sqlite';store=JobStore(db,contract=CONTRACT);store.create_project('plain-string');project=store.public_project('plain-string');store.commit('plain-string',0,uid(),uid(),definitions=definitions,manual=[{'id':digest([s,p,o]),'subject':s,'predicate':p,'object':o} for s,p,o in store_facts]);before=store.state('plain-string');store.close();backend=DirectWorker(db,project);records=[]
try:
 for capability,identity in [('reasoning.execute','all'),*[('query.execute',k) for k in queries],*[('validation.execute',k) for k in shapes]]:
  request=parameters(project,capability,identity);record=completed(backend,request);meta,payload=backend.store.semantic_result(project,record['metadata']['resultId']);assert meta==record['metadata'];record['payload']=payload;records.append(record);(out/f'{len(records):02}-{capability.split(".")[0]}-{identity}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
 assert backend.store.state('plain-string')==before
finally:backend.close()
summary={'candidateHead':manifest['head'],'implementation':IMPLEMENTATION,'python':sys.version,'inputSha256':sha(turtle.encode()),'parse':{k:v for k,v in parsing.items() if k not in ['terms','representations']},'actualCompletedWorkerJobs':len(records),'authorityStateUnchanged':True,'results':[]}
for record in records:
 p=record['payload'];summary['results'].append({'capability':record['request']['capability'],'definitionId':record['request']['definitionId'],'jobId':record['job']['jobId'],'state':record['job']['state'],'query':p.get('query'),'reasoning':p.get('reasoning'),'report':p.get('report')})
assert all(sha((root/p).read_bytes())==h for p,h in manifest['executionInputs'].items());summary['frozen204InputsUnchangedBeforeAndAfter']=True;(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
