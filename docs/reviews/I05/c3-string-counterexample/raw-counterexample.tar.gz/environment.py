import importlib.metadata as md,hashlib,json,sys
from pathlib import Path
from ontolearn_engine import semantic,semantic_turtle,semantic_query,semantic_execution,semantic_scopes,rdf_snapshot
import rdflib.term,pyshacl.constraints.core.value_constraints,pyshacl.constraints.core.other_constraints,pyshacl.constraints.core.cardinality_constraints
mods=[semantic,semantic_turtle,semantic_query,semantic_execution,semantic_scopes,rdf_snapshot,rdflib.term,pyshacl.constraints.core.value_constraints,pyshacl.constraints.core.other_constraints,pyshacl.constraints.core.cardinality_constraints]
x={'python':sys.version,'executable':sys.executable,'packages':{p:md.version(p) for p in ['rdflib','pyshacl','pyparsing']},'readOnlyModuleFiles':{m.__name__:{'path':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in mods}}
Path('build/i05-plain-string-c3/environment.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
