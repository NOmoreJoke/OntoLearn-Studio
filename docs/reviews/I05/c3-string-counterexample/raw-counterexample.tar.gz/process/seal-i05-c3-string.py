from pathlib import Path
import hashlib,io,json,tarfile
from datetime import datetime
root=Path.cwd();src=root/'build/i05-plain-string-c3';dst=root/'docs/reviews/I05/c3-string-counterexample';sha=lambda b:hashlib.sha256(b).hexdigest();members=[];excluded=[]
for p in sorted(src.rglob('*')):
 if not p.is_file():continue
 b=p.read_bytes();name=p.relative_to(src).as_posix()
 if p.name.endswith(('.sqlite','.sqlite-wal','.sqlite-shm','.writer-lock')):
  excluded.append({'originalPath':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b),'reason':'Synthetic mutable database or writer-lock, not required raw execution output.'});continue
 members.append((p,name,b))
p=root/'build/seal-i05-c3-string.py';members.append((p,'process/seal-i05-c3-string.py',p.read_bytes()))
a=dst/'raw-counterexample.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=9) as tf:
 for p,n,b in members:
  info=tarfile.TarInfo(n);info.size=len(b);info.mtime=int(p.stat().st_mtime);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
rows=[{'member':n,'originalPath':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)} for p,n,b in members]
with tarfile.open(a,'r:gz') as tf:
 assert len(tf.getmembers())==len(rows)
 for m,r in zip(tf.getmembers(),rows):
  b=tf.extractfile(m).read();assert m.name==r['member'] and len(b)==r['bytes'] and sha(b)==r['sha256']
x={'finding':'I05-C3-STRING-1','frozenCandidateHead':'3289d67dbfb19545c7a3b3b26753cdd0065741bb','createdAt':datetime.now().astimezone().isoformat(),'archive':a.name,'archiveBytes':a.stat().st_size,'archiveSha256':sha(a.read_bytes()),'memberCount':len(rows),'uncompressedBytes':sum(r['bytes'] for r in rows),'allMembersReadbackVerified':True,'actualCompletedWorkerJobs':12,'driverExitCode':int((src/'exit-code.txt').read_text()),'scope':'Complete bounded real source Store/coordinator/worker result receipts, all payload/pages, input/original lexical forms and actual canonical state, pure parse/language controls, source binding/environment, actual stdout/stderr/exit and both pre-worker setup failures/scripts. No product/GUI/full-suite/package execution beyond stated probe.','excluded':excluded,'members':rows};(dst/'manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items() if k not in ('members','excluded')},ensure_ascii=False));print('excluded',len(excluded))
