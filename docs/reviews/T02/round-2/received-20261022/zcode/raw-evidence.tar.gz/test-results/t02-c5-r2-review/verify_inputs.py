#!/usr/bin/env python3
"""C5 R2 independent input manifest verification. Read-only against git objects."""
import hashlib
import json
import subprocess
import sys

REPO = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-zcode-review-e5ad54e"
R2 = f"{REPO}/docs/reviews/T02/round-2"


def git_show(ref: str, path: str) -> bytes:
    r = subprocess.run(["git", "-C", REPO, "show", f"{ref}:{path}"], capture_output=True)
    if r.returncode != 0:
        raise RuntimeError(f"git show failed for {ref}:{path}: {r.stderr.decode()[:200]}")
    return r.stdout


def check_entry(e: dict, source: str, use_worktree: bool = False):
    path, ref = e["path"], e.get("ref")
    if use_worktree or ref is None:
        try:
            blob = open(f"{REPO}/{path}", "rb").read()
        except OSError as ex:
            return f"MISSING-WORKTREE {source} {path} {ex}"
    else:
        try:
            blob = git_show(ref, path)
        except RuntimeError as ex:
            return f"GIT-ERROR {source} {path} {ex}"
    n, h = len(blob), hashlib.sha256(blob).hexdigest()
    if n != e["bytes"] or h != e["sha256"]:
        return f"MISMATCH {source} {path}@{ref} expect {e['bytes']}B/{e['sha256']} got {n}B/{h}"
    return None


def main():
    im = json.load(open(f"{R2}/input-manifest.json"))
    pm = json.load(open(f"{R2}/preparation-manifest.json"))
    fails = []
    counts = {}
    for group, entries in [
        ("fullBranchDeltaFiles", im["fullBranchDeltaFiles"]),
        ("unchangedReferences", im["unchangedReferences"]),
        ("currentPolicyPayloads", im["currentPolicyPayloads"]),
        ("preparationManifest.payloads", pm["payloads"]),
    ]:
        ok = 0
        for e in entries:
            err = check_entry(e, group, use_worktree=(group == "currentPolicyPayloads" and "ref" not in e))
            if err:
                fails.append(err)
            else:
                ok += 1
        counts[group] = f"{ok}/{len(entries)}"
    print("VERIFY COUNTS:", json.dumps(counts))
    if fails:
        print("FAILURES:")
        for f in fails:
            print(" ", f)
        sys.exit(1)
    print("ALL MANIFEST ENTRIES VERIFIED")


if __name__ == "__main__":
    main()
