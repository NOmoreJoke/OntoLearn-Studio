"""R2 independent Unicode/type counterexamples (attempt 2, ASCII-only source).

Distinct from the 31 suite cases: different surrogate code points, JSON-decoded
values in every C4-escaping category, mutation checks, legal-Unicode
preservation. Surrogates are built via chr() so this file stays valid UTF-8.
"""

import json
import sys
from dataclasses import replace

sys.path.insert(0, "packages/engine/src")
sys.path.insert(0, "packages/engine/tests")

from ontolearn_engine.ontology import (  # noqa: E402
    Copy,
    Entity,
    ExternalReference,
    Fact,
    OntologyError,
    Put,
    Snapshot,
    Triple,
    change_preview,
    deletion_impact,
    rdf_triples,
)
from ontolearn_engine.ontology.service import snapshot_digest  # noqa: E402

SURROGATES = [chr(0xDB80), chr(0xDBFF), chr(0xDC00)]  # mid/edge high + low surrogate


def j(s):
    return json.loads(json.dumps(s))  # ordinary JSON-decoded str, no custom objects


results = []


def expect_fixed(label, reason, location, action):
    try:
        action()
        results.append(("FAIL-NOERROR", label))
        return
    except OntologyError as e:
        ok = e.reason == reason and e.location == location and str(e) == reason
        results.append(("OK" if ok else "WRONG(%s,%s)" % (e.reason, e.location), label))
        return
    except Exception as e:  # noqa: BLE001
        results.append(("ESCAPED-RAW %s: %s" % (type(e).__name__, str(e)[:80]), label))


def expect_ok(label, action):
    try:
        action()
        results.append(("OK", label))
    except Exception as e:  # noqa: BLE001
        results.append(("UNEXPECTED %s: %s" % (type(e).__name__, str(e)[:80]), label))


E_IRI = "urn:t02:Equipment"


def base(project="project-a", revision=7, **kw):
    return Snapshot(
        project,
        revision,
        (
            Entity(E_IRI, "class", "Equipment", labels=(("devices", "zh"),)),
            Entity("urn:t02:P", "objectProperty", "hasAlarm", domain=(E_IRI,), range=("urn:t02:A",)),
            Entity("urn:t02:A", "class", "Alarm"),
            Entity("urn:t02:dev", "individual", "001", types=(E_IRI,)),
        ),
        **kw,
    )


# 1) C4 originally-escaping paths via JSON-decoded lone surrogates (new code points)
for bad in SURROGATES:
    v = j("x-" + bad)
    expect_fixed("project[%s]" % hex(ord(bad)), "invalid_text", "project", lambda v=v: change_preview(base(project=v)))
    ent = Entity(E_IRI, "class", "E", synonyms=(v,))
    expect_fixed("synonyms[%s]" % hex(ord(bad)), "invalid_text", "synonyms", lambda e=ent: change_preview(replace(base(), entities=(e,))))
    ent2 = Entity(E_IRI, "class", "E", examples=(v,))
    expect_fixed("examples[%s]" % hex(ord(bad)), "invalid_text", "examples", lambda e=ent2: change_preview(replace(base(), entities=(e,))))
    ent3 = Entity("urn:" + v, "class", "E")
    expect_fixed("entity-iri[%s]" % hex(ord(bad)), "invalid_iri", "", lambda e=ent3: change_preview(replace(base(), entities=(e,))))
    ent4 = Entity(E_IRI, "class", "E", labels=((v, "zh"),))
    expect_fixed("labels[%s]" % hex(ord(bad)), "invalid_text", "labels", lambda e=ent4: change_preview(replace(base(), entities=(e,))))
    ent5 = Entity(E_IRI, "class", "E", definitions=((v, ""),))
    expect_fixed("definitions[%s]" % hex(ord(bad)), "invalid_text", "definitions", lambda e=ent5: change_preview(replace(base(), entities=(e,))))
    ext = ExternalReference(v, E_IRI)
    expect_fixed("external-source[%s]" % hex(ord(bad)), "invalid_external_reference", "", lambda x=ext: change_preview(replace(base(), external_references=(x,))))

# 2) Put/Copy command fields with JSON-decoded surrogates
v = j("put-" + chr(0xDBFF))
edited = Entity(E_IRI, "class", "Equipment", synonyms=(v,))
expect_fixed("put-synonyms", "invalid_text", "synonyms", lambda: change_preview(base(), (Put(edited, False),)))
new_iri = Entity("urn:new-" + v, "class", "N")
expect_fixed("put-create-iri", "invalid_iri", "", lambda: change_preview(base(), (Put(new_iri, True),)))
expect_fixed("copy-target-iri", "invalid_iri", "", lambda: change_preview(base(), (Copy(E_IRI, "urn:copy-" + v, "Copy"),)))
expect_fixed("copy-identifier", "invalid_identifier", "", lambda: change_preview(base(), (Copy(E_IRI, "urn:copy2", v),)))

# 3) RDF terms: fact object literal containing a JSON-decoded lone surrogate
obj = j('"bad-') + v + j('"')
expect_fixed("triple-object-literal-surrogate", "invalid_rdf_term", "", lambda: Triple("urn:s", "urn:p", obj))
name_prop = Entity(
    "urn:t02:name", "dataProperty", "name",
    domain=(E_IRI,), range=("http://www.w3.org/2001/XMLSchema#string",),
)
snap2 = replace(base(), entities=(*base().entities, name_prop))
expect_fixed("add-fact-object-literal-surrogate", "invalid_rdf_term", "", lambda: change_preview(snap2, add_facts=(Fact("urn:t02:dev", "urn:t02:name", obj),)))

# 4) deletion target / internal digest boundary
expect_fixed("deletion-target-surrogate", "not_found", "", lambda: deletion_impact(base(), "urn:" + j(chr(0xDC00))))
try:
    snapshot_digest(base(project=j("p" + chr(0xD800))))
    results.append(("DIGEST-NOERROR(internal-only)", "snapshot_digest unvalidated"))
except UnicodeEncodeError:
    results.append(("INTERNAL-NOTE", "snapshot_digest(unvalidated) raises UnicodeEncodeError; not in __all__, unreachable from exported API"))
except Exception as e:  # noqa: BLE001
    results.append(("INTERNAL-OTHER %s" % type(e).__name__, "snapshot_digest unvalidated"))

# 5) input immutability after rejection + service still healthy
snap = base()
snapshot_before = repr(snap)
for bad_cmd in (
    (Put(Entity(E_IRI, "class", "Equipment", synonyms=(j("x" + chr(0xD800)),)), False),),
    (Copy(E_IRI, "urn:c-" + j(chr(0xDBFF)), "c"),),
):
    try:
        change_preview(snap, bad_cmd)
    except OntologyError:
        pass
still = change_preview(snap)
ok = repr(snap) == snapshot_before and still.added == () and still.removed == ()
results.append(("OK" if ok else "FAIL", "input-unchanged-and-service-healthy"))

# 6) legal Unicode preserved verbatim (no silent normalization/replacement)
legal = chr(0x1D306) + " bengzhan" + chr(0x1F680) + " e" + chr(0x0301) + " zwj:" + chr(0x1F468) + chr(0x200D) + chr(0x1F4BC) + " zen:" + chr(0x200B) + " CJK:" + chr(0x20000)
ent = Entity("urn:shebei:" + chr(0x1D306), "class", "Eq", labels=((legal, "zh"),), definitions=((legal, ""),), synonyms=(legal,), examples=(legal,))
snap_legal = Snapshot(j("xiangmu" + chr(0x1F680)), 0, (ent,))
expect_ok("legal-unicode-preview", lambda: change_preview(snap_legal))
texts = [t.object for t in rdf_triples(snap_legal) if "label" in t.predicate or "comment" in t.predicate]
ok_legal = len(texts) == 2 and all(legal in t for t in texts)
results.append(("OK" if ok_legal else "FAIL(%d)" % len(texts), "legal-unicode-verbatim-in-rdf"))

# 7) OntologyError carries no input value (fixed text only)
try:
    change_preview(base(project=j("leak-" + chr(0xD800) + "-token")))
    results.append(("FAIL-NOERROR", "no-input-value-in-diagnostic"))
except OntologyError as e:
    leaked = "leak" in str(e) or "token" in str(e)
    results.append(("OK" if not leaked else "FAIL", "no-input-value-in-diagnostic"))

bad = [r for r in results if r[0] != "OK" and not r[0].startswith("INTERNAL-NOTE")]
print("total checks: %d" % len(results))
for tag, label in results:
    print("%-14s %s" % (tag, label))
print("PROBE-RESULT:", "ALL-EXPECTED" if not bad else "%d UNEXPECTED" % len(bad))
raise SystemExit(0 if not bad else 1)
