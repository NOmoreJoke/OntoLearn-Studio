"""Independent M3.1-Flash round-2 probe for T02-S1 C5.

Read-only against the product tree. Uses only the public/private ontology API
plus a temporary copy of the C4 (35aa) implementation for an A/B contrast.
No product, test, fixture, lock, config or acceptance file is modified.
"""

import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import traceback
from dataclasses import replace

from ontolearn_engine.ontology import (
    Copy,
    Delete,
    Entity,
    ExternalReference,
    Fact,
    OntologyError,
    Put,
    Snapshot,
    Triple,
    change_preview,
    deletion_impact,
    rdf_triples,
)
from ontolearn_engine.ontology.service import snapshot_digest

ROOT = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-minimax-review-e5ad54e"
REPORT = []


def say(line):
    print(line, flush=True)
    REPORT.append(line)


def native_exc(fn):
    """Return ('ok', value) or ('native', exception) for a call."""
    try:
        return ("ok", fn())
    except OntologyError as error:
        return ("ontology", error)
    except BaseException as error:  # noqa: BLE001 - probe purpose
        return ("native", error)


# ---------------------------------------------------------------- 1. C4 residual
say("=== 1. C4 residual reproduction on C5 (product e5ad54e) ===")
base_snapshot = Snapshot("p", 0, (Entity("urn:e", "class", "E"),))
for label, maker in (
    ("project", lambda s: replace(s, project="p\ud800")),
    (
        "synonyms",
        lambda s: replace(
            s, entities=(replace(s.entities[0], synonyms=("syn\ud800",)),)
        ),
    ),
    (
        "examples",
        lambda s: replace(
            s, entities=(replace(s.entities[0], examples=("ex\ud800",)),)
        ),
    ),
):
    bad = maker(base_snapshot)
    kind, value = native_exc(lambda: change_preview(bad))
    if kind == "ontology":
        say(
            f"  {label}: OntologyError reason={value.reason!r} location={value.location!r} "
            f"str={str(value)!r}"
        )
    else:
        say(f"  {label}: NATIVE {type(value).__name__}: {value}")


# ------------------------------------------------- 2. A/B contrast against C4 code
say("")
say("=== 2. Same repro against the C4 (35aa) implementation, extracted to a temp dir ===")
tmp = tempfile.mkdtemp(prefix="t02-c4-contrast-")
pkg = pathlib.Path(tmp) / "c4ontology"
pkg.mkdir()
for name in ("__init__.py", "model.py", "service.py"):
    blob = subprocess.run(
        ["git", "-C", ROOT, "cat-file", "-p", f"35aa93fc007e92632d83747f7fe345295db340c8:packages/engine/src/ontolearn_engine/ontology/{name}"],
        capture_output=True,
        check=True,
    ).stdout
    (pkg / name).write_bytes(blob)
sys.path.insert(0, tmp)
import c4ontology  # noqa: E402
from c4ontology import Entity as C4Entity, Snapshot as C4Snapshot  # noqa: E402
from c4ontology import change_preview as c4_change_preview  # noqa: E402

c4_base = C4Snapshot("p", 0, (C4Entity("urn:e", "class", "E"),))
for label, maker in (
    ("project", lambda s: replace(s, project="p\ud800")),
    (
        "synonyms",
        lambda s: replace(
            s, entities=(replace(s.entities[0], synonyms=("syn\ud800",)),)
        ),
    ),
    (
        "examples",
        lambda s: replace(
            s, entities=(replace(s.entities[0], examples=("ex\ud800",)),)
        ),
    ),
):
    bad = maker(c4_base)
    kind, value = native_exc(lambda: c4_change_preview(bad))
    detail = f"{type(value).__name__}: {value}" if kind == "native" else repr(value)
    say(f"  C4 {label}: {kind} -> {detail}")
shutil.rmtree(tmp, ignore_errors=True)
say("  (contrast only; the C4 tree was never modified and is not part of this candidate)")

# ------------------------------------------------- 3. Independent exhaustive sweep
say("")
say("=== 3. Exhaustive lone-surrogate sweep (independent injection-point set) ===")


def surrogate(seed, prefix="x"):
    return prefix + chr(seed)


def injection_points(value):
    """Return (point_name, callable) pairs that place `value` into a distinct field."""
    entity = Entity("urn:e", "class", "E")
    plain = Snapshot("p", 0, (entity,))
    points = {}

    points["base.project"] = replace(plain, project=value)
    points["base.entity.iri"] = replace(
        plain, entities=(replace(entity, iri="urn:" + value),)
    )
    points["base.entity.identifier"] = replace(
        plain, entities=(replace(entity, identifier=value),)
    )
    points["base.entity.labels.text"] = replace(
        plain, entities=(replace(entity, labels=((value, "zh"),)),)
    )
    points["base.entity.labels.language"] = replace(
        plain, entities=(replace(entity, labels=(("text", value),)),)
    )
    points["base.entity.definitions.text"] = replace(
        plain, entities=(replace(entity, definitions=((value, "zh"),)),)
    )
    points["base.entity.synonyms"] = replace(
        plain, entities=(replace(entity, synonyms=(value,)),)
    )
    points["base.entity.examples"] = replace(
        plain, entities=(replace(entity, examples=(value,)),)
    )
    points["base.entity.parents"] = replace(
        plain, entities=(replace(entity, parents=(value,)),)
    )
    points["base.entity.domain"] = replace(
        plain, entities=(replace(entity, kind="objectProperty", domain=(value,)),)
    )
    points["base.entity.range"] = replace(
        plain, entities=(replace(entity, kind="dataProperty", range=(value,)),)
    )
    points["base.entity.types"] = replace(
        plain, entities=(replace(entity, kind="individual", types=(value,)),)
    )
    points["base.entity.class_type"] = replace(
        plain, entities=(replace(entity, class_type=value),)
    )
    points["base.entity.kind"] = replace(
        plain, entities=(replace(entity, kind=value),)
    )
    points["base.external_reference.source"] = replace(
        plain, external_references=(ExternalReference(value, "urn:e"),)
    )
    points["base.external_reference.target"] = replace(
        plain, external_references=(ExternalReference("src", value),)
    )
    points["base.fact.subject"] = replace(
        plain,
        entities=(replace(entity, kind="individual"),),
        facts=(Fact(value, "urn:p", '"v"'),),
    )
    points["base.fact.predicate"] = replace(
        plain,
        entities=(replace(entity, kind="individual"),),
        facts=(Fact("urn:s", value, '"v"'),),
    )
    points["base.fact.object"] = replace(
        plain,
        entities=(replace(entity, kind="individual"),),
        facts=(Fact("urn:s", "urn:p", '"' + value + '"'),),
    )
    return points


surrogates = list(range(0xD800, 0xE000))
core = [
    "base.project",
    "base.entity.iri",
    "base.entity.labels.text",
    "base.entity.synonyms",
    "base.entity.examples",
    "base.fact.subject",
    "base.fact.predicate",
    "base.fact.object",
]
native_hits = []
reasons = {}
checked = 0
for seed in surrogates:
    value = surrogate(seed)
    points = injection_points(value)
    for name, snapshot in points.items():
        if name not in core and seed not in (0xD800, 0xDFFF):
            continue
        checked += 1
        kind, result = native_exc(lambda: change_preview(snapshot))
        if kind == "native":
            native_hits.append((name, hex(seed), type(result).__name__, str(result)))
        elif kind == "ontology":
            reasons.setdefault(name, set()).add(result.reason)
            if str(result) != result.reason:
                native_hits.append((name, hex(seed), "LEAK", str(result)))
        else:
            native_hits.append((name, hex(seed), "ACCEPTED", "no error raised"))
say(f"  checked {checked} (point, surrogate) combinations over 2048 code points")
say(f"  native exceptions / leaks / silent acceptances: {len(native_hits)}")
for hit in native_hits[:20]:
    say(f"    HIT {hit}")
say("  observed fixed reasons per injection point:")
for name in sorted(reasons):
    say(f"    {name}: {sorted(reasons[name])}")

# ------------------------------------------------- 4. Put / command paths
say("")
say("=== 4. Put and command paths with lone surrogates ===")
plain = Snapshot("p", 0, (Entity("urn:e", "class", "E"),))
put_points = {
    "put.entity.iri": replace(plain.entities[0], iri="urn:" + surrogate(0xD800)),
    "put.entity.labels": replace(plain.entities[0], labels=(("t" + surrogate(0xD800), "zh"),)),
    "put.entity.definitions": replace(
        plain.entities[0], definitions=(("t" + surrogate(0xD800), "zh"),)
    ),
    "put.entity.synonyms": replace(plain.entities[0], synonyms=("s" + surrogate(0xD800),)),
    "put.entity.examples": replace(plain.entities[0], examples=("e" + surrogate(0xD800),)),
    "put.entity.identifier": replace(plain.entities[0], identifier="i" + surrogate(0xD800)),
}
for name, entity in put_points.items():
    kind, result = native_exc(lambda e=entity: change_preview(plain, (Put(e, False),)))
    if kind == "ontology":
        say(f"  {name}: OntologyError {result.reason!r} / {result.location!r}")
    else:
        say(f"  {name}: {kind} {type(result).__name__}: {result}")

kind, result = native_exc(
    lambda: change_preview(plain, add_facts=(Fact("urn:s" + surrogate(0xD800), "urn:p", '"v"'),))
)
say(f"  add_facts surrogate subject: {kind} {getattr(result, 'reason', result)}")
kind, result = native_exc(
    lambda: change_preview(plain, remove_facts=(Fact("urn:s", "urn:p", '"' + surrogate(0xD800) + '"'),))
)
say(f"  remove_facts surrogate object: {kind} {getattr(result, 'reason', result)}")
kind, result = native_exc(lambda: deletion_impact(plain, {}))
say(f"  deletion_impact non-string target: {kind} {getattr(result, 'reason', result)}")
kind, result = native_exc(lambda: rdf_triples(plain))
say(f"  rdf_triples on valid snapshot: {kind} ok={kind == 'ok'}")

# ------------------------------------------------- 5. Valid unicode verbatim
say("")
say("=== 5. Valid Unicode preserved verbatim (CJK / emoji / decomposed accent) ===")
text = "泵站🚀 é"
entity = Entity(
    "urn:设备:🚀",
    "class",
    "Equipment",
    labels=((text, "zh"),),
    definitions=((text, "zh"),),
    synonyms=(text,),
    examples=(text,),
)
snap = Snapshot("项目🚀", 0, (entity,))
preview = change_preview(snap)
say(f"  empty diff: added={preview.added} removed={preview.removed}")
say(f"  entity preserved: {preview.candidate.entities == (entity,)}")
say(f"  label bytes preserved: {preview.candidate.entities[0].labels == entity.labels}")
say(f"  project preserved: {preview.candidate.project == '项目🚀'}")
edited = change_preview(snap, (Put(replace(entity, definitions=(("更新" + text, "zh"),)), False),))
say(f"  edited added: {edited.added}")
say(f"  decomposed accent kept (no NFC): {'e\\u0301' in edited.added[0].object}")

# ------------------------------------------------- 6. digest encoding semantics
say("")
say("=== 6. Digest encoding semantics unchanged (no escape-only workaround) ===")
import hashlib  # noqa: E402

payload = json.dumps(
    {"project": "项目", "revision": 0, "entities": []},
    ensure_ascii=False,
    sort_keys=True,
    separators=(",", ":"),
).encode("utf-8")
expected = hashlib.sha256(payload).hexdigest()
actual = snapshot_digest(Snapshot("项目", 0, ()))
say(f"  snapshot_digest == sha256(utf-8 json, ensure_ascii=False): {actual == expected}")
say(f"  digest differs from ensure_ascii=True variant: "
    f"{actual != hashlib.sha256(json.dumps({'project': '项目', 'revision': 0, 'entities': []}, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}")

# ------------------------------------------------- 7. module-level digest on unvalidated input
say("")
say("=== 7. Module-level snapshot_digest on an UNVALIDATED snapshot (not in __all__) ===")
unvalidated = Snapshot("p\ud800", 0, ())
kind, result = native_exc(lambda: snapshot_digest(unvalidated))
say(f"  snapshot_digest(unvalidated): {kind} -> "
    f"{type(result).__name__ if kind == 'native' else result}")
import ontolearn_engine.ontology as pkg  # noqa: E402

say(f"  snapshot_digest exported in ontology.__all__: {'snapshot_digest' in pkg.__all__}")

print("\n".join([]))
with open(
    os.path.join(ROOT, "test-results/t02-c5-r2-review/metadata/probe_unicode_independent.txt"),
    "w",
) as handle:
    handle.write("\n".join(REPORT) + "\n")
print("PROBE_DONE")
