"""Independent probe part 2: corrections to part 1 plus Copy / create=True / Store paths.

Part 1 had two defects in the PROBE SCRIPT itself (not product defects):
  - the digest cross-check rebuilt an incomplete payload, so it never matched;
  - the "decomposed accent" probe used a precomposed literal, so the assertion was
    meaningless.
Both are corrected here, and the C4/C5 digest equivalence is proved by running the
same valid snapshot through both implementations.
"""

import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
from dataclasses import asdict, replace

from ontolearn_engine.ontology import (
    Copy,
    Entity,
    ExternalReference,
    Fact,
    OntologyError,
    Put,
    Snapshot,
    change_preview,
)
from ontolearn_engine.ontology.service import snapshot_digest

ROOT = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-minimax-review-e5ad54e"
OUT = []


def say(line):
    print(line, flush=True)
    OUT.append(line)


def probe(fn):
    try:
        return ("ok", fn())
    except OntologyError as error:
        return ("ontology", f"{error.reason}/{error.location}")
    except BaseException as error:  # noqa: BLE001
        return ("native", f"{type(error).__name__}: {error}")


plain = Snapshot("p", 0, (Entity("urn:e", "class", "E"),))

say("=== A. Put(create=True) with a lone-surrogate IRI ===")
bad_iri = replace(plain.entities[0], iri="urn:" + chr(0xD800))
say(f"  create=True : {probe(lambda: change_preview(plain, (Put(bad_iri, True),)))}")
say(f"  create=False: {probe(lambda: change_preview(plain, (Put(bad_iri, False),)))}")

say("")
say("=== B. Copy with lone surrogates ===")
say(f"  Copy.source bad : {probe(lambda: change_preview(plain, (Copy('urn:' + chr(0xD800), 'urn:c', 'C'),)))}")
say(f"  Copy.identifier bad: {probe(lambda: change_preview(plain, (Copy('urn:e', 'urn:c', 'c' + chr(0xD800)),)))}")
say(f"  Copy.target bad : {probe(lambda: change_preview(plain, (Copy('urn:e', 'urn:' + chr(0xD800), 'C'),)))}")

say("")
say("=== C. Digest semantics: identical result on C5 and C4 for a valid snapshot ===")
valid = Snapshot("项目", 3, (Entity("urn:e", "class", "E", labels=(("设备", "zh"),)),))
c5_digest = snapshot_digest(valid)
payload = asdict(valid)
for key in ("entities", "facts", "external_references"):
    payload[key] = sorted(payload[key], key=lambda x: json.dumps(x, sort_keys=True))
manual = hashlib.sha256(
    json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()
say(f"  C5 snapshot_digest                       = {c5_digest}")
say(f"  manual sha256(json ensure_ascii=False)   = {manual}")
say(f"  match (digest encoding semantics intact)  = {c5_digest == manual}")

tmp = tempfile.mkdtemp(prefix="t02-c4-digest-")
pkg = pathlib.Path(tmp) / "c4ontology"
pkg.mkdir()
for name in ("__init__.py", "model.py", "service.py"):
    blob = subprocess.run(
        ["git", "-C", ROOT, "cat-file", "-p", f"35aa93fc007e92632d83747f7fe345295db340c8:packages/engine/src/ontolearn_engine/ontology/{name}"],
        capture_output=True,
        check=True,
    ).stdout
    (pkg / name).write_bytes(blob)
sys.path.insert(0, tmp)
from c4ontology.service import snapshot_digest as c4_snapshot_digest  # noqa: E402

c4_digest = c4_snapshot_digest(valid)
say(f"  C4 (35aa) snapshot_digest for same input = {c4_digest}")
say(f"  C4 == C5 for a valid snapshot            = {c4_digest == c5_digest}")
shutil.rmtree(tmp, ignore_errors=True)

say("")
say("=== D. Decomposed accent really preserved (explicit U+0301) ===")
text = "泵站🚀 é"
entity = Entity("urn:设备:🚀", "class", "Equipment", labels=((text, "zh"),), synonyms=(text,))
snap = Snapshot("项目🚀", 0, (entity,))
edited = change_preview(snap, (Put(replace(entity, definitions=((text, "zh"),)), False),))
say(f"  added object: {edited.added}")
say(f"  contains decomposed sequence e+U+0301: {'e\\u0301' in edited.added[0].object}")
say(f"  contains precomposed U+00E9        : {'\\u00e9' in edited.added[0].object}")
say(f"  entity label bytes identical        : {edited.candidate.entities[0].labels == entity.labels}")

say("")
say("=== E. Real Store path: surrogate in a definition payload ===")
from ontolearn_engine.storage import Store  # noqa: E402

with tempfile.TemporaryDirectory() as tmpdir:
    store = Store(pathlib.Path(tmpdir) / "probe.db")
    store.create_project("p")
    store.commit(
        "p",
        0,
        "seed",
        "seed-job",
        definitions=[
            {"layer": "ontology", "id": "d1", "value": {"triples": []}},
            {
                "layer": "constraint",
                "id": "d2",
                "value": {"note": "surrogate \ud800 payload"},
            },
        ],
    )
    ref = store.snapshot("p")
    source = store.load_snapshot(ref)
    writes = store._db.total_changes
    editor = Snapshot("p", 1)
    from ontolearn_engine.ontology.source_projection import bind_rdf_projection  # noqa: E402

    say(f"  bind_rdf_projection with surrogate payload: {probe(lambda: bind_rdf_projection(ref, source, editor))}")
    say(f"  store total_changes unchanged: {store._db.total_changes == writes}")
    store.close()

say("")
say("=== F. Editor carrying a surrogate project into the projection entry point ===")
bad_project = Snapshot("p" + chr(0xD800), 1)
say(f"  change_preview on editor with surrogate project: {probe(lambda: change_preview(bad_project))}")

with open(
    f"{ROOT}/test-results/t02-c5-r2-review/metadata/probe_unicode_independent_part2.txt", "w"
) as handle:
    handle.write("\n".join(OUT) + "\n")
print("PROBE2_DONE")
