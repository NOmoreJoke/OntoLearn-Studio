const { classTree } = await import('./tmp/view-model.js')
const row = (iri, parents = []) => ({
  iri, parents, kind: 'class', identifier: iri, labels: [[iri, 'zh']], definitions: [],
  synonyms: [], examples: [], domain: [], range: [], types: [],
})
const chain = (n) => Array.from({length:n}, (_,i)=>row(`urn:c${String(i).padStart(6,'0')}`, i===0?[]:[`urn:c${String(i-1).padStart(6,'0')}`]))
const wide = (n) => [row('urn:root'), ...Array.from({length:n}, (_,i)=>row(`urn:c${String(i).padStart(6,'0')}`, ['urn:root']))]
const cyclic = (n) => Array.from({length:n}, (_,i)=>row(`urn:c${i}`, [`urn:c${(i+1)%n}`]))
for (const [label, make] of [['chain', chain], ['wide', wide], ['cyclic', cyclic]]) {
  for (const n of [1000, 2000, 4000]) {
    const rows = make(n)
    const t0 = process.hrtime.bigint()
    const out = classTree(rows)
    const t1 = process.hrtime.bigint()
    console.log(`${label} n=${n} rows=${out.length} ms=${(Number(t1-t0)/1e6).toFixed(1)}`)
  }
}
const rows = chain(50)
console.log('order stable under input reversal:', JSON.stringify(classTree(rows)) === JSON.stringify(classTree([...rows].reverse())))
const c1 = classTree(cyclic(20))
console.log('cyclic: rows rendered', c1.length, 'repeated markers', c1.filter(r=>r.repeated).length)
