import hashlib, subprocess, os, json
ROOT="/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-minimax-review-e5ad54e"
PATHS=["apps/desktop/src/renderer/src/ontology/OntologyPage.tsx","apps/desktop/src/renderer/src/ontology/ontology.css","apps/desktop/src/renderer/src/ontology/view-model.ts","docs/iterations/T02/ui-probe/build.mjs","docs/iterations/T02/ui-probe/check.mjs","docs/iterations/T02/ui-probe/fixture.json","docs/iterations/T02/ui-probe/harness.tsx","docs/iterations/T02/ui-probe/index.html","packages/engine/src/ontolearn_engine/ontology/__init__.py","packages/engine/src/ontolearn_engine/ontology/model.py","packages/engine/src/ontolearn_engine/ontology/service.py","packages/engine/src/ontolearn_engine/ontology/source_projection.py","packages/engine/tests/test_ontology_editor.py","packages/engine/tests/test_ontology_fixed_inputs.py","packages/engine/tests/test_ontology_input_boundaries.py","packages/engine/tests/test_ontology_source_projection.py","tests/fixtures/ontology/invalid-turtle.ttl","tests/fixtures/ontology/manifest.json","tests/fixtures/ontology/manual-supported.ttl","tests/fixtures/ontology/supported-shacl-template.ttl","tests/fixtures/ontology/t09-fixed-inputs/G-base.json","tests/fixtures/ontology/t09-fixed-inputs/manifest.json","tests/fixtures/ontology/unsupported-owl.ttl","tests/fixtures/ontology/unsupported-shacl-path.ttl","tests/unit/t02-ontology-views.test.ts"]
PROD="e5ad54e5762157cafe532c2a0c07c22e8dd737cb"
BASE="5f910b52c69d86a1076b2032e5d3c63e715947f3"
rows=[]
for p in PATHS:
    wt=open(os.path.join(ROOT,p),'rb').read()
    g=subprocess.run(["git","-C",ROOT,"cat-file","-p",f"{PROD}:{p}"],capture_output=True).stdout
    gb=subprocess.run(["git","-C",ROOT,"cat-file","-p",f"{BASE}:{p}"],capture_output=True)
    base_exists = gb.returncode==0
    rows.append({"path":p,"wtBytes":len(wt),"wtSha":hashlib.sha256(wt).hexdigest(),
        "productSha":hashlib.sha256(g).hexdigest() if g else None,
        "wtEqualsProduct": wt==g,
        "baseExists":base_exists,
        "changedFromBase": (hashlib.sha256(gb.stdout).hexdigest()!=hashlib.sha256(g).hexdigest()) if base_exists else "new"})
print("total",len(rows))
bad=[r for r in rows if not r["wtEqualsProduct"]]
print("wt!=product:",len(bad))
for r in bad: print("  ",r["path"])
for r in rows: print(("CHANGED " if r["changedFromBase"] is not True else "same    ")+r["path"], r["wtBytes"])
json.dump(rows, open(os.path.join(ROOT,'test-results/t02-c5-r2-review/metadata/product-path-verification.json'),'w'),ensure_ascii=False,indent=1)
