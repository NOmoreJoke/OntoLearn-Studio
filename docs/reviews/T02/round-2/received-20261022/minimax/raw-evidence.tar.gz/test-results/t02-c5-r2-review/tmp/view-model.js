export function classTree(objects) {
    const classes = objects.filter((row) => row.kind === 'class');
    const byId = new Map(classes.map((row) => [row.iri, row]));
    const result = [];
    const visited = new Set();
    const sorted = (values) => [...values].sort((a, b) => (a.iri < b.iri ? -1 : a.iri > b.iri ? 1 : 0));
    const ordered = sorted(classes);
    // Index children once. Traversal still pays for edges and ancestor sets.
    const children = new Map();
    for (const row of ordered) {
        for (const parent of new Set(row.parents)) {
            if (!byId.has(parent))
                continue;
            const siblings = children.get(parent) ?? [];
            siblings.push(row);
            children.set(parent, siblings);
        }
    }
    const walk = (start) => {
        const stack = [{ row: start, depth: 0, ancestors: new Set() }];
        while (stack.length) {
            const { row, depth, ancestors } = stack.pop();
            const repeated = ancestors.has(row.iri) || visited.has(row.iri);
            result.push({ iri: row.iri, depth, repeated });
            if (repeated)
                continue;
            visited.add(row.iri);
            const next = new Set([...ancestors, row.iri]);
            for (const child of [...(children.get(row.iri) ?? [])].reverse())
                stack.push({ row: child, depth: depth + 1, ancestors: next });
        }
    };
    for (const root of ordered.filter((row) => !row.parents.some((id) => byId.has(id))))
        walk(root);
    // Closed cycles have no root; still display every class with an explicit reference marker.
    for (const row of ordered)
        if (!visited.has(row.iri))
            walk(row);
    return result;
}
export function localGraph(view, focus, limit = 30) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 100)
        throw new Error('invalid_limit');
    const all = view.triples
        .filter((row) => row.subject === focus || row.object === `<${focus}>`)
        .sort((a, b) => {
        const x = JSON.stringify([a.subject, a.predicate, a.object]);
        const y = JSON.stringify([b.subject, b.predicate, b.object]);
        return x < y ? -1 : x > y ? 1 : 0;
    });
    const edges = all.slice(0, limit);
    const ids = new Set([focus]);
    for (const edge of edges) {
        ids.add(edge.subject);
        if (edge.object.startsWith('<'))
            ids.add(edge.object.slice(1, -1));
    }
    return { nodes: [...ids].sort(), edges, total: all.length, truncated: all.length > edges.length };
}
export const kindLabels = {
    class: '类',
    objectProperty: '对象属性',
    dataProperty: '数据属性',
    individual: '个体',
};
export function identity(view) {
    return JSON.stringify([view.project, view.revision]);
}
/** A late/old project preview never enables a current-project confirmation. */
export function isCurrentPreview(view, preview) {
    return identity(view) === identity(preview);
}
export function labelOf(row) {
    return (row.labels.find(([, language]) => language === 'zh')?.[0] ??
        row.labels[0]?.[0] ??
        row.identifier);
}
export function definitionOf(row) {
    return (row.definitions.find(([, language]) => language === 'zh')?.[0] ?? row.definitions[0]?.[0] ?? '');
}
