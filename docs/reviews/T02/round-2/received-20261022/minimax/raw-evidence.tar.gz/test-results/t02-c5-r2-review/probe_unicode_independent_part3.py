"""Independent probe part 3.

Fixes two defects of my own earlier probe scripts (NOT product defects):
  - part 2 compared against double-escaped literals ("e\\\\u0301"), and the probe
    file itself contained a PRECOMPOSED U+00E9, so the decomposed-accent assertion
    was meaningless. Here the escape is written as a real codepoint.
  - part 2 could not commit a surrogate payload to a Store, so it never reached the
    owning-Store boundary. Here the boundary is probed directly.
"""

import json
import pathlib
import tempfile

from ontolearn_engine.ontology import Entity, OntologyError, Snapshot, change_preview
from ontolearn_engine.ontology.source_projection import bind_rdf_projection
from ontolearn_engine.storage import Store, digest

ROOT = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-minimax-review-e5ad54e"
OUT = []


def say(line):
    print(line, flush=True)
    OUT.append(line)


def probe(fn):
    try:
        return ("ok", fn())
    except OntologyError as error:
        return ("ontology", f"{error.reason}/{error.location}")
    except BaseException as error:  # noqa: BLE001
        return ("native", f"{type(error).__name__}: {error}")


say("=== A. Decomposed accent preserved as distinct codepoints (real escape) ===")
decomposed = "泵站\U0001F680 e" + chr(0x0301)
precomposed = "泵站\U0001F680 " + chr(0x00E9)
say(f"  probe string codepoints tail: {[hex(ord(c)) for c in decomposed[-2:]]}")
entity = Entity("urn:设备", "class", "Equipment", labels=((decomposed, "zh"),))
snap = Snapshot("项目", 0, (entity,))
preview = change_preview(snap)
say(f"  label stored verbatim (decomposed kept): {preview.candidate.entities[0].labels == ((decomposed, 'zh'),)}")
say(f"  decomposed != precomposed in this probe: {decomposed != precomposed}")
say(f"  no NFC normalization applied          : {chr(0x0301) in preview.candidate.entities[0].labels[0][0]}")
say(f"  no NFC normalization applied (precomposed absent): {chr(0x00E9) not in preview.candidate.entities[0].labels[0][0]}")

say("")
say("=== B. bind_rdf_projection with a hand-built source whose payload holds a surrogate ===")
with tempfile.TemporaryDirectory() as tmpdir:
    store = Store(pathlib.Path(tmpdir) / "probe.db")
    store.create_project("p")
    store.commit("p", 0, "seed", "seed-job", definitions=[
        {"layer": "ontology", "id": "d1", "value": {"triples": []}}
    ])
    ref = store.snapshot("p")
    source = store.load_snapshot(ref)
    writes = store._db.total_changes
    # Inject a lone surrogate into a definition payload of the SOURCE side.
    tampered = {k: v for k, v in source.items()}
    tampered["state"] = {k: (list(v) if isinstance(v, list) else v) for k, v in source["state"].items()}
    tampered["state"]["definitions"] = [
        {"layer": "ontology", "id": "d1", "payload": json.dumps({"triples": [], "note": "x" + chr(0xD800)})}
    ]
    editor = Snapshot("p", 1)
    say(f"  tampered source -> bind_rdf_projection: "
        f"{probe(lambda: bind_rdf_projection(digest(tampered), tampered, editor))}")
    say(f"  store total_changes unchanged: {store._db.total_changes == writes}")
    say(f"  Store._snapshot_state on surrogate payload: "
        f"{probe(lambda: Store._snapshot_state(tampered['state']))}")
    store.close()

say("")
say("=== C. Owning-Store boundary (storage.py, T01-owned, outside the 25-item scope) ===")
with tempfile.TemporaryDirectory() as tmpdir:
    store = Store(pathlib.Path(tmpdir) / "probe2.db")
    store.create_project("p")
    result = probe(lambda: store.commit("p", 0, "seed", "seed-job", definitions=[
        {"layer": "ontology", "id": "d1", "value": {"triples": [], "note": "x" + chr(0xD800)}}
    ]))
    say(f"  Store.commit with surrogate payload: {result}")
    say("  -> the native error is raised by ontolearn_engine/storage.py (T01-owned),")
    say("     not by the T02 ontology package, which contains no Store write call.")
    store.close()

import json  # noqa: E402

with open(
    f"{ROOT}/test-results/t02-c5-r2-review/metadata/probe_unicode_independent_part3.txt", "w"
) as handle:
    handle.write("\n".join(OUT) + "\n")
print("PROBE3_DONE")
