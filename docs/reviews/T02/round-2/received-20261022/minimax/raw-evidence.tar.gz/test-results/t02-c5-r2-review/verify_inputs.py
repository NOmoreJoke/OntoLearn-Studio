import json, hashlib, subprocess, os
ROOT="/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-c5-minimax-review-e5ad54e"
m=json.load(open(os.path.join(ROOT,'docs/reviews/T02/round-2/input-manifest.json')))
out={"checked":[], "mismatch":[], "missing":[]}
def blob(ref, path):
    r=subprocess.run(["git","-C",ROOT,"cat-file","-p",f"{ref}:{path}"],capture_output=True)
    return None if r.returncode!=0 else r.stdout
def rec_check(listname, p, ref, b, s, data, source):
    if data is None:
        out["missing"].append({"list":listname,"path":p,"ref":ref}); return
    actual_b=len(data); actual_s=hashlib.sha256(data).hexdigest()
    ok=(actual_b==b and actual_s==s)
    r={"list":listname,"path":p,"ref":ref,"source":source,"expectBytes":b,"actualBytes":actual_b,"expectSha256":s,"actualSha256":actual_s,"match":ok}
    out["checked"].append(r)
    if not ok: out["mismatch"].append(r)
for listname,key in [("delta120","fullBranchDeltaFiles"),("ref10","unchangedReferences")]:
    for it in m[key]:
        d=blob(it["ref"], it["path"])
        rec_check(listname, it["path"], it["ref"], it["bytes"], it["sha256"], d, "git")
for it in m["currentPolicyPayloads"]:
    fp=os.path.join(ROOT,it["path"])
    d=open(fp,'rb').read() if os.path.exists(fp) else None
    rec_check("policy4", it["path"], "worktree", it["bytes"], it["sha256"], d, it.get("source",""))
print(json.dumps({"total_checked":len(out["checked"]),"mismatch_count":len(out["mismatch"]),"missing_count":len(out["missing"])},ensure_ascii=False))
for r in out["mismatch"]: print("MISMATCH", json.dumps(r,ensure_ascii=False))
for r in out["missing"]: print("MISSING", json.dumps(r,ensure_ascii=False))
json.dump(out, open(os.path.join(ROOT,'test-results/t02-c5-r2-review/metadata/input-verification.json'),'w'), ensure_ascii=False, indent=1)
