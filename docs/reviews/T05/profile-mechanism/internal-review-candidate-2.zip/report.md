# Candidate-2 独立 delta 复审

结论：**当前 candidate-2 不通过；可结束本次冻结并集中修复下列三组 P2，再封存下一候选定点复核。** 其余原 R1/R3/R4/R5/R6、root R1–R3 的具体反例修复均有对应关闭依据；原 R2 的一般直接入口边界、N2 的全部计费边界仍未关闭。无需为等待本报告继续冻结 candidate-2；原件已在本目录保留。

## 固定输入与实际命令

Candidate manifest SHA-256 `122ca1830f441349790b0db6b0288571c04a0dc0b0cff2668f54e95ec9eac695`；ZIP 35205B/SHA `4fb63f5f1c429e3d377d9756f3dbfb6a812ba24861e63a6fb4dc3566b1a3c7a2`。开始和最终均核20路径集合、当前磁盘每项 bytes/hash、ZIP每项原bytes完全一致；ZIP testzip 无坏成员。candidate-1-to-2.diff.raw SHA `4ce1a08c0f3e857d292f4d1086b13f03f00c7e92fe02b2cb5e9a4a4be29c0139`。复审全部实质代码/测试/fixture delta，复用已审未变数学规范，不重做完整规范审计。root候选1预读全文已对照。

实际运行：`uv run --frozen --no-sync python docs/reviews/T05/profile-mechanism/internal-review-candidate-2/probes.py.raw`，exit **0**，stdout3723B，stderr0B。probes.receipt.json 来自实际 subprocess.run returncode 与输出原字节；并非事后猜测退出码。脚本完整输入在 probes.py.raw，输出原件在 probes.stdout.raw/stderr.raw。七模块从本目录冻结 ZIP 的原代码直接 compile/exec；仅构造隔离 namespace，未修改源码，不导入旧RDF parser或其他候选。源ZIP/manifest副本一并保留。前期inline反例的同一条件已在该冻结运行重现；此receipt对应此次运行，不冒充较早inline命令的原始启动收据。

## 剩余问题

### C2-R1 / P2：直接入口仍能执行外来回调，比较错误还可携带未验证位置

位置：rule_comparator.py:18–24；rule_profile.py:258–265；rule_terms.py:87 位置门仅由 parse_value 调用。

完整输入/输出见 probes 三个 open-R2 记录：对两个真实 parser 签发的 S 值，传 Probe 作为 operator，`op not in OPS` 在拒绝前调用 __eq__ 六次；Probe 只向列表 append，无外部副作用。`account_input(Foreign(), Budget())` 中 Foreign 是普通 type，唯一设置 `__module__=Probe()`，walker 在确认 module 是内建 str 前与五个模块名做 membership，执行五次 __eq__。这没有修改私有 issuer 表、模块方法或被测类。另 `compare_values(...,'invalid',...,InputLocation(section=Probe()))` 返回 INVALID_RULE 且 ProfileFailure.location.section 仍是 Probe，不符合安全字段边界。

必要修法：比较入口在枚举/分派前检查 operator 确切 str；所有接受 location 的直接入口复用无hook类型/枚举门，拒绝损坏位置时不将该位置原样带入 failure。walker 在 membership/sys.modules/反射前核 __module__/__name__ 确切 str，或通过实际允许 class identity 表识别。补仅append Probe 的 operator/module/location 回归。已签发 ProfileValue 的身份/digest 防护本身有效，不能据此关闭其他输入字段。

### C2-R2 / P2：fingerprint 仍可省略 Budget，直接绕过哈希计费

位置：rule_profile.py:296–303；test_quality_profile_firing.py:327 的伪造摘要回归仍走无Budget调用。

实际 `fingerprint(b'x'*262145)` 成功返回 `9408817bc040328d1c403ff97e94cea3dfd3a361b2fb7ecc7af75ff3a5157139`，完全没有 Budget，超默认输入字节上限的数据也进入 sha256。正常内部调用现均传预算，故此处不声称真实evaluate已绕过；问题是已承诺的直接纯入口仍公开无界路径。

必要修法：强制真实 Budget，不保留 None 默认免计费分支；在hash前核有界输入并预扣实际工作。明确不把内部已编码数据重复当外部输入造成额外语义变化；伪计划回归同步传真实Budget。补无/外来budget及hash前work/bytes失败边界。

### C2-R3 / P2：tuple_compare 的 int 分支未查位长且固定收费1

位置：rule_profile.py:199–215，特别208–210。

实际 `tuple_compare((1<<32768,),((1<<32768)+1,),Budget())` 返回 -1，两个操作数均32769bits，超过temporary_bits32768；usage仅work=1，其他0。这与新增 check_ints/check_number 的事前位长门不一致，也没按limb计整数排序比较费用。反例有界，仅约4KiB整数，未做压力或性能测量。

必要修法：整数比较前核适用位长限额并按参与limb预扣工作；bool可独立常量分支。补位长±1与低work失败、长共同前缀大整数比较的实际入口回归。

## 逐项处置

| 原意见 | 当前处置与证据 |
| --- | --- |
| R1 双常量预检 | 关闭。compile调用同comparator；独立运行 IRI lt IRI、integer eq S 在零binding前 TYPE_MISMATCH/原comparison0失败；合法1 gt2编译成功、零binding空批。 |
| R2 callback/精确类型 | 原未签发/被改value与parse_value位置反例关闭：无hook、Internal/INVALID_RULE。新Value weakref identity+原digest真实核验，非producer授权。但C2-R1使整项仍未关闭。 |
| R3 catalog重分类schema | 关闭。保留四namespace谓词及schema声明对象禁区；独立运行四谓词全部UNSUPPORTED_RULE_OUTPUT/head0。代码另有声明类回归，rdf:type普通受控类保留。 |
| R4 伪plan/等码 | 关闭。issued actual-plan identity+原digest+同budget；复制seal/重算摘要仍Internal；独立int/string与tuple/list编码不等，dataclass加专属括号/类名/字段编码。不是跨producer认证。 |
| R5 / root R1 facts代表 | 关闭。由已稳定排序firings、原head位置挑raw代表后按abstract key去重；simple/string与source两种反序完整payload/digest相同，所有raw/source仍在各自firing。四份完整payload原字节保留。 |
| R6 / root R2 签名与fixture | 关闭。648=6×6×3×6全有序混型独立三点真值实跑相符；30有向替换都实际调用替代operator并与原签名不等。fixture输入构造使用definition/catalog/binding/when/proof，完整asdict firing/facts/profile与expected逐字段比较；不是仅少数字段或调用同一checker当oracle。 |
| root R3 原InputLocation | 该具体反例关闭，section/side先exact-type；独立probe无hook。一般比较位置安全仍见C2-R1。 |
| N2 catalog/扫描/hash等 | catalog总account在任何IRI扫描/排序前，别名按出现计；12n数字/8n日期/4n小段与lang预扣覆盖改动扫描；内部hash调用传Budget；原22 trace单位未改。仍有C2-R2/R3，不能整项关闭。 |

本轮没有改数学舍入/日历政策；新身份检查不变更值域矩阵；规则链/完整comparison/多head及最终batch原子路径未删改。fixture新增truth signatures为手工三点六算子表，完整expected不由本轮被测运行回填；本审未证明作者历史生成过程，仅核内容、驱动与比较路径。弱引用表在对象失效时移除，不用token作为producer授权。

## 实际边界与终态

本次只写本专属证据目录，无产品/测试/配置/分支修改；未GUI/网络/Store/原有或未批I05/T01实现，不复跑全量检查。父线转述candidate-2专项1399与全check635TS/2599Python exit0，本审尚未独立绑定读取其全部终态原件，故不将转述登记为本审运行结果；本审只有上述真实有界CLI exit0与独立静态delta核验。三组P2足以暂不通过，无需扩大扫描到不变产品。

本结论仅本私有纯机制阶段delta，不替代指定外审/同候选双审、CI/远端、真实I05图匹配/完整source/producer/Store/worker/公共错误路由、目标平台与FR500–505父验收。可解冻集中修复这三组并绑定candidate-3；不应将candidate-2原件或历史失败原件覆盖。
