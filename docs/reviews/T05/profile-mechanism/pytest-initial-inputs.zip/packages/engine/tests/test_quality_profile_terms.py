"""Lexical/source/term identity witnesses for the adopted private profile."""

import json
from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest

from ontolearn_engine.quality.rule_profile import (
    RDF,
    XSD,
    Budget,
    InputLocation,
    ProfileFailure,
    SourceRecord,
    TermInput,
)
from ontolearn_engine.quality.rule_terms import GRANDFATHERED, parse_value, term_key

FIXTURES = Path(__file__).resolve().parents[3] / "tests/fixtures/quality/profile-v1"


def fixture(name):
    return json.loads((FIXTURES / name).read_text())


def term(kind, text, language=None):
    return TermInput("literal", text, (RDF if kind == "langString" else XSD) + kind, language)


def value(kind, text, language=None, budget=None):
    return parse_value(term(kind, text, language), None, budget or Budget())


@pytest.mark.parametrize("case", fixture("lexical.json")["valid"])
def test_lexical_positive(case):
    v = value(case["type"], case["lexical"], case.get("language"))
    assert v.term.lexical_form == case["lexical"]


@pytest.mark.parametrize("case", fixture("lexical.json")["invalid"])
def test_lexical_negative(case):
    loc = InputLocation("comparison", 7, "right")
    with pytest.raises(ProfileFailure) as caught:
        parse_value(term(case["type"], case["lexical"]), loc, Budget())
    assert (caught.value.reason, caught.value.location) == (case["reason"], loc)
    assert str(caught.value) == case["reason"]
    assert case["lexical"] not in caught.value.args or case["lexical"] == ""


@pytest.mark.parametrize(
    "label", fixture("lexical.json")["valid_languages"] + sorted(GRANDFATHERED)
)
def test_all_language_branches(label):
    assert value("langString", "\0\ufffe", label).language == label.lower()


@pytest.mark.parametrize("label", fixture("lexical.json")["invalid_languages"])
def test_bad_languages(label):
    with pytest.raises(ProfileFailure, match="INVALID_LITERAL_LEXICAL"):
        value("langString", "hello", label)


def test_source_spelling_and_abstract_term_are_separate():
    budget = Budget()
    source = SourceRecord("example", "given-digest", "r7", '"a"@EN')
    raw = TermInput("literal", "a", None, "EN", source)
    parsed = parse_value(raw, None, budget)
    assert parsed.term is raw and parsed.term.source is source
    assert term_key(parsed, budget) == term_key(value("langString", "a", "en"), budget)
    simple = parse_value(TermInput("literal", "a"), None, budget)
    assert term_key(simple, budget) == term_key(value("string", "a"), budget)
    assert term_key(value("integer", "01"), budget) != term_key(value("integer", "1"), budget)
    with pytest.raises(FrozenInstanceError):
        raw.lexical_form = "changed"


@pytest.mark.parametrize(
    "bad",
    [
        TermInput("literal", "a", ""),
        TermInput("literal", "a", RDF + "langString"),
        TermInput("literal", "a", XSD + "string", "en"),
        TermInput("literal", "\ud800"),
        TermInput("blank", "x"),
        TermInput("iri", "relative"),
        TermInput("iri", "urn:has space"),
    ],
)
def test_structural_inputs_never_become_values(bad):
    with pytest.raises(ProfileFailure, match="INVALID_RULE"):
        parse_value(bad, None, Budget())


def test_unsupported_datatype_and_missing_locations_are_explicit():
    with pytest.raises(ProfileFailure) as caught:
        parse_value(TermInput("literal", "x", "urn:unknown"), None, Budget())
    assert caught.value.reason == "UNSUPPORTED_LITERAL_DATATYPE"
    assert caught.value.location is None
    with pytest.raises(AttributeError):
        caught.value.reason = "other"
