"""Given-binding atomicity, complete occurrences, source and tamper witnesses."""

from dataclasses import replace

import pytest
from test_quality_profile_terms import fixture, term

from ontolearn_engine.quality.rule_firing import (
    BindingMatch,
    Catalog,
    Comparison,
    CompiledPlan,
    RuleSpec,
    Triple,
    Variable,
    check_firing_group,
    compile_rules,
    evaluate_bound_batch,
)
from ontolearn_engine.quality.rule_profile import (
    RDF,
    Budget,
    InputLocation,
    ProfileFailure,
    SourceRecord,
    TermInput,
)


def iri(s):
    return TermInput("iri", s)


def example(comparisons=None, heads=None, when=None):
    data = fixture("firing-cases.json")
    cat = Catalog(**{k: tuple(v) for k, v in data["catalog"].items()})
    s, v = Variable("?s"), Variable("?v")
    w = Triple(s, iri("urn:value"), v)
    head = Triple(s, iri("urn:out"), v)
    spec = RuleSpec(
        "r1",
        when or (w,),
        comparisons if comparisons is not None else (Comparison(v, "gt", term("integer", "1")),),
        heads or (head, head),
        SourceRecord("fixture:firing-cases", None, "1", "actual fixture"),
        "1",
        "given-definition-digest",
    )
    actual = Triple(iri("urn:a"), iri("urn:value"), term("integer", "2"))
    match = BindingMatch(
        "r1",
        (("?s", iri("urn:a")), ("?v", term("integer", "2"))),
        tuple(actual for _ in spec.when),
        tuple(("fact:1",) for _ in spec.when),
    )
    return spec, cat, match


def execute(spec=None, match=None, limits=None):
    r, c, m = example()
    b = Budget(limits)
    p = compile_rules((spec or r,), c, b)
    return p, b, evaluate_bound_batch(p, (match or m,), b)


def test_complete_duplicate_heads_and_basis_fixture():
    p, b, batch = execute()
    expected = fixture("firing-cases.json")["expected"]
    group = batch.firings[0]
    assert [h.index for h in group.heads] == expected["head_indices"]
    assert [c.index for c in group.comparisons] == expected["comparison_indices"]
    assert group.basis == tuple(expected["basis"])
    assert len(batch.facts) == expected["unique_facts"]
    assert len(group.heads) == 2 and group.heads[0].triple == group.heads[1].triple
    assert group.comparisons[0].left.value.numerator == 2
    assert group.comparisons[0].right.value.numerator == 1
    assert group.source.reference == "fixture:firing-cases"
    assert check_firing_group(p, group, b)


def test_duplicate_when_positions_and_distinct_firings_survive():
    r, c, m = example(when=(Triple(Variable("?s"), iri("urn:value"), Variable("?v")),) * 2)
    other = replace(
        m,
        bindings=(("?s", iri("urn:b")), ("?v", term("integer", "2"))),
        when=(Triple(iri("urn:b"), iri("urn:value"), term("integer", "2")),) * 2,
    )
    b = Budget()
    p = compile_rules((r,), c, b)
    result = evaluate_bound_batch(p, (other, m), b)
    assert len(result.firings) == 2
    assert result.firings[0].bindings[0][1] == iri("urn:a")
    assert len(result.firings[0].when) == 2
    assert len(result.firings[0].proof_leaves) == 2
    assert result.firings[0].basis == ("fact:1",)
    # Different bindings can produce exactly the same output; retain both firings.
    constant = replace(r, heads=(Triple(iri("urn:fixed"), iri("urn:out"), term("integer", "2")),))
    b = Budget()
    p = compile_rules((constant,), c, b)
    result = evaluate_bound_batch(p, (m, other), b)
    assert len(result.firings) == 2 and len(result.facts) == 1


def test_zero_match_bad_constant_and_unbound_have_real_locations():
    r, c, _ = example(comparisons=(Comparison(Variable("?v"), "eq", term("integer", "broken")),))
    with pytest.raises(ProfileFailure) as e:
        compile_rules((r,), c, Budget())
    assert (e.value.reason, e.value.location) == (
        "INVALID_LITERAL_LEXICAL",
        InputLocation("comparison", 0, "right"),
    )
    r = replace(r, comparisons=(Comparison(Variable("?missing"), "eq", term("integer", "1")),))
    with pytest.raises(ProfileFailure) as e:
        compile_rules((r,), c, Budget())
    assert e.value.reason == "UNBOUND_RULE_VARIABLE"
    assert e.value.location == InputLocation("comparison", 0, "left")


def test_false_does_not_hide_later_comparison_type_failure():
    r, c, m = example(
        comparisons=(
            Comparison(Variable("?v"), "lt", term("integer", "1")),
            Comparison(Variable("?v"), "eq", term("string", "x")),
        )
    )
    b = Budget()
    p = compile_rules((r,), c, b)
    with pytest.raises(ProfileFailure) as e:
        evaluate_bound_batch(p, (m,), b)
    assert (e.value.reason, e.value.location) == (
        "RULE_COMPARISON_TYPE_MISMATCH",
        InputLocation("comparison", 1),
    )


def test_false_and_zero_match_are_successful_empty_batches():
    r, c, m = example(comparisons=(Comparison(Variable("?v"), "lt", term("integer", "1")),))
    b = Budget()
    p = compile_rules((r,), c, b)
    assert evaluate_bound_batch(p, (m,), b).firings == ()
    b = Budget()
    p = compile_rules((r,), c, b)
    assert evaluate_bound_batch(p, (), b).facts == ()


def test_later_head_and_binding_failure_have_no_partial_return():
    r, c, m = example(
        heads=(
            Triple(Variable("?s"), iri("urn:out"), Variable("?v")),
            Triple(Variable("?v"), iri("urn:out"), term("integer", "1")),
        )
    )
    b = Budget()
    p = compile_rules((r,), c, b)
    with pytest.raises(ProfileFailure) as e:
        evaluate_bound_batch(p, (m,), b)
    assert (e.value.reason, e.value.location) == ("INVALID_RULE", InputLocation("head", 1))
    r, c, m = example()
    b = Budget()
    p = compile_rules((r,), c, b)
    corrupt = replace(m, bindings=(("?s", iri("urn:a")), ("?v", term("integer", "broken"))))
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        evaluate_bound_batch(p, (m, corrupt), b)


@pytest.mark.parametrize(
    "change",
    [
        lambda g: replace(g, heads=g.heads[:1]),
        lambda g: replace(g, comparisons=()),
        lambda g: replace(g, basis=("threshold-is-not-basis",)),
        lambda g: replace(g, policy="unknown"),
        lambda g: replace(g, revision="changed"),
        lambda g: replace(g, bindings=()),
    ],
)
def test_group_consistency_rejects_missing_or_changed_parts(change):
    p, b, batch = execute()
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        check_firing_group(p, change(batch.firings[0]), b)


def test_no_caller_marker_can_bypass_prevalidation_or_reuse_budget():
    r, c, m = example()
    b = Budget()
    p = compile_rules((r,), c, b)
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        CompiledPlan((), c, "forged", b)
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        evaluate_bound_batch(p, (m,), Budget())
    object.__setattr__(p, "digest", "tampered")
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        evaluate_bound_batch(p, (), b)


def test_duplicate_exact_match_is_internal_and_schema_outputs_rejected():
    r, c, m = example()
    b = Budget()
    p = compile_rules((r,), c, b)
    with pytest.raises(ProfileFailure, match="INTERNAL_ERROR"):
        evaluate_bound_batch(p, (m, m), b)
    bad = replace(r, heads=(Triple(iri("urn:C"), iri(RDF + "type"), iri("urn:C")),))
    with pytest.raises(ProfileFailure, match="UNSUPPORTED_RULE_OUTPUT"):
        compile_rules((bad,), c, Budget())
