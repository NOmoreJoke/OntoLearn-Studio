"""Bounded review-only probes against the exact candidate-1 ZIP source copy."""
import hashlib
import inspect
import json
from pathlib import Path
import sys
import types
from dataclasses import replace

HERE = Path(__file__).resolve().parent
SRC = HERE / "snapshot/packages/engine/src"
# Review import isolation only; the seven actual candidate modules are unmodified.
package = types.ModuleType("ontolearn_engine")
package.__path__ = [str(SRC / "ontolearn_engine")]
sys.modules["ontolearn_engine"] = package
from ontolearn_engine.quality.rule_profile import (
    Budget, InputLocation, ProfileFailure, ProfileLimits, RDF, SourceRecord,
    TermInput, XSD, encode_input, fingerprint,
)
from ontolearn_engine.quality.rule_terms import ProfileValue, parse_value
from ontolearn_engine.quality.rule_comparator import compare_values
from ontolearn_engine.quality.rule_firing import (
    BindingMatch, Catalog, Comparison, CompiledPlan, RuleSpec, Triple, Variable,
    compile_rules, evaluate_bound_batch,
)
import ontolearn_engine.quality.rule_comparator as comparator
import ontolearn_engine.quality.rule_firing as firing

def emit(case, **data):
    print(json.dumps({"case": case, **data}, ensure_ascii=True, sort_keys=True))

def iri(text, source=None):
    return TermInput("iri", text, source=source)

def integer(text):
    return TermInput("literal", text, XSD + "integer")

s, v = Variable("?s"), Variable("?v")
catalog = Catalog(classes=("urn:C",), data_properties=("urn:p", "urn:q"))
when = (Triple(s, iri("urn:p"), v),)
head = (Triple(s, iri(RDF + "type"), iri("urn:C")),)
valid = RuleSpec("r", when, (), head)
match = BindingMatch("r", (("?s", iri("urn:a")), ("?v", integer("1"))),
                     (Triple(iri("urn:a"), iri("urn:p"), integer("1")),), (("f1",),))

# R1: compile-time compatibility of two fully constant operands.
for op, left, right in [
    ("lt", iri("urn:a"), iri("urn:b")),
    ("eq", integer("1"), TermInput("literal", "1", XSD + "string")),
    ("lt", integer("2"), integer("1")),
]:
    b = Budget()
    rule = replace(valid, comparisons=(Comparison(left, op, right),))
    p = compile_rules((rule,), catalog, b)
    out = evaluate_bound_batch(p, (), b)
    emit("constant-compatibility", operator=op, left=left.kind + ":" + str(left.datatype_iri),
         right=right.kind + ":" + str(right.datatype_iri), compiled=True,
         zeroBindingFirings=len(out.firings))

# R2: only append-list callbacks, with no external effects.
calls = []
class Probe:
    def __gt__(self, other):
        calls.append("gt")
        return False
    def __lt__(self, other):
        calls.append("lt")
        return False
raw_bool = TermInput("literal", "true", XSD + "boolean")
out = compare_values(ProfileValue(raw_bool, "B", Probe()), "eq",
                     ProfileValue(raw_bool, "B", Probe()), Budget())
emit("profile-value-callback", result=out, callbacks=calls)
calls = []
class SectionProbe:
    def __eq__(self, other):
        calls.append(type(other).__name__)
        return False
try:
    parse_value(integer("1"), InputLocation(SectionProbe(), 0), Budget())
except ProfileFailure as e:
    emit("location-callback", reason=e.reason, callbacks=calls)

# R3: a catalog declaration must not reclassify protected schema predicates.
schema = "http://www.w3.org/2000/01/rdf-schema#subClassOf"
cat = replace(catalog, object_properties=(schema,))
rule = replace(valid, heads=(Triple(s, iri(schema), iri("urn:C")),))
b = Budget()
p = compile_rules((rule,), cat, b)
out = evaluate_bound_batch(p, (match,), b)
emit("schema-output", subject=out.facts[0].subject.lexical_form,
     predicate=out.facts[0].predicate.lexical_form, object=out.facts[0].object.lexical_form)

# R4: copied seal + recomputed public digest bypasses actual compilation.
b = Budget()
p = compile_rules((valid,), catalog, b)
bad = replace(valid, comparisons=(Comparison(v, "eq", integer("broken")),))
forged_rules = (replace(p.rules[0], spec=bad),)
fresh = Budget()
fresh.start("compile")
forged = CompiledPlan(forged_rules, catalog,
                      fingerprint(encode_input((forged_rules, catalog), fresh)),
                      fresh, p._seal)
out = evaluate_bound_batch(forged, (), fresh)
emit("copied-seal", badLiteral="broken", zeroBindingFirings=len(out.firings))
emit("typed-encoding", intEncoding=encode_input(1, Budget()).decode(),
     stringEncoding=encode_input("0x1", Budget()).decode(),
     equal=encode_input(1, Budget()) == encode_input("0x1", Budget()))

# R5: preserve both complete payloads; only the order of supplied matches differs.
for variant in ("source", "simple-explicit-string"):
    rules = []
    for index, name in enumerate(("a", "b")):
        subj = iri("urn:fixed", SourceRecord(text=name) if variant == "source" else None)
        obj = integer("2") if variant == "source" else TermInput(
            "literal", "a", None if index == 0 else XSD + "string")
        rules.append(RuleSpec(name, when, (), (Triple(subj, iri("urn:q"), obj),)))
    matches = (replace(match, rule_id="a"), replace(match, rule_id="b"))
    payloads = []
    for label, ms in (("ab", matches), ("ba", matches[::-1])):
        b = Budget()
        p = compile_rules(tuple(rules), catalog, b)
        out = evaluate_bound_batch(p, ms, b)
        filename = f"facts-{variant}-{label}.payload"
        (HERE / filename).write_bytes(out.payload)
        payloads.append(out.payload)
        emit("facts-order", variant=variant, inputOrder=label,
             firingOrder=[f.rule_id for f in out.firings],
             chosenSource=out.facts[0].subject.source.text if out.facts[0].subject.source else None,
             chosenDatatype=out.facts[0].object.datatype_iri,
             payload=filename, payloadBytes=len(out.payload), sha256=out.digest)
    emit("facts-order-comparison", variant=variant, equal=payloads[0] == payloads[1])

# R6: execute the actual authorized comparator with a final ne-dispatch mutation.
# This does not mutate any candidate module or file.
namespace = dict(vars(comparator))
source = inspect.getsource(comparator._compare_values)
assert source.count('"ne": c != 0') == 1
exec(compile(source.replace('"ne": c != 0', '"ne": c < 0'),
             "review-only-ne-to-lt", "exec"), namespace)
mutant = namespace["_compare_values"]
types_ = ("integer", "int", "nonNegativeInteger", "decimal", "float", "double")
same = []
for left_type in types_:
    for right_type in types_:
        left = parse_value(TermInput("literal", "1", XSD + left_type), None, Budget())
        for n in ("1", "2"):
            right = parse_value(TermInput("literal", n, XSD + right_type), None, Budget())
            for op in ("eq", "ne", "lt", "le", "gt", "ge"):
                same.append(mutant(left, op, right, Budget()) == compare_values(left, op, right, Budget()))
left = parse_value(integer("3"), None, Budget())
right = parse_value(integer("2"), None, Budget())
emit("operator-test-gap", coveredNumericChecks=len(same), allUnchanged=all(same),
     greaterSideOriginal=compare_values(left, "ne", right, Budget()),
     greaterSideMutant=mutant(left, "ne", right, Budget()))

# Additional N2: catalog work happens before the total input guard.
seen = []
original = firing._sort_unique
def observed_sort(values, budget):
    seen.append({"items": len(values), "inputBytesBeforeSort": dict(budget.usage)["input_bytes"]})
    return original(values, budget)
firing._sort_unique = observed_sort
b = Budget(ProfileLimits(input_bytes=1))
try:
    compile_rules((), Catalog(classes=tuple(f"urn:c{i}" for i in range(10))), b)
except ProfileFailure as e:
    emit("catalog-before-input-guard", reason=e.reason, sortCalls=seen, usage=dict(b.usage))
finally:
    firing._sort_unique = original

emit("probe-complete", sourceCopy=str(SRC), noProductFilesChanged=True,
     note="Review probes are not full engine, Store, graph, production or designated-review evidence.")
