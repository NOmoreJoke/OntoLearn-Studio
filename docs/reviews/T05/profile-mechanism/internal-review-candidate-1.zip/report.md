# T05 profile mechanism candidate-1 独立实现审查

结论：**不通过，可立即解冻集中修复**。本次完整阅读冻结7代码、7测试、6fixture；六组问题及一项相关N2问题如下，均应在新候选关闭。本结论不替代指定双模型或父FR验收。

## 固定对象与实际验证

- 阶段授权6228B，SHA256 `210f31b1406fb13fb616e1f94b026feea2f3437c270f709185d890715512d1f0`，已全文读回。
- candidate-1 manifest SHA256 `9e9e5ff5b1414dfa173d6915e831769e5320f32156442a0c61b816d9ae3cc66a`。
- candidate-1 ZIP 30298B，SHA256 `3a8b35c792e42b12cdaa59b2c660b8f4741b1268980c35e212efa462fbc95978`。20成员CRC可读，逐bytes/hash匹配manifest；初次审查时当前工作树20文件也全部匹配。
- 本目录snapshot仅是授权证据副本，不是Git worktree。后续CLI只导入该ZIP的七代码副本，避免父任务后续修复改变复现对象。合成namespace根仅用于隔离导入；不是包/真实入口验收。
- `probes.py`是完整、已实际执行的有界反例代码和原输入；实际argv/cwd/退出码/完整stdout/stderr见`probes-execution-receipt.json`及两个raw文件。退出0，stdout3316B，stderr0B。无产品测试/全check复跑，无Graph/Store/GUI/外发。
- 开发线报告专项919通过、全check635TS/2119Python通过；本审查未独立重跑全量，也没有把这些计数当作下列反例不存在的证明。
- 实际只写本专属证据目录，未改20个受审输入、分支或提交。

## 发现与建议

所有位置相对冻结 `packages/engine/src/ontolearn_engine/quality/`；测试位置相对 `packages/engine/tests/`。

### R1 / P2：双常量比较未做可静态判定的类型/操作合法性预检

`rule_firing.py:271–284`仅分别parse两个常量；兼容性只在`_one:387–391`发生。`IRI lt IRI`及`integer eq string`均compile成功，零binding返回成功空批。后者不是合法false，而是已采用矩阵规定的不兼容；其静态错误被零匹配遮蔽。

建议：两侧常量时在compile调用同一comparator校验域/operator，错误绑定真实comparison位置。合法常量false必须仍允许编译；单侧变量的实际域留到完整binding。`probes.py`同时保留合法`2 lt 1`空批对照。

### R2 / P2：直接API精确类型门不足，能调用输入对象方法

`rule_comparator.py:19–38`只检查ProfileValue外壳，直接对其value做比较。两个`ProfileValue(...,'B',Probe())`的Probe仅向本地list append，实际得到True并执行`__gt__`/`__lt__`。`rule_terms.py:52–61`在检查section/side字段精确类型前做membership；`InputLocation(SectionProbe(),0)`实际执行四次`__eq__`后才报INVALID_RULE。

这证明私有纯入参合同被绕过，不表示存在跨进程远程代码执行或真实系统权限突破。建议所有直接入口先验Budget、位置及内部值的精确内建类型/不变量，不能以dataclass外壳替代；损坏/伪造ProfileValue归Internal。检查范围应覆盖parse/compare、account/encode/fingerprint及数值辅助入口，避免先执行callback再失败。

### R3 / P2：catalog重分类可绕过schema输出保护

`rule_firing.py:178–213,223–232`没有独立保留schema谓词/声明对象保护。把`rdfs:subClassOf`列为catalog.object_properties后，规则head `(?s,rdfs:subClassOf,urn:C)`实际成功返回schema triple。

建议在独立受控输出门保留既有schema命名空间/声明类保护，不能因catalog把它重新列作普通属性/类而放行。rdf:type到受控普通类仍保留合法例。原catalog引用合法性与禁止schema修改是两项检查。

### R4 / P2：可复制seal重造“已编译”对象，编码还存在类型撞码

`CompiledPlan:95–105`接受复制自合法plan的`_seal`；`_check_plan:300–310`只核其当前自报digest。实际用合法plan的rule替换出integer词法`broken`、重算公开fingerprint并复制seal，新CompiledPlan对零binding成功返回空批，未经过真实compile预检。

此外`rule_profile.py:206–219`对整数1和字符串`0x1`均编码为字节`"0x1"`。类型变化可不改变完整性digest。对象签发与typed encoding需一起修复；仅比较新自报hash不足。

建议实际编译签发对象identity及原签发digest登记；拒绝复制标记/重算digest重造的对象，已签发对象自身被改也拒绝。类型化编码需对可进入完整性hash的每种结构保持无歧义。仍不把该本地签发登记称为真实producer授权。

### R5 / P2：相同抽象term的facts代表依赖matches顺序

`rule_firing.py:473–482`按抽象term key稳定排序后保留首个triple，同key没有确定代表选择。两个规则a/b给同一输出term，但原source不同，交换matches顺序后firings仍排序(a,b)，facts.source却分别取a/b，完整payload/digest不同。simple与显式xsd:string两个同抽象term表示也复现该问题。

建议facts采用不丢语义的规范term投影，完整原term/source留在各firing；或用已固定、与输入枚举无关的规则/head/source键确定代表。不得为稳定性删除任一firing依据。

完整实际原字节已保留：

| 案例 | payload | bytes | SHA256 |
|---|---|---:|---|
| source，a/b | facts-source-ab.payload | 3118 | 373c84c3d520eed5ea0a9872beec9dce8992ccd9c73698a80b446d9ddb1e3f4d |
| source，b/a | facts-source-ba.payload | 3118 | 917afa3f77a77137f11d0005fb76b0b8dcd089aefe62ce9fb9c7eb6b77890128 |
| simple/string，a/b | facts-simple-explicit-string-ab.payload | 2855 | 63da314edb2b9059d0cfc037de6fbf706692ad7891df500f5940b3ac6d6c238a |
| simple/string，b/a | facts-simple-explicit-string-ba.payload | 2892 | d1877e12fe8dc87cb984d21546d9de294d387c64758e7c523e9c9f11ae4de0df |

早期工作树inline反例的source案例使用了稍不同的catalog/match文本，曾输出3d03ece4…3549/9988af6b…d645；上述是本目录完整源/输入及真实收据对应的新冻结副本执行，不能把两组digest互称同一输入。

### R6 / P2：必需的1/2/3算子签名仍缺，NE→LT变异可漏过现有值取样

`test_quality_profile_comparator.py:32–53`用同值九域原子及全部numeric 1vs2，未完成已授权的1/2/3对阈值2签名。`comparison-matrix.json`也只提供one_vs_two。相等时ne与lt均false，1vs2时均true。

本审查从实际候选函数构造独立内存变异，仅把最后ne分派`c != 0`换成`c < 0`，不修改模块/文件；实际执行432个六型有序对×固定左1/右1或2×六op取样，所有结果不变；3vs2的ne才出现原True/变异False。此为测试取样缺口，不声称当前算子实现错误；没有宣称跑过完整变异后的pytest套件。

建议全6×6有序datatype、左1/2/3对阈值2×六op，独立固定真值签名；用实际执行的替换分派逐个杀死30个有向operator替换，保留原22例作用边界。

### N2 / P2关联：总输入护栏晚于catalog扫描/排序

`compile_rules:223–233`先遍历、验证和排序catalog，之后才account_input。实际以input_bytes=1、十个合法catalog类运行时，三个_sort_unique调用均观察到input_bytes=0，最终才RULE_INPUT_BUDGET，已消耗work428。仍有work上限，所以不称为无界内存/CPU；但违反先按总输入护栏限制逻辑出现次数再处理的要求。

建议在定义顶层长度/类型护栏后，把全体account_input置于catalog扫描/排序之前，alias按出现次数计。不得靠缓存/相同对象跳过收费。

## 未发现额外已证问题与未验边界

数值直接目标舍入、日历day+秒分数、UTF8/source逐出现计费、长前缀/排序比较收费、proof/basis/trace单位、输出流式预扣、批失败无partial以及lazy四API/__all__兼容均已全文审阅，暂未发现上述之外的已证反例；不是无限值域/所有恶意对象的穷尽证明。

未运行真实图matcher、RDFS/SHACL、Store/Job/IPC、包或目标平台/GUI/凭据；未读他线未批准实现。未重跑全check，不把独立机制返回冒称FR500–505、当前结果或发布通过。

## 首次环境失败与证据来源

最初直接用系统python3运行inline反例，在导入rule_profile.py第18行因Python3.9不支持dataclass(slots=True)失败；并未进入反例主体。原工具输出保留在官方聊天历史，该次exit字段未由当时orchestration打印，本报告不伪造原启动收据。

本目录另以冻结副本实际重放最小导入：`python39-import-replay.py`、完整stderr及receipt记录Python3.9.6、exit1；明确标为新重放，不混同原启动。随后所有实际反例用既有`uv run --frozen --no-sync python`执行，exit0。命令、所有原输入、完整输出与payload均在本目录可恢复；`evidence-manifest.json`列各文件bytes/hash，原报告/归档不改写为修后通过。
