"""Replay of initial environment import failure; frozen candidate1 source only."""
import sys, types
from pathlib import Path
p=types.ModuleType("ontolearn_engine")
p.__path__=[str(Path(__file__).resolve().parent / "snapshot/packages/engine/src/ontolearn_engine")]
sys.modules["ontolearn_engine"]=p
from ontolearn_engine.quality.rule_profile import Budget
