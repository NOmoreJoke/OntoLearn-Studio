# Candidate-3 定点独立复审

结论：**C2-R1与C2-R3关闭；C2-R2尚差空bytes hash最少1单位收费，当前candidate-3暂不通过。** 可解冻只补该收费与0/1回归，再定点复核；本轮未发现其他实质delta问题，不需要重跑未变648/30或数学oracle。

固定manifest3754B/SHA `a1b7d9a639c47142fa26ab69e63b856e9b4cbca738c60c4346d771e3d513c247`；ZIP36316B/SHA `5d133a08ad7392040a645beb2d22e133f2ec5da388a877096ebebc25065a9bc9`。20成员集合/bytes/hash与当前树逐一相等，ZIP testzip正常。完整读实质diff14274B/SHA `0e8eb4ce55429af734ef4fc99de21d4980ea71b322cee44c24582a8507685e84`，只审本轮三组修复与位置整数计费delta，未扩为新数学/全产品审查。

实际命令：`uv run --frozen --no-sync python docs/reviews/T05/profile-mechanism/internal-review-candidate-3/probes.py.raw`。真实subprocess.run exit **0**，stdout3086B/stderr0。probes.receipt.json保留实际argv/cwd/退出码与原输出长度，脚本及输出原字节均在本目录；七模块由本目录原件ZIP直接加载到隔离namespace，代码未修改。该exit0表示全部定点断言及剩余反例成功复现，不表示candidate通过。

| 项 | 独立核验与结论 |
| --- | --- |
| C2-R1 operator | exactstr在membership与分派前；仅append Probe不再触发eq/hash，INTERNAL_ERROR且location=None。关闭。 |
| C2-R1 walker元数据 | 改为模块中的真实允许class identity逐个比较，逐次扣work，不读取输入class的module/name；原__module__ Probe无hook，INVALID_RULE。关闭。 |
| C2-R1位置 | compare与parse_value/parse_number/parse_calendar/digits/utf8_size/iri_minimum共用无hook形状门；各原side/section Probe均无hook，拒绝后location=None。ProfileFailure构造过滤外来reason/classification/location形状。位置数字先位长/limb费用，再非负/跨度顺序检查。关闭本轮真实入口反例。 |
| C2-R3 tuple整数 | 先temporary_bits后两侧limb预扣；95/96bit在96cap内返回-1且work6，97bit在比较前RULE_INPUT_BUDGET/work0；work5失败。原32769bit反例先拒绝/work0。bool独立。关闭。 |
| 新位置index预算 | 在integer_bits96下，95/96bit index门成功/work3，97bit先资源拒绝/work0；未把大index序列化后再计费。符合本轮delta。 |
| C2-R2 hash主要路径 | 缺Budget/外来Budget均Internal；bytes4/cap3及work3均在实际sha256调用前失败（spy记录0）；4bytes/cap4/work4成功，work4，已编码semanticInput不重复扣。伪plan回归已传真实Budget。原免Budget大bytes路径已关闭。 |

唯一剩余：rule_profile.py fingerprint 的 `budget.debit(len(data))` 对空bytes扣0。实际 `fingerprint(b'', Budget(ProfileLimits(work=0)))` 仍进入sha256（spy [0]），返回 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`，work仍0。即使空输入也存在固定哈希工作；重复调用可免收费，不符合原计费约定。必要改为 `max(1,len(data))`，并证实work0在hash前WORK_LIMIT、work1调用一次hash/用1；保留bytes边界不变。不扩到其他恒等helper或通用Python进程防御。

只读了本线实际日志结尾：pytest-candidate-3.log1621B/SHA `a406d1d379b21003d32f42a393f5dd2c24a2626c22e3ccd6b5b0a837c7fa8256` 有1407 passed/2.13s；npm-check-candidate-3.log8100B/SHA `3b9a49c3ccd0213bc4513970ffd00c2b67d8816b65631ec9004905a328bf3d89` 有2607 Python passed/54.56s。日志内容支持这些passed摘要，本审未运行全check或取得原会话终态退出码，不将其写成本审exit0；原执行终态由父线实际回执封存。

仅写本专属证据目录，无产品/测试/配置/分支/GUI操作，不读其他候选实现，不重跑原矩阵。此前已关闭项沿原固定证据，不用本轮复用作为重跑声明。本私有阶段结论不替代指定同版双审、CI/远端、真实executor/Store/worker/公共协议接线及FR父验收。
