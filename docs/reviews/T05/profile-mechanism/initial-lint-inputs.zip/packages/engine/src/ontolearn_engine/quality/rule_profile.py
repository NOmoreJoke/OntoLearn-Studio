"""Private, bounded profile data and accounting; no execution/transport capability."""

from dataclasses import dataclass, fields
from hashlib import sha256

PROFILE = "OntoLearn-rule-comparison-profile/1"
BUDGET_VERSION = "mechanism-budget/1"
PINS = ("RDF-20140225", "SHACL-20170720", "SPARQL-20130321", "XSD-20120405")
XSD = "http://www.w3.org/2001/XMLSchema#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
NUMERIC = tuple(XSD + s for s in ("integer", "int", "nonNegativeInteger", "decimal", "float", "double"))
OPS = ("eq", "ne", "lt", "le", "gt", "ge")


@dataclass(frozen=True, slots=True)
class InputLocation:
    section: str | None = None
    index: int | None = None
    side: str | None = None
    span: tuple[int, int] | None = None


@dataclass(frozen=True, slots=True)
class SourceRecord:
    reference: str | None = None
    digest: str | None = None
    revision: str | None = None
    text: str | None = None


@dataclass(frozen=True, slots=True)
class TermInput:
    kind: str
    lexical_form: str
    datatype_iri: str | None = None
    language_raw: str | None = None
    source: SourceRecord | None = None


class ProfileFailure(Exception):
    """Safe local fields only. Traceback is never serialized by this module."""

    def __init__(self, reason, location=None, classification="input"):
        super().__init__(reason)
        self._safe = (reason, location, classification)

    @property
    def reason(self):
        return self._safe[0]

    @property
    def location(self):
        return self._safe[1]

    @property
    def classification(self):
        return self._safe[2]


def fail(reason="INVALID_RULE", location=None, classification="input"):
    raise ProfileFailure(reason, location, classification)


def internal(location=None):
    fail("INTERNAL_ERROR", location, "internal")


@dataclass(frozen=True, slots=True)
class ProfileLimits:
    input_bytes: int = 262144
    term_bytes: int = 16384
    source_bytes: int = 65536
    digits: int = 4096
    integer_bits: int = 16384
    temporary_bits: int = 32768
    rules: int = 100
    when: int = 16
    comparisons: int = 32
    heads: int = 16
    variables: int = 64
    bindings: int = 1024
    firings: int = 1024
    head_occurrences: int = 16384
    trace_items: int = 8192
    output_bytes: int = 262144
    work: int = 16777216

    def __post_init__(self):
        for f in fields(self):
            v = getattr(self, f.name)
            if type(v) is not int or not 0 <= v <= f.default:
                fail("RULE_INPUT_BUDGET", classification="resource")


class Budget:
    """Per-call debit-only counters. No public reset or limit replacement API.

    Trace units: each firing, binding pair, when/comparison/head occurrence,
    every proof-leaf occurrence and each retained basis reference = one unit.
    Aliases are traversed and charged per occurrence, never by object identity.
    """

    __slots__ = ("_limits", "_used", "_phase")

    def __init__(self, limits=None):
        if limits is not None and type(limits) is not ProfileLimits:
            fail("RULE_INPUT_BUDGET", classification="resource")
        self._limits = limits or ProfileLimits()
        self._used = dict.fromkeys(("work", "input_bytes", "output_bytes", "trace_items", "firings", "head_occurrences"), 0)
        self._phase = "new"

    @property
    def limits(self):
        return self._limits

    @property
    def usage(self):
        return tuple(self._used.items())

    def debit(self, amount=1, counter="work", location=None):
        if type(amount) is not int or amount < 0 or counter not in self._used:
            internal(location)
        value = self._used[counter] + amount
        if value > getattr(self.limits, counter):
            reason = {"work": "WORK_LIMIT", "input_bytes": "RULE_INPUT_BUDGET"}.get(counter, "RULE_EVIDENCE_RESULT_LIMIT")
            fail(reason, location, "resource")
        self._used[counter] = value

    def bound(self, value, name, location=None):
        if value > getattr(self.limits, name):
            fail("RULE_INPUT_BUDGET", location, "resource")

    def bits(self, value, temporary=False, location=None):
        self.bound(abs(value).bit_length(), "temporary_bits" if temporary else "integer_bits", location)

    def start(self, phase):
        expected = "new" if phase == "compile" else "compile"
        if self._phase != expected:
            internal()
        self._phase = phase


def utf8_size(text, budget, cap=None, location=None):
    if type(text) is not str:
        fail(location=location)
    # Precharge before scanning, including long common-prefix strings.
    budget.debit(len(text), location=location)
    n = 0
    for c in text:
        k = ord(c)
        if 0xD800 <= k <= 0xDFFF:
            fail(location=location)
        n += 1 if k < 128 else 2 if k < 2048 else 3 if k < 65536 else 4
        if cap is not None and n > cap:
            fail("RULE_INPUT_BUDGET", location, "resource")
    budget.debit(n, location=location)
    return n


def text_compare(a, b, budget):
    budget.debit(len(a) + len(b) + 1)
    return (a > b) - (a < b)


def tuple_compare(a, b, budget):
    for x, y in zip(a, b, strict=False):
        if type(x) is str and type(y) is str:
            c = text_compare(x, y, budget)
        elif type(x) is tuple and type(y) is tuple:
            c = tuple_compare(x, y, budget)
        else:
            budget.debit()
            c = (x > y) - (x < y)
        if c:
            return c
    return (len(a) > len(b)) - (len(a) < len(b))


def _walk(value, budget, output, sink, depth=0):
    """Streaming canonical private encoding, precharged before every append.

    Integers use hex strings (no process-global decimal conversion policy).
    Fixed class names and field names are encoded as well as their values.
    No json.dumps, arbitrary repr/iterators, callbacks or alias exemption.
    """
    if depth > 32:
        fail("RULE_INPUT_BUDGET", classification="resource")

    def emit(data):
        budget.debit(len(data))
        budget.debit(len(data), "output_bytes" if output else "input_bytes")
        if sink is not None:
            sink.extend(data)

    t = type(value)
    if t is str:
        utf8_size(value, budget)
        emit(b'"')
        for c in value:
            k = ord(c)
            data = ("\\u%04x" % k).encode() if k < 32 or c in '\\"' else c.encode("utf-8")
            emit(data)
        emit(b'"')
    elif value is None or t is bool:
        emit(b"null" if value is None else b"true" if value else b"false")
    elif t is int:
        budget.bits(value)
        budget.debit(max(1, abs(value).bit_length() // 4 + 2))
        emit(('"' + hex(value) + '"').encode())
    elif t in (tuple, list):
        budget.debit(len(value))
        emit(b"[")
        for item in value:
            _walk(item, budget, output, sink, depth + 1)
            emit(b",")
        emit(b"]")
    elif t.__module__ in tuple(__package__ + "." + n for n in ("rule_profile", "rule_firing", "rule_numbers", "rule_calendar", "rule_terms")) and hasattr(t, "__dataclass_fields__"):
        emit(b"[")
        _walk(t.__name__, budget, output, sink, depth + 1)
        for f in fields(value):
            _walk(f.name, budget, output, sink, depth + 1)
            _walk(getattr(value, f.name), budget, output, sink, depth + 1)
        emit(b"]")
    else:
        fail()


def account_input(value, budget):
    _walk(value, budget, False, None)


def encode_input(value, budget):
    sink = bytearray()
    _walk(value, budget, False, sink)
    return bytes(sink)


def encode_output(value, budget):
    sink = bytearray()
    _walk(value, budget, True, sink)
    return bytes(sink)


def fingerprint(data):
    return sha256(data).hexdigest()
