"""Complete operator/domain classifications plus independent true/false signatures."""

import pytest
from ontolearn_engine.quality.rule_comparator import compare_values
from ontolearn_engine.quality.rule_profile import OPS, Budget, ProfileFailure, TermInput
from ontolearn_engine.quality.rule_terms import parse_value
from test_quality_profile_terms import fixture, value

MATRIX = fixture("comparison-matrix.json")
ATOMS = [
    ("integer", "1", None),
    ("string", "1", None),
    ("langString", "1", "en"),
    ("iri", "urn:1", None),
    ("boolean", "false", None),
    ("date", "2000-01-01Z", None),
    ("date", "2000-01-01", None),
    ("dateTime", "2000-01-01T00:00:00Z", None),
    ("dateTime", "2000-01-01T00:00:00", None),
]


def atom(i):
    kind, text, lang = ATOMS[i]
    return (
        parse_value(TermInput("iri", text), None, Budget())
        if kind == "iri"
        else value(kind, text, lang)
    )


@pytest.mark.parametrize("i,j,k", [(i, j, k) for i in range(9) for j in range(9) for k in range(6)])
def test_complete_nine_domain_six_operator_table(i, j, k):
    left, right = atom(i), atom(j)
    if MATRIX["cells"][i][j][k] == "E3":
        with pytest.raises(ProfileFailure, match="RULE_COMPARISON_TYPE_MISMATCH"):
            compare_values(left, OPS[k], right, Budget())
    else:
        assert (
            compare_values(left, OPS[k], right, Budget())
            == [True, False, False, True, False, True][k]
        )


@pytest.mark.parametrize(
    "left,right,k",
    [(a, b, k) for a in MATRIX["numeric_types"] for b in MATRIX["numeric_types"] for k in range(6)],
)
def test_all_216_mixed_numeric_true_false_cells(left, right, k):
    assert (
        compare_values(value(left, "1"), OPS[k], value(right, "2"), Budget())
        == MATRIX["one_vs_two"][k]
    )


@pytest.mark.parametrize("op", OPS)
def test_different_language_ne_does_not_turn_true(op):
    with pytest.raises(ProfileFailure, match="RULE_COMPARISON_TYPE_MISMATCH"):
        compare_values(
            value("langString", "x", "en"), op, value("langString", "x", "en-US"), Budget()
        )


def test_unicode_scalar_order_no_normalization():
    b = Budget()
    assert compare_values(value("string", "\U00010000"), "gt", value("string", "\ue000"), b)
    assert not compare_values(value("string", "e\u0301"), "eq", value("string", "\u00e9"), b)
    assert compare_values(value("string", ""), "lt", value("string", "a"), b)
