# 既有探针执行范围更正（只追加，不改旧原件）

candidate-2 report.md（SHA cedff0138daca5ef91d48d89ff6f92ae42c1e2390380664a6ff4ab1967882965）及candidate-3 report.md（SHA 66233b9055ce4b317c3b7a6550d496a6ed504c2c5e51abb472f12784400f90dd）曾写“七模块由ZIP执行/加载”，数量不准确。

对应 probes.py.raw 实际从原件ZIP执行 **六个 rule_* 模块**：rule_profile、rule_numbers、rule_calendar、rule_terms、rule_comparator、rule_firing；另外创建两个合成namespace ontolearn_engine 与 ontolearn_engine.quality，**未执行ZIP的 __init__.py**。七代码文件均做原bytes/hash核验，不等于七代码文件均执行。旧报告/脚本/输出/receipt原字节保持，更正不影响六模块中已复现反例、输入哈希或退出码。

__init__兼容性沿原静态审查和原树 fresh subprocess 专项单独证明，不能由上述隔离探针证明。父线此前实际完成的专项/normalcheck属于原树测试运行，与这些ZIP探针执行范围应分开记录。

candidate-4本次只执行冻结ZIP的rule_profile.py一个模块，放在单个合成ModuleType名称t05_candidate4_rule_profile下；未执行其余五rule模块或init，未重跑旧矩阵/数学/旧探针。20输入仍全部实际核哈希。本说明是实际执行范围纠正，不将未运行内容补写成历史通过。
