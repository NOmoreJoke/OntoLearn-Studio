# Candidate-4 最终独立实现审查

结论：**本已授权私有纯profile/给定binding机制阶段的独立实现审查通过。** candidate1–3实质意见在固定candidate4累计内容上均已关闭，本次精确空hash delta无剩余问题。通过只指当前20输入的代码/测试/fixture审查，不代表FR500–505、真实executor/producer/Store/worker/公共协议、目标平台、指定同候选双模型外审、CI/PR/合并或远端已经通过。

## 固定候选与定点运行

manifest3754B/SHA `ef5bb61f32248c05ccfe3364e0a56e2bbe34cd09d92b841a4faafcb8685fa967`；ZIP36379B/SHA `4df1cb3ea85d096ae007497d0639173f9ef5f78b273475df6c47ea9953181894`。candidate3-to4 diff1517B/SHA `c7ebbbd1f0e183847fc69540c8bb195e76aeb15f077a937c4cf3492b472bbd13`，实际恰两文件：fingerprint改max(1,len(data))，limits新增空hash work0/1及同Budget耗尽回归。未重新审未变数学规范或运行旧648/30/旧probe。

实际命令：`uv run --frozen --no-sync python docs/reviews/T05/profile-mechanism/internal-review-candidate-4/probes.py.raw`；真实subprocess exit **0**，stdout652B/stderr0B，原脚本/输出/receipt保留。本次只从ZIP执行rule_profile.py一个原模块；合成ModuleType用于隔离导入，__init__.py未执行。

hash spy实际证明：空bytes/work0在hash调用前WORK_LIMIT，调用列表[]；work1成功返回标准空SHA256，work用1，调用[0]；同Budget再次调用在hash前WORK_LIMIT，调用列表仍[0]。源字节cap和非空按长度收费未改变。C2-R2剩余空hash免计费关闭。

## 累计关闭依据

- 双静态常量在零binding前经同comparator预检；合法false不是错误。给定binding仍完整核所有comparison/全head，整批输出前不发布partial。
- parser值与CompiledPlan由实际object identity+原digest登记，复制seal/重算摘要不当作签发；typed编码区分int/string、tuple/list、dataclass。此为损坏/误用防护，不冒充producer授权。
- 直接operator及原位置外来字段先exact-type门，walker识别实际允许class identity、不反射输入type元数据；原仅append Probe反例无回调，拒绝时不保留外来位置。
- catalog不能重新分类schema禁区；普通受控rdf:type输出仍允许。facts按稳定firings/head选raw代表，所有原term/source仍在各firing，反序完整payload不变。
- 648混型三点签名、30实际替换与完整fixture输入/expected逐字段测试缺口已在candidate2关闭，本轮沿固定证据，不称重新执行。
- catalog总输入门早于IRI扫描/排序；数字/日期/lang预扫描、issuer检查、哈希、tuple整数位长/limb及位置数字均收费；22 trace单位未改，空hash最低1补齐。预算仍防护上限，不称容量/性能。

累计依据为candidate1完整审查、candidate2完整实质delta、candidate3三组定点、candidate4精确两文件补丁；每轮原ZIP/report/receipt分别保留。candidate2/3“七模块执行”的数量误述已在 prior-execution-scope-correction.md追加纠正（实际六rule模块+两合成namespace，init未执行），不改原report。原树fresh subprocess导出兼容测试与ZIP探针区分。

## 全20输入实测哈希闭环

开始与最终都将当前树bytes/hash逐项对manifest及ZIP原成员核相等；ZIP成员集合恰为20、testzip无坏成员；source-validation.json保留全部实际观测值，非仅引用期望manifest。下表是最终实际值：

| 路径 | bytes | SHA-256 |
| --- | ---: | --- |
| `packages/engine/src/ontolearn_engine/quality/rule_calendar.py` | 4047 | `6a2e43b029f7069e398f696ff19948d9e806f06fecd9a1e239b889a55e528aec` |
| `packages/engine/src/ontolearn_engine/quality/rule_comparator.py` | 1750 | `9a495876a182d1cad4cac86bb4651c1627e4afc37e1bf9bb3d62be6bb0e95ff2` |
| `packages/engine/src/ontolearn_engine/quality/rule_firing.py` | 19149 | `5116aa3e96ae10e7f37eb7afddceef50879869d38af116f9c794437edf49243c` |
| `packages/engine/src/ontolearn_engine/quality/rule_numbers.py` | 7372 | `6b080a55bd8f4af1a1120b55448e02a1a442c231a32ab575ce6e82de054164f9` |
| `packages/engine/src/ontolearn_engine/quality/rule_profile.py` | 11987 | `b40b73f65f474cda32ac42caeeb837ad6470a7daeeba9013d8f69e7f0c5a261c` |
| `packages/engine/src/ontolearn_engine/quality/rule_terms.py` | 5909 | `8f58a68b896a62443ab3681c29802905d5ff1e010a944d32eb07f988319cc19a` |
| `packages/engine/src/ontolearn_engine/quality/__init__.py` | 548 | `9a5130c2fdbe376e5e4c15e68085f01724847ff13e9b2c195cf270e476806d9c` |
| `packages/engine/tests/test_quality_profile_calendar.py` | 2161 | `f6e92592186e309a251cbbab592b851f866c943de8904b9a1b0fa281f6185e1c` |
| `packages/engine/tests/test_quality_profile_comparator.py` | 3104 | `db51f846890b30431e77ac632ec4f23c9ec92b43fb1d54e309a8b1a52df9ea08` |
| `packages/engine/tests/test_quality_profile_firing.py` | 13589 | `faebe038b897ee4e375a9db0c1eff909e45d19b9aad1fab39c1869357dab363f` |
| `packages/engine/tests/test_quality_profile_imports.py` | 2078 | `05b28ee714c19397a349fc4d38aba5bde0986c235dd1ed7d26ae9d73072d981c` |
| `packages/engine/tests/test_quality_profile_limits.py` | 12576 | `94daa65e1ca762b78c95fd6f3d32ff921ae5e9ffc0be77d2983bcba70272c650` |
| `packages/engine/tests/test_quality_profile_numbers.py` | 2370 | `40c15c6003b38affb79b499b104ea866bec6f51cfd4f2127aeb5e9516aed992e` |
| `packages/engine/tests/test_quality_profile_terms.py` | 6394 | `c487c46312c03b2a5d9e7d3d8de0c29b23ecf07a3883e7fdc1c5b63c9370cf76` |
| `tests/fixtures/quality/profile-v1/calendar-oracles.json` | 1004 | `616fd0c5d4bc052f5abfc14b02bba095f849bd672b2beda63933e79186ab2016` |
| `tests/fixtures/quality/profile-v1/comparison-matrix.json` | 5512 | `9bbbb0c8351999bb1cf7152fa2ecacc1b24b36f6f23772c395ba90b27978fb72` |
| `tests/fixtures/quality/profile-v1/firing-cases.json` | 9298 | `c001a6462b7f3ae54563b99c699bf6281c09020f2695f62f7bd2a92a715e6599` |
| `tests/fixtures/quality/profile-v1/lexical.json` | 3294 | `2d893831f1c4ecbee88e93f75a03c302e92cef1999eadfad68ca1d4abcf5bf79` |
| `tests/fixtures/quality/profile-v1/manifest.json` | 1057 | `1bfb51fabf7c8eb60bc63c469a56315f4a2b4bad17a959472de6fb2a2e78323b` |
| `tests/fixtures/quality/profile-v1/numeric-oracles.json` | 9898 | `554882960460ba2416e0d4dcc5cbf72d43525e3838decee8bc72215e3dae26c3` |

## 检查终态与未验边界

本审自己的定点进程exit0已在probes.receipt.json记录。父线已回执candidate3原会话session76797真实exit0：1407专项/635TS/2607Python，仅绑定candidate3，**不作candidate4终态**。

本轮读取candidate4专项日志1621B/SHA `d4722eacf578ce831e4b3000c0b1096a5ca59e24dde5021d18a0e293bb251285`，内容1408 passed/2.12s；本报告封存时完整normalcheck原会话session7748尚待父线正式终态回执，未据运行中90%输出登记通过或使用candidate3终态替代。最终check日志/退出码须父线原件另行绑定candidate4，属于独立测试门，不改变本代码审查结论。

只写本专属证据目录，无产品/测试/配置/分支修改；无GUI/外发/凭据/未批实现消费。未扩大为标准全符合性或真实业务集成验收；先前明确的IRI真实入口precondition、真正图匹配/来源认证/完整执行/平台与父FR门保持。
