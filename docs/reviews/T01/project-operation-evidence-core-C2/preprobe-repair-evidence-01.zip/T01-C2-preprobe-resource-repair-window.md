# T01 C2：正文探针前资源门修复

2026-10-22。历史256/5b内部收件原件保留；现暂停该候选作为后续可采用C2供方，精确重新打开资源前门，不否定已读事实关系/正常用例或伪称本轮已运行恶意库。根已实际读固定operation_evidence.py210–325/360–420：_cost283–284的metadata SQL同时做length(col)、length(CAST(col AS BLOB))和instr(col,char(0))，_raw仅固定小额度，实际按u/n的probe预扣在SQL返回后。大TEXT扫描/转换可能先于对应票，事后resource-limit/rollback不能补付。这是已确认的静态发生顺序遗漏，原收件的“metadata先界再正文”结论须作此修正。

S1独立源码审另查SQLite3.50.4 OP_Column读取目标列之前可能按完整物理record header复制至98307B；目标TEXT u与逻辑schema<=32不单独给出该header的界。此项尚由独立报告精确论证适用路径，不能拿小正文/坏行最终被拒当作分配前门。需分别记录SQLite内部固定控制开销与逻辑typed证据费，不将容量/源码推断冒运行证明。

继续原T01、原C2树；仅原两个新writer operation_evidence.py及test_project_operation_evidence.py可修。原52、profile1/canonical/Store/Job/schema/依赖/资源/其它树保持只读，MAX_QUERY_COUNT/READ_WORK/PROBE_WORK和用户/工程限额不提高，不采用S1未批准jsonb算法。不添加UDF/任意SQL入口，不改变同连接事务/未知caller事务不动/真实cleanup故障规则。

先取得真正不扫描正文的类型/字节长度或其它经实际SQLite计划/源码证实的有界前门，再对实际转换/length/NUL/费用SQL预扣，物理header/statement控制等另有足够先验票；不能仅换函数名字或在返回后补账。只读实际源码、有限真实临时库/原writer专项与必要反例可沿本窗口执行，独立验证bytes-before-body的真实计划，不跑原生/GUI/模型。若新SQLite特性/版本前提不可避免，列具体sourceID/不支持有限处理及平台待验，不改锁或偷偷放宽原支持面。

保原256/5b/129专项/430工具归档和全部费用原账。新测试覆盖超大TEXT在低预算前未扫描/未物化、schema/record异常、三编码真实非空正例、重复工作、预算±1与取消清理，正向材料不能全拒取绿。若任何保守固定费将正常材料普遍拒绝，应报告具体预算和替代策略，不用提高cap掩盖。

原作者分配唯一实施者后独立审查实际最小delta；不得由本次实施者自签。新完整54产品/test、固定候选、正常check/sources必要验证及原始双流/首失败、独立结论后回交根复核。未闭合前不组合56、不授profile2或formal resolved；T05当前149数学输入未含C2，不需因此重测。父门/指定双新审/CI/远端develop/pushPRmerge/Goal保持。
