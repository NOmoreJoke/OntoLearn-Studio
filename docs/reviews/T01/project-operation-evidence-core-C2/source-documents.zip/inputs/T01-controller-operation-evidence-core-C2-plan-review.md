# T01 C2 原操作证据核心：控制侧固定方案审查

结论：固定 docs-only `0a03539a44c43fafb2f890953bbb59a77ea33a05` 的 C2 方案在本次静态审查范围内可进入根的精确实施审批，未发现新的阻断设计问题。两项 P2、一项 P3 及预算/清理意见已在最终42685B方案具体处置；不将方案审查写成产品、真实数据库、预算运行或正式 resolution 通过。两个新 writer 与全部新 guard 都仍需根明确授权。本审没有修改 owner 文件、产品、测试、shared state/Goal 或旧控制报告，仅写本文件。

本轮仅文件/Git/stdlib AST、JSON、ZIP、hash和静态算式，没有 import/执行产品、SQLite/DB/SQL探针、测试、构建、子进程fixture、GUI/native/Keychain、网络或模型。没有新建C2树/branch、stage/commit或替根授权；另在当前C1树存在的dispatch/permanent-drain未跟踪文档不属于本候选，未采用其内容当C2接口。

## 1. 固定候选与范围

当前树 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-project-create-core`，实际HEAD为0a03539，parent为 `a33cc80e82475e54d74b4e48c1fd32f32979983a`；a33为独立C1控制收口过程提交，不并入423b原59件。C2本次delta精确9项新docs：主plan、fixed-foundation、两独审、review-dispositions、checks、original-evidence ZIP/index、source-manifest。没有产品/测试改动。

根准备授权4190B / SHA256 `3a2fb6b04154bdc29fcda1d92c74cfe7c5e8438950ae55c7b49dd573d05d9195`已全文读并与ZIP原件核同；AGENTS当前15852B / `78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759`与此前全文已读及原包相同；common17891B/e437原件身份沿用。固定39602B合同ff725第3/6/7/8/9节和C1源码切点是本次依据，不改变旧合同。主plan/两独审全文及处置/checks已读；初次主plan输出中段截断后精确补读§5–6，未把截断当全文。

| C2 固定文件 | bytes | SHA256 |
| --- | ---: | --- |
| docs/iterations/T01/project-operation-evidence-core-C2-plan.md | 42685 | e7db89cb52cc75707d0e7a00e637e97701bea7e7d49f623ef464cb1baf44b96b |
| fixed-foundation-inputs.json | 14521 | aef7b7c2d61cadb0eb8de73b5697f7ce78d384d217ff301bacd9038ff291f9cd |
| independent-plan-review.md | 15910 | 3af0cf66dafce54cfcc2fa9174ec428385e26667d0c2552b3938fcc31f99a605 |
| budget-investigation.md | 35416 | 7e672b9134e77ef9df73fc9706486e94976d7bc8d27f39dde14853282df017a1 |
| review-dispositions.md | 4221 | 9125ffa5fa24c2d41bc61477055ad5eead8541f3da3e17447e3dbe662489ab77 |
| checks.json | 1369 | 85661543f744a737efda278cbac62e459c478dc9f9d60fe04aa3220c3472ba72 |
| original-evidence.zip | 474208 | a91c1b58e70f3b5200e21da76a127b6b39152b30ff97dba03420ac21483e9ebf |
| original-evidence-index.json | 105684 | 1f993e77d4769c4a9bd1535aa9d19f15fbe383514c81016bbd45d19839c9cd2f |
| source-manifest.json | 2222 | 7185fcf2dba06c80d05a46e94059cddb0c28477c4ff622cdbeccd064eb5b110e |

除首项外表内路径相对 `docs/reviews/T01/project-operation-evidence-core-C2-plan/`。8项manifest输入逐current/Git/bytes/SHA核同，manifest自身用固定Git和完整source ZIP绑定。`/tmp/t01-operation-evidence-core-C2-plan-source.zip` 550132B / `d1f8b3eaa2f918e7eb3b6bfc4e089ecbcbe248885521091ee927180dbc85ef62`，成员set精确这9项，逐项内容等于固定Git及current。保护AGENTS未stage；未跟踪dispatch文档保持独立，不算C2 dirty产品。

拟foundation52条均已从完整清单解析并逐项核 `423b7e4c799f188cf2ce6e8e7121893ce85624cd` Git=current=0a03539 Git=原bytes/SHA，全部role readonly，32个Python文件仅AST parse。C1原59件也逐项核current=423b Git=当前Git未变；没有重跑C1。拟 `.worktrees/T01-operation-evidence-core` 实际不存在，两个新writer尚未建立；当前没有“已实施C2”事实。

## 2. 最小精确施工范围与可复用闭包

可以独立于未交付 physical binding 先做内部证据核验机制，但它只说明当前已打开库内真实持久记录，不能关闭原意图unknown。根若批准，精确范围为：从5f910b52新树/branch `feature/weekly-t01-operation-evidence-core`，按14521B清单逐52项只读接收423b字节、独立adoption；只新增：

- `packages/engine/src/ontolearn_engine/project/operation_evidence.py`。
- `packages/engine/tests/test_project_operation_evidence.py`。

实施专属docs目录须另由根冻结。相对5f完整产品/测试54项，不仅是两个新文件；52项含C1全部writer、旧测试、reader、canonical、main、worker、coordinator、I05 runtime都不转移维护权。不改DDL/table/kind/default3、协议注册、公开Host/main/preload/UI或依赖/锁，不复制旧validator或造stub。若真实gate无法闭合，先给具体调用栈/SQL模板/原文件最小diff申请，不自动扩大到project目录。

方案EvidenceView不继承/构造Store，不更换real._db、不透传真实boundmethod；只把原unbound读实现绑定view，所有SQL继续同一真实conn的MeteredGate。已定点核实际 `_accepted_job/get_job/_job_prepared_plan/blob/_project`、Store `_project_snapshot/load_snapshot/revision/vector/state/_state/mapping_status/_has_retirements/_read/marker` 和format3完整history、C1creation_context、application claim/confirmation/plan、ChangeSet accepted_plan/_verify_plan/_receipt。Plan中的原staticmethod/classmethod绑定要保持描述符语义：_snapshot_state沿原Store类、内部cls._definition/_fact仍是原纯校验；不能给缺方法返回true/空集合。未知SQL fail closed、不回落真实conn，既有validator参数均传view。

受理Job先沿唯一claim发现真实jobId，再核完整context/fingerprint、原request/issuedImplementation/Limits、原snapshot/参数、runConfig events/consumption、prepared/confirmation；不是JOIN或DTO摘要核验。`_accepted_job`自身没有证明terminal result/marker完整互证，新核心必须按方案补真实材料关系。ChangeSet用原accepted_plan(host=None)做历史核验，避免传原host触发当前base仍相同的误拒；原host/session另由实际envelope+job_details原确认回执交叉对selector，普通actor不补session。

创建复用C1三immutable行及原receipt，再核完整mixed history到当前head；后续metadata/domain/draft.restore、原application claim/prepared/confirmation、当前state/vector/application_state仍在必要闭包。不只两个CP，不从当前base重新推原plan，不调用全库format3.validate/_validate_job3却只给目标闭包收费。初始完整Job-ready仍是可信owner前置；本次保持schema/catalog/全库raw guard加目标完整语义，不追认既有启动分配风险已解决。

目前静态闭包未见必须修改52项只读源码的切点；这不是已实现gate闭合。后续必须真实覆盖原helper全部传递SQL、staticmethod/classmethod、sqlite.Row索引/keys/dict、cursor fetch/iteration及未知模板拒绝，不能用模板覆盖率摘要掩盖绕门SQL。

## 3. 真实只读事务、失败穿透与清理

入口先拒未知caller活动事务且不回滚它；本次自己BEGIN，同conn完成schema/预算/probe/validator/有限结果后ROLLBACK。没有SAVEPOINT/第二连接/临时表，也不调用snapshot/public_project/project_get/reconcile/create/commit或worker。成功不发布写COMMIT，取消/失败也finally释放本次事务与临时seen/cache，不关闭owner Store/lease，不覆盖未知authorizer/progress callback。

P2-C2-01方案层面关闭有实际依据：固定format3.receipt_for/load_checkpoint会把sqlite3.DatabaseError（含OperationalError busy/I/O）吞为Format3Fault结构错误；若在外层才分类已经太迟。新门在execute、fetchone/fetchmany/fetchall、iterator-next最早边界，把真实SQLite错误按主码转换为独立EvidenceControl(Exception)，不继承sqlite3.Error、ValueError/KeyError/TypeError/OverflowError等旧捕获族；资源和未知模板也同样穿透。入口释放后再映射有限storage-busy/storage-failure/resource-limit/unsupported-profile，不能把存储或预算失败变成正常incomplete。定点查所复用源码的except列表，没有发现另外会吞该独立控制异常的广义捕获。

MAX_QUERY_COUNT65536内开头保留BEGIN/最终ROLLBACK各1槽，业务最多65534；最后ROLLBACK走固定独立控制路径，不被耗尽业务/证据/probe/read-work或未知模板guard挡住。它是明确两控制槽，不是无限旁路。BEGIN未成功且无本次事务不伪rollback；实际cleanup失败保首因、向owner报告有限清理失败状态，不能声称已释放。未来必须在额度耗尽/±1、execute/fetch/iteration错误及取消时实核in_transaction=False与全dump不变，不能以本方案关闭代替真实故障实验。

## 4. 计价、先界与重复工作

每个唯一实际行按“固定全列名→原SQL typed值”的canonical UTF8对象计一次；TEXT中的context/payload/dto保原SQL字符串，NULL=4B、整数按原十进制，列名/冒号/逗号/括号均收费。字段JSON内嵌与独立snapshot/blob是两处实际材料；同一(table,rowid)当前事务重复引用只扣一次，不能按内容hash合并不同PK/表。完整PK本身可能大，因此先有限rowid/count定位，完整费用通过再给正文。JOIN的commits和commit_evidence分开实际行收费；完整批量查询先count/有限locator/全命中费用，不能先fetchall巨PK/正文或用LIMIT截断history。

四阶段已冻结：A廉价metadata（rowid/type/字符数/实际存储bytes/NUL/有限行数）；B先预扣probe工作；C再跑精确canonical费用SQL并扣证据额度；D最后原完整正文SELECT、实际typed行canonical核同并扩引用。不能把metadata和完整replace/scanner混同SELECT，亦不能先接整TEXT的Python UDF计价。元数据查询/所有schema正文不免费，原raw guard的数据库编码BLOB口径与新UTF8证据口径分开。

UTF8式 `2+u+N(34)+N(92)+短转义N+5*其他控制N` 与当前ensure_ascii=False canonical一致；先拒NUL/非法scalar，不依赖JSON1。UTF16LE/BE按unicode(substr)逐scalar计UTF8/转义，不能把UTF16 CAST字节当UTF8；portable可能平方扫描，必须在scanner前按n预扣。完整行系数与标点公式正确；NULL/BLOB/REAL/异常编码的有限拒绝与读后核同仍需真实专项，而非本文已测。

新政策是三个独立工程guard：MAX_PROBE_WORK536870912，UTF8首次TEXT `256+160*(u+1)`、portable `256+16*(n+1)^2`，NULL/INTEGER每字段64单位、每行128；MAX_QUERY_COUNT65536；MAX_READ_WORK536870912每SQL128+每次将物化的完整实际行canonical费用，重复投影照扣，metadata按固定列数和已界命中行数提前预留。seen免唯一证据费不免重复SQL/物化工作；mapping_status→vector及多个CP重复load_snapshot必须按实际调用扣work。系数是拒绝政策，不是CPU/opcode/RSS证明，没有假定未到callback提供时间保障。

selector/key/value的scalar先按字符计canonicalUTF8界，再真正分块escape；深度32、节点≤maxSelectorBytes、有界keys后排序；不会因使用iterencode就自动满足先界。原件中的200000个U+0001首chunk1200002B静态反例支持这一禁例，不能先分配后检查。输入显式maxEvidenceBytes≤67108864、selector≤262144、return≤131072，均正safe integer无bool/无限默认；真实frame/page/envelope更小值由未来真实caller提供，不用fixture数值假装供方已到。

## 5. 平方guard是否使常见Job必然全拒绝

未发现这种先验全拒绝反例。本审只做stdlib AST常量提取与算式，没有执行产品或SQLite：35张基础/应用/Job表的DDL SQL正文按portable收费合20,947,104；连38条依原源码格式重构的immutable trigger SQL正文共31,167,488，低于536,870,912。该小计不含其他catalog/metadata/业务行，不冒充完整C2总费用或真实schema运行。

另按固定writer实际字典和既有test_job_store的IMPL/LIMITS、dependencies.json空definitions政策，用规范36字节UUID、revision0空snapshot、原完整context/DTO构造纯静态材料：普通queued test.read的context1130/DTO1862字符，所列主要业务TEXT的UTF8 probe544224、portable76,557,456；queued test.rounds的context1729/DTO1891，主要TEXT UTF8 probe651936、portable105,744,592。与上述schema SQL相加仍有明显余量，不能据B²式声称所有非空库/普通受理Job都先被拒绝。这些是源形状算式，不是contract/runtime/SQL执行或完整逐模板成本验收，也没有冒称其包含全部重复读取/metadata费用。

政策边界必须准确：单个TEXT不含其他开销时portable最大n5791、UTF8最大u3355440；累计更紧。合法但更大的UTF16 Job/ChangeSet材料可能resource-limit，即使maxEvidenceBytes尚有余量，这是新增明确工程拒绝界，不是兼容所有合法大小的承诺。不能仅凭“64MiB证据上界”宣称普遍可读，也不能把资源拒绝写成缺证。

建议根精确审批时把正向验收写清：UTF8、真实UTF16LE、UTF16BE同schema库里，至少完整普通已受理Job和合法runNULL/零轮rounds经过真正入口成功，保完整实际probe/query/read-work流水；再测超限±1。不能只测UTF16费用函数和超限拒绝来冒充可用核心。若正常代表fixture实际被完整schema/传递查询费用拒绝，应回到具体政策/SQL分解修订，不放宽原validator或删证据。现有静态余量足以支持先精确实施并实证，不要求为未发生的普遍拒绝先扩大写范围。

## 6. 状态、原来源与完整结果关系

P2-C2-02在最终稿真正关闭到双向结构闭包：run=NULL+progressNone的queued/尚未start_run的running/cancelling/failed/cancelled合法，不补run；已有run零轮running/cancelling可无terminal，failed/cancelled有对应terminal且progress可None；成功必须有真实run、连续完整轮次/terminal/末snapshot/consumption。无论jobs.run是否NULL，先按rounds.job=本Job读取全部关联轮，要求run精确等于jobs.run，NULL时集合空；非NULL再按所指run读全部轮反核job归属。仅沿run正查会漏runNULL孤儿/同Job跨run，新增第128行和矩阵补足；不扩大到扫所有无关联run_terminal JSON猜归因。

P3-C2-03也在实际writer关系上落实：results.dependencies对原Job的选定dependencyVector，job_results.manifests对原context、projection对definitionId/scope/parametersHash、kind对_publish_job实际capability映射、cache_key对Store.publish原project/kind/snapshot/dependencies/implementation公式；payload存在时同版row及rowId/ordinal各自唯一、原排序、receipt/summary/audit互证。atomic的marker+commit_evidence+immutable app receipt/完整history不能被DTO替代；round snapshot不能误用正式_project_snapshot；history.replayable=false不能作坏证据的通过证明。

cache payload=NULL可合法回收，receipt亦如此；不以PAYLOAD_EVICTED否定真实受理/终态，也不回填或重建正文；缺真正immutable证据仍incomplete。普通旧Job未持久host/session，完整Job事实可读但originEvidence=not-recorded，未来正式unknown不夹DTO；普通prepared actor不是host/session。ChangeSet数据库内recorded来源也不是物理库/dispatch/current permission。复制A→B后只能说明B现存记录；相同UUID/hash/libraryEvidenceRef不能关闭A原意图unknown。

## 7. 原件、历史修订和剩余门

原ZIP13成员set/唯一名及每个bytes/SHA核同；三份tool-records逐原rollout captured-prefix SHA、byte offset/长度、原行号/行SHA和call_id/outputs配对核验，成员恰原字节拼接：primary41pair/83records、core独审56/112、budget独审42/84，共139pair/279records，1条standalone异步输出另标。原件含并行dispatch相关记录，归档计数不是139次C2独立验收；不能把它们采用为C2源码/接口。ZIP捕获之后的归档验证/提交/source包不被倒称已在ZIP，最终绑定由本次Git/source逐项核验完成。

format01/02两份日志各66B，全文显示Checking formatting/All matched files use Prettier code style；原实际c14d42、423cc7 exit0与各独立格式exec_command对应，非产品检查。主草稿dcebb→ff93→1724→最终e7db时态及两独审追加补审保留；15910B独审开头41960历史结论须连最后e7db追加读，不把中间审查误当终稿。f52949/b4d2f2及db96f4原工具与最终第128行一致，两P2/P3仅方案层面关闭。原patch行匹配失败原子拒写亦保留；本审不重跑格式或C1产品凑通过。

根可据固定候选授权上面两新writer、52全只读采用、同conn全传递gate、四阶段typed费用、三个独立guard、有限事实union及保留清理规则；应同时保完整正向/损坏/预算/零写和清理真实验收。本文只提出可精确批准的范围和条件，不代根授写权。

正式resolved仍需I06原dispatch物理库重新证明能力、当前库/项目read与catalog+creation-receipt-read窄cap、可信原request/issuedImplementation/Limits/host-session关联、真实frame/page/envelope及canonical公开适配。缺物理绑定必须physical-binding-unavailable，权限失败先于内容可见；unknown/null不等于notAccepted、不自动重派。没有新context版本或真人来源producer就不能改旧Job hash来补归因。原启动/ChangePreview分配风险、真实Host/首IO/native/双OS真人、GLM-5.3最高和MiniMax M3.1-Flash xhigh指定双审、CI/PR/正常develop合并、父FR/57P0和完整Goal均未由本审放行。
