# T01 C2：原操作证据核心的精确实施窗口

2026-10-21。本件批准原T01功能聊天继续内部C2机制实现。根已全文读固定纯docs 0a03539a44c43fafb2f890953bbb59a77ea33a05 的42685B主方案 SHA e7db89cb52cc75707d0e7a00e637e97701bea7e7d49f623ef464cb1baf44b96b、15910B事务独审、35416B预算独审、处置与checks。控制独审 T01-controller-operation-evidence-core-C2-plan-review.md 17623B/SHA95a1f73b077afe9f98bcf719f0f609359b229108e2395143ec05ee5111a164b1已全文读回；52输入另由根实际逐Git/current/bytes/hash核同。方案问题在方案层面关闭，不倒称产品/数据库/预算验收已通过。

## 唯一树、采用与writer

从批准5f910b52c69d86a1076b2032e5d3c63e715947f3新建 .worktrees/T01-operation-evidence-core，branch feature/weekly-t01-operation-evidence-core。不切换或改C1旧树，原423b59件、a33收口、0a03539九件和并行两个方案文档全部保留。保护当前15852B/78df AGENTS、17891B/e437 common、原64及原型，不stage未授权文件。

精确只读采用控制同目录 T01-operation-evidence-C2-fixed-foundation-inputs.json，原字节14521B/SHA aef7b7c2d61cadb0eb8de73b5697f7ce78d384d217ff301bacd9038ff291f9cd。52项全部来自423b7e4c799f188cf2ce6e8e7121893ce85624cd，只接清单文件原Git字节，独立adoption提交并交实际ref/hash；不whole-commit、不复制旧环境/资料。52项维护权不转移，含C1 lifecycle、Store/Job/format3/reader、canonical/main/worker/coordinator和I05 task-runtime均只读。

产品与测试只准两个新增writer：

- packages/engine/src/ontolearn_engine/project/operation_evidence.py
- packages/engine/tests/test_project_operation_evidence.py

新过程文档只准 docs/iterations/T01/project-operation-evidence-core-C2.md 与 docs/reviews/T01/project-operation-evidence-core-C2/。可在此新目录保存必要只读审查、完整日志/原件、费用流水、manifest与交接，不写旧plan或原审查。完整相对5f产品/测试候选为52+2=54，再加全部新过程docs，不仅报两个文件。不得改__init__、DDL/表/索引/default3、协议/registry、公开Host/renderer/preload/main、依赖/锁、CI或四个T03构建路径。真闭包不足时交实际SQL/调用栈/最小旧路径diff另申，不默扩，不复制validator或造stub保表面范围。

## 已批准内部契约与真实证据

按固定主方案§3完整实现唯一私有read_operation_evidence(real_job_store, selector, *, maxEvidenceBytes, maxSelectorBytes, maxReturnBytes, readerLimits)。可信owner已持有同一真实连接、启动完成且实际format3/Job3的Store为前置；不接path/connection factory/JSON capability，不新Store、不换real._db。selector沿39602B/ff725合同原精确字段、原expectedRequest/issuedImplementation/Limits，不取当前默认、不补host/session。

批准主方案的evidenceVersion1有限create-record/job-record/no-evidence/incomplete-evidence内部union。普通Job来源未记录时明确not-recorded；ChangeSet recorded只表示库内原材料交叉一致。所有异常为有限安全code/params，identity-conflict拒异操作内容，storage-busy/storage-failure/resource-limit不得变incomplete。无resolved/permissionGranted/正式scope/原物理dispatch认证，不注册公共服务，不新意图账本，不自动重派。

EvidenceView只绑定固定原unbound只读实现，保持staticmethod/classmethod和sqlite.Row语义；所有传递SQL走同conn MeteredGate，无真实boundmethod透传、__getattr__回退或未知模板passthrough。严格复用原claim/accepted/prepared/confirmation/ChangeSet/history/creation validator，不建第二简化validator。新增真实terminal/result/rounds关系按方案补齐。完整必要闭包包括全部引用blob/segment/detail、创建三immutable行、到当前head混合history、当前域/app状态、实际terminal/result元数据及存在payload。cache NULL不否定原受理，不补cache。rounds按job反查与run正查双向一致；合法runNULL/零轮不得误拒，结构孤儿/跨run不可漏掉。

## 精确费用、查询门与清理

批准主方案§5口径：固定全列名到原SQL typed值组成canonical UTF8对象，每唯一实际(table,rowid)行计一次，列名/标点/NULL/原TEXT转义均完整计费，随后正文独立核同。实际不同PK即使同payload/hash分别计费；JOIN两来源分别计，seen不豁免重复SQL/读取工作。

每次严格metadata-only定位/type/n/u/NUL/行界 → 先预扣probe工作 → 精确canonical费用SQL及证据预扣 → 原完整正文SELECT/解析/扩引用。不得将昂贵计价塞入metadata SELECT，不先搬巨PK/正文/Python UDF后收费，不用LIMIT截断完整history。

批准明确内部工程拒绝界：MAX_PROBE_WORK=536870912，首次TEXT UTF8收费256+160*(u+1)，UTF16LE/BE portable收费256+16*(n+1)^2，NULL/INTEGER每字段64，每行128；MAX_QUERY_COUNT=65536，预留BEGIN/ROLLBACK各1，业务最多65534；MAX_READ_WORK=536870912，每query128+本次全部实际物化行canonical费用，重复照扣，metadata按128+128*固定返回列数*已界行数在执行前预留。schema材料亦计；全库ReadLimits原raw/structure/work guard另保。不得混为同一预算、承诺CPU/RSS/耗时或64MiB普遍兼容。任何新常量/费用变更先给具体证据另申。

maxEvidenceBytes显式正safe integer≤67108864、selector≤262144、return≤131072，拒bool/无限/零负；selector深度32/节点≤maxSelectorBytes，key/value逐scalar先计canonical字节再真正分块escape/encode，keys有界才排序，不靠iterencode巨chunk后计费。未来真实frame/page/envelope较小界由真实caller供给，fixture值只验证机制。

先拒未知caller活动事务而不回滚它；本次BEGIN，同conn完成后成功/失败/取消均ROLLBACK，不关闭owner Store/lease。不覆盖authorizer/progress callback，无新连接/临时表/写helper。门在execute/fetch/iterator最早边界将SQLite错误转为不属旧helper捕获族的独立EvidenceControl，资源/未知模板同样穿透，finally后安全映射。两控制槽包含总额，ROLLBACK不受耗尽业务额度挡住；实际cleanup失败保首因并有限报告，不伪称已释放。

## 实际验证与冻结交付

允许在新树独立本地环境执行本C2真实临时SQLite机制测试、受影响专项、正常npm run check与独立npm run verify:sources；必要开发依赖按既有锁安装，不升级/改锁/借其他树环境。不运行GUI/Electron/e2e、native/Keychain/用户目录/模型网络/付费，不构建包。根仅控制核验，测试与产品由原T01执行。

完整执行方案§10。额外明确必须有正向入口：UTF8、真实UTF16LE、UTF16BE同schema库，各至少完整普通已受理Job及合法runNULL/零轮rounds成功，真实create_job/start等原writer驱动；保完整probe/query/read工作流水和独立canonical全行参考，不只费用函数/超限拒绝。需真实ChangeSet preview→paged确认→Job、C1创建→后续history、atomic/rounds终态与cache回收、实际重开和损坏/来源/identity/资源±1反例。不得手填expected证明整链、删证据/放宽validator求正向通过。若代表正常材料被累计guard拒绝，交具体实际流水和最小政策/SQL修订建议，不默加预算或称成功。

外部authorizer禁全部写、完整dump前后同、trace新BEGIN→读→ROLLBACK；真实execute/fetch/iterator busy/locked/I/O与资源故障穿透、未知caller事务不动、业务额度恰耗尽仍清理。本次SQL错误注入若只能为受控故障缝，准确标明，不冒充OS磁盘故障。低预算不得先正文物化。保存首fail、实际每命令exit/timeout及完整stdout/stderr，原44skip按真实受影响基线核验并解释，不隐藏/强删。

先固定54完整候选与新过程证据，独立agent做最终真实源码/来源/预算/生命周期审查与必要修复复审；保历史反例及处置，不把无发现意见写成数学证明。交base/adoption/product/process ref、全差异manifest/current与Git对应、原件来源索引、正常check/source实际终态及完整未测边界。实现审查期间受审实现冻结；无变化不重测旧C1。不重建原Goal。

原T01另两个dispatch/permanent-drain与ontology supplier准备继续仅docs，各自作者/路径独立；新C2产品窗口独占，不因方案并行授旧engine/Store额外写权。正式create/resolution、原dispatch/物理绑定/current_scope/真实frame/Host首IO、既有启动/preview分配风险、目标Win11x64/mac15arm64/真人、指定GLM-5.3最高与M3.1-Flash xhigh同版双外审、CI、push/PR/正常develop合并及父FR/57P0仍未关闭。本件不授推送合并或替代第三方审查。
