import hashlib
import json
import sqlite3
import sys
from pathlib import Path

from ontolearn_engine import storage
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT, create
from test_project_operation_evidence import create_project, create_selector, job_selector, readonly

BASE = Path(sys.argv[1])
OUT = BASE / 'matrix'
OUT.mkdir(exist_ok=False)
CAPS = dict(maxEvidenceBytes=67108864, maxSelectorBytes=262144,
            maxReturnBytes=131072, readerLimits=ReadLimits())
original_audit = core._MeteredGate._audit
original_close = core._Cursor.close
active = []
injection = {}
results = []

def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')

def collect(gate, event, **facts):
    active.append(dict(event=event, **facts))
    if (injection.get('first') is not None and not injection.get('triggered')
            and event == 'query' and facts['sql'] == 'rowid cursor advance reservation'):
        injection['triggered'] = True
        raise injection['first']

core._MeteredGate._audit = collect

def invoke(owner, selector, label, limits=None, constants=None):
    global active
    active = []
    constants = constants or {}
    old = {name: getattr(core, name) for name in constants}
    for name, value in constants.items():
        setattr(core, name, value)
    result = failure = None
    trace = []
    try:
        with readonly(owner) as observed:
            trace = observed
            try:
                result = core.read_operation_evidence(owner, selector, **(CAPS | (limits or {})))
            except BaseException as exc:
                failure = exc
    finally:
        for name, value in old.items():
            setattr(core, name, value)
    evidence = dict(label=label, outcome=type(failure).__name__ if failure else result['finding'],
                    reason=getattr(failure, 'reason', None),
                    cleanupFailed=getattr(failure, 'cleanup_failed', False),
                    transaction=owner._db.in_transaction, trace=trace, ledger=active)
    with (OUT / (label + '.json')).open('x') as stream:
        json.dump(evidence, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    results.append({key: value for key, value in evidence.items() if key not in ('trace', 'ledger')})
    return result, failure, active, trace

try:
    print(json.dumps(dict(python=sys.version, sqlite=sqlite3.sqlite_version,
                         sourceSha=hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest())), flush=True)
    for encoding in ('UTF-8', 'UTF-16le', 'UTF-16be'):
        path = OUT / (encoding + '.sqlite')
        connect = sqlite3.connect
        def encoded_connect(*args, **kwargs):
            db = connect(*args, **kwargs)
            db.execute("PRAGMA encoding='" + encoding + "'")
            return db
        storage.sqlite3.connect = encoded_connect
        try:
            owner = JobStore(path, contract=CONTRACT, target_format=3)
        finally:
            storage.sqlite3.connect = connect
        try:
            intent, project = create_project(owner)
            job = create(owner, project=project['projectId'])
            selected = job_selector(job)
            expected = owner.get_job(job['projectId'], job['jobId'])
            result, failure, ledger, trace = invoke(owner, selected, encoding + '-normal')
            assert failure is None and result['finding'] == 'job-record' and result['job'] == expected
            summary = ledger[-1]
            assert summary['event'] == 'rollback'
            assert trace[0] == 'BEGIN' and trace[-1] == 'ROLLBACK'
            # The amount oracle serializes the complete actual typed SQL row.
            charged = [event for event in ledger if event['event'] == 'charged']
            assert len({(event['table'], event['rowid']) for event in charged}) == len(charged)
            oracle = 0
            for event in charged:
                table = event['table'].replace('"', '""')
                row = owner._db.execute('SELECT * FROM "' + table + '" WHERE _rowid_=?',
                                        (event['rowid'],)).fetchone()
                amount = len(encode(dict(row)))
                assert amount == event['bytes']
                oracle += amount
            assert oracle == summary['evidence']
            if encoding != 'UTF-8':
                continue
            dimensions = {
                'evidence': ('maxEvidenceBytes', summary['evidence']),
                'selector': ('maxSelectorBytes', len(encode(selected))),
                'return': ('maxReturnBytes', len(encode(result))),
                'probe': ('MAX_PROBE_WORK', summary['probePeak']),
                'read': ('MAX_READ_WORK', summary['readWork']),
                'query': ('MAX_QUERY_COUNT', summary['queries']),
            }
            for dimension, (name, exact) in dimensions.items():
                for delta in (-1, 0, 1):
                    limits = {name: exact + delta} if name.startswith('max') else None
                    constants = {name: exact + delta} if name.startswith('MAX') else None
                    current, failure, _, _ = invoke(owner, selected,
                        dimension + '-' + str(delta), limits, constants)
                    if delta < 0:
                        assert type(failure) is core.EvidenceFault and failure.reason == 'resource-limit'
                    else:
                        assert failure is None and current == result
            for label, limits, constants in (
                ('low-evidence', {'maxEvidenceBytes': 1}, None),
                ('low-probe', None, {'MAX_PROBE_WORK': 1}),
                ('low-read', None, {'MAX_READ_WORK': 1}),
                ('low-query', None, {'MAX_QUERY_COUNT': 2}),
            ):
                _, failure, _, trace = invoke(owner, selected, label, limits, constants)
                assert type(failure) is core.EvidenceFault and failure.reason == 'resource-limit'
                if label == 'low-probe':
                    assert not any('instr(' in sql or 'replace(' in sql or 'WITH RECURSIVE' in sql for sql in trace)
                if label == 'low-evidence':
                    assert not any(sql.startswith('SELECT * FROM') for sql in trace)
                if label in ('low-read', 'low-query'):
                    assert trace == ['BEGIN', 'ROLLBACK']
        finally:
            owner.close()

    # Unsupported but well-formed small SQL schemas: no file damage or large values.
    for alias in ('rowid', '_rowid_', 'oid', '_t01_rowkey'):
        for upper in (False, True):
            name = alias.upper() if upper else alias
            owner = JobStore(OUT / ('alias-' + name + ('-up' if upper else '-lo') + '.sqlite'),
                             contract=CONTRACT, target_format=3)
            try:
                intent, project = create_project(owner)
                owner.put_blob(project['projectId'], {'small': 'normal'})
                owner._db.execute('ALTER TABLE job_blobs ADD COLUMN "' + name + '" TEXT')
                _, failure, ledger, trace = invoke(owner, create_selector(intent),
                                                  'alias-' + name + ('-up' if upper else '-lo'))
                assert failure is None
                assert results[-1]['outcome'] == 'incomplete-evidence'
                assert not any(sql.startswith(('SELECT rowid FROM', 'SELECT _rowid_ FROM'))
                               and '"job_blobs"' in sql for sql in trace)
                assert not any(event['event'] == 'native-metadata' and event['table'] == 'job_blobs'
                               for event in ledger)
            finally:
                owner.close()

    owner = JobStore(OUT / 'close.sqlite', contract=CONTRACT, target_format=3)
    try:
        intent, _ = create_project(owner)
        for first_kind in (None, 'resource', 'cancel'):
            for close_kind in ('memory', 'interrupt', 'sqlite'):
                first = (core.EvidenceFault('resource-limit') if first_kind == 'resource'
                         else KeyboardInterrupt('first fixture cancellation') if first_kind else None)
                close_failure = (MemoryError('fixture close memory') if close_kind == 'memory'
                                 else KeyboardInterrupt('fixture close interruption') if close_kind == 'interrupt'
                                 else sqlite3.OperationalError('fixture close driver'))
                if close_kind == 'sqlite':
                    close_failure.sqlite_errorcode = sqlite3.SQLITE_IOERR
                injection.clear()
                injection.update(first=first, triggered=False)
                closed = []
                class Driver:
                    def close(self):
                        raise close_failure
                def failed_close(cursor):
                    original_close(cursor)
                    closed.append(True)
                    return original_close(core._Cursor(Driver()))
                core._Cursor.close = failed_close
                try:
                    _, failure, _, trace = invoke(owner, create_selector(intent),
                        'close-' + str(first_kind) + '-' + close_kind)
                finally:
                    core._Cursor.close = original_close
                assert closed == [True] and trace[-1] == 'ROLLBACK'
                if first is not None:
                    assert failure is first and first.cleanup_failed is True
                elif close_kind == 'sqlite':
                    assert type(failure) is core.EvidenceFault and failure.reason == 'storage-failure'
                else:
                    assert failure is close_failure
        injection.clear()
    finally:
        owner.close()
    with (BASE / 'matrix-results.json').open('x') as stream:
        json.dump(results, stream, indent=2)
        stream.write('\n')
    assert len(results) == 42
    print(json.dumps(dict(cases=len(results), allAssertionsPassed=True,
                         sourceShaAfter=hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest())), flush=True)
finally:
    core._MeteredGate._audit = original_audit
    core._Cursor.close = original_close
