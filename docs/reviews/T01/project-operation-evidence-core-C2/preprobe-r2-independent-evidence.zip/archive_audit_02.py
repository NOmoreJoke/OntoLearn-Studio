from pathlib import Path
import collections,hashlib,json,stat,zipfile
root=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-operation-evidence-core/docs/reviews/T01/project-operation-evidence-core-C2')
index_path=root/'preprobe-repair-evidence-r2.json';index=json.loads(index_path.read_bytes());archive=Path(index['archive']['path'])
assert archive.stat().st_size==index['archive']['bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==index['archive']['sha256']
rows=index['rows'];rowmap={r['member']:r for r in rows};assert len(rowmap)==len(rows)
raw=index['rawToolStream'];source=Path(raw['source']);alllines=source.read_bytes().splitlines(keepends=True);offsets=[];offset=0;response=tools=0;source_info={}
for line_no,line in enumerate(alllines,1):
 if line_no>raw['lastLine1']:break
 data=json.loads(line)
 if data['type']=='response_item':
  response+=1
  kind=data['payload']['type']
  if kind in {'function_call','function_call_output','custom_tool_call','custom_tool_call_output'}:
   tools+=1
   source_info[line_no]=(offset,response,tools)
 offset+=len(line)
raw_member=next(r['member'] for r in rows if r['member'].endswith('.jsonl'))
with zipfile.ZipFile(archive) as z:
 infos=z.infolist();assert len(infos)==len(rows) and len({i.filename for i in infos})==len(infos)
 assert set(i.filename for i in infos)==set(rowmap)
 for info in infos:
  p=Path(info.filename);assert not p.is_absolute() and '..' not in p.parts
  assert stat.S_IFMT(info.external_attr>>16)!=stat.S_IFLNK
  h=hashlib.sha256();total=0
  with z.open(info) as stream:
   while chunk:=stream.read(1048576):h.update(chunk);total+=len(chunk)
  r=rowmap[info.filename];assert total==r['bytes'] and h.hexdigest()==r['sha256']
  if info.filename!=raw_member:
   s=Path(r['source']);assert s.is_file()
   h=hashlib.sha256()
   with s.open('rb') as stream:
    while chunk:=stream.read(1048576):h.update(chunk)
   assert s.stat().st_size==r['bytes'] and h.hexdigest()==r['sha256']
 rawbytes=z.read(raw_member);rawlines=rawbytes.splitlines(keepends=True)
 assert len(rawlines)==raw['recordCount']==len(raw['records'])
 pairs=collections.defaultdict(list);memberoffset=0;terminal={};selected_calls={}
 for n,(meta,line) in enumerate(zip(raw['records'],rawlines,strict=True),1):
  original=alllines[meta['sourceLine1']-1]
  assert line==original and len(line)==meta['bytesIncludingLF'] and hashlib.sha256(line).hexdigest()==meta['sha256']
  assert source_info[meta['sourceLine1']]==(meta['sourceByteOffset0'],meta['sourceResponseItemOrdinal1'],meta['sourceToolRecordOrdinal1'])
  assert n==meta['memberRecordOrdinal1'] and memberoffset==meta['memberByteOffset0'];memberoffset+=len(line)
  entry=json.loads(line);p=entry['payload'];assert entry['timestamp']==meta['timestamp'] and p['type']==meta['type'] and p['call_id']==meta['callId']
  pairs[p['call_id']].append(p['type'])
  if p['type'].endswith('_output'):
   content=p['output'];texts=[content] if isinstance(content,str) else [x['text'] for x in content if 'text' in x]
   for text in texts:
    try:item=json.loads(text)
    except (ValueError,TypeError):continue
    stack=[item]
    while stack:
     nested=stack.pop()
     if type(nested) is dict:
      if nested.get('chunk_id') in ['14c887','de486a','ef5d16']:
       terminal[nested['chunk_id']]=nested;selected_calls[p['call_id']]=p
      stack.extend(nested.values())
     elif type(nested) is list:stack.extend(nested)
 assert len(pairs)==raw['pairCount']==30
 assert all(len(v)==2 and not v[0].endswith('_output') and v[1].endswith('_output') for v in pairs.values())
 for chunk,code in [('14c887',0),('de486a',0),('ef5d16',1)]:assert terminal[chunk]['exit_code']==code
 result={'archiveBytes':archive.stat().st_size,'archiveSha256':index['archive']['sha256'],'membersChecked':len(infos),'liveArtifactsChecked':len(infos)-1,'sourceRecords':len(rawlines),'pairs':len(pairs),'selectionFirstLine1':raw['firstLine1'],'actualFirstLine1':raw['records'][0]['sourceLine1'],'lastLine1':raw['lastLine1'],'terminals':terminal,'allAssertionsPassed':True}
 with (Path(__file__).parent/'archive-audit-result-02.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result,ensure_ascii=False))
