import hashlib,json,sys,tempfile
from pathlib import Path
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT
from test_project_operation_evidence import create_project
base=Path(sys.argv[1]); source=Path(core.__file__)
print(json.dumps({"source":str(source),"bytes":source.stat().st_size,"sha256":hashlib.sha256(source.read_bytes()).hexdigest()}),flush=True)
owner=JobStore(base/"scan.sqlite",contract=CONTRACT,target_format=3)
events=[]
original=core._MeteredGate._audit
core._MeteredGate._audit=lambda self,event,**facts:events.append({"event":event,**facts})
try:
 _,project=create_project(owner)
 for i in range(300):owner.put_blob(project["projectId"],{"i":i,"payload":"x"*1000})
 rowid=owner._db.execute("SELECT rowid FROM job_blobs ORDER BY rowid DESC LIMIT 1").fetchone()[0]
 gate=core._MeteredGate(owner._db,67108864,ReadLimits());gate.encoding="UTF-8"
 steps=[0]
 owner._db.set_progress_handler(lambda:steps.__setitem__(0,steps[0]+1) or 0,1)
 before=steps[0];amount=gate._cost("job_blobs",rowid);after=steps[0]
 owner._db.set_progress_handler(None,0)
 event=next(e for e in events if e["event"]=="query" and e["sql"].startswith("SELECT *") and '"job_blobs"' in e["sql"])
 plan=[tuple(r) for r in owner._db.execute("EXPLAIN "+event["sql"],(rowid,))]
 result={"rows":300,"targetRowid":rowid,"amount":amount,"bodyQuery":event,"opcodes":plan,"entireCostVmSteps":after-before,"readWork":gate.read_work,"probe":gate.probe}
 (base/"scan-evidence.json").write_text(json.dumps(result,indent=2)+"\n")
 (base/"scan-ledger.json").write_text(json.dumps(events,indent=2)+"\n")
 print(json.dumps({"rows":300,"bodySql":event["sql"],"reservedWork":event["reservedWork"],"controlWork":event["controlWork"],"realTableRewindNext":[r for r in plan if r[1] in ["Rewind","Next","SeekRowid","Column"]],"readWork":gate.read_work}),flush=True)
finally:
 core._MeteredGate._audit=original
 owner.close()
