import hashlib,json,tempfile
from pathlib import Path
import test_project_operation_evidence as t
from ontolearn_engine.project import operation_evidence as c
source=Path('packages/engine/src/ontolearn_engine/project/operation_evidence.py')
result={'sourceBytes':len(source.read_bytes()),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'observed':[]}
with tempfile.TemporaryDirectory(prefix='t01-c2-rowid-shadow-') as d:
 s=t.JobStore(Path(d)/'facts.sqlite',contract=t.CONTRACT,target_format=3)
 try:
  intent,p=t.create_project(s);ref=s.put_blob(p['projectId'],'original')
  s._db.execute('ALTER TABLE job_blobs ADD COLUMN rowid TEXT')
  with t.corrupt_immutable(s,'job_blobs'):
   s._db.execute('UPDATE job_blobs SET rowid=? WHERE ref=?',('x'*1048576,ref))
  result['plan']=[tuple(r) for r in s._db.execute('EXPLAIN SELECT rowid FROM "job_blobs" NOT INDEXED LIMIT 16385')]
  old=c._Cursor.fetchone
  def observed(cursor):
   row=old(cursor)
   if row and type(row[0]) is str and len(row[0])==1048576:result['observed'].append({'firstFieldType':'str','bytes':len(row[0].encode()),'valuePrefix':row[0][:1]})
   return row
  c._Cursor.fetchone=observed
  try:
   gate=c._MeteredGate(s._db,67108864,t.ReadLimits());gate.encoding='UTF-8'
   try:gate._rowids('job_blobs',16384)
   except BaseException as exc:result['direct']={'exception':type(exc).__name__,'reason':getattr(exc,'reason',None),'readWork':gate.read_work,'probe':gate.probe}
   try:result['entryResult']=t.read(s,t.create_selector(intent))
   except BaseException as exc:result['entryException']={'exception':type(exc).__name__,'reason':getattr(exc,'reason',None)}
  finally:c._Cursor.fetchone=old
  result['transactionAfter']=s._db.in_transaction
 finally:s.close()
Path('/tmp/t01-c2-preprobe-repair-20261022-01/rowid-shadow-counterexample.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert not result['observed'],'Unpaid TEXT materialized through shadowed rowid before native/probe bound'
