from pathlib import Path
__path__.append('/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-operation-evidence-core/packages/engine/src/ontolearn_engine/project')
