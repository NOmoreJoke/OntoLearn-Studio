from pathlib import Path
import json,hashlib,zipfile,collections,re,subprocess
root=Path.cwd();r=root/'docs/reviews/T01/project-operation-evidence-core-C2';e=Path('/tmp/t01-c2-preprobe-repair-20261022-01')
def sha(b):return hashlib.sha256(b).hexdigest()
def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
previous=json.loads((r/'preprobe-repair-evidence-02.json').read_text())
known=set()
for name in ['preprobe-repair-evidence-01.json','preprobe-repair-evidence-02.json','preprobe-repair-r1-counterexamples.json']:
 for x in json.loads((r/name).read_text())['rows']:
  if 'source' in x:known.add((x['source'],x['sha256']))
zpath=r/'preprobe-repair-evidence-r2.zip';assert not zpath.exists()
entries=[];payloads={}
def add(name,b,source=None,**extra):
 assert name not in payloads;payloads[name]=b;entries.append({'member':name,'bytes':len(b),'sha256':sha(b),**({'source':str(source)} if source else {}),**extra})
for p in sorted(e.rglob('*')):
 if p.is_file() and p.suffix in {'.json','.jsonl','.log','.py','.txt','.md'}:
  b=p.read_bytes()
  if (str(p),sha(b)) not in known:add('delta/'+str(p.relative_to(e)),b,p)
source=Path('/Users/kyle/.codex/sessions/2026/10/21/rollout-2026-10-21T20-28-12-01a15e6e-f47e-7960-8e8b-d79eff4f21b8.jsonl');data=source.read_bytes();offset=ro=to=0;rows=[];CALL={'custom_tool_call','function_call'};OUT={'custom_tool_call_output','function_call_output'}
for line,b in enumerate(data.splitlines(keepends=True),1):
 v=json.loads(b);q=v.get('payload',{});ty=q.get('type')
 if v.get('type')=='response_item':ro+=1
 if v.get('type')=='response_item' and ty in CALL|OUT:
  to+=1;rows.append({'line':line,'offset':offset,'ro':ro,'to':to,'raw':b,'payload':q,'timestamp':v.get('timestamp')})
 offset+=len(b)
lo=previous['rawToolStream']['lastLine1']+1
pairs=collections.defaultdict(list)
for a in rows:
 if a['line']>=lo:pairs[a['payload']['call_id']].append(a)
complete={k for k,v in pairs.items() if len(v)==2 and v[0]['payload']['type'] in CALL and v[1]['payload']['type'] in OUT};selected=[a for a in rows if a['line']>=lo and a['payload']['call_id'] in complete]
raw=b''.join(x['raw'] for x in selected);add('tool-records/c2-resource-repair-r2.jsonl',raw,source,role='only complete C2 repair response_item tool call/output records; no session_meta/reasoning/messages')
records=[];exits=[];off=0
for i,a in enumerate(selected,1):
 q=a['payload'];records.append({'sourceAbsolutePath':str(source),'sourceLine1':a['line'],'sourceByteOffset0':a['offset'],'sourceResponseItemOrdinal1':a['ro'],'sourceToolRecordOrdinal1':a['to'],'memberRecordOrdinal1':i,'memberByteOffset0':off,'timestamp':a['timestamp'],'type':q['type'],'callId':q['call_id'],'bytesIncludingLF':len(a['raw']),'sha256':sha(a['raw'])});off+=len(a['raw'])
 if q['type'] in OUT:
  v=q.get('output');txt='\n'.join(str(k.get('text','')) for k in v if isinstance(k,dict)) if isinstance(v,list) else v if isinstance(v,str) else json.dumps(v)
  for hit in re.finditer(r'"chunk_id"\s*:\s*"([0-9a-f]+)"(?:(?!"chunk_id").)*?"exit_code"\s*:\s*(-?\d+)',txt,re.S):exits.append({'chunkId':hit[1],'exitCode':int(hit[2]),'sourceOutputLine1':a['line'],'callId':q['call_id']})
for t,c in [('549a43',1),('ef5d16',1),('14c887',0),('de486a',0),('1dae81',0),('f15822',0)]:assert any(x['chunkId']==t and x['exitCode']==c for x in exits),(t,c)
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in payloads.items():z.writestr(name,b)
index={'scope':'Final R2 delta originals after immutable01/02/R1-blocker archives. Prior exact source/hash artifacts referenced rather than duplicated. Original SQLite runtime files excluded.','rows':entries,'archive':fp(zpath),'rawToolStream':{'source':str(source),'firstLine1':lo,'lastLine1':selected[-1]['line'],'pairCount':len(complete),'recordCount':len(records),'records':records,'actualNestedExitLedger':exits,'captureBoundary':'Only completed pairs before this sealing call. Sealing/check/commit followups after capture remain in actual source and external receipt, not silently claimed inside ZIP.'},'previousArchive':previous['archive'],'missingIntermediateLedgerSources':previous['missingIntermediateLedgerSources'],'missingRule':previous['missingRule']};(r/'preprobe-repair-evidence-r2.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':fp(zpath),'members':len(entries),'toolPairs':len(complete),'toolRecords':len(records),'firstLine':lo,'lastLine':selected[-1]['line']},ensure_ascii=False))
