from pathlib import Path
import json,hashlib,zipfile,collections,re,subprocess
root=Path.cwd();r=root/'docs/reviews/T01/project-operation-evidence-core-C2';e=Path('/tmp/t01-c2-preprobe-repair-20261022-01')
def sha(b):return hashlib.sha256(b).hexdigest()
def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
previous=json.loads((r/'preprobe-repair-evidence-01.json').read_text());known={(x['source'],x['sha256']) for x in previous['rows']};zpath=r/'preprobe-repair-evidence-02.zip';assert not zpath.exists()
entries=[];payloads={}
def add(name,b,source=None,**extra):
 assert name not in payloads;payloads[name]=b;entries.append({'member':name,'bytes':len(b),'sha256':sha(b),**({'source':str(source)} if source else {}),**extra})
for p in sorted(e.rglob('*')):
 if p.is_file() and p.suffix in {'.json','.jsonl','.log','.py','.txt','.md'}:
  b=p.read_bytes()
  if (str(p),sha(b)) not in known:add('delta/'+str(p.relative_to(e)),b,p)
proof=[]
for name,path,ranges in [('sqlite3.c',Path('/tmp/t01-primary-s1-sqlite-3500400-source/sqlite3.c'),[(76966,76999),(77066,77164),(77200,77216),(77346,77447),(77816,77895),(97359,97416),(97435,97482),(97505,97548),(115504,115522),(130532,130567)]),('cursor.c',Path('/tmp/t01-primary-s1-cpython-31212-source/cursor.c'),[(1096,1144),(852,887)])]:
 b=path.read_bytes();lines=b.splitlines(keepends=True);records=[]
 for lo,hi in ranges:
  part=b''.join(lines[lo-1:hi]);records.append({'firstLine1':lo,'lastLine1':hi,'sourceByteOffset0':sum(map(len,lines[:lo-1])),'bytes':len(part),'sha256':sha(part)})
 add('upstream/'+name,b,path,role='official static source only; no build/install/code adoption')
 proof.append({**fp(path),'snippets':records})
source=Path('/Users/kyle/.codex/sessions/2026/10/21/rollout-2026-10-21T20-28-12-01a15e6e-f47e-7960-8e8b-d79eff4f21b8.jsonl');data=source.read_bytes();offset=ro=to=0;rows=[];CALL={'custom_tool_call','function_call'};OUT={'custom_tool_call_output','function_call_output'}
for line,b in enumerate(data.splitlines(keepends=True),1):
 v=json.loads(b);q=v.get('payload',{});ty=q.get('type')
 if v.get('type')=='response_item':ro+=1
 if v.get('type')=='response_item' and ty in CALL|OUT:
  to+=1;rows.append({'line':line,'offset':offset,'ro':ro,'to':to,'raw':b,'payload':q,'timestamp':v.get('timestamp')})
 offset+=len(b)
starts=[x for x in rows if x['payload']['type'] in CALL and 'cmd:"cat /Users/kyle/Documents/工作/知爻/本体/iteration-control/2026-10-21-weekly-release/T01-C2-preprobe-resource-repair-window.md"' in str(x['payload'].get('input',''))];assert len(starts)==1
lo=starts[0]['line'];pairs=collections.defaultdict(list)
for a in rows:
 if a['line']>=lo:pairs[a['payload']['call_id']].append(a)
complete={k for k,v in pairs.items() if len(v)==2 and v[0]['payload']['type'] in CALL and v[1]['payload']['type'] in OUT};selected=[a for a in rows if a['line']>=lo and a['payload']['call_id'] in complete]
raw=b''.join(x['raw'] for x in selected);add('tool-records/c2-resource-repair.jsonl',raw,source,role='only complete C2 repair response_item tool call/output records; no session_meta/reasoning/messages')
records=[];exits=[];off=0
for i,a in enumerate(selected,1):
 q=a['payload'];records.append({'sourceAbsolutePath':str(source),'sourceLine1':a['line'],'sourceByteOffset0':a['offset'],'sourceResponseItemOrdinal1':a['ro'],'sourceToolRecordOrdinal1':a['to'],'memberRecordOrdinal1':i,'memberByteOffset0':off,'timestamp':a['timestamp'],'type':q['type'],'callId':q['call_id'],'bytesIncludingLF':len(a['raw']),'sha256':sha(a['raw'])});off+=len(a['raw'])
 if q['type'] in OUT:
  v=q.get('output');txt='\n'.join(str(k.get('text','')) for k in v if isinstance(k,dict)) if isinstance(v,list) else v if isinstance(v,str) else json.dumps(v)
  for hit in re.finditer(r'"chunk_id"\s*:\s*"([0-9a-f]+)"(?:(?!"chunk_id").)*?"exit_code"\s*:\s*(-?\d+)',txt,re.S):exits.append({'chunkId':hit[1],'exitCode':int(hit[2]),'sourceOutputLine1':a['line'],'callId':q['call_id']})
for t,c in [('bac5e4',1),('99543e',0),('1a87af',0),('43c604',0)]:assert any(x['chunkId']==t and x['exitCode']==c for x in exits),(t,c)
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in payloads.items():z.writestr(name,b)
index={'scope':'Read-ready delta originals after immutable evidence01; previous exact source/hash entries referenced rather than duplicated. Original runtime SQLite files excluded.','rows':entries,'archive':fp(zpath),'rawToolStream':{'source':str(source),'firstLine1':lo,'lastLine1':selected[-1]['line'],'pairCount':len(complete),'recordCount':len(records),'records':records,'actualNestedExitLedger':exits,'captureBoundary':'Only completed pairs before this sealing call. Sealing/check/commit followups after capture remain in actual source and external receipt, not silently claimed inside ZIP.'},'previousArchive':previous['archive'],'missingIntermediateLedgerSources':previous['missingIntermediateLedgerSources'],'missingRule':previous['missingRule']};(r/'preprobe-repair-evidence-02.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
sp={'scope':'Exact offline upstream source and actual EXPLAIN provenance, source algorithm facts not adoption of S1 implementation/policy.','sources':proof,'sqliteSourceId':'2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3','runtime':'own tree CPython3.12.12 / SQLite3.50.4; version/sourceID and actual local plans tested, not binary reproduction or cross-platform acceptance','actualExplanations':[fp(p) for p in sorted((e/'check-01-tmp').rglob('native-point-explain.json'))], 'normalLedgerStatistics':json.loads((e/'normal-ledger-statistics.json').read_text()),'firstFailureLedger':fp(e/'first-counterexample-ledger.json'),'rawPairCount':len(complete),'actualRawExitCount':len(exits),'gateLimitPolicy':'Original caps unchanged; physical header/local/seek/statement and scan/cache work added before actual execution. Rowids stream with per-step prepayment and strict monotonicity; subsequent source access by bounded rowid point sets; no BtreeCount/page_count assumption/serialize/raw parser in product.','originalEvidenceLoss':previous['missingRule']};(r/'preprobe-repair-source-proof.json').write_text(json.dumps(sp,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':fp(zpath),'members':len(entries),'toolPairs':len(complete),'toolRecords':len(records),'firstLine':lo,'lastLine':selected[-1]['line'],'sourceProof':fp(r/'preprobe-repair-source-proof.json')},ensure_ascii=False))
