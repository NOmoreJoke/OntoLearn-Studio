import sys,tempfile,json,sqlite3,hashlib
from pathlib import Path
sys.path[:0]=['packages/engine/src','packages/engine/tests']
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine import storage
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT,create,IMPL,LIMITS,uid
from test_project_operation_evidence import FaultConnection
p=Path(core.__file__);print('source',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
original=sqlite3.connect
storage.sqlite3.connect=lambda *a,**k:original(*a,**k,factory=FaultConnection)
with tempfile.TemporaryDirectory(prefix='t01-c2-cancel-') as d:
 s=JobStore(Path(d)/'facts.sqlite',contract=CONTRACT,target_format=3);s.create_project('audit');pr=s.public_project('audit');j=create(s,project=pr)
 sel={'resolutionVersion':1,'kind':'job','operationId':j['operationId'],'projectId':pr,'jobId':j['jobId'],'expectedRequest':{'projectId':pr,'operationId':j['operationId'],'capability':j['capability'],'input':j['input'],'confirmationRef':j['confirmationRef']},'issuedImplementation':IMPL,'issuedLimits':LIMITS,'originalOrigin':{'hostClientId':uid(),'engineSessionId':uid()}}
 def cancelled(_):raise KeyboardInterrupt('controlled cancellation')
 old=core._catalog;core._catalog=cancelled
 s._db.target='ROLLBACK';s._db.stage='execute';s._db.error=sqlite3.OperationalError('controlled rollback');s._db.error.sqlite_errorcode=sqlite3.SQLITE_IOERR
 try:core.read_operation_evidence(s,sel,maxEvidenceBytes=67108864,maxSelectorBytes=262144,maxReturnBytes=131072,readerLimits=ReadLimits())
 except BaseException as e:print(json.dumps({'exception':type(e).__name__,'cleanupFailed':getattr(e,'cleanup_failed',None),'context':type(e.__context__).__name__ if e.__context__ else None,'cause':type(e.__cause__).__name__ if e.__cause__ else None,'transaction':s._db.in_transaction}))
 finally:core._catalog=old;s._db.stage=None;s._db.execute('ROLLBACK');s.close()
