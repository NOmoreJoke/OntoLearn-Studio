import sys, tempfile, json, hashlib
from pathlib import Path
sys.path[:0]=['packages/engine/src','packages/engine/tests']
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT,create,IMPL,LIMITS,uid
p=Path('packages/engine/src/ontolearn_engine/project/operation_evidence.py')
print('source',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
with tempfile.TemporaryDirectory(prefix='t01-c2-audit-') as d:
 s=JobStore(Path(d)/'test.sqlite',contract=CONTRACT,target_format=3)
 s.create_project('audit');project=s.public_project('audit')
 j=create(s,project=project)
 sel={'resolutionVersion':1,'kind':'job','operationId':j['operationId'],'projectId':project,'jobId':j['jobId'],'expectedRequest':{'projectId':project,'operationId':j['operationId'],'capability':j['capability'],'input':j['input'],'confirmationRef':j['confirmationRef']},'issuedImplementation':IMPL,'issuedLimits':LIMITS,'originalOrigin':{'hostClientId':uid(),'engineSessionId':uid()}}
 from ontolearn_engine.storage import digest,canonical
 from test_project_host_read_services import corrupt_immutable
 context=json.loads(s._db.execute('SELECT context FROM jobs WHERE id=?',(j['jobId'],)).fetchone()[0]);context['manifests']=[]
 fingerprint=digest(context)
 with corrupt_immutable(s,'jobs'):
  s._db.execute('UPDATE jobs SET context=?,fingerprint=? WHERE id=?',(canonical(context),fingerprint,j['jobId']))
 with corrupt_immutable(s,'operation_claims'):
  s._db.execute('UPDATE operation_claims SET fingerprint=? WHERE operation=?',(fingerprint,j['operationId']))
 before='\n'.join(s._db.iterdump())
 try:
  r=core.read_operation_evidence(s,sel,maxEvidenceBytes=67108864,maxSelectorBytes=262144,maxReturnBytes=131072,readerLimits=ReadLimits())
  out={'finding':r['finding']}
 except BaseException as e:
  out={'exception':type(e).__name__,'reason':getattr(e,'reason',None),'message':str(e)}
 print(json.dumps({**out,'unchanged':before=='\n'.join(s._db.iterdump()),'transaction':s._db.in_transaction}))
 s.close()
