import sys,tempfile,json,hashlib
from pathlib import Path
sys.path[:0]=['packages/engine/src','packages/engine/tests']
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT,create,IMPL,LIMITS,uid
p=Path(core.__file__);print('source',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
for mode in ('tables65','columns33'):
 with tempfile.TemporaryDirectory(prefix='t01-c2-bounds-') as d:
  s=JobStore(Path(d)/'facts.sqlite',contract=CONTRACT,target_format=3);s.create_project('audit');pr=s.public_project('audit');j=create(s,project=pr)
  if mode=='tables65':
   n=s._db.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
   for i in range(65-n):s._db.execute('CREATE TABLE audit_extra_'+str(i)+'(v TEXT)')
  else:
   n=len(s._db.execute('PRAGMA table_info(jobs)').fetchall())
   for i in range(33-n):s._db.execute('ALTER TABLE jobs ADD COLUMN audit_extra_'+str(i)+' TEXT')
  sel={'resolutionVersion':1,'kind':'job','operationId':j['operationId'],'projectId':pr,'jobId':j['jobId'],'expectedRequest':{'projectId':pr,'operationId':j['operationId'],'capability':j['capability'],'input':j['input'],'confirmationRef':j['confirmationRef']},'issuedImplementation':IMPL,'issuedLimits':LIMITS,'originalOrigin':{'hostClientId':uid(),'engineSessionId':uid()}}
  before='\n'.join(s._db.iterdump());trace=[];s._db.set_trace_callback(trace.append)
  try:r=core.read_operation_evidence(s,sel,maxEvidenceBytes=67108864,maxSelectorBytes=262144,maxReturnBytes=131072,readerLimits=ReadLimits());out={'finding':r['finding']}
  except core.EvidenceFault as e:out={'fault':e.reason}
  s._db.set_trace_callback(None)
  print(json.dumps({'mode':mode,**out,'tableNamesMaterialized':"SELECT name FROM sqlite_master WHERE type='table'" in trace,'jobsPragmaMaterialized':any(x=='PRAGMA table_info("jobs")' for x in trace),'unchanged':before=='\n'.join(s._db.iterdump()),'transaction':s._db.in_transaction,'last':trace[-1]}));s.close()
