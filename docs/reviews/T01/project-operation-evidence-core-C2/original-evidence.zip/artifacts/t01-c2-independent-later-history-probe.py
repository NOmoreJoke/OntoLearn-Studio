import sys, tempfile, json, hashlib
from pathlib import Path
sys.path[:0]=['packages/engine/src','packages/engine/tests']
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT,create,IMPL,LIMITS,uid
p=Path('packages/engine/src/ontolearn_engine/project/operation_evidence.py')
print('source',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
with tempfile.TemporaryDirectory(prefix='t01-c2-audit-') as d:
 s=JobStore(Path(d)/'test.sqlite',contract=CONTRACT,target_format=3)
 s.create_project('audit');project=s.public_project('audit')
 j=create(s,project=project)
 sel={'resolutionVersion':1,'kind':'job','operationId':j['operationId'],'projectId':project,'jobId':j['jobId'],'expectedRequest':{'projectId':project,'operationId':j['operationId'],'capability':j['capability'],'input':j['input'],'confirmationRef':j['confirmationRef']},'issuedImplementation':IMPL,'issuedLimits':LIMITS,'originalOrigin':{'hostClientId':uid(),'engineSessionId':uid()}}
 from test_project_host_read_services import corrupt_immutable
 from ontolearn_engine.project import format3
 s.commit('audit',0,uid(),'later-domain',definitions=[{'layer':'rule','id':'r','value':{'enabled':True}}])
 current=s._db.execute('SELECT checkpoint FROM app_projects WHERE project=?',('audit',)).fetchone()[0]
 with corrupt_immutable(s,'app_checkpoints'):
  s._db.execute('UPDATE app_checkpoints SET payload=? WHERE id=?',('{}',current))
 before='\n'.join(s._db.iterdump());trace=[];s._db.set_trace_callback(trace.append)
 r=core.read_operation_evidence(s,sel,maxEvidenceBytes=67108864,maxSelectorBytes=262144,maxReturnBytes=131072,readerLimits=ReadLimits())
 s._db.set_trace_callback(None)
 try:format3._history(s,'audit');history='ACCEPT'
 except ValueError:history='REJECT'
 print(json.dumps({'finding':r['finding'],'historyValidator':history,'readAppCheckpoint':any('FROM app_checkpoints' in x for x in trace),'unchanged':before=='\n'.join(s._db.iterdump()),'transaction':s._db.in_transaction}))
 s.close()
