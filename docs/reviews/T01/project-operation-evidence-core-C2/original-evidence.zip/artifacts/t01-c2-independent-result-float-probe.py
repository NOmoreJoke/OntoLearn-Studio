import sys, tempfile, json, hashlib
from pathlib import Path
sys.path[:0]=['packages/engine/src','packages/engine/tests']
from ontolearn_engine.project import operation_evidence as core
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project.project_host import ReadLimits
from test_job_store import CONTRACT,create,IMPL,LIMITS,uid
p=Path('packages/engine/src/ontolearn_engine/project/operation_evidence.py')
print('source',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
with tempfile.TemporaryDirectory(prefix='t01-c2-audit-') as d:
 s=JobStore(Path(d)/'test.sqlite',contract=CONTRACT,target_format=3)
 s.create_project('audit');project=s.public_project('audit')
 j=create(s,project=project)
 sel={'resolutionVersion':1,'kind':'job','operationId':j['operationId'],'projectId':project,'jobId':j['jobId'],'expectedRequest':{'projectId':project,'operationId':j['operationId'],'capability':j['capability'],'input':j['input'],'confirmationRef':j['confirmationRef']},'issuedImplementation':IMPL,'issuedLimits':LIMITS,'originalOrigin':{'hostClientId':uid(),'engineSessionId':uid()}}
 s.start_job(j['jobId'])
 s.finish_read_job(j['jobId'],[{'rowId':uid(),'ordinal':0,'cells':[1.5,1.0,-0.5]}])
 before='\n'.join(s._db.iterdump())
 r=core.read_operation_evidence(s,sel,maxEvidenceBytes=67108864,maxSelectorBytes=262144,maxReturnBytes=131072,readerLimits=ReadLimits())
 print(json.dumps({'jobState':s.get_job(project,j['jobId'])['state'],'payload':s.result(s.get_job(project,j['jobId'])['resultRef']['resultId'])['payload'],'finding':r['finding'],'unchanged':before=='\n'.join(s._db.iterdump()),'transaction':s._db.in_transaction}))
 s.close()
