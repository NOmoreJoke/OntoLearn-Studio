# T01 本体编辑真实供方：投影、metadata、持久proof与预算方案准备

2026-10-21。总控接受T02固定4406103/4229214/d597b3c的方案技术方向与S1–S5供方请求；根独审15654B/SHA c8c048c9d799e54d5eb4ad34324238a2ba834dcb724a7b020af50199fcb9cadc已全文读，未批准T02产品、采用或运行。现由原T01唯一维护者准备准确供方合同，不能让T02用假supplier或手填plan先做成功测试。

本件仅新docs/iterations/T01/ontology-projection-and-changeset-supplier-plan.md及docs/reviews/T01/ontology-projection-and-changeset-supplier-plan/，不改C1/C2/dispatch方案或产品/测试/依赖/AGENTS/旧报告。可由不同agent在独立docs路径与已授权C2/dispatch调查并行，产品writer窗口仍由根序列化批准，不打断正在收尾的检查。当前无新代码树、schema或共享源码写权，不重开/重建原Goal。

必读T02固定主方案44243B/SHA6b88b1f7a8e9b7b08719f6b48dda16905a3eb800a7b8baef21f4b7a26b06983c（.worktrees/T02-ontology/docs/iterations/T02/typed-changeset-integration-plan.md，固定4406103ac309b21ddabb5f99b3efd11265acb64f），根T02-controller-typed-changeset-integration-plan-review.md及T01真实固定423b相应切点。只读T02四模块，不复制/import/执行/修改其来源或环境。旧493/b54及T01 C1/5de原件保留。

请统一冻结以下供方方案，而不是只新增一个初次preview wrapper：

**S1真实一致投影。** 已开真实JobStore3中单次全新只读事务取得public/internal映射、当前revision/完整vector/state、原factID/owner/source_row/managed_value/墓碑、全部definition payload/显式引用、retirement control，以及同版Entity metadata真实内容或可审查缺失证明。不能调用可能补写的snapshot/public_project；完整源/RDF/多重支持不可表示时精确有限失败，不丢字段再假完整。按实际ReadLimits/SQL先界再读blob与受限解码；输出直接供T02真实Snapshot/Preview和S2复验，不另造无消费者公共DTO或权限。

**Entity metadata与完整FR-200路径。** 原产品要求真实中文名/英文标识/定义/同义词/示例的创建、编辑、复制、删除和完整Diff/undo。现project_host项目名称不是Entity metadata。根不将T02提出的v_+IRIhex显示标识批准为正式英文标识存储或完整FR字段；请优先给唯一版本化metadata真实存放/读取/原子写/历史与包保留方案，明确与RDF term/实体IRI/definition ID的关系且不随意改原IRI。针对旧纯RDF确证无metadata的源，给保真读取/缺失报告/后续真实补录或显式标为显示派生的可选策略及差别，根后续明确选择；不得默填业务字段。支持S1先行只读真实源的阶段，但不能用永久missing/unsupported替后续全FR实现。若真实metadata扩展是首条正确写入链的必要前置，应如实先排该扩展，不为最易通过而坚持一条值编辑切片。

**S2原唯一plan的持久绑定。** sourceBinding由S1真实源产生，覆盖原public/internal/ref/vector/control、真实metadata/缺失材料及schema/投影/适配版本。纳原job_plans.payload版本化envelope、独立previewHash命名域、planRef、参数与原confirmation/Job/context/receipt；原storePreviewIdentity不改名混域，不添第二plan/receipt账本。preview保存、confirm签发、Job接收claim、commit写入各原外层真实事务中复验当前source/proof；不能包装层核后跨await/事务调用旧方法。Diff完整页/cursor与proof同版，多个匹配plan/proof歧义拒绝，不扫第一项即用。旧版本/旧receipt历史安全兼容或明确拒绝，已提交后当前metadata变化不抹历史真提交；新提交/undo另取当前proof。

**执行前计费与持久增长。** 给固定实际调用图cost profile及式子/版本、精确hook位置，先于T02 Snapshot/validate/bind/change_preview和每个T01旧helper解析/复制/历史/旧plan/blob/页扫描执行。整链共享累计预算，失败不退工作，实际结束才释放保留，重复页/旧helper重复SQL工作不能只靠唯一行字节去重覆盖。沿T02拟保护值与实际更紧canonical/ReadLimits交集评估，证明至少完整正例能真走完；若不够，应给可审的必要meter/工程界修订依据而非实现成全拒绝。原preview/confirm可持久artifact，首写前计全plan/blob/cursor/Job/history增长，单事务失败零部分artifact/域写，成功旧历史与receipt不能删。不得猴补旧函数或事后追账。

给准确拟写新/旧路径、唯一owner、固定采用ref/path/bytes/SHA、完整依赖闭包、版本/schema/兼容策略、实施顺序与真实临时JobStore3矩阵。候选S1新增ontology_projection.py+专测可独立先行；S2新增ontology_changesets.py+专测及domain_changesets/job_store必要delta必须实列，transactions/canonical/metadata旧路径若需改逐项申请。T02 adapter只产原changeSetPlan，不直写SQL/Store/confirm；维护权不转，接口请求由根路由，不擅自发别的聊天任务。

验收计划必须从真实T01 source→T02真实change_preview→typed adapter→原preview/全Diff→显式机制确认→Job→全量读回/undo，原ID与全部支持/RDF/metadata/control/vector完整核。覆盖同revision proof/metadata缺失材料/派生policy/vector/control在各真实事务漂移、queued后变更、坏proof/歧义plan/旧cursor、已提交后源变化的历史receipt、mapped/多支持/metadata-only/完整非RDF字段、取消/失败/响应丢失/重开/不相交undo，以及每项预算±1/首次旧函数尚未进入/重复失败累计。fixture人类确认与生产当前scope/真实人类分别标；正式位置/native/公开桥/目标OS后置但不豁免。

方案经独立agent实质审查和反例处置，冻结docs/ref/manifest交根，再分别批准实际S1/metadata/S2/T02消费代码窗口。当前只文档格式/Git/hash/静态源读取，不跑产品/tests/DB/子进程/native/GUI/HMR/模型，不推送PR合并，不更改默认格式或公共注册。完整FR200–204、57P0/C–G/PRD10–12、目标双OS/真人/指定同版双审/CI/正常develop合并与远端门保持。
