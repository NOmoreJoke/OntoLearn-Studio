# T02→T01 typed ChangeSet 集成方案：总控独立审查

2026-10-21。结论：固定修订方案4406103及最终交付d597b3c的方案质量可接受，未发现需退回T02再修的新增阻断。原两项P2在**方案层**闭合：来源证明进入T01原持久plan并贯穿各真实事务；预算先于旧函数执行保守预扣。不能直接批准T02两个新writer开工，更不能标完整T02通过。最小有实际价值的后续实施应先由T01冻结S1投影/metadata缺失政策及预算合同，再精确批准S1只读供应实件；S2原链版本扩展完成后才批准T02适配和完整临时Job链。

本审唯一写本报告。仅Git/文件/stdlib JSON/AST/hash静态读取；不import/执行产品、测试、构建、GUI/native/HMR/模型，不向开发聊天发消息，不写共享state或owner证据/Goal。下文函数行为是固定源码静态证据，运行验收全部仍将来待执行。34项来源逐hash并不等于本审全文审完全部源码、测试和PRD。

## 1. 固定版本、完整交付与保护原件

已全文读取根准备授权4421B/SHA256 `1df025397031187df021041560153d0e78636689730db9bcba64c65b7c6fdebc`。本次实际树 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/T02-ontology`，当前HEAD `d597b3c00980652042163d250c875d660d4d371e`，根原产品493及原过程b54不变。

| 对象 | 实际固定身份 |
| --- | --- |
| 初版方案 | 64bbfe27a2191e65e8e81ab34862b9867e46a034；36337B/e33e3a165c62ba4017b8c85da11bdbc040b375aec8007d33e387f41a37a4e1b3 |
| 两P2修订 | 4406103ac309b21ddabb5f99b3efd11265acb64f |
| 主方案/最终独审等九件固定docs | 4229214e95d1407f0dbdcb93317d480b2e7cb59b |
| 追加delivery manifest后的交付HEAD | d597b3c00980652042163d250c875d660d4d371e |
| 最终主方案 | 44243B/SHA256 `6b88b1f7a8e9b7b08719f6b48dda16905a3eb800a7b8baef21f4b7a26b06983c` |
| source-manifest | 17269B/7b5bfa123871e4985b667ddd50b341de51ce90aac042f703cdf12ec793119894 |
| delivery-manifest | 4555B/f5a9ac444246b0ade3ec4f556a93aa3b5029c28d5a4f951839464e427147378b |

主方案184行已分段全文读取。初审2458B/22e607…、复审1116B/e6ed21…及处置1484B/619b81…均全文读回。初审准确保留64bb“不通过/两P2”，没有把原行号套到当前修订；复审准确只对4406103方案质量通过，未冒称实施或产品运行通过。

本审对delivery列出的9件逐当前bytes/SHA与其4229214 Git blob核同；额外delivery本件在d597固定，不自引hash。实际b54→d597恰10新增doc（主说明+九review文件），全部在根唯一授权目录；没有product/tests/scripts/apps旧文件变化，没有修改旧status。原source-manifest和intake自初审到当前相同。初版review-input的36337B/SHA也从真实64bb Git重算匹配，不倒贴新版。

受保护AGENTS15852B/78df2825…、两PNG293943B/4dd1d541…和269334B/87944618…逐当前匹配intake；实际status仍只有AGENTS未暂存和这两张未知PNG未跟踪，均未stage。本审不将两PNG当本次交付或新UI证据。

## 2. 固定来源与静态闭包

逐34项读current bytes/hash及固定ref Git blob，全部一致；5控制输入hash也全同，包括根授权、readiness、Q6采纳回执/决定和共同指令。T02固定49321221733ea927484647352e05e7d833cebc86，T01固定423b7e4c799f188cf2ce6e8e7121893ce85624cd，环境固定批准5f910b52c69d86a1076b2032e5d3c63e715947f3。没有用T01可变HEAD替来源。

34项组成：14 T01本地Python闭包、5 canonical/resources、4 T02 editor、4 T01参考、4环境、3 T02参考。独立用stdlib AST从job_store/project_host/domain_changesets三个seed沿绝对/相对/晚导入及parent packages重新遍历，实际本地闭包恰14，清单无缺漏或多列。canonical通过实际contract_v2/schema/registry/errors和invalidation资源另列。此证明静态本地闭包，**不是动态导入、第三方发行data、实际包/PYZ或未来供应代码闭包证明**；供应版本变化必须更新采用清单。参考测试/说明不自动变运行helper。

本审全文读T02 model/service/source_projection三件、T01 transactions/rdf_snapshot两件；并定点读T01 domain_changesets的supported/preview/_envelope/_verify_plan/accepted_plan/commit、JobStore确认/接收/commit、project_host ReadLimits/workspace、Store snapshot/_snapshot_state及实际changeSetPlan schema。未把87KB JobStore/76KB Store整件hash当全部代码逻辑已审。

## 3. 真实生产输入、原ID与首切片可表达性

T02 `change_preview`实际签名支持remove_facts/add_facts；它先校验原Snapshot，再构造真实candidate、完整RDF集合差、base_digest和Entity变化。方案§4从该真实调用产出Preview，纯适配才形成原`edits[record_id]=newObject`，没有手填plan/expected替生产，也没有第二commit/Job/确认入口。

方案选择“已有individual的一条manual dataProperty事实对象变化”，不是笼统类/属性全保存。恰一removed+一added、同S/P不同O、无Entity变化、其它完整字段相同；旧语句恰一人工fact支持、同slot无其它活动事实、无definition重叠、新语句无已有支持，再从真实StatementSource定位原ID。这样不从无序RDF差集猜配对，不会以RDF集合去重抹去支持。

实际Store._snapshot_state保ID跨对象编辑/墓碑；其ID只要求唯一非空，但typed schema edits propertyNames要求64位小写hex。因此“当前源可能合法但ID不符合typed hash便拒绝、绝不换ID”准确；已有符合形状却非当前S/P/O内容hash的原ID仍必须保持。新增的digest规则不用于本次编辑ID。T02 Fact无recordID，故必须使用真实供应/BoundRdfProjection，而不能用新object哈希重算。

T01 supported88–127只允许触及ontology payload的triples/singleValuedPredicates/references与三个归属字段均None的manual fact。mapped、override、墓碑、多重支持不能通过removed_sources直接删或伪装manual。方案保留无关且可完整投影的数据，无法完整投影/证明的整批拒绝；没有将未知字段静默丢弃再宣称完整图相等。

T02 Entity的identifier确实强制非空模式，labels/definitions只(text,language)，事实限制已声明property/individual和允许datatype，BNode拒绝。源中的多角色、typed label/comment及其它完整RDF可能不可表示，这是现有模型真实边界。方案明确完全可投影才入选，保持owl:Class/rdfs:Class原声明，不把IRI/localName当definition ID，不将project-level名称metadata当Entity元数据。首切片不修改结构定义/singleValuedPredicates/reference；父需求未消失。

## 4. metadata与来源证明：P2-1方案闭合

初审指出的缺口成立：现423b ChangePreview.identity只绑定plan/before/after/control/intent等，不自动绑定独立metadata来源、派生政策和完整当前vector；_envelope503起扫描第一项匹配、_verify_plan的旧字段集和参数blob也没有新proof。直接包一次preview不能保证确认/queued→commit时同revision漂移被拒绝。

修订§4.70–82明确：

- 真实S1在同一连接/一致读获得public/internal关联、sourceRef/vector/control及metadata内容或确证缺失材料，源hash只证完整性、不授当前权限。
- 新proof保存在T01原job_plans.payload的版本化envelope内，previewHash另命名绑定storePreviewIdentity+sourceBinding；preparedPlanRef是完整envelope摘要，原parameters/confirmation/Job/context/receipt继续沿这一个绑定，不新建表/可变意图账本。
- preview保存前、confirm签发前、Job接收claim前及最终commit写前均在各自原真实外层事务重读复验，不能包装层检查后跨await/事务调用旧方法。排队之后来源变化仍拒绝；旧分页cursor不能确认新proof，重复歧义匹配拒绝。
- 已提交后的历史receipt校验原历史proof，不能因当前metadata变化就把真提交改叫未发生；新提交/undo使用新当前proof，undo目标旧proof仍仅证明历史。

这些要求足以关闭原P2的**设计遗漏**。它们尚无实现：旧accepted_plan(host=None)在commit分支不自行核完整当前metadata/vector，ProjectTransactions.commit只复验state/control。修订没有假称旧423b本身已满足。T01 S2必须实际扩展domain_changesets/job_store和相应原严格validator/fixtures；若需transactions/canonical改动必须单列，不能只准新增wrapper而省掉原链。

派生identifier `v_`+IRI UTF8 hex是待T01/root决定的显示政策，不是现权限/正式英文标识存储。synonyms/examples空值只可来自完整源“确证不存在”，未知opaque字段不能按空。派生长度仍受原模型和拟bytes预算，不能为了能投影给任意大IRI放宽。T01不接受absence/派生政策时，必须先有唯一metadata版本化扩展；T02无权自造RDF词汇。该分支准确保留了真实缺口。

S1供应合同必须明确“缺失证明”覆盖哪些真实持久位置、哪些schema版本与不认识的payload如何拒绝；不能实现为caller传metadataComplete=true。S2还须冻结新envelope/previewHash namespace、v1兼容或安全拒绝、旧receipt历史读取和newproof cursor规则。上述是修订已明示的实施前供方交付，不是本审新增已发现产品缺陷。

## 5. 执行前预算：P2-2方案闭合但实施门仍在

旧T02 Triple创建、validate/rdf_triples、change_preview、bind_rdf_projection都会重复term解析、canonical/asdict和全量集合构造；旧T01 _envelope读取所有plan、_verify_plan/分页/confirm再次验证旧blob/历史。只在adapter返回时检查输出大小无法约束这些先发生的工作，初审P2成立。

修订§7明确在首个Snapshot/bind/change_preview之前建立整次预算：SQL先界原bytes/rows/历史，再有界解码，逐固定调用图保守预扣所有解析次数/字节、完整副本和保留池；失败不返工作，释放仅回真实结束的保留槽；旧函数内部重复不能藏在“新增比较最多4次”中。最多64次page调用和一次preview/确认成功/Job接收/commit，失败重试仍消费同交互预算；undo是明确新操作。无法由有界实际输入保守预扣的旧函数，须先批准必要meter writer，不猴补、不事后补计。

source≤1MiB/4096records/8192supports、1MiB结果、8MiB编码保留与64MiB-work等是待审工程拒绝上限，与实际ReadLimits/canonical更紧值取交；不是Q5容量/毫秒/RSS或新的Q6类型限制。完整库仍沿validation_bytes/work独立收费，不把source cap当全库上限；preview持久artifact与最终domain写分开计，单次事务失败零部分artifact、先前成功artifact可保留但要有限清理，不能泛称所有preview全库不变。

因此P2-2在方案层可关闭；**数值表不是已冻结cost profile/实现证明**。T01必须交逐实际ref可核的成本函数/调用次数/原hook位置，含失败/重复页/旧plan/历史与写入增长。首正例也要证明预算内可真正走完，不能最后实现成所有非空项目都拒绝。若meter扩展必要，原“两新T02 writer”窗口明确不足，按修订§7.145重新精确申请原T02三文件或T01原链writer；不能默许。

## 6. 真实确认/Job/undo及全FR边界

方案要求读全原segment/manifest、顺序/offset/rawByteLength/hash/base64并拼完整UTF8后解码，防分块切多字节；T02语义Diff不能替原record Diff。末页完成不是人类确认；T02/Agent不得自动confirm。临时库显式fixture确认只证机制，真实人类/host/current_scope/App另验。

确认结果的snapshot/parameters/planRef逐值交原create_changeset_job，实际start→commit_job→原commit.receipt.v1/marker/resultRef。implementation/limits必须同版批准，不能抄旧IMPL占位。queued/running/已提交边界、响应丢失按原operation/Job/receipt只读对账、unknown不当未提交，都保留。undo走原真实impact→机制确认→Job，保不相交后续修改；不伪造逆plan，不要求undo后revision/history回退或全库字节复原。

FR表未把首切片当全部本体：FR200全部概念/字段/引用、FR201结构/实例全操作、FR202真实三视图与可信分页、FR203完整Turtle与允许模板/列表/往返、FR204/T08真实草稿及人类确认分别列具体后续供方。S3完整Entity metadata/映射覆盖墓碑/多支持选择、S4当前scope/named桥/App、S5 Turtle/模板/可移植保留均未关闭。永久unsupported没有代替原P0。T01 canonical/Store/Job/project仍原owner，I05语义、I06能力与壳、T03build、T05模板、T10包未转责。

## 7. 最小可批准阶段与必要供方顺序

**现在可接受：本方案技术方向与明确供方请求。现在不可接受：直接授T02两writer/新树运行或称全T02完成。**它缺的是实际T01合同/实现，不应让T02再用合成supplier预填一个成功测试。

最小后续实现可分为下列有明确消费目标的依赖顺序，由根决定具体批准，不由本审派发：

1. **先冻结T01 S1/S2单一供方合同和cost profile。**输入固定423b14本地闭包及resources，明确metadata确证缺失/派生政策、同连接当前domain投影、完整支持/原IDs、sourceBinding版本和各原事务复验；所有预算先执行接点给实际代码位置。新采用清单必须由T01自己的固定ref和拟writer生成，34项来源表不是可直接复制的批准manifest。此步骤可沿原T01当前只读方案调查安全点办理，不争写C2。
2. **最小先行真实产品阶段是S1只读投影供方。**候选两个新writer为T01 `packages/engine/src/ontolearn_engine/project/ontology_projection.py` 与 `packages/engine/tests/test_project_ontology_projection.py`；旧project_host/Store变化须另授。已打开真实临时JobStore3、单次新只读事务、完整source/metadata/absence/支持及预算，authorizer禁写/完整dump/重开/同revision漂移/坏opaque/预算边界证明；不调用Store.snapshot、不新表/DDL、不授物理位置/公共读取。其输出必须直接符合后续实际T02 Snapshot生产与S2proof需要，不能再造无消费者的展示DTO。
3. **S2原链扩展与T02消费实际集成后续准入。**T01新ontology_changesets及专属test，加明确授权domain_changesets/job_store必需delta，transactions/canonical额外delta逐项申报；真实持久proof、各事务复验和预算实现固定/独审后，才准T02新typed_changeset_adapter与唯一集成test。新T02树从实际批准develop建立，精确只读采用新供方闭包，不wholecommit、不共享环境、不改冻结493。实际测试从S1真实当前源→T02真实change_preview→纯adapter→原preview/全Diff→fixture确认→Job提交→全量读回/undo，并逐阶段漂移/取消/损坏/响应丢失/预算前拒绝。机制临时库联验不是正式用户位置许可或完整FR通过。

S1可以先于生产native到位，但不能签发LocationLease/physical-binding或默认runtime3/ready。S2的持久proof扩展不是原423b零改即可复用；无论工程选择内部namespace如何命名，都必须保持唯一原plan/receipt/Store/Job与旧历史安全兼容/拒绝，不能通过第二DTO/boolean权限/第二账本规避。

最终57P0/C–G/PRD10–12、FR200–204、真实App/人类/两OS/原scope/完整Turtle、T08/T09/T10跨模块、指定GLM-5.3最高与M3.1-Flash xhigh同候选双方全新任务、所有意见、CI/正常develop合并及远端核验均保留。本轮产品运行/测试/双外审/推送/PR/合并新增0，Goal未改。
