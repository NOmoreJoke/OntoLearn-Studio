# T01 为 I05 供应真实受理、物料通道、来源与选择租期：合同准备

2026-10-22。继续同一原 T01 聊天和 Goal。已批准的 C2、dispatch 实现继续；本请求是独立 docs 子任务，不授新共享源码、schema、产品测试或依赖写权。可以由独立 agent 在新 docs 路径调查，避免与当前作者争写。原 C1/C2/dispatch、本体编辑方案及原件均保留。不要先完成整个 T01 才响应以下最小真实链请求，也不以临时第二 Store、意图表或调用者自签 receipt 代替唯一 owner。

## 固定输入与当前窗口

I05 最终方案在 `.worktrees/I05-profile-restore`，最终 docs ref `a3592837d854628948ef4c468b6c839f21763273`、主稿 ref `496f31a1eab57e7c8abf65ea200de8e3b895d17e`：`docs/iterations/I05/formal-producer-and-selected-integration-plan.md`，69523B/SHA256 `23a4ae9f7974185db61664fb1db892586140ea20995f1bb5950943717bd0ed4c`。请全文读取，尤其 §§4–8 的实际 capture、consumer U、角色流、持久来源、fullview 和累计费用。根独审 `I05-controller-formal-producer-selected-plan-prereview.md` 35841B/SHA256 `ac6934f2b2e842aad90cba252835629064ae4ee06452892f3f4f551a774c6909`，§7.5 为路由清单。原 SB/CPS/OL 阻断已在方案层关闭，不能算代码或真实 Job 验收已通过。

根已向原 I05 发出 `I05-producer-fullview-implementation-authorization.md`（9754B/SHA256 `2517a322ab2952c1a9444a6963fc790935240a158e0647ce7b2a706461e75031`），仅新树固定135采用及九 writer、完整139候选。其实现真实 codec、原唯一计算捕获、共用 decoder 的完整7/15/11只读恢复视图；暂不实现 Job/Store/selected/scopes 接线，不消费当前 T01/I06 WIP。原L、预算或前像不能从 payload 反推或 oracle 代供。

初始 resources 冲突已由根技术选择：采用固定 `3ef2f6952ed1a4f852da31c0bef7e8d8679752a5` 的2927B版，只加私有 `semantic_identity(profile)`；全局 IMPLEMENTATION、resource_manifest、LIMITS 保持原 i04。此选择仅初始内部组合，不提供正式每能力身份准入。T01 仍负责真实 per-capability resolver 及其来源与兼容校验；不要全局替换 health/startup 身份或复制一套常量。I05 输入清单只读，不授 resources 写权。

## S1：原受理与完整原始物料

从实际 `job_store.py` 的 create_job/_accepted_job、coordinator.dispatch、domain_changesets 以及现 Python/TS canonical/schema 切点说明最小私有受理。拟新 `project/profile_jobs.py` 仅建议，最终以实际路径清单为准。冻结 versioned semanticInput、完整 typed RuleSpec 保存/确认与原 producer input/source/definition material，绑定原 Job、operation、context、snapshot/vector/manifests、parser/options、policy、参数和可信 implementation。缺物料、未知 policy、跨 project/request 不一致必须有限失败，不倒填旧 context/claim。

所有 K（包括 K=0）都必须从当前 consumer 原 snapshot 固定独立 assertedRecords/ontologyRecords/input/source 的 U，与共享 definitions 的 D 分层；U不能借 producer 旧 input 或只靠 derived results 充图。按已审合同 U≤16MiB（input/source各8MiB）、D≤8MiB，实际源前门先界、再解码与复制并计费，不能先 `snapshot()` 造无界物料再收费。保存原序、SourceRecord/TermInput 全字段与 None、空串及语言拼写，实际 I05 codec 提供后按固定接口消费。

保持旧6字段 DTO/普通 Job/旧受理兼容；新合同先私有内部真实临时库链可验证。正式公开来源、原 dispatch/current_scope/位置权限仍由 I06 真 owner 给，不能因内部 fixture 被允许而公开默认放行。

## S2：同一 owned worker 的有限角色通道

只由 T01 维护 worker/coordinator，必要 `__main__.py`/私有 canonical delta 实列。按主稿 §8 lowercase hex phase/role 合同传真实 input/source/defs、producer capture、consumer U 与 metadata，不用多路假进程或 child 打开 Store。具体原合同为32768B raw块、65536B hex、header4096B加LF，总≤69633B，仍须与262144B帧共同实际证明；不要把单帧8MiB传输想象成已供应。

保原120s/512MiB及正常 complete+正常 child exit、取消、late/backpressure、frame完整性、ordinal/length/digest/终止等约束，所有传输、反编码、暂存、重复读取与并持计 T/S/H。旧 test.* 行为保持。不要借当前 dispatch 的 stop(void)/pending0/kill 返回证明永久释放。

## S3：唯一 Store 的原子来源和缓存角色

从 job_store/storage/format3 的真实事务提出 typed 私有 origin/ref 与可回收 role schema、唯一迁移、旧库读写兼容版本；建议 profile_artifacts 模块不自动授路径。完整保存原物料、原17L与预算/实现身份、来源和实际 original capture，原 immutable Job/context/claim/receipt/L 不 GC。最终 cancel/scope/权限 fence 和正常 child exit 之后，在同一原事务一次保存 artifact/origin/result/terminal；任一失败 rollback，无半结果或另一次补签。

公开 job_details/job_results/result_get/page 等白名单应完整列出，不能泄私有 ref、角色路径或权限材料。typed canonical 的长度、精确类型、字段历史与反复读取先计费；历史数据未知或损坏不能自动补可信来源。

## S4：完整选择、pin/GC 和不可重置累计费用

设计最小真实 open_profile_selection/close_profile_selection 接口：有序0..32 ids、重复拒绝，绑定 consumer 原 Job 的 U/D；逐原 result reader 供实际 B/Q、origin、原17L与原预算，不收 caller expected。先核真实权限再读内容，区分缺失、已回收、损坏、source missing、权限失败；保持 same snapshot/reasoning kind/available/重叠manifest及完整implementation相同门，旧普通 rows/page 兼容。

逐 artifact R_j 各按其原N≤100/17L发行一次，不能将 K*N 塞一池或重置累计费用。consumer 的非重置 Σcap/usage、C/T/S/H、实际 native/view/Graph 和 live-retired 并持逐一归真实 owner；ledger live0 不等于引用已释放。给 job/artifact/history/pin/retired 等有限工程 quota 的具体建议值、公式、来源与正常正例，交根明确批准后才实施；不要借 Q5 设业务用户容量默认值或擅改原17L。same Job 仅复用尚有效 handle；新合法 consumer Job 不能免费继承分配。

## S5：claim 对账和永久排空

在 C2 和 dispatch 已实际供应的有限事实基础上给最小接口，原 claim 发现须原 Job/context 互证，响应丢失/重开不能用 marker null 断言未受理。真实 create/resolve 权限不能从只读 C2 facts 或编造 authority 位生成。原 scope/current 权限及 physical binding 由 I06 唯一 owner 另供；明确 T01 所需固定接口，不让未回供成为内部正常 Job 链永远无法验证的理由。

所有 child/三管道/starting/timer/监听器/retired owner/native 的真实终态必须接入；超时、TTL、PID消失或kill返回均不能单独释放租期。给成功、取消、异常、响应丢失、重开、旧 artifact 退役的 ownership 转移与失败清理表，永久 drain 的完成条件与可读证据都要具体。

## 交付和后续批准

新过程只写 `docs/iterations/T01/profile-job-artifact-selection-supplier-plan.md` 和 `docs/reviews/T01/profile-job-artifact-selection-supplier-plan/`。先列实际 fixed ref/path/bytes/SHA、现有 helper 调用图、私有 schema/身份/旧历史兼容、必要新增/旧 writer、完整 adopted closure 和最小实施顺序。C2与dispatch在不同树已有授权，不复制其当前WIP；本体编辑7753666方案的 schema/job_plans/domain_changesets/resource identity 若有相同切点，给统一唯一 writer 序列及版本，不造平行迁移。固定前可读现源码，但不能宣称尚未冻结新实现可采用。

独立 agent 必须实质审来源、预算、持有与每个事务终态，给完整正常非空正例，以及K0/K1/K32、不同实际原N/disabled、错误类型/Unicode/最后字段、每预算差1/重复失败不退工作、损坏/权限/GC/pin/取消/响应丢失/重开、旧版本与多角色通道反例。保完整输入/原命令/首失败与真实双流，计划阶段不运行产品或造执行出口；冻结 docs commit、manifest、独审/处置和原件后交根，根再按精确路径逐段批准代码窗口与真正组合。

本请求无产品采用/写入、DB/test/native/build/GUI/模型网络/付费、push/PR/merge或 Goal 状态权。完整父 I05、57P0/C–G/PRD10–12、数学 M1/源包、两个目标OS/真人与指定同版双模型、CI、正常 develop 合并及远端核验均保持。接口请求由根路由，不擅自发其他聊天。
