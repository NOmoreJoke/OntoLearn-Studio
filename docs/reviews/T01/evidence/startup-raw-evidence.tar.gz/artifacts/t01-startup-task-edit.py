from pathlib import Path
p=Path('apps/desktop/src/main/engine.ts');s=p.read_text();a='export class EngineSupervisor {\n';assert s.count(a)==1;s=s.replace(a,a+'''  /** Runtime brand check: legacy transport adapters never acquire startup authority. */
  static owns(value: unknown): value is EngineSupervisor {
    return !!value && typeof value === 'object' && #origins in value
  }
''');p.write_text(s)
p=Path('apps/desktop/src/main/task-service.ts');s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a));s=s.replace(a,b)
rep('  safeError,','  safeError,\n  safeDisplayError,')
rep('  acceptsJobEvent,','  acceptsJobEvent,\n  acceptsBusiness3JobEvent,\n  validateBusiness3,')
rep("import type { EngineConnectionState } from './engine'", "import { EngineSupervisor, type EngineConnectionState } from './engine'")
rep('export class TaskService {','''export class TaskService {
  #supervisor?: EngineSupervisor
  #caught = new WeakMap<object, SafeError>()
  private validate(name: string, value: unknown): boolean {
    return this.#supervisor?.profile === 'business3' ? validateBusiness3(name, value) : validateV2(name, value)
  }''')
rep('''  constructor(private engine: TaskEngine) {
    this.lastReadySession''','''  constructor(private engine: TaskEngine) {
    this.#supervisor = EngineSupervisor.owns(engine) ? engine : undefined
    this.lastReadySession''')
rep('''  private connectionChanged(event: EngineConnectionState): void {
    if (''','''  private connectionChanged(event: EngineConnectionState): void {
    if (this.#supervisor && event.state === 'disconnected') {
      const issued = this.#supervisor.projectConnectionFailure(event)
      if (!issued) return
      event = issued
    }
    if (''')
s=s.replace("!validateV2('error', event.error)","!this.validate('error', event.error)")
s=s.replace('safeError(event.error)','safeDisplayError(event.error)')
s=s.replace('error: safeError(recovery.error)','error: safeDisplayError(recovery.error)')
s=s.replace('''    if (!validateV2(`params_${method}`, params))''','''    if (!this.validate(`params_${method}`, params))''')
rep('''    const result = await this.engine.request(method, params)
    if (generation !== this.generation)''','''    const operation = this.engine.request(method, params)
    let result: unknown
    try { result = await operation } catch (cause) {
      if (generation !== this.generation) throw { error: denied }
      if (this.#supervisor) {
        const token = Object.freeze({})
        this.#caught.set(token, this.#supervisor.projectFailure(cause, operation))
        throw token
      }
      throw cause
    }
    if (generation !== this.generation)''')
s=s.replace("validateV2('result_job.subscribe', result)","this.validate('result_job.subscribe', result)")
s=s.replace('!validateV2(`result_${method}`, result)','!this.validate(`result_${method}`, result)')
rep('''      return { ok: false, error: safeError((error as { error?: unknown } | null)?.error) }''','''      const authenticated = error && typeof error === 'object' ? this.#caught.get(error) : undefined
      return { ok: false, error: authenticated ? safeDisplayError(authenticated) : safeError((error as { error?: unknown } | null)?.error) }''')
s=s.replace("!validateV2('notification', value)","!this.validate('notification', value)")
s=s.replace('!acceptsJobEvent(value, watch.binding)',"!(this.#supervisor?.profile === 'business3' ? acceptsBusiness3JobEvent(value, watch.binding) : acceptsJobEvent(value, watch.binding))")
p.write_text(s)
p=Path('apps/desktop/src/main/index.ts');s=p.read_text();a='''      dataPath: fixture?.databasePath ?? join(app.getPath('userData'), 'engine.sqlite'),''';assert s.count(a)==1;s=s.replace(a,"      profile: !app.isPackaged && process.argv.includes('--t01-internal-business3') ? 'business3' : 'legacy2',\n"+a)
a='''    try {
      return { ok: true, data: await supervisor.health() }
    } catch (error) {
      return { ok: false, error: safeError((error as { error?: unknown } | null)?.error) }
    }''';assert s.count(a)==1;s=s.replace(a,'''    const operation = supervisor.health()
    try {
      return { ok: true, data: await operation }
    } catch (error) {
      return { ok: false, error: supervisor.projectFailure(error, operation) }
    }''');p.write_text(s)
p=Path('apps/desktop/src/renderer/src/task-presentation.ts');s=p.read_text();s=s.replace('import { safeError,','import { safeDisplayError,');s=s.replace('const error = safeError(value)','const error = safeDisplayError(value)');a="    case 'permission.denied':";assert s.count(a)==1;s=s.replace(a,'''    case 'project.formatUnsupported':
      return { ...base, what: '项目格式暂不受支持。', why: '当前内部引擎不能打开此项目格式。', fix: '保留项目文件并使用兼容版本后重新检查。' }
'''+a);s=s.replace("what: '本地引擎连接已中断。',","what: '本地引擎当前不可用。',");p.write_text(s)
