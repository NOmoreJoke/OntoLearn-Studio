const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const root = process.cwd();
const ts = require(path.join(root, 'node_modules/typescript'));
const asar = require(path.join(root, 'node_modules/@electron/asar'));
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
const identity = b => ({bytes:b.length, sha256:digest(b)});
const resources = path.join(root, 'release/mac-arm64/OntoLearn Studio.app/Contents/Resources');
const main = fs.readFileSync(path.join(root, 'apps/desktop/out/main/index.js'));
assert.deepEqual(asar.extractFile(path.join(resources, 'app.asar'), 'out/main/index.js'), main);
// Parse only the data literal. No evaluation of the bundle or Electron handlers.
const ast = ts.createSourceFile('main.js', main.toString('utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
const declarations = new Map();
for (const statement of ast.statements) {
  if (ts.isVariableStatement(statement)) {
    for (const d of statement.declarationList.declarations) {
      if (ts.isIdentifier(d.name) && d.initializer) declarations.set(d.name.text, d.initializer);
    }
  }
}
function literal(node, stack = new Set()) {
  if (ts.isStringLiteral(node) || ts.isNumericLiteral(node)) return ts.isNumericLiteral(node) ? Number(node.text) : node.text;
  if (node.kind === ts.SyntaxKind.TrueKeyword) return true;
  if (node.kind === ts.SyntaxKind.FalseKeyword) return false;
  if (node.kind === ts.SyntaxKind.NullKeyword) return null;
  if (ts.isArrayLiteralExpression(node)) return node.elements.map(x => literal(x, stack));
  if (ts.isObjectLiteralExpression(node)) {
    const result = {};
    for (const property of node.properties) {
      if (ts.isShorthandPropertyAssignment(property)) result[property.name.text] = literal(property.name, stack);
      else {
        assert(ts.isPropertyAssignment(property));
        assert(ts.isIdentifier(property.name) || ts.isStringLiteral(property.name) || ts.isNumericLiteral(property.name));
        result[property.name.text] = literal(property.initializer, stack);
      }
    }
    return result;
  }
  if (ts.isIdentifier(node)) {
    assert(!stack.has(node.text), 'data literal cycle');
    assert(declarations.has(node.text), 'missing top level data literal');
    return literal(declarations.get(node.text), new Set([...stack, node.text]));
  }
  throw new Error('Non-data AST node: ' + ts.SyntaxKind[node.kind]);
}
const registry = fs.readFileSync(path.join(root, 'packages/contracts/v2/registry.json'));
assert(declarations.has('registry_default'));
assert.deepEqual(literal(declarations.get('registry_default')), JSON.parse(registry));
const bindings = [];
for (const name of fs.readdirSync(path.join(root, 'packages/contracts/v2')).filter(x => x.endsWith('.json')).sort()) {
  const source = fs.readFileSync(path.join(root, 'packages/contracts/v2', name));
  assert.deepEqual(fs.readFileSync(path.join(resources, 'contracts/v2', name)), source);
  assert.deepEqual(fs.readFileSync(path.join(resources, 'engine/_internal/contracts/v2', name)), source);
  bindings.push({path:'v2/'+name,...identity(source)});
}
const helper = fs.readFileSync(path.join(root, 'packages/contracts/python/contract_v2.py'));
assert.deepEqual(fs.readFileSync(path.join(resources, 'engine/_internal/contracts/python/contract_v2.py')), helper);
const lock = fs.readFileSync(path.join(root, 'uv.lock'));
assert.deepEqual(fs.readFileSync(path.join(resources, 'engine/_internal/provenance/uv.lock')), lock);
const executable = fs.readFileSync(path.join(resources, 'engine/ontolearn-engine'));
assert.deepEqual(executable, fs.readFileSync(path.join(root, 'build/engine/ontolearn-engine/ontolearn-engine')));
const result = {scope:'Static actual asar/compiled constant/resource equality; no Electron handler or desktop executed', compiledMain:{...identity(main),asarExact:true},compiledRegistryBinding:'registry_default',registryHash:digest(registry),resources:bindings,helper:identity(helper),lockSHA256:digest(lock),engineExecutableSHA256:digest(executable)};
fs.writeFileSync(process.argv[2], JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify(result)+'\n');
