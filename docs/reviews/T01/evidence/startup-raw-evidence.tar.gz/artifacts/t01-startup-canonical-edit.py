import json, hashlib, copy
from pathlib import Path
root=Path('packages/contracts/v2')
def load(n): return json.loads((root/(n+'.json')).read_text())
def save(n,v): (root/(n+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
d=load('schema'); e=load('errors'); r=load('registry'); f=load('fixtures'); b=load('binding-regressions')
empty={'type':'object','properties':{},'required':[],'additionalProperties':False}
formats={'type':'object','properties':{'supportedFormats':{'type':'array','items':{'const':3},'minItems':1,'maxItems':1}},'required':['supportedFormats'],'additionalProperties':False}
busy={'type':'object','properties':{'retryAfterMs':{'const':250}},'required':['retryAfterMs'],'additionalProperties':False}
specs={
 'PROJECT_FORMAT_UNSUPPORTED': {'messageKey':'project.formatUnsupported','retryable':False,'paramsSchema':formats},
 'STORAGE_BUSY': {'messageKey':e['codes']['STORAGE_BUSY']['messageKey'],'retryable':True,'paramsSchema':busy},
 'STORAGE_FAILURE': {'messageKey':e['codes']['STORAGE_FAILURE']['messageKey'],'retryable':False,'paramsSchema':empty},
 'INTERNAL_ERROR': {'messageKey':e['codes']['INTERNAL_ERROR']['messageKey'],'retryable':False,'paramsSchema':empty},
}
e['startup']={'diagnosticVersion':1,'profile':'business3','maxPayloadBytes':1024,'codes':specs}
d['$defs']['error_startup']={'oneOf':[{'type':'object','properties':{'code':{'const':code},'messageKey':{'const':v['messageKey']},'retryable':{'const':v['retryable']},'params':v['paramsSchema']},'required':['code','messageKey','retryable','params'],'additionalProperties':False} for code,v in specs.items()]}
d['$defs']['startupFailure']={'type':'object','properties':{'kind':{'const':'startupFailure'},'diagnosticVersion':{'const':1},'engineSessionId':{'const':None},'registryHash':{'$ref':'#/$defs/hash'},'error':{'$ref':'#/$defs/error_startup'}},'required':['kind','diagnosticVersion','engineSessionId','registryHash','error'],'additionalProperties':False}
r['startupDiagnostic']={'diagnosticVersion':1,'profile':'business3','phase':'pre-hello-only','schema':'#/$defs/startupFailure','errorSchema':'#/$defs/error_startup','maxPayloadBytes':1024,'payloadLength':'raw-before-CR-removal-excluding-LF','singlePerAttempt':True}
save('schema',d); save('errors',e); save('registry',r)
# Actual hash must be refreshed after final prettier / profile transition.
