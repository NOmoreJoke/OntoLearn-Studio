"""No-window test harness: resource identity and real packaged stdio only."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import tempfile
from uuid import uuid4

root=Path.cwd(); executable=Path(sys.argv[1]).resolve(); report_path=Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('probe_contract',root/'packages/contracts/python/contract_v2.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
registry_hash=hashlib.sha256((root/'packages/contracts/v2/registry.json').read_bytes()).hexdigest()
def raw(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode()}
env={k:v for k,v in os.environ.items() if k in {'HOME','TMPDIR','TMP','TEMP','LANG','LC_ALL','LC_CTYPE','TZ','SystemRoot','WINDIR'}}
manifest_process=subprocess.run([str(executable),'--protocol-resources'],capture_output=True,env=env,timeout=20)
assert manifest_process.returncode==0,manifest_process.stderr
manifest=json.loads(manifest_process.stdout);assert manifest['frozen'] is True
expected_resources={'python/contract_v2.py':hashlib.sha256((root/'packages/contracts/python/contract_v2.py').read_bytes()).hexdigest()}
expected_resources.update({'v2/'+p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'packages/contracts/v2').glob('*.json')})
assert manifest['resources']==expected_resources and manifest['registryHash']==registry_hash
assert manifest['implementation']['dependencyLockHash']==hashlib.sha256((root/'uv.lock').read_bytes()).hexdigest()
report={'scope':'No Electron/desktop launch. Actual unsigned packaged engine resources, SQLite, worker and stdio.','executable':str(executable),'executableSHA256':hashlib.sha256(executable.read_bytes()).hexdigest(),'manifestProcess':{'returncode':manifest_process.returncode,'stdout':raw(manifest_process.stdout),'stderr':raw(manifest_process.stderr)},'manifest':manifest,'sessions':[]}
class Session:
 def __init__(self,database,profile,project=None,test_mode=False):
  self.profile=profile;self.version=3 if profile=='business3' else 2;self.sent=[];self.received=[];self.session=None
  local=dict(env,ONTOLEARN_DB_PATH=str(database),ONTOLEARN_ALLOWED_PROJECTS=json.dumps([project] if project else []))
  if test_mode:local['ONTOLEARN_TEST_MODE']='1'
  self.process=subprocess.Popen([str(executable)]+(['--t01-internal-profile=business3'] if self.version==3 else []),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=local)
  self.selector=selectors.DefaultSelector();self.selector.register(self.process.stdout,selectors.EVENT_READ)
  self.hello=self.call('hello',{'supportedVersions':[self.version],'clientId':str(uuid4())})
  assert self.hello['selectedVersion']==self.version and self.hello['registryHash']==registry_hash
 def read(self):
  assert self.selector.select(12),'packaged stdout timed out'
  line=self.process.stdout.readline(262146);assert line and line.endswith(b'\n') and len(line)<=262145,line
  self.received.append(line);return json.loads(line)
 def call(self,method,params):
  request={'kind':'request','protocolVersion':2 if method=='hello' else self.version,'id':str(uuid4()),'engineSessionId':None if method=='hello' else self.session,'method':method,'params':params}
  assert (C.validate_business3 if self.version==3 else C.validate)('request',request)
  b=json.dumps(request,separators=(',',':')).encode()+b'\n';self.sent.append(b);self.process.stdin.write(b);self.process.stdin.flush()
  while True:
   value=self.read()
   assert (C.validate_business3 if self.version==3 else C.validate)('envelope',value),value
   if value['kind']=='notification':continue
   assert value['id']==request['id'] and value['method']==method,value
   assert value['ok'],value
   if method=='hello':self.session=value['engineSessionId']
   else:assert value['engineSessionId']==self.session
   return value['result']
 def close(self,label):
  self.process.stdin.close();self.process.wait(timeout=12);remaining=self.process.stdout.read();stderr=self.process.stderr.read();self.selector.close()
  if remaining:self.received.extend(remaining.splitlines(keepends=True))
  assert self.process.returncode==0,(self.process.returncode,stderr)
  assert not stderr,stderr
  report['sessions'].append({'label':label,'profile':self.profile,'returncode':self.process.returncode,'stdin':raw(b''.join(self.sent)),'stdout':raw(b''.join(self.received)),'stderr':raw(stderr)})
with tempfile.TemporaryDirectory(prefix='t01-packaged-') as temporary:
 directory=Path(temporary)
 for profile in ['legacy2','business3']:
  s=Session(directory/(profile+'.sqlite'),profile);assert s.call('health',{})=={'status':'ok','engineVersion':s.hello['engineVersion']};s.close(profile+'-health')
 future=directory/'future.sqlite'
 import sqlite3
 with sqlite3.connect(future) as db:db.execute('PRAGMA user_version=4')
 failure=subprocess.run([str(executable),'--t01-internal-profile=business3'],input=b'',capture_output=True,env=dict(env,ONTOLEARN_DB_PATH=str(future)),timeout=12)
 assert failure.returncode==1 and failure.stderr==b'' and failure.stdout.endswith(b'\n')
 payload=failure.stdout[:-1];diagnosis=json.loads(payload)
 assert b'\n' not in payload and C.validate_startup_failure(diagnosis,len(payload),registry_hash)
 assert diagnosis['error']==C.startup_error('PROJECT_FORMAT_UNSUPPORTED',{'supportedFormats':[3]})
 with sqlite3.connect(future) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==4
 report['sessions'].append({'label':'future-format-safe-failure','returncode':failure.returncode,'stdout':raw(failure.stdout),'stderr':raw(failure.stderr)})
 # Prepare through the same source Store3; the actual packaged coordinator/worker publishes the commit.
 sys.path.insert(0,str(root/'packages/engine/src'))
 from ontolearn_engine.job_store import JobStore
 from ontolearn_engine.resources import CONTRACT
 database=directory/'atomic.sqlite';project=str(uuid4());store=JobStore(database,contract=CONTRACT,target_format=3)
 store.create_project(project);snapshot=store.project_get(project);parameters=store.put_blob(project,{'workMs':50})
 prepared=store.prepare_plan(project,snapshot['projectRevision'],{'definitions':[{'layer':'rule','id':'packaged-startup3','value':{'enabled':True}}]},actor=str(uuid4()),permission='write');store.close()
 params={'projectId':project,'operationId':str(uuid4()),'capability':'test.atomic','input':{'inputSnapshotId':snapshot['inputSnapshotId'],'scope':'asserted','definitionId':'probe','parametersHash':parameters,'derivedResultIds':[],'preparedPlanRef':prepared['preparedPlanRef']},'confirmationRef':prepared['confirmationRef']}
 s=Session(database,'business3',project,True);assert s.call('project.get',{'projectId':project})['formatVersion']==3
 job=s.call('job.create',params);s.call('job.subscribe',{'projectId':project,'jobId':job['jobId']})
 import time
 deadline=time.monotonic()+10
 while time.monotonic()<deadline:
  job=s.call('job.get',{'projectId':project,'jobId':job['jobId']})
  if job['state'] in {'succeeded','failed','cancelled'}:break
  time.sleep(.01)
 assert job['state']=='succeeded',job
 assert s.call('job.create',params)['jobId']==job['jobId']
 assert s.call('result.get',{'projectId':project,'resultId':job['resultRef']['resultId']})['inputSnapshotId']==snapshot['inputSnapshotId']
 assert s.call('project.get',{'projectId':project})['projectRevision']==snapshot['projectRevision']+1
 s.close('real-packaged-coordinator-worker-atomic')
 s=Session(database,'business3',project,True);assert s.call('operation.get',{'projectId':project,'operationId':params['operationId']})['jobId']==job['jobId'];assert s.call('job.create',params)['jobId']==job['jobId'];s.close('packaged-reopen-operation-idempotency')
 with sqlite3.connect(database) as db:assert db.execute('SELECT count(*) FROM operation_claims WHERE operation=?',(params['operationId'],)).fetchone()[0]==1
 report['atomic']={'jobId':job['jobId'],'operationId':params['operationId'],'state':job['state'],'claims':1,'revisionDelta':1}
report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actualExecutable':str(executable),'resourceFiles':len(expected_resources),'registryHash':registry_hash,'sessions':len(report['sessions']),'atomic':report['atomic'],'reportBytes':report_path.stat().st_size,'reportSHA256':hashlib.sha256(report_path.read_bytes()).hexdigest()},ensure_ascii=False))
