import json, hashlib, copy, base64
from pathlib import Path
p=Path('packages/contracts/v2')
f=json.loads((p/'fixtures.json').read_text()); registry_hash=hashlib.sha256((p/'registry.json').read_bytes()).hexdigest()
old=f['business3']['registryHash']
def replace(v):
 if isinstance(v,list): return [replace(x) for x in v]
 if isinstance(v,dict): return {k:replace(x) for k,x in v.items()}
 return registry_hash if v==old else v
f['business3']=replace(f['business3'])
specs=json.loads((p/'errors.json').read_text())['startup']['codes']
errors=[]
for code,s in specs.items():
 params={'supportedFormats':[3]} if code=='PROJECT_FORMAT_UNSUPPORTED' else {'retryAfterMs':250} if code=='STORAGE_BUSY' else {}
 errors.append({'code':code,'messageKey':s['messageKey'],'retryable':s['retryable'],'params':params})
base={'kind':'startupFailure','diagnosticVersion':1,'engineSessionId':None,'registryHash':registry_hash,'error':errors[0]}
cases=[]
def add(name,v,valid=True): cases.append({'name':name,'value':v,'valid':valid})
for e in errors: add(e['code'],{**base,'error':e})
for k in base:
 v=copy.deepcopy(base); del v[k]; add('missing '+k,v,False)
for k,v in [('protocolVersion',2),('requestId','00000000-0000-4000-8000-000000000001'),('path','/private')]: add('extra '+k,{**base,k:v},False)
for k,v in [('kind','response'),('diagnosticVersion',2),('diagnosticVersion',True),('engineSessionId','00000000-0000-4000-8000-000000000001'),('registryHash','f'*64),('registryHash','A'*64)]: add('wrong '+k+str(v),{**base,k:v},False)
for key,v in [('supportedFormats',[2]),('supportedFormats',[3,2]),('actualFormat',4)]:
 e=copy.deepcopy(errors[0]); e['params']={key:v}; add('format params '+str(v),{**base,'error':e},False)
for e in [dict(errors[0],raw='secret'),dict(errors[0],retryable=True),dict(errors[0],messageKey='engine.internal'),dict(errors[1],params={'retryAfterMs':249}),dict(errors[2],params={'operationId':'00000000-0000-4000-8000-000000000001'})]: add('bad error '+str(len(cases)),{**base,'error':e},False)
raw=[]
def rawadd(name,s,valid=True,chunks=None):
 b=s.encode(); payload=b[:-1] if b.endswith(b'\n') else b
 raw.append({'name':name,'wireUtf8':s,'wireBase64':base64.b64encode(b).decode(),'wireBytes':len(b),'payloadByteLength':len(payload),'valid':valid,'chunksBase64':[base64.b64encode(c).decode() for c in (chunks or [b])]})
compact=json.dumps(base,ensure_ascii=False,separators=(',',':'))
for e in errors: rawadd('golden '+e['code'],json.dumps({**base,'error':e},ensure_ascii=False,separators=(',',':'))+'\n')
for n in [1023,1024,1025]:
 s=compact+' '*(n-len(compact.encode()))+'\n'; rawadd('payload '+str(n),s,n<=1024)
rawadd('2000 whitespace',compact+' '*2000+'\n',False)
rawadd('escaped same decoded',compact.replace('startupFailure','\\u0073tartupFailure')+'\n')
rawadd('CRLF',compact+'\r\n')
# CR is counted before removal: decoded object same, raw 1025 must reject.
rawadd('CR over boundary',compact+' '*(1024-len(compact.encode()))+'\r\n',False)
w=(compact+'\r\n').encode(); rawadd('split across chunks',w.decode(),True,[w[:5],w[5:len(w)-2],w[-2:-1],w[-1:]])
# JSON whitespace with split multibyte invalid field proves strict UTF8 parsing remains authoritative.
invalid=compact[:-1]+',"extra":"中文"}\n'; ib=invalid.encode(); split=ib.index('中'.encode())+1
rawadd('multibyte split invalid shape',invalid,False,[ib[:split],ib[split:]])
f['startup']={'registryHash':registry_hash,'diagnosticVersion':1,'maxPayloadBytes':1024,'errors':errors,'cases':cases,'raw':raw}
(p/'fixtures.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
b=json.loads((p/'binding-regressions.json').read_text())
b['startupBindings']=[
 {'name':'matching prehello internal3','profile':'business3','generation':2,'currentGeneration':2,'preHello':True,'alreadyReported':False,'expectedRegistryHash':registry_hash,'receivedRegistryHash':registry_hash,'eligible':True},
 {'name':'legacy2 cannot upgrade','profile':'legacy2','generation':2,'currentGeneration':2,'preHello':True,'alreadyReported':False,'expectedRegistryHash':registry_hash,'receivedRegistryHash':registry_hash,'eligible':False},
 {'name':'old generation','profile':'business3','generation':1,'currentGeneration':2,'preHello':True,'alreadyReported':False,'expectedRegistryHash':registry_hash,'receivedRegistryHash':registry_hash,'eligible':False},
 {'name':'posthello','profile':'business3','generation':2,'currentGeneration':2,'preHello':False,'alreadyReported':False,'expectedRegistryHash':registry_hash,'receivedRegistryHash':registry_hash,'eligible':False},
 {'name':'duplicate startup','profile':'business3','generation':2,'currentGeneration':2,'preHello':True,'alreadyReported':True,'expectedRegistryHash':registry_hash,'receivedRegistryHash':registry_hash,'eligible':False},
 {'name':'wrong hash','profile':'business3','generation':2,'currentGeneration':2,'preHello':True,'alreadyReported':False,'expectedRegistryHash':registry_hash,'receivedRegistryHash':'f'*64,'eligible':False},
]
(p/'binding-regressions.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print(registry_hash,len(cases),len(raw))
