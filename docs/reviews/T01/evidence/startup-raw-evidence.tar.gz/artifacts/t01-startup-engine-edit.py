from pathlib import Path
p=Path('apps/desktop/src/main/engine.ts');s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
rep("import { resolve, join } from 'node:path'", "import { resolve, join, dirname, isAbsolute } from 'node:path'")
rep("import { type EngineHealth } from '@ontolearn/contracts'", "import { safeError, safeBusiness3Error, safeStartupError, type SafeError, type EngineHealth } from '@ontolearn/contracts'")
rep("import { matchesResponse, validateV2, v2Registry } from '@ontolearn/contracts/v2'", "import { matchesResponse, matchesBusiness3Response, validateBusiness3, validateStartupFailure, validateV2, v2Registry } from '@ontolearn/contracts/v2'")
rep("  selectedVersion: 2\n", "  selectedVersion: 2 | 3\n")
rep("  expectedRegistryHash: string\n", "  expectedRegistryHash: string\n  profile: EngineProfile\n  startupPromise: Promise<Session>\n  resolveStart(session: Session): void\n  rejectStart(error: EngineError): void\n  startupCause?: EngineError\n")
rep('export interface SupervisorOptions {', "export type EngineProfile = 'legacy2' | 'business3'\ninterface FailureOrigin {\n  session: Session\n  profile: EngineProfile\n  generation: number\n  preHello: boolean\n  startupPromise: Promise<Session>\n  provenance: 'startup3' | 'business3' | 'business2' | 'local'\n  value: SafeError\n}\nexport interface SupervisorOptions {\n  /** Trusted main-process option; never derived from inherited environment or renderer. */\n  profile?: EngineProfile")
rep('export class EngineSupervisor {', '''export class EngineSupervisor {
  #origins = new WeakMap<object, FailureOrigin>()
  #operations = new WeakMap<Promise<unknown>, { cause: object; origin: FailureOrigin }>()
  #connections = new WeakMap<object, { session: Session; state: EngineConnectionState }>()
  readonly profile: EngineProfile''')
rep('    this.startupMs = bounded(options.startupMs, 10000, 60000)', '''    if (options.profile !== undefined && !['legacy2', 'business3'].includes(options.profile)) throw invalid()
    this.profile = options.profile ?? 'legacy2'
    this.startupMs = bounded(options.startupMs, 10000, 60000)''')
a='''  private connectionState(state: EngineConnectionState): void {
    for (const listener of [...this.connectionListeners]) {
      try {
        listener(structuredClone(state))'''
b='''  private connectionState(session: Session, state: EngineConnectionState): void {
    for (const listener of [...this.connectionListeners]) {
      try {
        const delivered = structuredClone(state)
        this.#connections.set(delivered, { session, state: structuredClone(state) })
        listener(delivered)'''
rep(a,b)
idx=s.index('  private diagnostic(')
s=s[:idx]+'''  /** Projection authenticates the original rejection and the actual public operation promise. */
  projectFailure(cause: unknown, originatingPromise: Promise<unknown>): SafeError {
    const issued = this.#operations.get(originatingPromise)
    if (issued && issued.cause === cause && this.#origins.get(issued.cause) === issued.origin) {
      const origin = issued.origin
      return origin.provenance === 'startup3' ? safeStartupError(origin.value)
        : origin.profile === 'business3' ? safeBusiness3Error(origin.value) : safeError(origin.value)
    }
    // Legacy adapters have no startup authority; neither classes nor shapes confer it.
    try { return safeError((cause as { error?: unknown } | null)?.error) } catch { return safeError(null) }
  }
  projectConnectionFailure(event: unknown): Extract<EngineConnectionState, { state: 'disconnected' }> | undefined {
    if (!event || typeof event !== 'object') return undefined
    const issued = this.#connections.get(event)
    if (!issued || issued.state.state !== 'disconnected') return undefined
    return structuredClone(issued.state)
  }
  private sign(session: Session, error: EngineError, provenance: FailureOrigin['provenance'] = 'local'): EngineError {
    const previous = this.#origins.get(error)
    if (previous) return error
    const value = provenance === 'startup3' ? safeStartupError(error.error)
      : session.profile === 'business3' ? safeBusiness3Error(error.error) : safeError(error.error)
    this.#origins.set(error, Object.freeze({ session, profile: session.profile,
      generation: session.generation, preHello: !session.hello, startupPromise: session.startupPromise,
      provenance, value: structuredClone(value) }))
    return error
  }
  private operation<T>(work: () => Promise<T>): Promise<T> {
    const promise = Promise.resolve().then(work).catch((cause: unknown) => {
      if (cause && typeof cause === 'object') {
        const origin = this.#origins.get(cause)
        if (origin) this.#operations.set(promise, { cause, origin })
      }
      throw cause
    })
    return promise
  }
  private validate(session: Session, name: string, value: unknown): boolean {
    return session.profile === 'business3' ? validateBusiness3(name, value) : validateV2(name, value)
  }
''' +s[idx:]
rep('''    session.terminal = true
    session.reader.stop()''','''    error = session.startupCause ?? this.sign(session, error)
    if (!session.hello) session.startupCause = error
    session.terminal = true
    session.reader.stop()
    session.rejectStart(error)''')
rep("      this.connectionState({\n        state: 'disconnected',", "      this.connectionState(session, {\n        state: 'disconnected',")
rep("        error: validateV2('error', error.error)\n          ? error.error\n          : {\n              code: 'INTERNAL_ERROR',\n              messageKey: 'engine.internal',\n              params: {},\n              retryable: false,\n            },", "        error: session.profile === 'business3' ? safeBusiness3Error(error.error) : safeError(error.error),")
rep('''    const { command, args } = this.options.command ?? getEngineCommand(this.location)
    const env''','''    const selected = this.options.command ?? getEngineCommand(this.location)
    const command = selected.command
    const args = [...selected.args]
    if (this.profile === 'business3') {
      const database = this.options.dataPath
      if (database && !isAbsolute(database)) throw invalid()
      args.push('--t01-internal-profile=business3')
      if (database) args.push(`--t01-internal-backup=${join(dirname(database), `.t01-backup-${randomUUID()}.sqlite`)}`)
    }
    const env''')
rep('''    const session: Session = {
      child,''','''    let resolveStart!: (session: Session) => void
    let rejectStart!: (error: EngineError) => void
    const startupPromise = new Promise<Session>((resolve, reject) => { resolveStart = resolve; rejectStart = reject })
    const session: Session = {
      child,
      profile: this.profile,
      startupPromise,
      resolveStart,
      rejectStart,''')
rep('(value) => this.receive(session, value),', '(value, metadata) => this.receive(session, value, metadata.payloadByteLength),')
start=s.index('    return new Promise<Session>((resolveStart, rejectStart) => {')
end=s.index('\n  private scheduleHeartbeat',start)
s=s[:start]+'''    const fail = (error: EngineError): void => this.finish(session, error)
    session.startupTimer = setTimeout(() => fail(timeout('startup')), this.startupMs)
    child.once('error', () => fail(exited()))
    child.once('close', () => fail(exited()))
    child.once('spawn', () => {
      if (!this.current(session)) { fail(exited()); return }
      void this.send(session, 'hello', { supportedVersions: [session.profile === 'business3' ? 3 : 2], clientId: randomUUID() }, this.handshakeMs, 'handshake').then((value) => {
        const hello = value as Hello
        if (!this.current(session) || hello.registryHash !== registryHash) { fail(invalid()); return }
        clearTimeout(session.startupTimer)
        this.failures = 0
        this.scheduleHeartbeat(session)
        session.resolveStart(session)
      }, fail)
    })
    return startupPromise
  }
''' +s[end:]
rep('''  private receive(session: Session, value: unknown): void {
    if (!this.current(session)) return
    if (validateV2('notification', value)) {''','''  private receive(session: Session, value: unknown, payloadByteLength: number): void {
    if (!this.current(session)) return
    if (value && typeof value === 'object' && (value as Record<string, unknown>).kind === 'startupFailure') {
      if (session.profile === 'business3' && !session.hello && !session.startupCause &&
          validateStartupFailure(value, payloadByteLength, session.expectedRegistryHash)) {
        const error = this.sign(session, new EngineError((value as { error: SafeError }).error), 'startup3')
        session.startupCause = error
        this.finish(session, error)
      } else this.finish(session, invalid())
      return
    }
    if (this.validate(session, 'notification', value)) {''')
rep("    if (!validateV2('response', value)) {", "    if (!this.validate(session, 'response', value)) {")
rep('''    if (!pending || !matchesResponse(pending.request, value)) {
      this.diagnostic('unmatchedResponse')
      if (++session.anomalies >= 3) this.finish(session, invalid())''','''    if (!pending || !(session.profile === 'business3'
      ? matchesBusiness3Response(pending.request, value, session.expectedRegistryHash)
      : matchesResponse(pending.request, value))) {
      this.diagnostic('unmatchedResponse')
      if (session.profile === 'business3' || ++session.anomalies >= 3) this.finish(session, invalid())''')
rep("      this.connectionState({\n        state: 'ready',", "      this.connectionState(session, {\n        state: 'ready',")
rep('''    else pending.reject(new EngineError(response.error as SafeEngineError))''','''    else {
      const error = this.sign(session, new EngineError(response.error as SafeEngineError), session.profile === 'business3' ? 'business3' : 'business2')
      pending.reject(error)
      if (pending.request.method === 'hello') this.finish(session, error)
    }''')
rep('''      protocolVersion: 2,
      engineSessionId: method === 'hello' ? null : session.hello?.engineSessionId,''','''      protocolVersion: method === 'hello' ? 2 : session.profile === 'business3' ? 3 : 2,
      engineSessionId: method === 'hello' ? null : session.hello?.engineSessionId,''')
rep("    if (!validateV2('request', request)) return Promise.reject(invalid())", "    if (!this.validate(session, 'request', request)) return Promise.reject(this.sign(session, invalid()))")
rep('rejectRequest(timeout(phase))','rejectRequest(this.sign(session, timeout(phase)))')
start=s.index('  async request(method: string, params: Record<string, unknown>): Promise<unknown> {')
end=s.index('\n}\n\n/** Compatibility',start)
s=s[:start]+'''  request(method: string, params: Record<string, unknown>): Promise<unknown> {
    return this.operation(async () => {
      if (method === 'hello') throw new EngineError({ code: 'INVALID_STATE', messageKey: 'protocol.invalidState', params: {}, retryable: false })
      const session = await this.ensure()
      return this.send(session, method, params, Math.min(this.requestMs, session.hello!.limits.requestMs), 'request')
    })
  }
  health(): Promise<EngineHealth> {
    return this.operation(async () => {
      const session = await this.ensure()
      const value = await this.send(session, 'health', {}, Math.min(this.requestMs, session.hello!.limits.requestMs), 'request') as { engineVersion: string; status: 'ok' }
      if (!this.current(session)) throw this.sign(session, exited())
      const hello = session.hello!
      if (value.engineVersion !== hello.engineVersion) throw this.sign(session, invalid())
      return { protocolVersion: hello.selectedVersion, ...value,
        capabilities: hello.capabilities.filter((capability) => capability === 'health') } as EngineHealth
    })
  }''' +s[end:]
p.write_text(s)
