import json,hashlib,base64,copy,re
from pathlib import Path
rootdir=Path('packages/contracts/v2')
f=json.loads((rootdir/'fixtures.json').read_text());reg=json.loads((rootdir/'registry.json').read_text());rh=hashlib.sha256((rootdir/'registry.json').read_bytes()).hexdigest();old=f['business3']['registryHash']
def encode(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),sort_keys=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def replace(v):
 if isinstance(v,list):return [replace(x) for x in v]
 if isinstance(v,dict):return {k:replace(x) for k,x in v.items()}
 return rh if v==old else v
f['business3']=replace(f['business3'])
f['startup']['registryHash']=rh
f['startup']['cases']=replace(f['startup']['cases'])
# Preserve each original wire's escaping/padding/chunk boundaries; replace only same-length registry hex.
stringtoken=re.compile(r'"(?:\\.|[^"\\])*"')
def rehash_wire(w):
 def repl(m):
  token=m.group()
  if json.loads(token)!=old:return token
  units=re.findall(r'\\u[0-9a-fA-F]{4}|\\.|[^\\]',token[1:-1]);assert len(units)==64
  return '"'+''.join('\\u%04x'%ord(c) if unit.startswith('\\u') else c for c,unit in zip(rh,units))+'"'
 return stringtoken.sub(repl,w)
for x in f['startup']['raw']:
 lengths=[len(base64.b64decode(c)) for c in x['chunksBase64']];w=rehash_wire(x['wireUtf8']);b=w.encode();assert len(b)==x['wireBytes'];x['wireUtf8']=w;x['wireBase64']=base64.b64encode(b).decode();at=0;chunks=[]
 for n in lengths:chunks.append(base64.b64encode(b[at:at+n]).decode());at+=n
 assert at==len(b);x['chunksBase64']=chunks
ids={k:f'00000000-0000-4000-8000-{n:012d}' for n,k in enumerate(['project','session','request','cursor','target','confirmation'],1)}
preview='b'*64;prepared='c'*64;inp='d'*64;params='e'*64
facthash=sha(encode(['urn:asset-1','urn:name','\"设备甲\"']).encode())
plan={'definitions':[{'layer':'ontology','id':'Asset','value':{'triples':[{'subject':'urn:Asset','predicate':'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','object':'<http://www.w3.org/2000/01/rdf-schema#Class>'}],'singleValuedPredicates':['urn:name'],'references':[]}}],'manual':[{'id':facthash,'subject':'urn:asset-1','predicate':'urn:name','object':'"设备甲"'}]}
doc=[{'resource':['definition','ontology','Asset'],'before':None,'after':{'layer':'ontology','id':'Asset','payload':encode(plan['definitions'][0]['value'])}},{'resource':['fact',facthash],'before':None,'after':{**plan['manual'][0],'owner':None,'source_row':None,'managed_value':None}}]
impact=[{'kind':'later-edit','resource':['fact',facthash],'operationId':ids['target'],'revision':2,'beforeSnapshotId':'1'*64,'afterSnapshotId':'2'*64,'before':'"甲"','after':'"乙"'},{'kind':'evidence-unavailable','targetOperationId':ids['target'],'baseRevision':3}]
def document(name,value,kind):
 raw=encode(value).encode();parts=[];segments=[]
 for ordinal,off in enumerate(range(0,len(raw),32768)):
  b=raw[off:off+32768];descriptor={'ordinal':ordinal,'byteOffset':off,'rawByteLength':len(b),'sha256':sha(b)};parts.append(descriptor);segments.append({**descriptor,'dataBase64':base64.b64encode(b).decode()})
 manifest={'documentKind':kind,'documentHash':sha(raw),'totalBytes':len(raw),'segmentCount':len(parts),'segments':parts}
 pages=[{'projectId':ids['project'],'previewHash':preview,'documentKind':kind,'documentHash':sha(raw),'segments':segments[i:i+2],'nextCursor':ids['cursor'],'complete':i+2>=len(parts)} for i in range(0,len(parts),2)]
 return {'name':name,'value':value,'rawUtf8':raw.decode(),'manifest':manifest,'pages':pages}
docs=[document('complete diff',doc,'diff'),document('undo impact',impact,'undo-impact'),document('multibyte across segments',[{'resource':['definition','ontology','Large'],'before':{'payload':'中'*24000},'after':None}],'diff')]
manifest=docs[0]['manifest'];ready={'status':'ready','projectId':ids['project'],'baseRevision':1,'previewHash':preview,'preparedPlanRef':prepared,'inputSnapshotId':inp,'parametersHash':params,'intent':'change','targetOperationId':None,'summary':'新增2项','manifest':manifest}
conflict={'status':'conflict','projectId':ids['project'],'baseRevision':1,'previewHash':preview,'targetOperationId':ids['target'],'summary':'后续修改导致撤销暂停','impactComplete':False,'manifest':docs[1]['manifest']}
confirm={'projectId':ids['project'],'previewHash':preview,'preparedPlanRef':prepared,'confirmationRef':ids['confirmation'],'inputSnapshotId':inp,'parametersHash':params}
qp={'projectId':ids['project'],'baseRevision':1,'intent':'change','plan':plan};qu={'projectId':ids['project'],'baseRevision':1,'intent':'undo','targetOperationId':ids['target']};pg={'projectId':ids['project'],'previewHash':preview,'documentKind':'diff','pageSize':2,'cursor':None};qc={'projectId':ids['project'],'previewHash':preview,'completionCursor':ids['cursor']}
cases=[]
def add(name,schema,value,valid=True):cases.append({'name':name,'schema':schema,'value':copy.deepcopy(value),'valid':valid})
for name,schema,value in [('typed plan','changeSetPlan',plan),('change preview','params_changeset.preview',qp),('undo preview','params_changeset.preview',qu),('ready','result_changeset.preview',ready),('ready undo','result_changeset.preview',{**ready,'intent':'undo','targetOperationId':ids['target']}),('conflict','result_changeset.preview',conflict),('page params','params_changeset.diff.page',pg),('page result','result_changeset.diff.page',docs[0]['pages'][0]),('confirm params','params_changeset.confirm',qc),('confirm result','result_changeset.confirm',confirm)]:add(name,schema,value)
for kind in [None,[],1,True,{'arbitrary':'opaque'},{'triples':[],'unknown':True}]:
 v=copy.deepcopy(plan);v['definitions'][0]['value']=kind;add('reject ontology '+str(kind),'changeSetPlan',v,False)
for key in ['mapping','compensate','application','workMs','rows']:
 add('reject plan '+key,'changeSetPlan',{key:{}},False)
for extra in ['actor','permission','confirmed','confirmationRef']:
 add('reject confirm '+extra,'params_changeset.confirm',{**qc,extra:True},False)
for field in ['preparedPlanRef','confirmationRef']:
 add('conflict no '+field,'result_changeset.preview',{**conflict,field:prepared},False)
add('ready cannot use impact','result_changeset.preview',{**ready,'manifest':docs[1]['manifest']},False)
add('conflict cannot use diff','result_changeset.preview',{**conflict,'manifest':manifest},False)
add('change target null','result_changeset.preview',{**ready,'targetOperationId':ids['target']},False)
add('undo target required','result_changeset.preview',{**ready,'intent':'undo'},False)
for n in [0,201]:add('pageSize '+str(n),'params_changeset.diff.page',{**pg,'pageSize':n},False)
for n in [16777217,0]:add('bytes '+str(n),'changeSetManifest',{**manifest,'totalBytes':n},False)
for field,value in [('segmentCount',2),('segmentCount',513)]:add(field+str(value),'changeSetManifest',{**manifest,field:value},False)
for field,value in [('ordinal',1),('byteOffset',1),('rawByteLength',32769)]:
 v=copy.deepcopy(manifest);v['segments'][0][field]=value;add('manifest '+field,'changeSetManifest',v,False)
v=copy.deepcopy(docs[0]['pages'][0]);v['segments'][0]['dataBase64']='YQ==';add('segment mismatched bytes','changeSetPage',v,False)
add('completion cursor cannot be null','changeSetPage',{**docs[0]['pages'][0],'nextCursor':None},False)
add('change cannot have target','params_changeset.preview',{**qp,'targetOperationId':ids['target']},False)
add('undo cannot have plan','params_changeset.preview',{**qu,'plan':plan},False)
bindings=[]
def binding(name,method,p,result):
 q={'kind':'request','protocolVersion':3,'id':ids['request'],'engineSessionId':ids['session'],'method':method,'params':p};r={'kind':'response','protocolVersion':3,'id':ids['request'],'engineSessionId':ids['session'],'method':method,'ok':True,'result':result};bindings.append({'name':name,'request':copy.deepcopy(q),'response':copy.deepcopy(r),'valid':True});return q,r
for name,method,p,result in [('change','changeset.preview',qp,ready),('undo ready','changeset.preview',qu,{**ready,'intent':'undo','targetOperationId':ids['target']}),('undo conflict','changeset.preview',qu,conflict),('page','changeset.diff.page',pg,docs[0]['pages'][0]),('confirm','changeset.confirm',qc,confirm)]:
 q,r=binding(name,method,p,result)
 for field,value in [('id',ids['confirmation']),('engineSessionId',ids['confirmation'])]:
  bad=copy.deepcopy(r);bad[field]=value;bindings.append({'name':name+' wrong '+field,'request':q,'response':bad,'valid':False})
 for field,value in [('projectId',ids['confirmation'])]+([('baseRevision',2)] if method=='changeset.preview' else [('previewHash','f'*64)]):
  bad=copy.deepcopy(r);bad['result'][field]=value;bindings.append({'name':name+' wrong '+field,'request':q,'response':bad,'valid':False})
 if method=='changeset.diff.page':
  bad=copy.deepcopy(r);bad['result']['documentKind']='undo-impact';bindings.append({'name':'page wrong kind','request':q,'response':bad,'valid':False})
# Independent stdlib-generated full byte budget oracles, generated in tests without a 16MiB fixture duplication.
generated=[]
for size in [32767,32768,32769,16777216,16777217]:
 raw=b'["'+b'x'*(size-4)+b'"]';generated.append({'rawByteLength':size,'sha256':sha(raw),'segmentCount':(size+32767)//32768,'valid':size<=16777216})
f['changesets']={'profile':'explicit-internal-business3','registryHash':rh,'ids':ids,'cases':cases,'bindings':bindings,'documents':docs,'generatedBoundaries':generated}
(rootdir/'fixtures.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
b=json.loads((rootdir/'binding-regressions.json').read_text());b['changesets']=bindings;b['startupBindings']=replace(b['startupBindings']);(rootdir/'binding-regressions.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print(rh,'cases',len(cases),'bindings',len(bindings),'documents',len(docs))
