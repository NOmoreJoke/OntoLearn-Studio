let electron = require("electron");
let node_path = require("node:path");
let node_fs = require("node:fs");
let node_url = require("node:url");
let node_child_process = require("node:child_process");
let node_crypto = require("node:crypto");
//#region ../../node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
	const numericValues = Object.values(entries).filter((v) => typeof v === "number");
	return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
}
function joinValues(array, separator = "|") {
	return array.map((val) => stringifyPrimitive(val)).join(separator);
}
function jsonStringifyReplacer(_, value) {
	if (typeof value === "bigint") return value.toString();
	return value;
}
var Cached = class {
	constructor(getter) {
		this._getter = getter;
		this._value = void 0;
	}
	get value() {
		const getter = this._getter;
		if (getter !== void 0) {
			this._value = getter();
			this._getter = void 0;
		}
		return this._value;
	}
};
function cached(getter) {
	return new Cached(getter);
}
function nullish(input) {
	return input === null || input === void 0;
}
function cleanRegex(source) {
	const start = source.startsWith("^") ? 1 : 0;
	const end = source.endsWith("$") ? source.length - 1 : source.length;
	return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
	const ratio = val / step;
	const roundedRatio = Math.round(ratio);
	const tolerance = 4 * Number.EPSILON * Math.max(Math.abs(ratio), 1);
	if (Math.abs(ratio - roundedRatio) < tolerance) return 0;
	return ratio - roundedRatio;
}
function assignProp(target, prop, value) {
	Object.defineProperty(target, prop, {
		value,
		writable: true,
		enumerable: true,
		configurable: true
	});
}
/**
* Whichever object a def's `shape` currently answers from: the one the caller passed until the first read, the frozen copy after it.
*
* Its keys and descriptors read without invoking anything, which is what lets a discriminated union check its discriminator, and the cycle walk read a shape, without resolving a getter that references the schema being constructed. A def that answers `shape` from an accessor of its own has none.
*/
function rawShape(def) {
	const desc = Object.getOwnPropertyDescriptor(def, "shape");
	return desc?.get ? desc.get.raw : desc?.value;
}
function sourceShape(schema) {
	return rawShape(schema._zod.def) ?? schema._zod.def.shape;
}
function deferProp(target, key, getter) {
	Object.defineProperty(target, key, {
		get() {
			const value = getter();
			assignProp(this, key, value);
			return value;
		},
		enumerable: true,
		configurable: true
	});
}
function putProp(target, key, value) {
	if (key in target) assignProp(target, key, value);
	else target[key] = value;
}
/**
* Copies `keys` of `source`'s shape onto `target`, each value passed through `wrap`.
*
* A key the source has resolved is copied through now, so the derived shape states it outright and nothing has to resolve it to learn what it holds. A key the source still defers stays deferred, and reads back through the source's own `shape`, so it resolves once and both shapes get that one schema.
*/
function mirrorShape(target, source, keys, wrap) {
	const raw = sourceShape(source);
	for (const key of keys) {
		const desc = Object.getOwnPropertyDescriptor(raw, key);
		if (!desc.enumerable) continue;
		if (desc.get) deferProp(target, key, () => {
			const value = source._zod.def.shape[key];
			return wrap ? wrap(value, key) : value;
		});
		else putProp(target, key, wrap ? wrap(desc.value, key) : desc.value);
	}
}
function mirrorProps(target, source) {
	for (const key of Reflect.ownKeys(source)) {
		const desc = Object.getOwnPropertyDescriptor(source, key);
		if (!desc.enumerable) continue;
		if (desc.get) deferProp(target, key, () => source[key]);
		else putProp(target, key, desc.value);
	}
}
function mergeDefs(...defs) {
	const mergedDescriptors = {};
	for (const def of defs) {
		const descriptors = Object.getOwnPropertyDescriptors(def);
		Object.assign(mergedDescriptors, descriptors);
	}
	return Object.defineProperties({}, mergedDescriptors);
}
function esc(str) {
	return JSON.stringify(str);
}
function slugify(input) {
	return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
function isObject(data) {
	return typeof data === "object" && data !== null && !Array.isArray(data);
}
var allowsEval = /* @__PURE__*/ cached(() => {
	if (globalConfig.jitless) return false;
	if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) return false;
	try {
		new Function("");
		return true;
	} catch (_) {
		return false;
	}
});
function isPlainObject(o) {
	if (isObject(o) === false) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return true;
	const prot = ctor.prototype;
	if (isObject(prot) === false) return false;
	if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
	return true;
}
function shallowClone(o) {
	if (isPlainObject(o)) return { ...o };
	if (Array.isArray(o)) return [...o];
	if (o instanceof Map) return new Map(o);
	if (o instanceof Set) return new Set(o);
	return o;
}
var propertyKeyTypes = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]);
function escapeRegex(str) {
	return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
	const cl = new inst._zod.constr(def ?? inst._zod.def);
	if (!def || params?.parent) cl._zod.parent = inst;
	return cl;
}
function normalizeParams(_params) {
	const params = _params;
	if (!params) return {};
	if (typeof params === "string") return { error: () => params };
	if (params?.message !== void 0) {
		if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
		params.error = params.message;
	}
	delete params.message;
	if (typeof params.error === "string") return {
		...params,
		error: () => params.error
	};
	return params;
}
function stringifyPrimitive(value) {
	if (typeof value === "bigint") return value.toString() + "n";
	if (typeof value === "string") return `"${value}"`;
	return `${value}`;
}
function optionalKeys(shape) {
	return Object.keys(shape).filter((k) => {
		return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
	});
}
var NUMBER_FORMAT_RANGES = /*@__PURE__*/ (() => ({
	safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}))();
var BIGINT_FORMAT_RANGES = {
	int64: [/* @__PURE__*/ BigInt("-9223372036854775808"), /* @__PURE__*/ BigInt("9223372036854775807")],
	uint64: [/* @__PURE__*/ BigInt(0), /* @__PURE__*/ BigInt("18446744073709551615")]
};
function pick(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
	const newShape = {};
	mirrorShape(newShape, schema, maskedKeys(schema, mask));
	return clone(schema, mergeDefs(currDef, {
		shape: newShape,
		checks: []
	}));
}
function maskedKeys(schema, mask) {
	const raw = sourceShape(schema);
	const keys = [];
	for (const key of Reflect.ownKeys(mask)) {
		if (!Object.getOwnPropertyDescriptor(raw, key)?.enumerable) throw new Error(`Unrecognized key: "${String(key)}"`);
		if (mask[key]) keys.push(key);
	}
	return keys;
}
function omit(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
	const omitted = new Set(maskedKeys(schema, mask));
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)).filter((key) => !omitted.has(key)));
	return clone(schema, mergeDefs(currDef, {
		shape: newShape,
		checks: []
	}));
}
function extend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to extend: expected a plain object");
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) {
		const existingShape = sourceShape(schema);
		for (const key of Reflect.ownKeys(shape)) if (Object.getOwnPropertyDescriptor(existingShape, key) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function extended(schema, shape) {
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)));
	mirrorProps(newShape, shape);
	return newShape;
}
function safeExtend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to safeExtend: expected a plain object");
	return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function merge(a, b) {
	if (!b?._zod?.def) throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (a._zod.def.checks?.length) throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	const newShape = {};
	mirrorShape(newShape, a, Reflect.ownKeys(sourceShape(a)));
	mirrorShape(newShape, b, Reflect.ownKeys(sourceShape(b)));
	return clone(a, mergeDefs(a._zod.def, {
		shape: newShape,
		get catchall() {
			return b._zod.def.catchall;
		},
		checks: b._zod.def.checks ?? []
	}));
}
function partial(Class, schema, mask, name = "partial") {
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) throw new Error(`.${name}() cannot be used on object schemas containing refinements`);
	const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), Class && ((value, key) => selected && !selected.has(key) ? value : new Class({
		type: "optional",
		innerType: value
	})));
	return clone(schema, mergeDefs(schema._zod.def, {
		shape: newShape,
		checks: []
	}));
}
function required(Class, schema, mask) {
	const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), (value, key) => selected && !selected.has(key) ? value : new Class({
		type: "nonoptional",
		innerType: value
	}));
	return clone(schema, mergeDefs(schema._zod.def, { shape: newShape }));
}
function aborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
	return false;
}
function explicitlyAborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
	return false;
}
function prefixIssues(path, issues) {
	return issues.map((iss) => {
		var _a;
		(_a = iss).path ?? (_a.path = []);
		iss.path.unshift(path);
		return iss;
	});
}
function unwrapMessage(message) {
	return typeof message === "string" ? message : message?.message;
}
/** The leading size checks of `defChecks` that set an upper bound, each paired with it. */
function sizeCaps(defChecks) {
	const caps = [];
	for (const ch of defChecks ?? []) {
		const d = ch._zod.def;
		if (!/_(length|size)$|_equals$/.test(d.check)) break;
		const max = d.maximum ?? d.length ?? d.size;
		if (max >= 0) caps.push([max, ch]);
	}
	return caps;
}
function attachSchema(issues, start, inst) {
	var _a;
	for (let i = start; i < issues.length; i++) (_a = issues[i]).schema ?? (_a.schema = inst);
}
function finalizeIssue(iss, ctx, config) {
	var _a;
	const traits = iss.inst?._zod?.traits;
	if (traits?.has("$ZodType")) {
		if (traits.has("$ZodCheck")) (_a = iss).schema ?? (_a.schema = iss.inst);
		else iss.schema = iss.inst;
	}
	const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
	const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
	const full = {};
	for (const k of Object.keys(iss)) {
		if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__") continue;
		full[k] = iss[k];
	}
	full.path ?? (full.path = []);
	full.message = message;
	if (ctx?.reportInput) full.input = iss.input;
	return full;
}
var highSurrogate = /[\uD800-\uDBFF]/;
function codePointLength(str) {
	const units = str.length;
	if (!highSurrogate.test(str)) return units;
	let count = units;
	for (let i = 0; i < units - 1; i++) if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
		count--;
		i++;
	}
	return count;
}
function getLengthableOrigin(input) {
	if (Array.isArray(input)) return "array";
	if (typeof input === "string") return "string";
	return "unknown";
}
function parsedType(data) {
	const t = typeof data;
	switch (t) {
		case "number": return Number.isNaN(data) ? "nan" : "number";
		case "object": {
			if (data === null) return "null";
			if (Array.isArray(data)) return "array";
			const obj = data;
			if (obj && Object.getPrototypeOf(obj) !== Object.prototype && "constructor" in obj && obj.constructor) return obj.constructor.name;
		}
	}
	return t;
}
function issue(...args) {
	const [iss, input, inst] = args;
	if (typeof iss === "string") return {
		message: iss,
		code: "custom",
		input,
		inst
	};
	return { ...iss };
}
/**
* Installs a trait's members on its prototype. Each value builds that member for the instance on first read; the built value shadows the accessor as an own property, so a detached `const { parse } = schema` keeps working.
*
* Call this from a `proto` initializer, which runs once per prototype — never per instance.
*/
function members(proto, table) {
	for (const key in table) {
		const desc = Object.getOwnPropertyDescriptor(table, key);
		if (desc.get) Object.defineProperty(proto, key, {
			...desc,
			enumerable: false
		});
		else defineBound(proto, key, desc.value);
	}
}
/** Shadows a prototype member with an own value, so a getter that builds from the instance runs once. */
function own(inst, key, value, enumerable = true) {
	Object.defineProperty(inst, key, {
		configurable: true,
		writable: true,
		enumerable,
		value
	});
	return value;
}
/** Like {@link own}, for a member that was never an own data property and has to stay out of `Object.keys`. */
function hide(inst, key, value) {
	return own(inst, key, value, false);
}
/** Adds members a table derives from the instance: each builds on first read and shadows as own data, and assignment shadows the same way, as when these were own properties. */
/* @__NO_SIDE_EFFECTS__ */
function derived(computes, table) {
	for (const key in computes) {
		const compute = computes[key];
		Object.defineProperty(table, key, {
			configurable: true,
			enumerable: true,
			get() {
				return own(this, key, compute(this));
			},
			set(value) {
				own(this, key, value);
			}
		});
	}
	return table;
}
function defineBound(proto, key, fn) {
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			return this == null ? fn : own(this, key, fn.bind(this));
		},
		set(value) {
			own(this, key, value);
		}
	});
}
/** Returns the prototype to install on, or `undefined` if this group is already installed on it. */
function claim(inst, sentinel) {
	const proto = Object.getPrototypeOf(inst);
	return sentinel in proto ? void 0 : proto;
}
var installing;
var broke = false;
var breaker = {
	configurable: true,
	get() {
		broke = true;
	}
};
/**
* Installs a lazily-derived internal on the `_zod` prototype of `inst`'s
* constructor, computed from the internals object itself and cached there on
* first read. One accessor per constructor rather than one per instance.
*/
function defineLazyInternal(inst, key, compute) {
	const proto = Object.getPrototypeOf(inst._zod);
	if (key in proto && installing !== inst._zod) {
		installing = void 0;
		return;
	}
	installing = inst._zod;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			Object.defineProperty(this, key, breaker);
			const outer = broke;
			broke = false;
			try {
				const value = compute(this);
				if (broke) delete this[key];
				else Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					value
				});
				broke = broke || outer;
				return value;
			} catch (err) {
				delete this[key];
				broke = broke || outer;
				throw err;
			}
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				value
			});
		}
	});
}
/**
* Installs `key` on `inst`'s prototype, computed by `make` on first read and cached there as an own
* data property. One accessor per constructor rather than one per instance, because an own accessor
* puts every instance after the first into v8 dictionary mode. The key doubles as the sentinel.
*/
function installLazyProp(inst, key, make, enumerable) {
	const proto = claim(inst, key);
	if (!proto) return;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			const desc = {
				configurable: true,
				writable: true,
				enumerable,
				value: void 0
			};
			Object.defineProperty(this, key, desc);
			desc.value = make(this);
			Object.defineProperty(this, key, desc);
			return desc.value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				enumerable,
				value
			});
		}
	});
}
/** Marks the thunk `_catch` synthesises for a constant catch value. `Function.length` cannot tell that thunk from a user callback — rest and defaulted parameters both report arity 0 — and a user callback reads `ctx.error`, whose issues only finalize correctly against the caller's per-parse error map. Provenance can say what arity cannot. A plain string key rather than `Symbol.for`, whose call at module scope no bundler can prove pure — the same shape that anchored `urlCanParse` into every build. */
var CONSTANT_CATCH = "~constantCatch";
/** Wraps a constant catch value in a thunk tagged with {@link CONSTANT_CATCH}. */
function constantCatch(value) {
	const fn = () => value;
	fn[CONSTANT_CATCH] = true;
	return fn;
}
//#endregion
//#region ../../node_modules/zod/v4/core/core.js
var _a$1;
var _zodDesc = {
	value: void 0,
	enumerable: false
};
var _E = "captureStackTrace" in Error ? Error : null;
function newError(Definition) {
	const E = _E;
	if (E) {
		const saved = E.stackTraceLimit;
		if (typeof saved === "number") {
			try {
				E.stackTraceLimit = 0;
			} catch {
				_E = null;
				return new Definition();
			}
			try {
				return new Definition();
			} finally {
				E.stackTraceLimit = saved;
			}
		}
	}
	return new Definition();
}
/* @__NO_SIDE_EFFECTS__ */
function $constructor(name, initializer, proto, params) {
	const zodProto = {};
	function Internals(def) {
		this.def = def;
		this.constr = _;
		this.traits = /* @__PURE__ */ new Set();
	}
	Internals.prototype = zodProto;
	const protoMembers = proto;
	const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
	function init(inst, def) {
		if (!inst._zod) {
			_zodDesc.value = new Internals(def);
			try {
				Object.defineProperty(inst, "_zod", _zodDesc);
			} finally {
				_zodDesc.value = void 0;
			}
		} else if (inst._zod.traits.has(name)) return;
		inst._zod.traits.add(name);
		initializer(inst, def);
		if (initialized) {
			const own = Object.getPrototypeOf(inst);
			const ctorProto = inst._zod.constr.prototype;
			let up = own;
			while (up && up !== ctorProto) up = Object.getPrototypeOf(up);
			const target = up ?? own;
			if (!initialized.has(target)) {
				initialized.add(target);
				members(target, protoMembers);
			}
		}
		const proto = _.prototype;
		for (const k in proto) {
			if (!Object.prototype.hasOwnProperty.call(proto, k)) continue;
			if (!(k in inst)) inst[k] = proto[k].bind(inst);
		}
	}
	const Parent = params?.Parent ?? Object;
	class Definition extends Parent {}
	Object.defineProperty(Definition, "name", { value: name });
	function _(def) {
		const inst = params?.Parent ? newError(Definition) : this;
		init(inst, def);
		const deferred = inst._zod.deferred;
		if (deferred) {
			for (const fn of deferred) fn();
			inst._zod.deferred = void 0;
		}
		const pp = globalThis.__zod_globalConfig?.postProcessor;
		if (pp) pp(inst);
		return inst;
	}
	Object.defineProperty(_, "init", { value: init });
	Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
		if (params?.Parent && inst instanceof params.Parent) return true;
		return inst?._zod?.traits?.has(name);
	} });
	Object.defineProperty(_, "name", { value: name });
	return _;
}
var $ZodAsyncError = class extends Error {
	constructor() {
		super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
	}
};
var $ZodEncodeError = class extends Error {
	constructor(name) {
		super(`Encountered unidirectional transform during encode: ${name}`);
		this.name = "ZodEncodeError";
	}
};
(_a$1 = globalThis).__zod_globalConfig ?? (_a$1.__zod_globalConfig = {});
var globalConfig = globalThis.__zod_globalConfig;
function config(newConfig) {
	if (newConfig) Object.assign(globalConfig, newConfig);
	return globalConfig;
}
//#endregion
//#region ../../node_modules/zod/v4/core/errors.js
function _getMessage() {
	const internals = this._zod;
	internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
	return internals.message;
}
function _setMessage(value) {
	this._zod.message = value;
}
var _messageDesc = {
	get: _getMessage,
	set: _setMessage,
	enumerable: true,
	configurable: true
};
var _issuesDesc = {
	value: void 0,
	enumerable: false
};
var _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
var initializer$1 = (inst, def) => {
	inst.name = "$ZodError";
	_issuesDesc.value = def;
	Object.defineProperty(inst, "issues", _issuesDesc);
	_issuesDesc.value = void 0;
	Object.defineProperty(inst, "message", _messageDesc);
	const proto = Object.getPrototypeOf(inst);
	if (!_installedToString.has(proto)) {
		_installedToString.add(proto);
		Object.defineProperty(proto, "toString", {
			configurable: true,
			enumerable: false,
			get() {
				const value = () => this.message;
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
				return value;
			},
			set(value) {
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
			}
		});
	}
};
var $ZodError = /* @__PURE__ */ $constructor("$ZodError", initializer$1);
/** Get-or-create `obj[key]` as an own data property. A path segment naming an inherited member
* ("toString", "constructor") would otherwise read through to the prototype, and assigning
* "__proto__" would hit the setter instead of creating a key. */
function node(obj, key, make) {
	if (!Object.prototype.hasOwnProperty.call(obj, key)) {
		if (key === "__proto__") Object.defineProperty(obj, key, {
			value: make(),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else obj[key] = make();
	}
	return obj[key];
}
function flattenError(error, mapper = (issue) => issue.message) {
	const fieldErrors = {};
	const formErrors = [];
	for (const sub of error.issues) if (sub.path.length > 0) node(fieldErrors, sub.path[0], () => []).push(mapper(sub));
	else formErrors.push(mapper(sub));
	return {
		formErrors,
		fieldErrors
	};
}
function formatError(error, mapper = (issue) => issue.message) {
	const fieldErrors = { _errors: [] };
	const processError = (error, path = []) => {
		for (const issue of error.issues) if (issue.code === "invalid_union" && issue.errors.length) issue.errors.map((issues) => processError({ issues }, [...path, ...issue.path]));
		else if (issue.code === "invalid_key") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else if (issue.code === "invalid_element") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else {
			const fullpath = [...path, ...issue.path];
			if (fullpath.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < fullpath.length) {
					const el = fullpath[i];
					const terminal = i === fullpath.length - 1;
					if (el === "_errors") {
						if (terminal) curr._errors.push(mapper(issue));
						i++;
						continue;
					}
					if (!Object.prototype.hasOwnProperty.call(curr, el)) Object.defineProperty(curr, el, {
						value: { _errors: [] },
						enumerable: true,
						writable: true,
						configurable: true
					});
					const node = curr[el];
					if (terminal) node._errors.push(mapper(issue));
					curr = node;
					i++;
				}
			}
		}
	};
	processError(error);
	return fieldErrors;
}
//#endregion
//#region ../../node_modules/zod/v4/core/parse.js
function finalizeParams(callee, params) {
	return {
		callee: params?.callee ?? callee,
		Err: params?.Err
	};
}
var _parse = (_Err) => {
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: false
		} : { async: false };
		const result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) throw new $ZodAsyncError();
		if (result.issues.length) {
			const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, _params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _parseAsync = (_Err) => {
	const fn = async (schema, value, _ctx, params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: true
		} : { async: true };
		let result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) result = await result;
		if (result.issues.length) {
			const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _safeParse = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: false
	} : { async: false };
	const result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) throw new $ZodAsyncError();
	return result.issues.length ? failure(_Err, result.issues, ctx) : {
		success: true,
		data: result.value
	};
};
function failure(Err, issues, ctx) {
	let error;
	return {
		success: false,
		get error() {
			if (!error) {
				error = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
				issues = void 0;
				ctx = void 0;
			}
			return error;
		},
		set error(e) {
			error = e;
			issues = void 0;
			ctx = void 0;
		}
	};
}
var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: true
	} : { async: true };
	let result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) result = await result;
	return result.issues.length ? failure(_Err, result.issues, ctx) : {
		success: true,
		data: result.value
	};
};
var COMPILE_INVALID = /* @__PURE__ */ Symbol.for("zod.compile.invalid");
var COMPILE_FALLBACK = /* @__PURE__ */ Symbol.for("zod.compile.fallback");
var validate = ((schema, value, _ctx) => {
	const validator = schema._zod.bag.validator;
	if (validator !== void 0) {
		if (validator(value) !== COMPILE_INVALID) return true;
		if (validator.definite === true && _ctx === void 0) return false;
	}
	return validateFallback(schema, value, _ctx);
});
function validateFallback(schema, value, _ctx) {
	const ctx = _ctx ? {
		..._ctx,
		async: false,
		abortEarly: true
	} : {
		async: false,
		abortEarly: true
	};
	const fallbackRun = schema._zod.bag.fallbackRun;
	let result;
	if (fallbackRun) {
		ctx[COMPILE_FALLBACK] = true;
		result = fallbackRun({
			value,
			issues: []
		}, ctx);
	} else result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) throw new $ZodAsyncError();
	return result.issues.length === 0;
}
var validateAsync$1 = async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: true,
		abortEarly: true
	} : {
		async: true,
		abortEarly: true
	};
	let result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) result = await result;
	return result.issues.length === 0;
};
var _encode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return parse(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		return parse(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _encodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return await parseAsync(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		return await parseAsync(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _safeEncode = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParse(_Err)(schema, value, ctx);
};
var _safeDecode = (_Err) => (schema, value, _ctx) => {
	return _safeParse(_Err)(schema, value, _ctx);
};
var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParseAsync(_Err)(schema, value, ctx);
};
var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
	return _safeParseAsync(_Err)(schema, value, _ctx);
};
//#endregion
//#region ../../node_modules/zod/v4/core/regexes.js
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var cuid = /^[cC][0-9a-z]{6,}$/;
var cuid2 = /^[0-9a-z]+$/;
var ulid = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/;
var xid = /^[0-9a-vA-V]{20}$/;
var ksuid = /^[A-Za-z0-9]{27}$/;
var nanoid = /^[a-zA-Z0-9_-]{21}$/;
function nanoidOfLength(length) {
	return new RegExp(`^[a-zA-Z0-9_-]{${length}}$`);
}
/** ISO 8601-1 duration regex. Does not support the 8601-2 extensions like negative durations or fractional/negative components. */
var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
/** A regex for any UUID-like identifier: 8-4-4-4-12 hex pattern */
var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
/** Returns a regex for validating an RFC 9562/4122 UUID.
*
* @param version Optionally specify a version 1-8. If no version is specified, all versions are supported. */
var uuid = (version) => {
	if (!version) return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
	return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
/** Practical email validation */
var email = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var _emoji$1 = `^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$`;
function emoji() {
	return new RegExp(_emoji$1, "u");
}
var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
var base64url = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/;
var httpProtocol = /^https?$/;
var e164 = /^\+[1-9]\d{6,14}$/;
var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
/** Anchors a pattern source. The interpolation lives here rather than at the call site because
* esbuild will not drop a `@__PURE__` call whose own argument interpolates a variable, but it
* will drop `anchor(dateSource)`. Keeping it inline pinned `date` into every bundle. */
function anchor(source) {
	return new RegExp(`^${source}$`);
}
var date = /*@__PURE__*/ anchor(dateSource);
function timeSource(args) {
	const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
	return typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : args.seconds ? `${hhmm}:[0-5]\\d(?:\\.\\d+)?` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function time(args) {
	return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
	const opts = ["Z"];
	if (args.offset) opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
	const qualified = `${timeSource({
		precision: args.precision,
		seconds: true
	})}(?:${opts.join("|")})`;
	const timeRegex = args.local ? `${qualified}|${timeSource({ precision: args.precision })}` : qualified;
	return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
}
var anyString = /^[\s\S]{0,}$/;
var integer = /^-?\d+$/;
var number$1 = /^-?\d+(?:\.\d+)?$/;
var boolean$1 = /^(?:true|false)$/i;
var lowercase = /^[^A-Z]*$/;
var uppercase = /^[^a-z]*$/;
//#endregion
//#region ../../node_modules/zod/v4/core/checks.js
var $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
	var _a;
	inst._zod ?? (inst._zod = {});
	inst._zod.def = def;
	(_a = inst._zod).onattach ?? (_a.onattach = []);
});
/** Default `when` for length-based checks: run only on non-nullish values with a `length`. */
var _whenHasLength = (payload) => {
	const val = payload.value;
	return !nullish(val) && val.length !== void 0;
};
var numericOriginMap = {
	number: "number",
	bigint: "bigint",
	object: "date"
};
var $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_big",
			maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_small",
			minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMultipleOf = /*@__PURE__*/ $constructor("$ZodCheckMultipleOf", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.check = (payload) => {
		if (typeof payload.value !== typeof def.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
		if (typeof payload.value === "bigint" ? def.value !== BigInt(0) && payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0) return;
		payload.issues.push({
			origin: typeof payload.value,
			code: "not_multiple_of",
			divisor: def.value,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
	$ZodCheck.init(inst, def);
	def.format = def.format || "float64";
	const isInt = def.format?.includes("int");
	const origin = isInt ? "int" : "number";
	const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
	inst._zod.check = (payload) => {
		const input = payload.value;
		if (isInt) {
			if (!Number.isInteger(input)) {
				payload.issues.push({
					expected: origin,
					format: def.format,
					code: "invalid_type",
					continue: false,
					input,
					inst
				});
				return;
			}
			if (!Number.isSafeInteger(input)) {
				if (input > 0) payload.issues.push({
					input,
					code: "too_big",
					maximum: Number.MAX_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				else payload.issues.push({
					input,
					code: "too_small",
					minimum: Number.MIN_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				return;
			}
		}
		if (input < minimum) payload.issues.push({
			origin: "number",
			input,
			code: "too_small",
			minimum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
		if (input > maximum) payload.issues.push({
			origin: "number",
			input,
			code: "too_big",
			maximum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMaxLength = /*@__PURE__*/ $constructor("$ZodCheckMaxLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units > def.maximum ? codePointLength(input) : units) <= def.maximum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_big",
			maximum: def.maximum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units) >= def.minimum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_small",
			minimum: def.minimum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLengthEquals = /*@__PURE__*/ $constructor("$ZodCheckLengthEquals", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		const length = typeof input === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input) : units;
		if (length === def.length) return;
		const origin = getLengthableOrigin(input);
		const tooBig = length > def.length;
		payload.issues.push({
			origin,
			...tooBig ? {
				code: "too_big",
				maximum: def.length
			} : {
				code: "too_small",
				minimum: def.length
			},
			inclusive: true,
			exact: true,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStringFormat = /*@__PURE__*/ $constructor("$ZodCheckStringFormat", (inst, def) => {
	var _a, _b;
	$ZodCheck.init(inst, def);
	if (def.pattern) (_a = inst._zod).check ?? (_a.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: def.format,
			input: payload.value,
			...def.pattern ? { pattern: def.pattern.toString() } : {},
			inst,
			continue: !def.abort
		});
	});
	else (_b = inst._zod).check ?? (_b.check = () => {});
});
var $ZodCheckRegex = /*@__PURE__*/ $constructor("$ZodCheckRegex", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: payload.value,
			pattern: def.pattern.toString(),
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLowerCase = /*@__PURE__*/ $constructor("$ZodCheckLowerCase", (inst, def) => {
	def.pattern ?? (def.pattern = lowercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckUpperCase = /*@__PURE__*/ $constructor("$ZodCheckUpperCase", (inst, def) => {
	def.pattern ?? (def.pattern = uppercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckIncludes = /*@__PURE__*/ $constructor("$ZodCheckIncludes", (inst, def) => {
	$ZodCheck.init(inst, def);
	const escapedRegex = escapeRegex(def.includes);
	def.pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position},}${escapedRegex}` : escapedRegex);
	inst._zod.check = (payload) => {
		if (payload.value.includes(def.includes, def.position)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: def.includes,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStartsWith = /*@__PURE__*/ $constructor("$ZodCheckStartsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.check = (payload) => {
		if (payload.value.startsWith(def.prefix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: def.prefix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckEndsWith = /*@__PURE__*/ $constructor("$ZodCheckEndsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.check = (payload) => {
		if (payload.value.endsWith(def.suffix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: def.suffix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckOverwrite = /*@__PURE__*/ $constructor("$ZodCheckOverwrite", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.check = (payload) => {
		payload.value = def.tx(payload.value);
	};
});
//#endregion
//#region ../../node_modules/zod/v4/core/doc.js
var Doc = class {
	constructor(args = [], closed = {}) {
		this.content = [];
		this.indent = 0;
		this.args = args;
		this.closed = closed;
	}
	indented(fn) {
		this.indent += 1;
		try {
			fn(this);
		} finally {
			this.indent -= 1;
		}
	}
	write(arg) {
		if (typeof arg === "function") {
			arg(this, { execution: "sync" });
			arg(this, { execution: "async" });
			return;
		}
		const lines = arg.split("\n").filter((x) => x);
		const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
		const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
		for (const line of dedented) this.content.push(line);
	}
	compile() {
		const F = Function;
		const content = this?.content ?? [``];
		return new F(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${content.join("\n")}\n};`)(...Object.values(this.closed));
	}
};
//#endregion
//#region ../../node_modules/zod/v4/core/versions.js
var version = {
	major: 4,
	minor: 6,
	patch: 7
};
//#endregion
//#region ../../node_modules/zod/v4/core/schemas.js
var $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
	var _a;
	inst ?? (inst = {});
	inst._zod.def = def;
	inst._zod.bag = inst._zod.bag || {};
	inst._zod.version = version;
	const defChecks = inst._zod.def.checks;
	const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
	for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
	if (checks.length === 0) {
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred?.push(() => {
			inst._zod.run = inst._zod.parse;
		});
	} else {
		const runChecks = (payload, checks, ctx) => {
			if (payload.memo) return payload;
			let isAborted = aborted(payload);
			let asyncResult;
			for (const ch of checks) {
				if (ch._zod.def.when) {
					if (explicitlyAborted(payload)) continue;
					if (!ch._zod.def.when(payload)) continue;
				} else if (isAborted) continue;
				const currLen = payload.issues.length;
				const _ = ch._zod.check(payload);
				if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
				if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
					await _;
					if (payload.issues.length === currLen) return;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				});
				else {
					if (payload.issues.length === currLen) continue;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				}
			}
			if (asyncResult) return asyncResult.then(() => {
				return payload;
			});
			return payload;
		};
		const handleCanaryResult = (canary, payload, ctx) => {
			if (aborted(canary)) {
				canary.aborted = true;
				return canary;
			}
			const checkResult = runChecks(payload, checks, ctx);
			if (checkResult instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
			}
			return inst._zod.parse(checkResult, ctx);
		};
		inst._zod.run = (payload, ctx) => {
			if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
			if (ctx.direction === "backward") {
				const canary = inst._zod.parse({
					value: payload.value,
					issues: []
				}, {
					...ctx,
					skipChecks: true
				});
				if (canary instanceof Promise) return canary.then((canary) => {
					return handleCanaryResult(canary, payload, ctx);
				});
				return handleCanaryResult(canary, payload, ctx);
			}
			const result = inst._zod.parse(payload, ctx);
			if (result instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return result.then((result) => runChecks(result, checks, ctx));
			}
			return runChecks(result, checks, ctx);
		};
	}
}, {
	get "~standard"() {
		return hide(this, "~standard", standardProps(this));
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	}
});
/** The Standard Schema surface for `inst`. Shared so wrappers can extend it without forcing it. */
var toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
async function validateAsync(inst, value) {
	const ctx = { async: true };
	return toStandardResult(await inst._zod.run({
		value,
		issues: []
	}, ctx), ctx);
}
function standardProps(inst) {
	return {
		validate: (value) => {
			const ctx = { async: false };
			try {
				const r = inst._zod.run({
					value,
					issues: []
				}, ctx);
				if (!(r instanceof Promise)) return toStandardResult(r, ctx);
			} catch (_) {}
			return validateAsync(inst, value);
		},
		vendor: "zod",
		version: 1
	};
}
var $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = def.pattern ?? anyString;
	inst._zod.parse = (payload, _) => {
		if (def.coerce) try {
			payload.value = String(payload.value);
		} catch (_) {}
		if (typeof payload.value === "string") return payload;
		payload.issues.push({
			expected: "string",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
var $ZodStringFormat = /*@__PURE__*/ $constructor("$ZodStringFormat", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	$ZodString.init(inst, def);
});
var $ZodGUID = /*@__PURE__*/ $constructor("$ZodGUID", (inst, def) => {
	def.pattern ?? (def.pattern = guid);
	$ZodStringFormat.init(inst, def);
});
var $ZodUUID = /*@__PURE__*/ $constructor("$ZodUUID", (inst, def) => {
	if (def.version) {
		const v = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[def.version];
		if (v === void 0) throw new Error(`Invalid UUID version: "${def.version}"`);
		def.pattern ?? (def.pattern = uuid(v));
	} else def.pattern ?? (def.pattern = uuid());
	$ZodStringFormat.init(inst, def);
});
var $ZodEmail = /*@__PURE__*/ $constructor("$ZodEmail", (inst, def) => {
	def.pattern ?? (def.pattern = email);
	$ZodStringFormat.init(inst, def);
});
function canParseURL(input) {
	try {
		if (typeof URL !== "undefined" && typeof URL.canParse === "function") return URL.canParse(input);
		new URL(input);
		return true;
	} catch {
		return false;
	}
}
function validateURL(trimmed, def) {
	if (!("normalize" in def) && !("hostname" in def) && !("protocol" in def)) return canParseURL(trimmed) || 2;
	return parseURLObject(trimmed, def);
}
/** Parses a URL while preserving the non-normalizing HTTP guard. */
function parseURLObject(trimmed, def) {
	if (!def.normalize && def.protocol?.source === httpProtocol.source && !/^https?:\/\//i.test(trimmed)) return 1;
	try {
		if (typeof URL !== "undefined") {
			const URLStatic = URL;
			if (typeof URLStatic.parse === "function") return URLStatic.parse(trimmed) ?? 2;
		}
		return new URL(trimmed);
	} catch {
		return 2;
	}
}
var asciiTabOrNewline = /[\t\n\r]/g;
/** The URL parser deletes every ASCII tab, LF and CR from its input before it parses, so `new URL("https://exa\nmple.com")` reports on `example.com`. Applying the same deletion to the returned value closes the half of that divergence which can move the host; the parser's other rewrite, stripping C0 controls at the edges, cannot. */
function stripTabAndNewline(value) {
	return value.replace(asciiTabOrNewline, "");
}
function urlHostnameOk(url, hostname) {
	hostname.lastIndex = 0;
	return hostname.test(url.hostname);
}
function urlProtocolOk(url, protocol) {
	protocol.lastIndex = 0;
	return protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol);
}
var $ZodURL = /*@__PURE__*/ $constructor("$ZodURL", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		try {
			const trimmed = payload.value.trim();
			const url = validateURL(trimmed, def);
			if (url === 1) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (url === 2) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (url === true) {
				payload.value = stripTabAndNewline(trimmed);
				return;
			}
			if (def.hostname && !urlHostnameOk(url, def.hostname)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: def.hostname.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			if (def.protocol && !urlProtocolOk(url, def.protocol)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: def.protocol.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			payload.value = def.normalize ? url.href : stripTabAndNewline(trimmed);
			return;
		} catch (_) {
			payload.issues.push({
				code: "invalid_format",
				format: "url",
				input: payload.value,
				inst,
				continue: !def.abort
			});
		}
	};
});
var $ZodEmoji = /*@__PURE__*/ $constructor("$ZodEmoji", (inst, def) => {
	def.pattern ?? (def.pattern = emoji());
	$ZodStringFormat.init(inst, def);
});
var $ZodNanoID = /*@__PURE__*/ $constructor("$ZodNanoID", (inst, def) => {
	if (def.length !== void 0 && (!Number.isInteger(def.length) || def.length < 1)) throw new Error(`Invalid nanoid length: ${def.length}`);
	def.pattern ?? (def.pattern = def.length === void 0 ? nanoid : nanoidOfLength(def.length));
	$ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link $ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var $ZodCUID = /*@__PURE__*/ $constructor("$ZodCUID", (inst, def) => {
	def.pattern ?? (def.pattern = cuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodCUID2 = /*@__PURE__*/ $constructor("$ZodCUID2", (inst, def) => {
	def.pattern ?? (def.pattern = cuid2);
	$ZodStringFormat.init(inst, def);
});
var $ZodULID = /*@__PURE__*/ $constructor("$ZodULID", (inst, def) => {
	def.pattern ?? (def.pattern = ulid);
	$ZodStringFormat.init(inst, def);
});
var $ZodXID = /*@__PURE__*/ $constructor("$ZodXID", (inst, def) => {
	def.pattern ?? (def.pattern = xid);
	$ZodStringFormat.init(inst, def);
});
var $ZodKSUID = /*@__PURE__*/ $constructor("$ZodKSUID", (inst, def) => {
	def.pattern ?? (def.pattern = ksuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodISODateTime = /*@__PURE__*/ $constructor("$ZodISODateTime", (inst, def) => {
	def.pattern ?? (def.pattern = datetime(def));
	$ZodStringFormat.init(inst, def);
});
var $ZodISODate = /*@__PURE__*/ $constructor("$ZodISODate", (inst, def) => {
	def.pattern ?? (def.pattern = date);
	$ZodStringFormat.init(inst, def);
});
var $ZodISOTime = /*@__PURE__*/ $constructor("$ZodISOTime", (inst, def) => {
	def.pattern ?? (def.pattern = time(def));
	$ZodStringFormat.init(inst, def);
});
var $ZodISODuration = /*@__PURE__*/ $constructor("$ZodISODuration", (inst, def) => {
	def.pattern ?? (def.pattern = duration);
	$ZodStringFormat.init(inst, def);
});
var $ZodIPv4 = /*@__PURE__*/ $constructor("$ZodIPv4", (inst, def) => {
	def.pattern ?? (def.pattern = ipv4);
	$ZodStringFormat.init(inst, def);
});
/** An IPv6 address is written with hex digits, colons and dots, and nothing else. The guard is what makes the check below an IPv6 check: `new URL("http://[...]")` parses an authority, not an address, so `@` and `\` re-delimit it and `"::@1\\"` validates against the host `0.0.0.1`. The URL parser also deletes ASCII tab, LF and CR rather than failing, which is how `"::1\n"` validated as `::1`. */
var ipv6Alphabet = /^[0-9a-fA-F:.]+$/;
function isValidIPv6(value) {
	if (!ipv6Alphabet.test(value)) return false;
	return canParseURL(`http://[${value}]`);
}
var $ZodIPv6 = /*@__PURE__*/ $constructor("$ZodIPv6", (inst, def) => {
	def.pattern ?? (def.pattern = ipv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (!isValidIPv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCIDRv4 = /*@__PURE__*/ $constructor("$ZodCIDRv4", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv4);
	$ZodStringFormat.init(inst, def);
});
function isValidCIDRv6(value) {
	const parts = value.split("/");
	if (parts.length !== 2) return false;
	const [address, prefix] = parts;
	if (!prefix) return false;
	const prefixNum = Number(prefix);
	if (`${prefixNum}` !== prefix) return false;
	if (prefixNum < 0 || prefixNum > 128) return false;
	return isValidIPv6(address);
}
var $ZodCIDRv6 = /*@__PURE__*/ $constructor("$ZodCIDRv6", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (!isValidCIDRv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
function isValidBase64(data) {
	if (data === "") return true;
	if (/\s/.test(data)) return false;
	if (data.length % 4 !== 0) return false;
	try {
		atob(data);
		return true;
	} catch {
		return false;
	}
}
var base64Charset = /^[0-9a-zA-Z+/]*={0,2}$/;
var $ZodBase64 = /*@__PURE__*/ $constructor("$ZodBase64", (inst, def) => {
	def.pattern ?? (def.pattern = base64Charset);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidBase64(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var base64urlCharset = /^[A-Za-z0-9_-]*$/;
function isValidBase64URL(data) {
	if (!base64urlCharset.test(data)) return false;
	const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
	return isValidBase64(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
}
var $ZodBase64URL = /*@__PURE__*/ $constructor("$ZodBase64URL", (inst, def) => {
	def.pattern ?? (def.pattern = base64urlCharset);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidBase64URL(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodE164 = /*@__PURE__*/ $constructor("$ZodE164", (inst, def) => {
	def.pattern ?? (def.pattern = e164);
	$ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
	try {
		const tokensParts = token.split(".");
		if (tokensParts.length !== 3) return false;
		const [header] = tokensParts;
		if (!header) return false;
		const parsedHeader = JSON.parse(atob(header));
		if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT") return false;
		if (!parsedHeader.alg) return false;
		if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm)) return false;
		return true;
	} catch {
		return false;
	}
}
var $ZodJWT = /*@__PURE__*/ $constructor("$ZodJWT", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidJWT(payload.value, def.alg)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = number$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Number(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
		const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : void 0 : void 0;
		payload.issues.push({
			expected: "number",
			code: "invalid_type",
			input,
			inst,
			...received ? { received } : {}
		});
		return payload;
	};
});
var $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
	$ZodCheckNumberFormat.init(inst, def);
	$ZodNumber.init(inst, def);
});
var $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = boolean$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Boolean(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "boolean") return payload;
		payload.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input,
			inst
		});
		return payload;
	};
});
var $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload) => payload;
});
var $ZodNever = /*@__PURE__*/ $constructor("$ZodNever", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _ctx) => {
		payload.issues.push({
			expected: "never",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
function capSize(inst, size) {
	const caps = sizeCaps(inst._zod.def.checks);
	if (!caps.length) return;
	const cap = Math.min(...caps.map((c) => c[0]));
	const parse = inst._zod.parse;
	inst._zod.parse = (payload, ctx) => {
		const n = size(payload.value);
		if (n > cap && !ctx?.skipChecks && ctx?.direction !== "backward") {
			for (const [max, ch] of sizeCaps(inst._zod.def.checks)) if (n > max && ch._zod.def.when(payload)) {
				const start = payload.issues.length;
				ch._zod.check(payload);
				payload.issues[start].continue = false;
				attachSchema(payload.issues, start, inst);
				return payload;
			}
		}
		return parse(payload, ctx);
	};
}
var arraySize = (input) => Array.isArray(input) ? input.length : -1;
function handleArrayResult(result, final, index) {
	if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
	final.value[index] = result.value;
}
var $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!Array.isArray(input)) {
			payload.issues.push({
				expected: "array",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
		const proms = [];
		const abortEarly = ctx?.abortEarly;
		for (let i = 0; i < input.length; i++) {
			const item = input[i];
			const result = def.element._zod.run({
				value: item,
				issues: []
			}, ctx);
			if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
			else {
				handleArrayResult(result, payload, i);
				if (abortEarly && result.issues.length !== 0 && aborted(result)) break;
			}
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
	capSize(inst, arraySize);
});
function handlePropertyResult(result, final, key, input, optin, optout) {
	const isPresent = key in input;
	const isOptionalOut = optout === "optional";
	if (!isPresent && isOptionalOut && optin === "optional") return;
	if (result.issues.length) {
		if (optin !== void 0 && isOptionalOut && !isPresent) return;
		final.issues.push(...prefixIssues(key, result.issues));
	}
	if (!isPresent && optin === void 0) {
		if (!result.issues.length) final.issues.push({
			code: "invalid_type",
			expected: "nonoptional",
			input: void 0,
			path: [key]
		});
		return;
	}
	if (result.value === void 0) {
		if (isPresent || optin === "defaulted" && !isOptionalOut) final.value[key] = void 0;
	} else final.value[key] = result.value;
}
var NO_SYMBOL_KEYS = [];
function normalizeDef(def) {
	const keys = Object.keys(def.shape);
	const ownSymbols = Object.getOwnPropertySymbols(def.shape);
	const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
	const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
	for (const k of allKeys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
	const okeys = optionalKeys(def.shape);
	return {
		...def,
		allKeys,
		symbolKeys,
		keySet: new Set(keys),
		numKeys: keys.length,
		optionalKeys: new Set(okeys)
	};
}
function handleCatchall(proms, input, payload, ctx, def, inst, abortEarly) {
	const unrecognized = [];
	const keySet = def.keySet;
	const _catchall = def.catchall._zod;
	const t = _catchall.def.type;
	const optin = _catchall.optin;
	const optout = _catchall.optout;
	let seen = 0;
	for (const key in input) {
		if (abortEarly && payload.issues.length !== seen) {
			if (aborted(payload, seen)) break;
			seen = payload.issues.length;
		}
		if (keySet.has(key)) continue;
		if (key === "__proto__") {
			if (t === "never") unrecognized.push(key);
			continue;
		}
		if (t === "never") {
			unrecognized.push(key);
			continue;
		}
		const r = _catchall.run({
			value: input[key],
			issues: []
		}, ctx);
		if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
		else handlePropertyResult(r, payload, key, input, optin, optout);
	}
	if (unrecognized.length) payload.issues.push({
		code: "unrecognized_keys",
		keys: unrecognized,
		input,
		inst,
		continue: true
	});
	if (!proms.length) return payload;
	return Promise.all(proms).then(() => {
		return payload;
	});
}
var $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
	$ZodType.init(inst, def);
	const desc = Object.getOwnPropertyDescriptor(def, "shape");
	const sh = desc?.get ? desc.get.raw : def.shape ?? {};
	if (sh) {
		const get = () => {
			const newSh = { ...sh };
			Object.defineProperty(def, "shape", { value: newSh });
			get.raw = newSh;
			return newSh;
		};
		get.raw = sh;
		Object.defineProperty(def, "shape", { get });
	}
	const _normalized = cached(() => normalizeDef(def));
	defineLazyInternal(inst, "propValues", (zod) => {
		const shape = zod.def.shape;
		const propValues = {};
		for (const key in shape) {
			const field = shape[key]._zod;
			if (field.values) {
				if (!Object.prototype.hasOwnProperty.call(propValues, key)) assignProp(propValues, key, /* @__PURE__ */ new Set());
				for (const v of field.values) propValues[key].add(v);
				if (field.optin !== void 0) propValues[key].add(void 0);
			}
		}
		return propValues;
	});
	const isObject$1 = isObject;
	const catchall = def.catchall;
	let value;
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$1(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
		const proms = [];
		const shape = value.shape;
		const abortEarly = ctx?.abortEarly;
		let seen = payload.issues.length;
		for (const key of value.allKeys) {
			if (abortEarly && payload.issues.length !== seen) {
				if (aborted(payload, seen)) break;
				seen = payload.issues.length;
			}
			if (key === "__proto__") continue;
			const el = shape[key];
			const optin = el._zod.optin;
			const optout = el._zod.optout;
			const r = el._zod.run({
				value: input[key],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
			else handlePropertyResult(r, payload, key, input, optin, optout);
		}
		if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
		return handleCatchall(proms, input, payload, ctx, _normalized.value, inst, abortEarly === true);
	};
});
var $ZodObjectJIT = /*@__PURE__*/ $constructor("$ZodObjectJIT", (inst, def) => {
	$ZodObject.init(inst, def);
	const superParse = inst._zod.parse;
	const _normalized = cached(() => normalizeDef(def));
	const memo = globalConfig.memoizer;
	const generateFastpass = (shape) => {
		const normalized = _normalized.value;
		const syms = normalized.symbolKeys;
		const doc = new Doc(["payload", "ctx"], {
			shape,
			inst,
			memo,
			syms
		});
		const parseStr = (k) => `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
		const prefixStr = (id, k) => `
          let ${id}_ab = false;
          for (let i = 0; i < ${id}.issues.length; i++) {
            const iss = ${id}.issues[i];
            iss.path = iss.path ? [${k}, ...iss.path] : [${k}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${id}_ab = true;
          }
          if (${id}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
		doc.write(`const input = payload.value;`);
		const ids = Object.create(null);
		let counter = 0;
		for (const key of normalized.allKeys) ids[key] = `key_${counter++}`;
		doc.write(memo ? `const newResult = memo.alloc(inst, payload, {}, ctx);` : `const newResult = {};`);
		for (const key of normalized.allKeys) {
			if (key === "__proto__") continue;
			const id = ids[key];
			const k = typeof key === "symbol" ? `syms[${syms.indexOf(key)}]` : esc(key);
			const isPresent = `${k} in input`;
			const schema = shape[key];
			const optin = schema?._zod?.optin;
			const isOptionalIn = optin !== void 0;
			const isOptionalOut = schema?._zod?.optout === "optional";
			doc.write(`const ${id} = ${parseStr(k)};`);
			if (isOptionalIn && isOptionalOut) {
				const assign = optin === "optional" ? `${id}_present` : `${id}.value !== undefined || ${id}_present`;
				doc.write(`
        const ${id}_present = ${isPresent};
        if (!${id}.issues.length || ${id}_present) {
          if (${id}.issues.length) {${prefixStr(id, k)}
          }

          if (${assign}) {
            newResult[${k}] = ${id}.value;
          }
        }

      `);
			} else if (!isOptionalIn) doc.write(`
        const ${id}_present = ${isPresent};
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
        if (!${id}_present && !${id}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${id}_present) {
          newResult[${k}] = ${id}.value;
        }

      `);
			else {
				doc.write(`
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
      `);
				if (optin === "defaulted") doc.write(`newResult[${k}] = ${id}.value;`);
				else doc.write(`
        if (${id}.value !== undefined || ${isPresent}) {
          newResult[${k}] = ${id}.value;
        }
      `);
			}
		}
		doc.write(`payload.value = newResult;`);
		doc.write(`return payload;`);
		return doc.compile();
	};
	let fastpass;
	const isObject$2 = isObject;
	const jit = !globalConfig.jitless;
	const fastEnabled = jit && allowsEval.value;
	const catchall = def.catchall;
	let value;
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$2(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
			if (!fastpass) fastpass = generateFastpass(def.shape);
			payload = fastpass(payload, ctx);
			if (!catchall) return payload;
			return handleCatchall([], input, payload, ctx, value, inst, ctx?.abortEarly === true);
		}
		return superParse(payload, ctx);
	};
});
function handleUnionResults(results, final, inst, ctx) {
	for (const result of results) if (result.issues.length === 0) {
		final.value = result.value;
		return final;
	}
	const nonaborted = results.filter((r) => !aborted(r));
	if (nonaborted.length === 1) {
		final.value = nonaborted[0].value;
		return nonaborted[0];
	}
	final.issues.push({
		code: "invalid_union",
		input: final.value,
		inst,
		errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
	});
	return final;
}
var $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
	defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
	defineLazyInternal(inst, "values", (zod) => {
		if (zod.def.options.every((o) => o._zod.values)) return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		if (zod.def.options.every((o) => o._zod.pattern)) {
			const patterns = zod.def.options.map((o) => o._zod.pattern);
			return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
		}
	});
	const first = def.options.length === 1 ? def.options[0]._zod.run : null;
	inst._zod.parse = (payload, ctx) => {
		if (first) return first(payload, ctx);
		let async = false;
		const results = [];
		for (const option of def.options) {
			const result = option._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) {
				results.push(result);
				async = true;
			} else {
				if (result.issues.length === 0) return result;
				results.push(result);
			}
		}
		if (!async) return handleUnionResults(results, payload, inst, ctx);
		return Promise.all(results).then((results) => {
			return handleUnionResults(results, payload, inst, ctx);
		});
	};
});
var $ZodIntersection = /*@__PURE__*/ $constructor("$ZodIntersection", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		const left = def.left._zod.run({
			value: input,
			issues: []
		}, ctx);
		const right = def.right._zod.run({
			value: input,
			issues: []
		}, ctx);
		if (left instanceof Promise || right instanceof Promise) return Promise.all([left, right]).then(([left, right]) => {
			return handleIntersectionResults(payload, left, right);
		});
		return handleIntersectionResults(payload, left, right);
	};
});
function mergeValues(a, b) {
	if (a === b) return {
		valid: true,
		data: a
	};
	if (a instanceof Date && b instanceof Date && +a === +b) return {
		valid: true,
		data: a
	};
	if (isPlainObject(a) && isPlainObject(b)) {
		const bKeys = Object.keys(b);
		const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		if (Object.prototype.hasOwnProperty.call(newObj, "__proto__")) delete newObj.__proto__;
		for (const key of sharedKeys) {
			if (key === "__proto__") continue;
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
			};
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	}
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return {
			valid: false,
			mergeErrorPath: []
		};
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
			};
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	}
	return {
		valid: false,
		mergeErrorPath: []
	};
}
function handleIntersectionResults(result, left, right) {
	const unrecKeys = /* @__PURE__ */ new Map();
	let unrecIssue;
	const keyIssues = /* @__PURE__ */ new Map();
	const collect = (iss, side) => {
		let keys;
		if (iss.code === "unrecognized_keys" && !iss.path?.length) {
			unrecIssue ?? (unrecIssue = iss);
			keys = iss.keys;
		} else if (iss.code === "invalid_key" && iss.origin === "record" && iss.path?.length === 1) {
			const k = String(iss.path[0]);
			if (!keyIssues.has(k)) keyIssues.set(k, iss);
			keys = [k];
		} else return false;
		for (const k of keys) {
			if (!unrecKeys.has(k)) unrecKeys.set(k, {});
			unrecKeys.get(k)[side] = true;
		}
		return true;
	};
	for (const iss of left.issues) if (!collect(iss, "l")) result.issues.push(iss);
	for (const iss of right.issues) if (!collect(iss, "r")) result.issues.push(iss);
	const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
	if (bothKeys.length) {
		const aggregated = unrecIssue ? bothKeys.filter((k) => unrecIssue.keys.includes(k)) : [];
		if (aggregated.length) result.issues.push({
			...unrecIssue,
			keys: aggregated
		});
		for (const k of bothKeys) if (!aggregated.includes(k) && keyIssues.has(k)) result.issues.push(keyIssues.get(k));
	}
	const merged = mergeValues(left.value, right.value);
	if (!merged.valid) {
		if (aborted(result)) return result;
		throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(merged.mergeErrorPath)}`);
	}
	result.value = merged.data;
	return result;
}
var $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!isPlainObject(input)) {
			payload.issues.push({
				expected: "record",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		const proms = [];
		const values = def.keyType._zod.values;
		if (values && !def.partial) {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			const recordKeys = /* @__PURE__ */ new Set();
			for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
				recordKeys.add(typeof key === "number" ? key.toString() : key);
				if (key === "__proto__") continue;
				const keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (keyResult.issues.length) {
					payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			let unrecognized;
			for (const key in input) if (!recordKeys.has(key)) {
				if (def.mode === "loose") {
					if (key === "__proto__") continue;
					payload.value[key] = input[key];
				} else {
					unrecognized = unrecognized ?? [];
					unrecognized.push(key);
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		} else {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			let unrecognized;
			for (const key of Reflect.ownKeys(input)) {
				if (key === "__proto__") continue;
				if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
				let keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (typeof key === "string" && number$1.test(key) && keyResult.issues.length) {
					const retryResult = def.keyType._zod.run({
						value: Number(key),
						issues: []
					}, ctx);
					if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (retryResult.issues.length === 0) keyResult = retryResult;
				}
				if (keyResult.issues.length) {
					if (def.mode === "loose") payload.value[key] = input[key];
					else if (values) {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					} else payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
});
var $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
	$ZodType.init(inst, def);
	const values = getEnumValues(def.entries);
	const valuesSet = new Set(values);
	inst._zod.values = valuesSet;
	defineLazyInternal(inst, "pattern", (zod) => {
		const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
		return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
	});
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (valuesSet.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
	$ZodType.init(inst, def);
	const values = new Set(def.values);
	inst._zod.values = values;
	defineLazyInternal(inst, "pattern", (zod) => {
		const vals = zod.def.values;
		return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
	});
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (values.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values: def.values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodTransform = /*@__PURE__*/ $constructor("$ZodTransform", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "optional";
	globalConfig.memoizer?.guard(inst);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		const _out = def.transform(payload.value, payload);
		if (ctx.async) return (_out instanceof Promise ? _out : Promise.resolve(_out)).then((output) => {
			payload.value = output;
			return payload;
		});
		if (_out instanceof Promise) throw new $ZodAsyncError();
		payload.value = _out;
		return payload;
	};
});
function handleOptionalResult(payload, result) {
	payload.value = result.issues.length ? void 0 : result.value;
	return payload;
}
var $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	inst._zod.optout = "optional";
	defineLazyInternal(inst, "values", (zod) => {
		const values = zod.def.innerType._zod.values;
		return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === void 0) {
			if (def.innerType._zod.optin !== "defaulted") return payload;
			const result = def.innerType._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) return result.then((result) => handleOptionalResult(payload, result));
			return handleOptionalResult(payload, result);
		}
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodExactOptional = /*@__PURE__*/ $constructor("$ZodExactOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "pattern", (zod) => zod.def.innerType._zod.pattern);
	inst._zod.parse = (payload, ctx) => {
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
	});
	defineLazyInternal(inst, "values", (zod) => {
		return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === null) return payload;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodDefault = /*@__PURE__*/ $constructor("$ZodDefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) {
			payload.value = def.defaultValue;
			/**
			* $ZodDefault returns the default value immediately in forward direction.
			* It doesn't pass the default value into the validator ("prefault"). There's no reason to pass the default value through validation. The validity of the default is enforced by TypeScript statically. Otherwise, it's the responsibility of the user to ensure the default is valid. In the case of pipes with divergent in/out types, you can specify the default on the `in` schema of your ZodPipe to set a "prefault" for the pipe.   */
			return payload;
		}
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleDefaultResult(result, def));
		return handleDefaultResult(result, def);
	};
});
function handleDefaultResult(payload, def) {
	if (payload.value === void 0) payload.value = def.defaultValue;
	return payload;
}
var $ZodPrefault = /*@__PURE__*/ $constructor("$ZodPrefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) payload.value = def.defaultValue;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNonOptional = /*@__PURE__*/ $constructor("$ZodNonOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => {
		const v = zod.def.innerType._zod.values;
		return v ? new Set([...v].filter((x) => x !== void 0)) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleNonOptionalResult(result, inst));
		return handleNonOptionalResult(result, inst);
	};
});
function handleNonOptionalResult(payload, inst) {
	if (!payload.issues.length && payload.value === void 0) payload.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: payload.value,
		inst
	});
	return payload;
}
function handleCatchResult(payload, result, def, ctx) {
	if (!result.issues.length) {
		payload.value = result.value;
		if (result.memo) payload.memo = true;
		return payload;
	}
	payload.value = def.catchValue({
		...result,
		value: payload.value,
		error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
		input: payload.value
	});
	return payload;
}
var $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run({
			value: payload.value,
			issues: []
		}, ctx);
		if (result instanceof Promise) return result.then((result) => handleCatchResult(payload, result, def, ctx));
		return handleCatchResult(payload, result, def, ctx);
	};
});
var $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") {
			const right = def.out._zod.run(payload, ctx);
			if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
			return handlePipeResult(right, def.in, ctx);
		}
		const left = def.in._zod.run(payload, ctx);
		if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
		return handlePipeResult(left, def.out, ctx);
	};
});
function handlePipeResult(left, next, ctx) {
	if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
		left.aborted = true;
		return left;
	}
	return next._zod.run({
		value: left.value,
		issues: left.issues
	}, ctx);
}
var $ZodReadonly = /*@__PURE__*/ $constructor("$ZodReadonly", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.innerType._zod.propValues);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType?._zod?.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType?._zod?.optout);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then(handleReadonlyResult);
		return handleReadonlyResult(result);
	};
});
function handleReadonlyResult(payload) {
	if (!payload.memo) payload.value = Object.freeze(payload.value);
	return payload;
}
var $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
	$ZodCheck.init(inst, def);
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _) => {
		return payload;
	};
	inst._zod.check = (payload) => {
		const input = payload.value;
		const r = def.fn(input);
		if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
		handleRefineResult(r, payload, input, inst);
	};
});
function handleRefineResult(result, payload, input, inst) {
	if (!result) {
		const _iss = {
			code: "custom",
			input,
			inst,
			path: [...inst._zod.def.path ?? []],
			continue: !inst._zod.def.abort
		};
		if (inst._zod.def.params) _iss.params = inst._zod.def.params;
		payload.issues.push(issue(_iss));
	}
}
//#endregion
//#region ../../node_modules/zod/v4/core/memoizer.js
var $ZodCyclicError = class extends Error {
	constructor() {
		super(`Cannot parse a reference cycle that closes through a transform`);
		this.name = "ZodCyclicError";
	}
};
/** Keyed off the context object every schema in one parse call already shares. */
var STATE = "~memo";
var NO_ISSUES = [];
function isRef(value) {
	return value !== null && typeof value === "object";
}
function cloneIssues(issues) {
	return issues.map((iss) => iss.path ? {
		...iss,
		path: iss.path.slice()
	} : { ...iss });
}
var recursive = /*@__PURE__*/ new WeakMap();
/** What the walk established, in order of certainty: ordered so the strongest answer among children wins. */
var NONE = 0;
var ASSUMED = 1;
var PROVEN = 2;
/** Whether this schema's subtree contains a cycle, so one parse can re-enter it. */
function isRecursive(inst, stack, resolve) {
	const cached = recursive.get(inst);
	if (cached !== void 0) return cached ? PROVEN : NONE;
	if (stack.has(inst)) return PROVEN;
	stack.add(inst);
	let result = NONE;
	const check = (child) => {
		if (result !== PROVEN && child?._zod) {
			const answer = isRecursive(child, stack, resolve);
			if (answer > result) result = answer;
		}
	};
	const shape = (sh, spread) => {
		let answer = NONE;
		for (const key of Reflect.ownKeys(sh)) {
			const desc = Object.getOwnPropertyDescriptor(sh, key);
			if (spread && !desc.enumerable) continue;
			const child = desc.get ? ASSUMED : desc.value?._zod ? isRecursive(desc.value, stack, resolve) : NONE;
			if (child > answer) answer = child;
		}
		return answer;
	};
	const merge = (answer) => {
		if (answer > result) result = answer;
	};
	const def = inst._zod.def;
	switch (def.type) {
		case "object": {
			const raw = rawShape(def);
			merge(raw ? shape(raw, true) : ASSUMED);
			check(def.catchall);
			break;
		}
		case "array":
			check(def.element);
			break;
		case "tuple":
			for (const el of def.items) check(el);
			check(def.rest);
			break;
		case "record":
		case "map":
			check(def.keyType);
			check(def.valueType);
			break;
		case "set":
			check(def.valueType);
			break;
		case "union":
			for (const el of def.options) check(el);
			break;
		case "intersection":
			check(def.left);
			check(def.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			check(def.innerType);
			break;
		case "pipe":
			check(def.in);
			check(def.out);
			break;
		case "function":
			check(def.input);
			check(def.output);
			break;
		case "lazy": {
			const inner = def._cachedInner ?? (resolve ? inst._zod.innerType : void 0);
			merge(inner ? isRecursive(inner, stack, false) : ASSUMED);
			break;
		}
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (const key in def) {
			const desc = Object.getOwnPropertyDescriptor(def, key);
			if (!desc || desc.get) continue;
			const value = desc.value;
			if (!value || typeof value !== "object") continue;
			if (value._zod) check(value);
			else if (Array.isArray(value)) for (const el of value) check(el);
		}
	}
	stack.delete(inst);
	return settle(inst, result);
}
/** An assumed answer must not outlive the resolution that settles it, so only a certain one is cached. */
function settle(inst, answer) {
	if (answer !== ASSUMED) recursive.set(inst, answer === PROVEN);
	return answer;
}
function bucketFor(state, inst) {
	let bucket = state.buckets.get(inst);
	if (!bucket) {
		bucket = /* @__PURE__ */ new WeakMap();
		state.buckets.set(inst, bucket);
	}
	return bucket;
}
var handoff;
var open = [];
var memo = {
	alloc(_inst, payload, empty) {
		const bucket = handoff;
		if (!bucket) return empty;
		handoff = void 0;
		const entry = {
			value: empty,
			issues: null
		};
		bucket.set(payload.value, entry);
		open.push(entry);
		return empty;
	},
	guard(inst) {
		var _a;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value)) throw new $ZodCyclicError();
				return base(payload, ctx);
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	},
	attach(inst) {
		var _a;
		let isRecursiveInst;
		let rechecked = false;
		let lastCtx;
		let lastBucket;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (isRecursiveInst === void 0) {
					const walked = isRecursive(inst, /* @__PURE__ */ new Set(), false);
					if (walked === NONE) {
						inst._zod.parse = base;
						if (inst._zod.run === wrapped) inst._zod.run = base;
						return base(payload, ctx);
					}
					if (walked === PROVEN || rechecked) isRecursiveInst = true;
					else rechecked = true;
				}
				const input = payload.value;
				if (!isRef(input)) return base(payload, ctx);
				let state = ctx[STATE];
				if (!state) {
					state = {
						buckets: /* @__PURE__ */ new WeakMap(),
						backEdges: void 0
					};
					ctx[STATE] = state;
				}
				let bucket;
				if (lastCtx === ctx) bucket = lastBucket;
				else {
					bucket = bucketFor(state, inst);
					lastCtx = ctx;
					lastBucket = bucket;
				}
				const hit = bucket.get(input);
				if (hit) {
					payload.value = hit.value;
					if (hit.issues) {
						if (hit.issues.length) payload.issues.push(...cloneIssues(hit.issues));
					} else {
						payload.memo = true;
						state.backEdges ?? (state.backEdges = /* @__PURE__ */ new WeakSet());
						state.backEdges.add(hit.value);
					}
					return payload;
				}
				handoff = bucket;
				const depth = open.length;
				const result = base(payload, ctx);
				handoff = void 0;
				const entry = open.length > depth ? open.pop() : void 0;
				if (result instanceof Promise) return result.then((r) => {
					if (entry) entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
					return r;
				});
				if (entry) entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
				return result;
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	}
};
/** The memoizer that gives containers cycle support. `zod` installs it by default; `zod/mini` opts in with `config({ memoizer: memoizer() })`. */
function memoizer() {
	return memo;
}
/** Whether this value is a node a back-edge resolved to before it finished. */
function isBackEdge(ctx, value) {
	const backEdges = ctx[STATE]?.backEdges;
	return backEdges !== void 0 && isRef(value) && backEdges.has(value);
}
//#endregion
//#region ../../node_modules/zod/v4/locales/en.js
var error = () => {
	const Sizable = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function getSizing(origin) {
		return Sizable[origin] ?? null;
	}
	const FormatDictionary = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		currency_code: "currency code",
		credit_card: "credit card number",
		iban: "IBAN",
		jwt: "JWT",
		template_literal: "input"
	};
	const TypeDictionary = { nan: "NaN" };
	function getTypeName(type, input) {
		if (type === "number" && typeof input === "number" && !Number.isFinite(input)) return String(input);
		return TypeDictionary[type] ?? type;
	}
	return (issue) => {
		switch (issue.code) {
			case "invalid_type": return `Invalid input: expected ${getTypeName(issue.expected)}, received ${getTypeName(parsedType(issue.input), issue.input)}`;
			case "invalid_value":
				if (issue.values.length === 1) return `Invalid input: expected ${stringifyPrimitive(issue.values[0])}`;
				return `Invalid option: expected one of ${joinValues(issue.values, "|")}`;
			case "too_big": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? "<=" : "<";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
				return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
			}
			case "too_small": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? ">=" : ">";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
				return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
			}
			case "invalid_format": {
				const _issue = issue;
				if (_issue.format === "starts_with") return `Invalid string: must start with "${_issue.prefix}"`;
				if (_issue.format === "ends_with") return `Invalid string: must end with "${_issue.suffix}"`;
				if (_issue.format === "includes") return `Invalid string: must include "${_issue.includes}"`;
				if (_issue.format === "regex") return `Invalid string: must match pattern ${_issue.pattern}`;
				return `Invalid ${FormatDictionary[_issue.format] ?? issue.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${issue.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${joinValues(issue.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${issue.origin}`;
			case "invalid_union":
				if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) return `Invalid discriminator value. Expected ${issue.options.map((o) => `'${o}'`).join(" | ")}`;
				if (issue.inclusive === false) return "Invalid input: more than one option matched";
				return "Invalid input";
			case "invalid_element": return `Invalid value in ${issue.origin}`;
			default: return `Invalid input`;
		}
	};
};
function en_default() {
	return { localeError: error() };
}
//#endregion
//#region ../../node_modules/zod/v4/core/registries.js
var _a;
var $ZodRegistry = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
	}
	add(schema, ..._meta) {
		const meta = _meta[0];
		this._map.set(schema, meta);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.set(meta.id, schema);
		return this;
	}
	clear() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
		return this;
	}
	remove(schema) {
		const meta = this._map.get(schema);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.delete(meta.id);
		this._map.delete(schema);
		return this;
	}
	get(schema) {
		const p = schema._zod.parent;
		if (p) {
			const pm = { ...this.get(p) ?? {} };
			delete pm.id;
			const f = {
				...pm,
				...this._map.get(schema)
			};
			return Object.keys(f).length ? f : void 0;
		}
		return this._map.get(schema);
	}
	has(schema) {
		return this._map.has(schema);
	}
};
function registry() {
	return new $ZodRegistry();
}
(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
//#endregion
//#region ../../node_modules/zod/v4/core/api.js
function snapshotChecks(def) {
	if (def.checks) def.checks = [...def.checks];
	return def;
}
// @__NO_SIDE_EFFECTS__
function _string(Class, params) {
	return new Class(snapshotChecks({
		type: "string",
		...normalizeParams(params)
	}));
}
// @__NO_SIDE_EFFECTS__
function _email(Class, params) {
	return new Class({
		type: "string",
		format: "email",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _guid(Class, params) {
	return new Class({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuid(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv4(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v4",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv6(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v6",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv7(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v7",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _url(Class, params) {
	return new Class({
		type: "string",
		format: "url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _emoji(Class, params) {
	return new Class({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _nanoid(Class, params) {
	return new Class({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link _cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
// @__NO_SIDE_EFFECTS__
function _cuid(Class, params) {
	return new Class({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cuid2(Class, params) {
	return new Class({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ulid(Class, params) {
	return new Class({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _xid(Class, params) {
	return new Class({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ksuid(Class, params) {
	return new Class({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv4(Class, params) {
	return new Class({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv6(Class, params) {
	return new Class({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv4(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv6(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64(Class, params) {
	return new Class({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64url(Class, params) {
	return new Class({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _e164(Class, params) {
	return new Class({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _jwt(Class, params) {
	return new Class({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDateTime(Class, params) {
	return new Class({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: false,
		local: false,
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDate(Class, params) {
	return new Class({
		type: "string",
		format: "date",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoTime(Class, params) {
	return new Class({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDuration(Class, params) {
	return new Class({
		type: "string",
		format: "duration",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _number(Class, params) {
	return new Class(snapshotChecks({
		type: "number",
		checks: [],
		...normalizeParams(params)
	}));
}
// @__NO_SIDE_EFFECTS__
function _int(Class, params) {
	return new Class({
		type: "number",
		check: "number_format",
		abort: false,
		format: "safeint",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _boolean(Class, params) {
	return new Class({
		type: "boolean",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _unknown(Class) {
	return new Class({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function _never(Class, params) {
	return new Class({
		type: "never",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _lt(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _lte(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _gt(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _gte(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _multipleOf(value, params) {
	return new $ZodCheckMultipleOf({
		check: "multiple_of",
		...normalizeParams(params),
		value
	});
}
// @__NO_SIDE_EFFECTS__
function _maxLength(maximum, params) {
	return new $ZodCheckMaxLength({
		check: "max_length",
		...normalizeParams(params),
		maximum
	});
}
// @__NO_SIDE_EFFECTS__
function _minLength(minimum, params) {
	return new $ZodCheckMinLength({
		check: "min_length",
		...normalizeParams(params),
		minimum
	});
}
// @__NO_SIDE_EFFECTS__
function _length(length, params) {
	return new $ZodCheckLengthEquals({
		check: "length_equals",
		...normalizeParams(params),
		length
	});
}
// @__NO_SIDE_EFFECTS__
function _regex(pattern, params) {
	return new $ZodCheckRegex({
		check: "string_format",
		format: "regex",
		...normalizeParams(params),
		pattern
	});
}
// @__NO_SIDE_EFFECTS__
function _lowercase(params) {
	return new $ZodCheckLowerCase({
		check: "string_format",
		format: "lowercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uppercase(params) {
	return new $ZodCheckUpperCase({
		check: "string_format",
		format: "uppercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _includes(includes, params) {
	return new $ZodCheckIncludes({
		check: "string_format",
		format: "includes",
		...normalizeParams(params),
		includes
	});
}
// @__NO_SIDE_EFFECTS__
function _startsWith(prefix, params) {
	return new $ZodCheckStartsWith({
		check: "string_format",
		format: "starts_with",
		...normalizeParams(params),
		prefix
	});
}
// @__NO_SIDE_EFFECTS__
function _endsWith(suffix, params) {
	return new $ZodCheckEndsWith({
		check: "string_format",
		format: "ends_with",
		...normalizeParams(params),
		suffix
	});
}
// @__NO_SIDE_EFFECTS__
function _overwrite(tx) {
	return new $ZodCheckOverwrite({
		check: "overwrite",
		tx
	});
}
// @__NO_SIDE_EFFECTS__
function _normalize(form) {
	return /* @__PURE__ */ _overwrite((input) => input.normalize(form));
}
// @__NO_SIDE_EFFECTS__
function _trim() {
	return /* @__PURE__ */ _overwrite((input) => input.trim());
}
// @__NO_SIDE_EFFECTS__
function _toLowerCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function _toUpperCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function _slugify() {
	return /* @__PURE__ */ _overwrite((input) => slugify(input));
}
// @__NO_SIDE_EFFECTS__
function _array(Class, element, params) {
	return new Class({
		type: "array",
		element,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _custom(Class, fn, _params) {
	const norm = normalizeParams(_params);
	norm.abort ?? (norm.abort = true);
	return new Class({
		type: "custom",
		check: "custom",
		fn,
		...norm
	});
}
// @__NO_SIDE_EFFECTS__
function _refine(Class, fn, _params) {
	return new Class({
		type: "custom",
		check: "custom",
		fn,
		...normalizeParams(_params)
	});
}
// @__NO_SIDE_EFFECTS__
function _superRefine(fn, params) {
	const ch = /* @__PURE__ */ _check((payload) => {
		payload.addIssue = (issue$2) => {
			if (typeof issue$2 === "string") payload.issues.push(issue(issue$2, payload.value, ch._zod.def));
			else {
				const _issue = issue$2;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = ch);
				_issue.continue ?? (_issue.continue = !ch._zod.def.abort);
				payload.issues.push(issue(_issue));
			}
		};
		return fn(payload.value, payload);
	}, params);
	return ch;
}
// @__NO_SIDE_EFFECTS__
function _check(fn, params) {
	const ch = new $ZodCheck({
		check: "custom",
		...normalizeParams(params)
	});
	ch._zod.check = fn;
	return ch;
}
//#endregion
//#region ../../node_modules/zod/v4/core/to-json-schema.js
function assignProps(target, ...sources) {
	for (const source of sources) for (const key of Reflect.ownKeys(source)) if (Object.prototype.propertyIsEnumerable.call(source, key)) assignProp(target, key, source[key]);
	return target;
}
function initializeContext(params) {
	let target = params?.target ?? "draft-2020-12";
	if (target === "draft-4") target = "draft-04";
	if (target === "draft-7") target = "draft-07";
	return {
		processors: params.processors ?? {},
		metadataRegistry: params?.metadata ?? globalRegistry,
		target,
		unrepresentable: params?.unrepresentable ?? "throw",
		override: params?.override ?? (() => {}),
		io: params?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: params?.cycles ?? "ref",
		reused: params?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: params?.external ?? void 0
	};
}
/**
* Applies the `unrepresentable` setting at a site that has no JSON Schema equivalent. Throws
* `message` unless the setting (or the handler's return value) says otherwise. Returns `true` if a
* custom JSON Schema was written into `json`, in which case the caller must not write its own.
*/
function handleUnrepresentable(schema, ctx, json, params, message) {
	const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({
		zodSchema: schema,
		path: params.path,
		message
	}) : ctx.unrepresentable;
	if (result === "any") return false;
	if (result === void 0 || result === "throw") throw new Error(message);
	Object.assign(json, result);
	return true;
}
function processSchema(schema, ctx, _params = {
	path: [],
	schemaPath: []
}) {
	var _a;
	const def = schema._zod.def;
	const seen = ctx.seen.get(schema);
	if (seen) {
		seen.count++;
		if (_params.schemaPath.includes(schema)) seen.cycle = _params.path;
		return seen.schema;
	}
	const result = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: _params.path
	};
	ctx.seen.set(schema, result);
	ctx.sharedDefsExtractedFor = void 0;
	ctx.sharedEmitDoneFor = void 0;
	const overrideSchema = schema._zod.toJSONSchema?.();
	if (overrideSchema) result.schema = overrideSchema;
	else {
		const params = {
			..._params,
			schemaPath: [..._params.schemaPath, schema],
			path: _params.path
		};
		if (schema._zod.processJSONSchema) schema._zod.processJSONSchema(ctx, result.schema, params);
		else {
			const _json = result.schema;
			const processor = ctx.processors[def.type];
			if (!processor) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
			processor(schema, ctx, _json, params);
		}
		const parent = schema._zod.parent;
		if (parent) {
			if (!result.ref) result.ref = parent;
			processSchema(parent, ctx, params);
			ctx.seen.get(parent).isParent = true;
		}
	}
	const meta = ctx.metadataRegistry.get(schema);
	if (meta) assignProps(result.schema, meta);
	if (ctx.io === "input" && isTransforming(schema)) {
		delete result.schema.examples;
		delete result.schema.default;
	}
	if (ctx.io === "input" && "_prefault" in result.schema) (_a = result.schema).default ?? (_a.default = result.schema._prefault);
	delete result.schema._prefault;
	return ctx.seen.get(schema).schema;
}
function encodeJSONPointerSegment(segment) {
	return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function extractDefs(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external) return;
	const idToSchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.entries()) {
		const id = ctx.metadataRegistry.get(entry[0])?.id;
		if (id) {
			const existing = idToSchema.get(id);
			if (existing && existing !== entry[0]) throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			idToSchema.set(id, entry[0]);
		}
	}
	const makeURI = (entry) => {
		const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
		if (ctx.external) {
			const externalId = ctx.external.registry.get(entry[0])?.id;
			const uriGenerator = ctx.external.uri ?? ((id) => id);
			if (externalId) return { ref: uriGenerator(externalId) };
			const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
			entry[1].defId = id;
			return {
				defId: id,
				ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id)}`
			};
		}
		const uriPrefix = `#`;
		const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
		if (entry[1] === root && !entry[1].schema.id) return { ref: uriPrefix };
		const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
		return {
			defId,
			ref: defUriPrefix + encodeJSONPointerSegment(defId)
		};
	};
	const extractToDef = (entry) => {
		if (entry[1].schema.$ref) return;
		const seen = entry[1];
		const { ref, defId } = makeURI(entry);
		seen.def = { ...seen.schema };
		if (defId) seen.defId = defId;
		const schema = seen.schema;
		for (const key in schema) delete schema[key];
		schema.$ref = ref;
	};
	if (ctx.cycles === "throw") for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.cycle) throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (schema === entry[0]) {
			extractToDef(entry);
			continue;
		}
		if (ctx.external) {
			const ext = ctx.external.registry.get(entry[0])?.id;
			if (schema !== entry[0] && ext) {
				extractToDef(entry);
				continue;
			}
		}
		if (ctx.metadataRegistry.get(entry[0])?.id) {
			extractToDef(entry);
			continue;
		}
		if (seen.cycle) {
			extractToDef(entry);
			continue;
		}
		if (seen.count > 1) {
			if (ctx.reused === "ref") extractToDef(entry);
		}
	}
	if (ctx.external) ctx.sharedDefsExtractedFor = ctx.external;
}
/** Rewrites `anyOf: [{type: "a"}, {type: "b"}]` to `type: ["a", "b"]`, which every JSON Schema draft treats as equivalent and most consumers render far better for the nullable case. Only branches that are a bare type assertion qualify — anything carrying a constraint, `$ref`, `const` or metadata is left alone. Runs after `flattenRef`, so a branch an override decorated or `$defs` extraction turned into a `$ref` is no longer bare and correctly stays in `anyOf`. `oneOf` is excluded: `integer` and `number` overlap, so "exactly one" and "at least one" are not the same there. OpenAPI 3.0 is excluded: its `type` must be a single string. */
function compactTypeUnion(schema) {
	const options = schema.anyOf;
	if (!Array.isArray(options) || options.length === 0 || schema.type !== void 0) return;
	const types = [];
	for (const option of options) {
		if (!option || typeof option !== "object") return;
		compactTypeUnion(option);
		const keys = Object.keys(option);
		if (keys.length !== 1 || keys[0] !== "type") return;
		const type = option.type;
		for (const member of Array.isArray(type) ? type : [type]) {
			if (typeof member !== "string") return;
			if (!types.includes(member)) types.push(member);
		}
	}
	delete schema.anyOf;
	schema.type = types.length === 1 ? types[0] : types;
}
/** Keywords `foldIntersection` knows how to combine. Anything else — `$ref`, `patternProperties`,
* an annotation like `description` — makes a member unfoldable, so a constraint this does not
* understand leaves the `allOf` alone instead of being silently dropped or misattributed. */
var FOLDABLE_KEYS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]);
var UNION_KEYS = ["oneOf", "anyOf"];
/** A member's constraint on a key it does not declare itself. A `catchall` states one; `false`, an absent `additionalProperties`, and the empty schema a loose object emits state nothing. */
function undeclaredConstraint(member) {
	const extra = member.additionalProperties;
	if (extra === void 0 || extra === false || typeof extra !== "object" || extra === null) return null;
	return Object.keys(extra).length ? extra : null;
}
/** Combines object members into the single object they describe together, or returns `null` if any of them carries a keyword outside {@link FOLDABLE_KEYS}. */
function foldObjects(members) {
	const objects = [];
	for (const member of members) {
		if (typeof member !== "object" || member.type !== "object") return null;
		for (const key in member) if (!FOLDABLE_KEYS.has(key)) return null;
		objects.push(member);
	}
	const properties = {};
	const required = /* @__PURE__ */ new Set();
	for (const object of objects) {
		for (const key in object.properties) {
			if (Object.prototype.hasOwnProperty.call(properties, key)) continue;
			const parts = [];
			for (const other of objects) {
				const part = other.properties?.[key] ?? undeclaredConstraint(other);
				if (part === null || part === void 0) continue;
				if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part))) parts.push(part);
			}
			assignProp(properties, key, parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts });
		}
		for (const key of object.required ?? []) required.add(key);
	}
	const folded = {
		type: "object",
		properties
	};
	if (required.size) folded.required = [...required];
	if (objects.every((object) => object.additionalProperties === false)) folded.additionalProperties = false;
	else {
		const constraints = [];
		for (const object of objects) {
			const constraint = undeclaredConstraint(object);
			if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint))) constraints.push(constraint);
		}
		if (constraints.length === 1) folded.additionalProperties = constraints[0];
		else if (constraints.length > 1) folded.additionalProperties = { allOf: constraints };
	}
	return folded;
}
/** `additionalProperties` in an `allOf` member sees only that member's own `properties`, so two
* closed object members reject each other's keys and the schema validates nothing. Zod's parser
* pools the key sets instead — `handleIntersectionResults` reports a key as unrecognized only when
* *every* side rejects it — so the emitted schema has to pool them too, and folding the members
* into one object is the encoding that says so on every target.
*
* This runs from `finalize`, after `extractDefs`, which is what keeps it clear of the `$ref`
* machinery: a member extracted into `$defs` is already a `$ref` by now and declines to fold, so it
* keeps its reference and its own closedness rather than being inlined as a stale copy. */
function foldIntersection(json) {
	const allOf = json.allOf;
	if (!Array.isArray(allOf) || allOf.length < 2) return;
	for (const key of FOLDABLE_KEYS) if (key in json) return;
	const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
	let folded = null;
	if (!unions.length) folded = foldObjects(allOf);
	else {
		const union = unions[0];
		const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));
		if (Object.keys(union).length !== 1) return;
		const rest = allOf.filter((m) => m !== union);
		const branches = union[keyword].map((branch) => foldObjects([...rest, branch]));
		if (branches.some((b) => !b)) return;
		folded = { [keyword]: branches };
	}
	if (!folded) return;
	delete json.allOf;
	assignProps(json, folded);
}
function finalize(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	const flattenRef = (zodSchema) => {
		const seen = ctx.seen.get(zodSchema);
		if (seen.ref === null) return;
		const schema = seen.def ?? seen.schema;
		const _cached = { ...schema };
		const ref = seen.ref;
		seen.ref = null;
		if (ref) {
			flattenRef(ref);
			const refSeen = ctx.seen.get(ref);
			const refSchema = refSeen.schema;
			if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
				schema.allOf = schema.allOf ?? [];
				schema.allOf.push(refSchema);
			} else assignProps(schema, refSchema);
			assignProps(schema, _cached);
			if (zodSchema._zod.parent === ref) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (!(key in _cached)) delete schema[key];
			}
			if (refSchema.$ref && refSeen.def) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) delete schema[key];
			}
		}
		const parent = zodSchema._zod.parent;
		if (parent && parent !== ref) {
			flattenRef(parent);
			const parentSeen = ctx.seen.get(parent);
			if (parentSeen?.schema.$ref) {
				schema.$ref = parentSeen.schema.$ref;
				if (parentSeen.def) for (const key in schema) {
					if (key === "$ref" || key === "allOf") continue;
					if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) delete schema[key];
				}
			}
		}
		ctx.override({
			zodSchema,
			jsonSchema: schema,
			path: seen.path ?? []
		});
	};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
		for (const entry of [...ctx.seen.entries()].reverse()) flattenRef(entry[0]);
		if (ctx.target !== "openapi-3.0") for (const entry of ctx.seen.entries()) compactTypeUnion(entry[1].def ?? entry[1].schema);
		for (const rewrite of ctx.deferred) rewrite();
		if (ctx.intersections.length) {
			const carriers = /* @__PURE__ */ new Map();
			for (const seen of ctx.seen.values()) for (const json of [seen.schema, seen.def]) {
				const allOf = json?.allOf;
				if (!Array.isArray(allOf)) continue;
				const existing = carriers.get(allOf);
				if (existing) existing.push(json);
				else carriers.set(allOf, [json]);
			}
			for (const allOf of ctx.intersections) for (const json of carriers.get(allOf) ?? []) foldIntersection(json);
		}
	}
	const result = {};
	if (ctx.target === "draft-2020-12") result.$schema = "https://json-schema.org/draft/2020-12/schema";
	else if (ctx.target === "draft-07") result.$schema = "http://json-schema.org/draft-07/schema#";
	else if (ctx.target === "draft-04") result.$schema = "http://json-schema.org/draft-04/schema#";
	else if (ctx.target === "openapi-3.0") {}
	if (ctx.external?.uri) {
		const id = ctx.external.registry.get(schema)?.id;
		if (!id) throw new Error("Schema is missing an `id` property");
		result.$id = ctx.external.uri(id);
	}
	assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
	const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
	if (rootMetaId !== void 0 && result.id === rootMetaId) delete result.id;
	const defs = ctx.external?.defs ?? {};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.def && seen.defId) {
			if (seen.def.id === seen.defId) delete seen.def.id;
			assignProp(defs, seen.defId, seen.def);
		}
	}
	if (ctx.external) ctx.sharedEmitDoneFor = ctx.external;
	if (ctx.external) {} else if (Object.keys(defs).length > 0) {
		if (ctx.target === "draft-2020-12") result.$defs = defs;
		else result.definitions = defs;
	}
	try {
		const finalized = JSON.parse(JSON.stringify(result));
		Object.defineProperty(finalized, "~standard", {
			value: {
				...schema["~standard"],
				jsonSchema: {
					input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
					output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
				}
			},
			enumerable: false,
			writable: false
		});
		return finalized;
	} catch (_err) {
		throw new Error("Error converting schema to JSON.");
	}
}
function isTransforming(_schema, _ctx) {
	const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
	if (ctx.seen.has(_schema)) return false;
	ctx.seen.add(_schema);
	const def = _schema._zod.def;
	if (def.type === "transform") return true;
	if (def.type === "array") return isTransforming(def.element, ctx);
	if (def.type === "set") return isTransforming(def.valueType, ctx);
	if (def.type === "lazy") return isTransforming(def.getter(), ctx);
	if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") return isTransforming(def.innerType, ctx);
	if (def.type === "intersection") return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
	if (def.type === "record" || def.type === "map") return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
	if (def.type === "pipe") {
		if (_schema._zod.traits.has("$ZodCodec")) return true;
		return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
	}
	if (def.type === "object") {
		for (const key in def.shape) if (isTransforming(def.shape[key], ctx)) return true;
		return false;
	}
	if (def.type === "union") {
		for (const option of def.options) if (isTransforming(option, ctx)) return true;
		return false;
	}
	if (def.type === "tuple") {
		for (const item of def.items) if (isTransforming(item, ctx)) return true;
		if (def.rest && isTransforming(def.rest, ctx)) return true;
		return false;
	}
	return false;
}
/**
* Creates a toJSONSchema method for a schema instance.
* This encapsulates the logic of initializing context, processing, extracting defs, and finalizing.
*/
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
	const ctx = initializeContext({
		...params,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
	const { libraryOptions, target } = params ?? {};
	const ctx = initializeContext({
		...libraryOptions ?? {},
		target,
		io,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
//#endregion
//#region ../../node_modules/zod/v4/core/json-schema-processors.js
var narrowMin = (agg, key, value) => {
	if (agg[key] === void 0 || value > agg[key]) agg[key] = value;
};
var narrowMax = (agg, key, value) => {
	if (agg[key] === void 0 || value < agg[key]) agg[key] = value;
};
var narrowBoth = (agg, value) => {
	narrowMin(agg, "minimum", value);
	narrowMax(agg, "maximum", value);
};
var addDivisor = (agg, value) => {
	agg.multipleOf ?? (agg.multipleOf = []);
	if (!agg.multipleOf.includes(value)) agg.multipleOf.push(value);
};
var addPattern = (agg, pattern) => {
	agg.patterns ?? (agg.patterns = /* @__PURE__ */ new Set());
	agg.patterns.add(pattern);
};
var intersectMime = (agg, mime) => {
	agg.mime = agg.mime ? agg.mime.filter((m) => mime.includes(m)) : [...mime];
};
var setFormat = (agg, format) => {
	agg.format = format;
	if (format.includes("int")) agg.isInt = true;
};
var minContributor = (agg, def) => narrowMin(agg, "minimum", def.minimum);
var maxContributor = (agg, def) => narrowMax(agg, "maximum", def.maximum);
var formatContributor = (ranges) => (agg, def) => {
	setFormat(agg, def.format);
	const [minimum, maximum] = ranges[def.format];
	narrowMin(agg, "minimum", minimum);
	narrowMax(agg, "maximum", maximum);
};
var contributors = {
	greater_than: (agg, def) => narrowMin(agg, def.inclusive ? "minimum" : "exclusiveMinimum", def.value),
	less_than: (agg, def) => narrowMax(agg, def.inclusive ? "maximum" : "exclusiveMaximum", def.value),
	multiple_of: (agg, def) => addDivisor(agg, def.value),
	number_format: formatContributor(NUMBER_FORMAT_RANGES),
	bigint_format: formatContributor(BIGINT_FORMAT_RANGES),
	min_length: minContributor,
	max_length: maxContributor,
	length_equals: (agg, def) => narrowBoth(agg, def.length),
	min_size: minContributor,
	max_size: maxContributor,
	size_equals: (agg, def) => narrowBoth(agg, def.size),
	string_format: (agg, def) => {
		setFormat(agg, def.format);
		if (def.pattern) addPattern(agg, def.pattern);
		if (def.format === "base64" || def.format === "base64url") agg.contentEncoding = def.format;
		if (def.local || def.precision === -1) agg.laxFormat = true;
	},
	mime_type: (agg, def) => intersectMime(agg, def.mime)
};
function aggregateChecks(schema) {
	const agg = {};
	const def = schema._zod.def;
	const list = schema._zod.traits.has("$ZodCheck") ? [schema, ...def.checks ?? []] : def.checks ?? [];
	for (const ch of list) contributors[ch._zod.def.check]?.(agg, ch._zod.def);
	const bag = schema._zod.bag;
	if (bag.minimum !== void 0) narrowMin(agg, "minimum", bag.minimum);
	if (bag.exclusiveMinimum !== void 0) narrowMin(agg, "exclusiveMinimum", bag.exclusiveMinimum);
	if (bag.maximum !== void 0) narrowMax(agg, "maximum", bag.maximum);
	if (bag.exclusiveMaximum !== void 0) narrowMax(agg, "exclusiveMaximum", bag.exclusiveMaximum);
	if (bag.multipleOf !== void 0) addDivisor(agg, bag.multipleOf);
	if (bag.format !== void 0) {
		agg.format ?? (agg.format = bag.format);
		if (bag.format.includes("int")) agg.isInt = true;
	}
	if (bag.mime) intersectMime(agg, bag.mime);
	for (const pattern of bag.patterns ?? []) addPattern(agg, pattern);
	return agg;
}
var formatMap = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
};
var exactPatterns = /* @__PURE__ */ new Map([[base64Charset, base64], [base64urlCharset, base64url]]);
var exactPattern = (p) => exactPatterns.get(p) ?? p;
var stringProcessor = (schema, ctx, _json, _params) => {
	const json = _json;
	json.type = "string";
	const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minLength = minimum;
	if (typeof maximum === "number") json.maxLength = maximum;
	if (format) {
		json.format = formatMap[format] ?? format;
		if (json.format === "") delete json.format;
		if (format === "time" || laxFormat) delete json.format;
	}
	if (contentEncoding) json.contentEncoding = contentEncoding;
	if (patterns && patterns.size > 0) {
		const patternList = [...patterns].map(exactPattern);
		if (patternList.length === 1) json.pattern = patternList[0].source;
		else if (patternList.length > 1) json.allOf = [...patternList.map((regex) => ({
			...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: regex.source
		}))];
	}
};
var numberProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const { minimum, maximum, multipleOf, exclusiveMaximum, exclusiveMinimum, isInt } = aggregateChecks(schema);
	json.type = isInt ? "integer" : "number";
	const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
	const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
	const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
	if (exMin) {
		if (legacy) {
			json.minimum = exclusiveMinimum;
			json.exclusiveMinimum = true;
		} else json.exclusiveMinimum = exclusiveMinimum;
	} else if (typeof minimum === "number") json.minimum = minimum;
	if (exMax) {
		if (legacy) {
			json.maximum = exclusiveMaximum;
			json.exclusiveMaximum = true;
		} else json.exclusiveMaximum = exclusiveMaximum;
	} else if (typeof maximum === "number") json.maximum = maximum;
	if (multipleOf) {
		const divisors = /* @__PURE__ */ new Set();
		for (const divisor of multipleOf) if (Number.isFinite(divisor) && divisor !== 0) divisors.add(Math.abs(divisor));
		else handleUnrepresentable(schema, ctx, json, params, `A multipleOf divisor of ${divisor} cannot be represented in JSON Schema`);
		const [first, ...rest] = divisors;
		if (first !== void 0) json.multipleOf = first;
		if (rest.length) json.allOf = [...json.allOf ?? [], ...rest.map((m) => ({ multipleOf: m }))];
	}
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
	json.type = "boolean";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
	json.not = {};
};
var enumProcessor = (schema, _ctx, json, _params) => {
	const def = schema._zod.def;
	const values = getEnumValues(def.entries);
	if (values.length === 0) {
		json.not = {};
		return;
	}
	if (values.every((v) => typeof v === "number")) json.type = "number";
	if (values.every((v) => typeof v === "string")) json.type = "string";
	json.enum = values;
};
var literalProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	if (def.values.length === 0) {
		json.not = {};
		return;
	}
	const vals = [];
	for (const val of def.values) if (val === void 0) {
		if (handleUnrepresentable(schema, ctx, json, params, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof val === "bigint") {
		if (handleUnrepresentable(schema, ctx, json, params, "BigInt literals cannot be represented in JSON Schema")) return;
		vals.push(Number(val));
	} else vals.push(val);
	if (vals.length === 0) {} else if (vals.length === 1) {
		const val = vals[0];
		json.type = val === null ? "null" : typeof val;
		if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") json.enum = [val];
		else json.const = val;
	} else {
		if (vals.every((v) => typeof v === "number")) json.type = "number";
		if (vals.every((v) => typeof v === "string")) json.type = "string";
		if (vals.every((v) => typeof v === "boolean")) json.type = "boolean";
		if (vals.every((v) => v === null)) json.type = "null";
		json.enum = vals;
	}
};
var customProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Custom types cannot be represented in JSON Schema");
};
var transformProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Transforms cannot be represented in JSON Schema");
};
var arrayProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const { minimum, maximum } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minItems = minimum;
	if (typeof maximum === "number") json.maxItems = maximum;
	json.type = "array";
	json.items = processSchema(def.element, ctx, {
		...params,
		path: [...params.path, "items"]
	});
};
function inputOptin(schema) {
	const def = schema._zod.def;
	if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) return inputOptin(def.out);
	if (def.type === "catch") return inputOptin(def.innerType);
	return schema._zod.optin;
}
var objectProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const shape = def.shape;
	if (Object.getOwnPropertySymbols(shape).length && handleUnrepresentable(schema, ctx, json, params, "Symbol keys cannot be represented in JSON Schema")) return;
	json.type = "object";
	json.properties = {};
	for (const key in shape) assignProp(json.properties, key, processSchema(shape[key], ctx, {
		...params,
		path: [
			...params.path,
			"properties",
			key
		]
	}));
	const requiredKeys = [];
	for (const key of Object.keys(shape)) {
		const field = def.shape[key];
		if (ctx.io === "input" ? inputOptin(field) === void 0 : field._zod.optout === void 0) requiredKeys.push(key);
	}
	if (requiredKeys.length > 0) json.required = requiredKeys;
	if (def.catchall?._zod.def.type === "never") json.additionalProperties = false;
	else if (!def.catchall) {
		if (ctx.io === "output") json.additionalProperties = false;
	} else if (def.catchall) json.additionalProperties = processSchema(def.catchall, ctx, {
		...params,
		path: [...params.path, "additionalProperties"]
	});
};
var unionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const isExclusive = def.inclusive === false;
	const options = def.options.map((x, i) => processSchema(x, ctx, {
		...params,
		path: [
			...params.path,
			isExclusive ? "oneOf" : "anyOf",
			i
		]
	}));
	if (isExclusive) json.oneOf = options;
	else json.anyOf = options;
};
var intersectionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const a = processSchema(def.left, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			0
		]
	});
	const b = processSchema(def.right, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			1
		]
	});
	const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
	const allOf = [...isSimpleIntersection(a) ? a.allOf : [a], ...isSimpleIntersection(b) ? b.allOf : [b]];
	json.allOf = allOf;
	ctx.intersections.push(allOf);
};
/** JSON object keys are always strings, so a numeric record key schema is re-expressed over the
* numeric-string form the record parser matches. Deferred to `finalize`, after the flatten: a key
* behind a wrapper only carries its own `type` before then, and a union key only has its branches.
*
* A numeric bound cannot apply to a property name, so `minimum` and its siblings are dropped rather
* than carried over: keeping them beside `type: "string"` reproduces the match-nothing schema this
* exists to fix. A key that carries one therefore emits wider than the record parses — `z.record(z.number().min(5), V)`
* accepts `"3"` — which is the deliberate trade, since throwing on it would reject an ordinary schema
* outright. */
function stringifyKeyNames(bySchema, json, visited) {
	if (json.$ref) {
		if (visited.has(json)) return json;
		visited.add(json);
		const def = bySchema.get(json)?.def;
		if (!def) return json;
		const inlined = stringifyKeyNames(bySchema, def, visited);
		return inlined === def ? json : inlined;
	}
	for (const keyword of ["anyOf", "oneOf"]) {
		const branches = json[keyword];
		if (!Array.isArray(branches)) continue;
		const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
		if (mapped.some((branch, i) => branch !== branches[i])) json = {
			...json,
			[keyword]: mapped
		};
	}
	const types = Array.isArray(json.type) ? json.type : [json.type];
	const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
	const values = json.enum ?? (json.const !== void 0 ? [json.const] : void 0);
	if (!numericType && !values?.some((v) => typeof v === "number")) return json;
	const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id, ...rest } = json;
	if (rest.enum) rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
	else if (typeof rest.const === "number") rest.const = String(rest.const);
	if (!numericType) return rest;
	rest.type = "string";
	if (!values) rest.pattern = (types.includes("number") ? number$1 : integer).source;
	return rest;
}
/** Every record of one conversion, so the carriers are found in a single pass rather than once per record. */
var pendingRecords = /* @__PURE__ */ new WeakMap();
function rewriteKeyNames(ctx) {
	const bySchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.values()) if (entry.def && !bySchema.has(entry.schema)) bySchema.set(entry.schema, entry);
	const rewrites = /* @__PURE__ */ new Map();
	for (const record of pendingRecords.get(ctx) ?? []) {
		const seen = ctx.seen.get(record);
		const names = (seen?.def ?? seen?.schema)?.propertyNames;
		if (!names || names === true || rewrites.has(names)) continue;
		const rewritten = stringifyKeyNames(bySchema, names, /* @__PURE__ */ new Set());
		if (rewritten !== names) rewrites.set(names, rewritten);
	}
	if (!rewrites.size) return;
	for (const entry of ctx.seen.values()) for (const carrier of [entry.schema, entry.def]) {
		const rewritten = carrier && rewrites.get(carrier.propertyNames);
		if (rewritten) carrier.propertyNames = rewritten;
	}
}
var recordProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	json.type = "object";
	const keyType = def.keyType;
	const patterns = aggregateChecks(keyType).patterns;
	if (def.mode === "loose" && patterns && patterns.size > 0) {
		const valueSchema = processSchema(def.valueType, ctx, {
			...params,
			path: [
				...params.path,
				"patternProperties",
				"*"
			]
		});
		json.patternProperties = {};
		for (const pattern of patterns) assignProp(json.patternProperties, exactPattern(pattern).source, valueSchema);
	} else {
		if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
			json.propertyNames = processSchema(def.keyType, ctx, {
				...params,
				path: [...params.path, "propertyNames"]
			});
			let pending = pendingRecords.get(ctx);
			if (!pending) {
				pending = [];
				pendingRecords.set(ctx, pending);
				ctx.deferred.push(() => rewriteKeyNames(ctx));
			}
			pending.push(schema);
		}
		json.additionalProperties = processSchema(def.valueType, ctx, {
			...params,
			path: [...params.path, "additionalProperties"]
		});
	}
	const keyValues = keyType._zod.values;
	const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== void 0;
	if (keyValues && !def.partial && !omittableOnInput) {
		const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
		if (validKeyValues.length > 0) json.required = validKeyValues.map(String);
	}
};
var nullableProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const inner = processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	if (ctx.target === "openapi-3.0") {
		seen.ref = def.innerType;
		json.nullable = true;
	} else json.anyOf = [inner, { type: "null" }];
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
/** Round-trips a default value through JSON so the emitted schema is guaranteed to be valid JSON.
* A BigInt has no reliable encoding, so it goes through `unrepresentable` like any other
* unrepresentable value. Returns a sentinel when the caller must not write a default of its own. */
var UNREPRESENTABLE_DEFAULT = Symbol();
function serializeDefaultValue(value, schema, ctx, json, params) {
	let unrepresentable = false;
	const serialized = JSON.stringify(value, (_, val) => {
		if (typeof val !== "bigint") return val;
		unrepresentable = true;
		return null;
	});
	if (!unrepresentable) return JSON.parse(serialized);
	handleUnrepresentable(schema, ctx, json, params, "BigInt defaults cannot be represented in JSON Schema");
	return UNREPRESENTABLE_DEFAULT;
}
var defaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json.default = value;
};
var prefaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	if (ctx.io !== "input") return;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json._prefault = value;
};
var catchProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	let catchValue;
	try {
		catchValue = def.catchValue(void 0);
	} catch {
		handleUnrepresentable(schema, ctx, json, params, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	const inIsTransform = def.in._zod.traits.has("$ZodTransform");
	const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
	processSchema(innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
//#endregion
//#region ../../node_modules/zod/v4/classic/errors.js
var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _lazyMethod(proto, key, make) {
	Object.defineProperty(proto, key, {
		configurable: true,
		enumerable: false,
		get() {
			const value = make(this);
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
			return value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
		}
	});
}
var initializer = (inst, issues) => {
	$ZodError.init(inst, issues);
	inst.name = "ZodError";
	const proto = Object.getPrototypeOf(inst);
	if (_installedErrorProtos.has(proto)) return;
	_installedErrorProtos.add(proto);
	_lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
	_lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
	_lazyMethod(proto, "addIssue", (self) => (issue) => {
		self.issues.push(issue);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	_lazyMethod(proto, "addIssues", (self) => (issues) => {
		self.issues.push(...issues);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	Object.defineProperty(proto, "isEmpty", {
		configurable: true,
		enumerable: false,
		get() {
			return this.issues.length === 0;
		}
	});
};
var ZodRealError = /*@__PURE__*/ $constructor("ZodError", initializer, void 0, { Parent: Error });
//#endregion
//#region ../../node_modules/zod/v4/classic/parse.js
var parse = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);
//#endregion
//#region ../../node_modules/zod/v4/classic/schemas.js
function _ensureDefaultLocale() {
	if (!globalConfig.localeError) config(en_default());
}
function _ensureDefaultMemoizer() {
	if (!globalConfig.memoizer) config({ memoizer: memoizer() });
}
var ZodType = /*@__PURE__*/ $constructor("ZodType", (inst, def) => {
	_ensureDefaultLocale();
	$ZodType.init(inst, def);
	inst.def = def;
	inst.type = def.type;
	return inst;
}, {
	check(...chks) {
		const def = this.def;
		return this.clone(mergeDefs(def, { checks: [...def.checks ?? [], ...chks.map((ch) => typeof ch === "function" ? { _zod: {
			check: ch,
			def: { check: "custom" },
			onattach: []
		} } : ch)] }), { parent: true });
	},
	with(...chks) {
		return this.check(...chks);
	},
	clone(def, params) {
		return clone(this, def, params);
	},
	brand() {
		return this;
	},
	register(reg, meta) {
		reg.add(this, meta);
		return this;
	},
	refine(check, params) {
		return this.check(refine(check, params));
	},
	superRefine(refinement, params) {
		return this.check(superRefine(refinement, params));
	},
	overwrite(fn) {
		return this.check(/* @__PURE__ */ _overwrite(fn));
	},
	optional() {
		return optional(this);
	},
	exactOptional() {
		return exactOptional(this);
	},
	nullable() {
		return nullable(this);
	},
	nullish() {
		return optional(nullable(this));
	},
	nonoptional(params) {
		return nonoptional(this, params);
	},
	array() {
		return array(this);
	},
	or(arg) {
		return union([this, arg]);
	},
	and(arg) {
		return intersection(this, arg);
	},
	transform(tx) {
		return pipe(this, transform(tx));
	},
	default(d) {
		return _default(this, d);
	},
	prefault(d) {
		return prefault(this, d);
	},
	catch(params) {
		return _catch(this, params);
	},
	pipe(target) {
		return pipe(this, target);
	},
	readonly() {
		return readonly(this);
	},
	describe(description) {
		const cl = this.clone();
		globalRegistry.add(cl, { description });
		return cl;
	},
	meta(...args) {
		if (args.length === 0) return globalRegistry.get(this);
		const cl = this.clone();
		globalRegistry.add(cl, args[0]);
		return cl;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(fn, ...args) {
		return args.length === 0 ? fn(this) : fn(this, ...args);
	},
	get "~standard"() {
		return hide(this, "~standard", {
			...standardProps(this),
			jsonSchema: {
				input: createStandardJSONSchemaMethod(this, "input"),
				output: createStandardJSONSchemaMethod(this, "output")
			}
		});
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	},
	parse: function _parse(data, params) {
		return parse(this, data, params, { callee: _parse });
	},
	parseAsync: async function _parseAsync(data, params) {
		return await parseAsync(this, data, params, { callee: _parseAsync });
	},
	safeParse(data, params) {
		return safeParse(this, data, params);
	},
	async safeParseAsync(data, params) {
		return safeParseAsync(this, data, params);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(value) {
		own(this, "spa", value);
	},
	validate(data, params) {
		return validate(this, data, params);
	},
	validateAsync(data, params) {
		return validateAsync$1(this, data, params);
	},
	encode: function _encode(data, params) {
		return encode(this, data, params, { callee: _encode });
	},
	decode: function _decode(data, params) {
		return decode(this, data, params, { callee: _decode });
	},
	encodeAsync: async function _encodeAsync(data, params) {
		return await encodeAsync(this, data, params, { callee: _encodeAsync });
	},
	decodeAsync: async function _decodeAsync(data, params) {
		return await decodeAsync(this, data, params, { callee: _decodeAsync });
	},
	safeEncode(data, params) {
		return safeEncode(this, data, params);
	},
	safeDecode(data, params) {
		return safeDecode(this, data, params);
	},
	async safeEncodeAsync(data, params) {
		return safeEncodeAsync(this, data, params);
	},
	async safeDecodeAsync(data, params) {
		return safeDecodeAsync(this, data, params);
	},
	toJSONSchema(params) {
		return createToJSONSchemaMethod(this, {})(params);
	},
	get description() {
		return globalRegistry.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
});
/** @internal */
var _ZodString = /*@__PURE__*/ $constructor("_ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
}, /*@__PURE__*/ derived({
	format: (inst) => aggregateChecks(inst).format ?? null,
	minLength: (inst) => aggregateChecks(inst).minimum ?? null,
	maxLength: (inst) => aggregateChecks(inst).maximum ?? null
}, {
	regex(...args) {
		return this.check(/* @__PURE__ */ _regex(...args));
	},
	includes(...args) {
		return this.check(/* @__PURE__ */ _includes(...args));
	},
	startsWith(...args) {
		return this.check(/* @__PURE__ */ _startsWith(...args));
	},
	endsWith(...args) {
		return this.check(/* @__PURE__ */ _endsWith(...args));
	},
	min(...args) {
		return this.check(/* @__PURE__ */ _minLength(...args));
	},
	max(...args) {
		return this.check(/* @__PURE__ */ _maxLength(...args));
	},
	length(...args) {
		return this.check(/* @__PURE__ */ _length(...args));
	},
	nonempty(...args) {
		return this.check(/* @__PURE__ */ _minLength(1, ...args));
	},
	lowercase(params) {
		return this.check(/* @__PURE__ */ _lowercase(params));
	},
	uppercase(params) {
		return this.check(/* @__PURE__ */ _uppercase(params));
	},
	trim() {
		return this.check(/* @__PURE__ */ _trim());
	},
	normalize(...args) {
		return this.check(/* @__PURE__ */ _normalize(...args));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ _toLowerCase());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ _toUpperCase());
	},
	slugify() {
		return this.check(/* @__PURE__ */ _slugify());
	}
}));
var ZodString = /*@__PURE__*/ $constructor("ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	_ZodString.init(inst, def);
}, {
	email(params) {
		return this.check(/* @__PURE__ */ _email(ZodEmail, params));
	},
	url(params) {
		return this.check(/* @__PURE__ */ _url(ZodURL, params));
	},
	jwt(params) {
		return this.check(/* @__PURE__ */ _jwt(ZodJWT, params));
	},
	emoji(params) {
		return this.check(/* @__PURE__ */ _emoji(ZodEmoji, params));
	},
	guid(params) {
		return this.check(/* @__PURE__ */ _guid(ZodGUID, params));
	},
	uuid(params) {
		return this.check(/* @__PURE__ */ _uuid(ZodUUID, params));
	},
	uuidv4(params) {
		return this.check(/* @__PURE__ */ _uuidv4(ZodUUID, params));
	},
	uuidv6(params) {
		return this.check(/* @__PURE__ */ _uuidv6(ZodUUID, params));
	},
	uuidv7(params) {
		return this.check(/* @__PURE__ */ _uuidv7(ZodUUID, params));
	},
	nanoid(params) {
		return this.check(/* @__PURE__ */ _nanoid(ZodNanoID, params));
	},
	cuid(params) {
		return this.check(/* @__PURE__ */ _cuid(ZodCUID, params));
	},
	cuid2(params) {
		return this.check(/* @__PURE__ */ _cuid2(ZodCUID2, params));
	},
	ulid(params) {
		return this.check(/* @__PURE__ */ _ulid(ZodULID, params));
	},
	base64(params) {
		return this.check(/* @__PURE__ */ _base64(ZodBase64, params));
	},
	base64url(params) {
		return this.check(/* @__PURE__ */ _base64url(ZodBase64URL, params));
	},
	xid(params) {
		return this.check(/* @__PURE__ */ _xid(ZodXID, params));
	},
	ksuid(params) {
		return this.check(/* @__PURE__ */ _ksuid(ZodKSUID, params));
	},
	ipv4(params) {
		return this.check(/* @__PURE__ */ _ipv4(ZodIPv4, params));
	},
	ipv6(params) {
		return this.check(/* @__PURE__ */ _ipv6(ZodIPv6, params));
	},
	cidrv4(params) {
		return this.check(/* @__PURE__ */ _cidrv4(ZodCIDRv4, params));
	},
	cidrv6(params) {
		return this.check(/* @__PURE__ */ _cidrv6(ZodCIDRv6, params));
	},
	e164(params) {
		return this.check(/* @__PURE__ */ _e164(ZodE164, params));
	},
	datetime(params) {
		return this.check(/* @__PURE__ */ _isoDateTime(ZodISODateTime, params));
	},
	date(params) {
		return this.check(/* @__PURE__ */ _isoDate(ZodISODate, params));
	},
	time(params) {
		return this.check(/* @__PURE__ */ _isoTime(ZodISOTime, params));
	},
	duration(params) {
		return this.check(/* @__PURE__ */ _isoDuration(ZodISODuration, params));
	}
});
function string(params) {
	return /* @__PURE__ */ _string(ZodString, params);
}
var ZodStringFormat = /*@__PURE__*/ $constructor("ZodStringFormat", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	_ZodString.init(inst, def);
});
var ZodISODateTime = /*@__PURE__*/ $constructor("ZodISODateTime", (inst, def) => {
	$ZodISODateTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODate = /*@__PURE__*/ $constructor("ZodISODate", (inst, def) => {
	$ZodISODate.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISOTime = /*@__PURE__*/ $constructor("ZodISOTime", (inst, def) => {
	$ZodISOTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODuration = /*@__PURE__*/ $constructor("ZodISODuration", (inst, def) => {
	$ZodISODuration.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmail = /*@__PURE__*/ $constructor("ZodEmail", (inst, def) => {
	$ZodEmail.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodGUID = /*@__PURE__*/ $constructor("ZodGUID", (inst, def) => {
	$ZodGUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodUUID = /*@__PURE__*/ $constructor("ZodUUID", (inst, def) => {
	$ZodUUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodURL = /*@__PURE__*/ $constructor("ZodURL", (inst, def) => {
	$ZodURL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmoji = /*@__PURE__*/ $constructor("ZodEmoji", (inst, def) => {
	$ZodEmoji.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNanoID = /*@__PURE__*/ $constructor("ZodNanoID", (inst, def) => {
	$ZodNanoID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var ZodCUID = /*@__PURE__*/ $constructor("ZodCUID", (inst, def) => {
	$ZodCUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /*@__PURE__*/ $constructor("ZodCUID2", (inst, def) => {
	$ZodCUID2.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodULID = /*@__PURE__*/ $constructor("ZodULID", (inst, def) => {
	$ZodULID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodXID = /*@__PURE__*/ $constructor("ZodXID", (inst, def) => {
	$ZodXID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodKSUID = /*@__PURE__*/ $constructor("ZodKSUID", (inst, def) => {
	$ZodKSUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /*@__PURE__*/ $constructor("ZodIPv4", (inst, def) => {
	$ZodIPv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /*@__PURE__*/ $constructor("ZodIPv6", (inst, def) => {
	$ZodIPv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /*@__PURE__*/ $constructor("ZodCIDRv4", (inst, def) => {
	$ZodCIDRv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /*@__PURE__*/ $constructor("ZodCIDRv6", (inst, def) => {
	$ZodCIDRv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64 = /*@__PURE__*/ $constructor("ZodBase64", (inst, def) => {
	$ZodBase64.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /*@__PURE__*/ $constructor("ZodBase64URL", (inst, def) => {
	$ZodBase64URL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodE164 = /*@__PURE__*/ $constructor("ZodE164", (inst, def) => {
	$ZodE164.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodJWT = /*@__PURE__*/ $constructor("ZodJWT", (inst, def) => {
	$ZodJWT.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNumber = /*@__PURE__*/ $constructor("ZodNumber", (inst, def) => {
	$ZodNumber.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
	inst.isFinite = true;
}, /*@__PURE__*/ derived({
	minValue: (inst) => {
		const { minimum, exclusiveMinimum } = aggregateChecks(inst);
		return Math.max(minimum ?? Number.NEGATIVE_INFINITY, exclusiveMinimum ?? Number.NEGATIVE_INFINITY);
	},
	maxValue: (inst) => {
		const { maximum, exclusiveMaximum } = aggregateChecks(inst);
		return Math.min(maximum ?? Number.POSITIVE_INFINITY, exclusiveMaximum ?? Number.POSITIVE_INFINITY);
	},
	isInt: (inst) => {
		const { isInt, multipleOf } = aggregateChecks(inst);
		return !!isInt || !!multipleOf?.some(Number.isSafeInteger);
	},
	format: (inst) => aggregateChecks(inst).format ?? null
}, {
	gt(value, params) {
		return this.check(/* @__PURE__ */ _gt(value, params));
	},
	gte(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	min(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	lt(value, params) {
		return this.check(/* @__PURE__ */ _lt(value, params));
	},
	lte(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	max(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	int(params) {
		return this.check(int(params));
	},
	safe(params) {
		return this.check(int(params));
	},
	positive(params) {
		return this.check(/* @__PURE__ */ _gt(0, params));
	},
	nonnegative(params) {
		return this.check(/* @__PURE__ */ _gte(0, params));
	},
	negative(params) {
		return this.check(/* @__PURE__ */ _lt(0, params));
	},
	nonpositive(params) {
		return this.check(/* @__PURE__ */ _lte(0, params));
	},
	multipleOf(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	step(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	finite() {
		return this;
	}
}));
function number(params) {
	return /* @__PURE__ */ _number(ZodNumber, params);
}
var ZodNumberFormat = /*@__PURE__*/ $constructor("ZodNumberFormat", (inst, def) => {
	$ZodNumberFormat.init(inst, def);
	ZodNumber.init(inst, def);
});
function int(params) {
	return /* @__PURE__ */ _int(ZodNumberFormat, params);
}
var ZodBoolean = /*@__PURE__*/ $constructor("ZodBoolean", (inst, def) => {
	$ZodBoolean.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean(params) {
	return /* @__PURE__ */ _boolean(ZodBoolean, params);
}
var ZodUnknown = /*@__PURE__*/ $constructor("ZodUnknown", (inst, def) => {
	$ZodUnknown.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => void 0;
});
function unknown() {
	return /* @__PURE__ */ _unknown(ZodUnknown);
}
var ZodNever = /*@__PURE__*/ $constructor("ZodNever", (inst, def) => {
	$ZodNever.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
	return /* @__PURE__ */ _never(ZodNever, params);
}
var ZodArray = /*@__PURE__*/ $constructor("ZodArray", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodArray.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
	inst.element = def.element;
}, {
	min(n, params) {
		return this.check(/* @__PURE__ */ _minLength(n, params));
	},
	nonempty(params) {
		return this.check(/* @__PURE__ */ _minLength(1, params));
	},
	max(n, params) {
		return this.check(/* @__PURE__ */ _maxLength(n, params));
	},
	length(n, params) {
		return this.check(/* @__PURE__ */ _length(n, params));
	},
	unwrap() {
		return this.element;
	}
});
function array(element, params) {
	return /* @__PURE__ */ _array(ZodArray, element, params);
}
var ZodObject = /*@__PURE__*/ $constructor("ZodObject", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodObjectJIT.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
	installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
}, {
	keyof() {
		return _enum(Object.keys(this._zod.def.shape));
	},
	catchall(catchall) {
		return this.clone(mergeDefs(this._zod.def, { catchall }));
	},
	passthrough() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	loose() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	strict() {
		return this.clone(mergeDefs(this._zod.def, { catchall: never() }));
	},
	strip() {
		return this.clone(mergeDefs(this._zod.def, { catchall: void 0 }));
	},
	extend(incoming) {
		return extend(this, incoming);
	},
	safeExtend(incoming) {
		return safeExtend(this, incoming);
	},
	merge(other) {
		return merge(this, other);
	},
	pick(mask) {
		return pick(this, mask);
	},
	omit(mask) {
		return omit(this, mask);
	},
	partial(...args) {
		return partial(ZodOptional, this, args[0]);
	},
	exactPartial(...args) {
		return partial(ZodExactOptional, this, args[0], "exactPartial");
	},
	required(...args) {
		return required(ZodNonOptional, this, args[0]);
	}
});
function object(shape, params) {
	return new ZodObject({
		type: "object",
		shape: shape ?? {},
		...normalizeParams(params)
	});
}
var ZodUnion = /*@__PURE__*/ $constructor("ZodUnion", (inst, def) => {
	$ZodUnion.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
	inst.options = def.options;
});
function union(options, params) {
	return new ZodUnion({
		type: "union",
		options,
		...normalizeParams(params)
	});
}
var ZodIntersection = /*@__PURE__*/ $constructor("ZodIntersection", (inst, def) => {
	$ZodIntersection.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
	return new ZodIntersection({
		type: "intersection",
		left,
		right
	});
}
var ZodRecord = /*@__PURE__*/ $constructor("ZodRecord", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodRecord.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
	inst.keyType = def.keyType;
	inst.valueType = def.valueType;
});
function record(keyType, valueType, params) {
	if (!valueType || !valueType._zod) return new ZodRecord({
		type: "record",
		keyType: string(),
		valueType: keyType,
		...normalizeParams(valueType)
	});
	return new ZodRecord({
		type: "record",
		keyType,
		valueType,
		...normalizeParams(params)
	});
}
var ZodEnum = /*@__PURE__*/ $constructor("ZodEnum", (inst, def) => {
	$ZodEnum.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
	inst.enum = def.entries;
	inst.options = [...inst._zod.values];
	const keys = new Set(Object.keys(def.entries));
	inst.extract = (values, params) => {
		const newEntries = {};
		for (const value of values) if (keys.has(value)) newEntries[value] = def.entries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
	inst.exclude = (values, params) => {
		const newEntries = { ...def.entries };
		for (const value of values) if (keys.has(value)) delete newEntries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
});
function _enum(values, params) {
	return new ZodEnum({
		type: "enum",
		entries: Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values,
		...normalizeParams(params)
	});
}
var ZodLiteral = /*@__PURE__*/ $constructor("ZodLiteral", (inst, def) => {
	$ZodLiteral.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
	inst.values = new Set(def.values);
	Object.defineProperty(inst, "value", { get() {
		if (def.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return def.values[0];
	} });
});
function literal(value, params) {
	return new ZodLiteral({
		type: "literal",
		values: Array.isArray(value) ? value : [value],
		...normalizeParams(params)
	});
}
var ZodTransform = /*@__PURE__*/ $constructor("ZodTransform", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodTransform.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
	inst._zod.parse = (payload, _ctx) => {
		if (_ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		payload.addIssue = (issue$1) => {
			if (typeof issue$1 === "string") payload.issues.push(issue(issue$1, payload.value, def));
			else {
				const _issue = issue$1;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = inst);
				payload.issues.push(issue(_issue));
			}
		};
		const output = def.transform(payload.value, payload);
		if (output instanceof Promise) return output.then((output) => {
			payload.value = output;
			return payload;
		});
		payload.value = output;
		return payload;
	};
});
function transform(fn) {
	return new ZodTransform({
		type: "transform",
		transform: fn
	});
}
var ZodOptional = /*@__PURE__*/ $constructor("ZodOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
	return new ZodOptional({
		type: "optional",
		innerType
	});
}
var ZodExactOptional = /*@__PURE__*/ $constructor("ZodExactOptional", (inst, def) => {
	$ZodExactOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
	return new ZodExactOptional({
		type: "optional",
		innerType
	});
}
var ZodNullable = /*@__PURE__*/ $constructor("ZodNullable", (inst, def) => {
	$ZodNullable.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
	return new ZodNullable({
		type: "nullable",
		innerType
	});
}
var ZodDefault = /*@__PURE__*/ $constructor("ZodDefault", (inst, def) => {
	$ZodDefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
	return new ZodDefault({
		type: "default",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodPrefault = /*@__PURE__*/ $constructor("ZodPrefault", (inst, def) => {
	$ZodPrefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
	return new ZodPrefault({
		type: "prefault",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodNonOptional = /*@__PURE__*/ $constructor("ZodNonOptional", (inst, def) => {
	$ZodNonOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
	return new ZodNonOptional({
		type: "nonoptional",
		innerType,
		...normalizeParams(params)
	});
}
var ZodCatch = /*@__PURE__*/ $constructor("ZodCatch", (inst, def) => {
	$ZodCatch.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
	return new ZodCatch({
		type: "catch",
		innerType,
		catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
	});
}
var ZodPipe = /*@__PURE__*/ $constructor("ZodPipe", (inst, def) => {
	$ZodPipe.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
	inst.in = def.in;
	inst.out = def.out;
});
function pipe(in_, out) {
	return new ZodPipe({
		type: "pipe",
		in: in_,
		out
	});
}
var ZodReadonly = /*@__PURE__*/ $constructor("ZodReadonly", (inst, def) => {
	$ZodReadonly.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
	return new ZodReadonly({
		type: "readonly",
		innerType
	});
}
var ZodCustom = /*@__PURE__*/ $constructor("ZodCustom", (inst, def) => {
	$ZodCustom.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function custom(fn, _params) {
	return /* @__PURE__ */ _custom(ZodCustom, fn ?? (() => true), _params);
}
function refine(fn, _params = {}) {
	return /* @__PURE__ */ _refine(ZodCustom, fn, _params);
}
function superRefine(fn, params) {
	return /* @__PURE__ */ _superRefine(fn, params);
}
var schema_default = {
	$schema: "https://json-schema.org/draft/2020-12/schema",
	$id: "urn:ontolearn:contracts:2",
	title: "I03 v2 design contract",
	$defs: /* @__PURE__ */ JSON.parse("{\"id\":{\"type\":\"string\",\"pattern\":\"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$\",\"maxLength\":36},\"hash\":{\"type\":\"string\",\"pattern\":\"^[0-9a-f]{64}$\",\"maxLength\":64},\"name\":{\"type\":\"string\",\"pattern\":\"^[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":128},\"dependencyKey\":{\"type\":\"string\",\"pattern\":\"^(facts:asserted|(ontology|mapping|constraint|rule|behavior|scenario|query|model):[A-Za-z0-9_.-]{1,128})$\",\"maxLength\":140},\"vector\":{\"type\":\"object\",\"propertyNames\":{\"$ref\":\"#/$defs/dependencyKey\"},\"additionalProperties\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"maxProperties\":4096},\"implementation\":{\"type\":\"object\",\"properties\":{\"executionSemanticsVersion\":{\"$ref\":\"#/$defs/name\"},\"engineVersion\":{\"$ref\":\"#/$defs/name\"},\"dependencyLockHash\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"executionSemanticsVersion\",\"engineVersion\",\"dependencyLockHash\"],\"additionalProperties\":false},\"scope\":{\"enum\":[\"asserted\",\"asserted+derived\",\"scenario\"]},\"limits\":{\"type\":\"object\",\"properties\":{\"startupMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000},\"handshakeMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000},\"requestMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000},\"totalMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":3600000},\"heartbeatMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000},\"cancelGraceMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000},\"maxFrameBytes\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":262144},\"maxQueuedJobs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":128},\"maxConcurrentJobs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":8},\"maxPageItems\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":200},\"maxPageBytes\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":131072},\"maxWorkerMemoryBytes\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":2147483648}},\"required\":[\"startupMs\",\"handshakeMs\",\"requestMs\",\"totalMs\",\"heartbeatMs\",\"cancelGraceMs\",\"maxFrameBytes\",\"maxQueuedJobs\",\"maxConcurrentJobs\",\"maxPageItems\",\"maxPageBytes\",\"maxWorkerMemoryBytes\"],\"additionalProperties\":false},\"error\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INVALID_REQUEST\"},\"messageKey\":{\"const\":\"protocol.invalidRequest\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"field\":{\"enum\":[\"envelope\",\"params\",\"identity\",\"config\",\"cursor\",\"dependency\",\"kind\"]}},\"required\":[\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"METHOD_NOT_ALLOWED\"},\"messageKey\":{\"const\":\"protocol.methodNotAllowed\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VERSION_INCOMPATIBLE\"},\"messageKey\":{\"const\":\"protocol.versionIncompatible\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"const\":2},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedVersions\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"HANDSHAKE_REQUIRED\"},\"messageKey\":{\"const\":\"protocol.handshakeRequired\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SESSION_MISMATCH\"},\"messageKey\":{\"const\":\"protocol.sessionMismatch\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"NOT_FOUND\"},\"messageKey\":{\"const\":\"resource.notFound\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resource\":{\"enum\":[\"project\",\"job\",\"result\",\"snapshot\",\"operation\",\"subscription\",\"cursor\"]}},\"required\":[\"resource\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"PERMISSION_DENIED\"},\"messageKey\":{\"const\":\"permission.denied\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"UNSUPPORTED_CAPABILITY\"},\"messageKey\":{\"const\":\"capability.unsupported\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"QUEUE_FULL\"},\"messageKey\":{\"const\":\"job.queueFull\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"retryAfterMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000}},\"required\":[\"retryAfterMs\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"TIMEOUT\"},\"messageKey\":{\"const\":\"job.timeout\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"phase\":{\"enum\":[\"startup\",\"handshake\",\"request\",\"total\",\"heartbeat\",\"cancel\"]}},\"required\":[\"phase\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"ENGINE_EXITED\"},\"messageKey\":{\"const\":\"engine.exited\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"REVISION_CONFLICT\"},\"messageKey\":{\"const\":\"project.revisionConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"expected\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"actual\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"expected\",\"actual\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"OWNERSHIP_CONFLICT\"},\"messageKey\":{\"const\":\"project.ownershipConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"detailRef\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"detailRef\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"IDENTITY_CONFLICT\"},\"messageKey\":{\"const\":\"operation.identityConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_BUSY\"},\"messageKey\":{\"const\":\"storage.busy\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"retryAfterMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000}},\"required\":[\"retryAfterMs\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_FAILURE\"},\"messageKey\":{\"const\":\"storage.failure\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"operationId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"CURSOR_MISMATCH\"},\"messageKey\":{\"const\":\"result.cursorMismatch\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"CURSOR_EXPIRED\"},\"messageKey\":{\"const\":\"result.cursorExpired\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"PAYLOAD_EVICTED\"},\"messageKey\":{\"const\":\"result.payloadEvicted\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resultId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"resultId\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INVALID_STATE\"},\"messageKey\":{\"const\":\"protocol.invalidState\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"MAPPING_VALUE_INVALID\"},\"messageKey\":{\"const\":\"mapping.valueInvalid\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"worksheetId\":{\"$ref\":\"#/$defs/id\"},\"row\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":1048576},\"column\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":16384},\"field\":{\"enum\":[\"key\",\"value\",\"type\",\"reference\"]},\"detailRef\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"worksheetId\",\"row\",\"column\",\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INTERNAL_ERROR\"},\"messageKey\":{\"const\":\"engine.internal\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SEMANTIC_INPUT_INVALID\"},\"messageKey\":{\"const\":\"semantics.inputInvalid\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"field\":{\"enum\":[\"syntax\",\"query\",\"rule\",\"constraint\"]}},\"required\":[\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"NETWORK_FORBIDDEN\"},\"messageKey\":{\"const\":\"semantics.networkForbidden\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"UNSUPPORTED_CONSTRUCT\"},\"messageKey\":{\"const\":\"semantics.unsupportedConstruct\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"construct\":{\"enum\":[\"rdfBlankNode\",\"sparqlForm\",\"ruleChain\",\"ruleRecursion\",\"shaclPath\",\"shaclAdvanced\",\"owlExpression\",\"rdfFormat\",\"rdfConstruct\",\"rdfsConstruct\",\"datatype\",\"literalValue\",\"queryFunction\",\"queryOrder\",\"querySlice\",\"ruleOutput\",\"validationScope\"]}},\"required\":[\"construct\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"RESOURCE_LIMIT\"},\"messageKey\":{\"const\":\"resource.limitExceeded\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resource\":{\"enum\":[\"memory\",\"actions\",\"rounds\",\"frame\",\"page\",\"semanticInput\",\"semanticResult\",\"semanticWork\"]}},\"required\":[\"resource\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false}]},\"progress\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"stage\":{\"enum\":[\"queued\",\"loading\",\"computing\",\"committing\",\"reconciling\"]},\"completed\":{\"const\":null},\"total\":{\"const\":null}},\"required\":[\"stage\",\"completed\",\"total\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"stage\":{\"enum\":[\"loading\",\"computing\",\"committing\"]},\"completed\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"total\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991}},\"required\":[\"stage\",\"completed\",\"total\"],\"additionalProperties\":false}]},\"committedProgress\":{\"type\":\"object\",\"properties\":{\"runId\":{\"$ref\":\"#/$defs/id\"},\"lastCommittedRound\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":1000},\"snapshotRef\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"runId\",\"lastCommittedRound\",\"snapshotRef\"],\"additionalProperties\":false},\"commitProgress\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"mode\":{\"const\":\"none\"}},\"required\":[\"mode\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"mode\":{\"const\":\"atomic\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"marker\":{\"oneOf\":[{\"const\":null},{\"type\":\"object\",\"properties\":{\"projectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"beforeSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"afterSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"planHash\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"projectRevision\",\"beforeSnapshotId\",\"afterSnapshotId\",\"planHash\"],\"additionalProperties\":false}]}},\"required\":[\"mode\",\"operationId\",\"marker\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"mode\":{\"const\":\"rounds\"},\"committedProgress\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/committedProgress\"}]}},\"required\":[\"mode\",\"committedProgress\"],\"additionalProperties\":false}]},\"resultRef\":{\"type\":\"object\",\"properties\":{\"resultId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"resultId\",\"inputSnapshotId\"],\"additionalProperties\":false},\"job\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"queued\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"const\":null},\"error\":{\"const\":null},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"const\":null},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"running\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"const\":null},\"error\":{\"const\":null},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"const\":null},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"cancelling\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"const\":null},\"error\":{\"const\":null},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"const\":null},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"succeeded\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"$ref\":\"#/$defs/resultRef\"},\"error\":{\"const\":null},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"failed\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"const\":null},\"error\":{\"$ref\":\"#/$defs/error\"},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"state\":{\"const\":\"cancelled\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"commitProgress\":{\"$ref\":\"#/$defs/commitProgress\"},\"resultRef\":{\"const\":null},\"error\":{\"const\":null},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"updatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"finishedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"jobId\",\"projectId\",\"operationId\",\"capability\",\"inputSnapshotId\",\"dependencyVector\",\"definitionSetDigests\",\"parametersHash\",\"scope\",\"implementation\",\"state\",\"stateVersion\",\"limits\",\"commitProgress\",\"resultRef\",\"error\",\"createdAtMs\",\"updatedAtMs\",\"finishedAtMs\",\"input\",\"confirmationRef\"],\"additionalProperties\":false}]},\"staleReason\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"ONTOLOGY_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^ontology:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"FACTS_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^facts:asserted$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"MAPPING_INPUT_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^mapping:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VALIDATION_DEFINITION_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^constraint:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"RULE_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^rule:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"BEHAVIOR_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^behavior:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SCENARIO_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^scenario:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"QUERY_CHANGED\"},\"dependency\":{\"type\":\"string\",\"pattern\":\"^query:[A-Za-z0-9_.-]{1,128}$\",\"maxLength\":140},\"before\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"after\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"code\",\"dependency\",\"before\",\"after\"],\"additionalProperties\":false}]},\"result\":{\"type\":\"object\",\"properties\":{\"resultId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"kind\":{\"enum\":[\"query\",\"reasoning\",\"validation\",\"behavior\",\"scenario\",\"test\",\"receipt\"]},\"definitionId\":{\"$ref\":\"#/$defs/name\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"inputProjectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"definitionSetDigests\":{\"type\":\"object\",\"propertyNames\":{\"enum\":[\"ontology\",\"rule\",\"constraint\",\"behavior\",\"scenario\",\"mapping\",\"query\"]},\"additionalProperties\":{\"$ref\":\"#/$defs/hash\"},\"maxProperties\":7},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"state\":{\"enum\":[\"current\",\"stale\",\"historical\"]},\"staleReason\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/staleReason\"},\"minItems\":0,\"maxItems\":4096},\"payloadStatus\":{\"enum\":[\"available\",\"evicted\"]},\"createdAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"historicalSelectionRequired\":{\"type\":\"boolean\"}},\"required\":[\"resultId\",\"projectId\",\"jobId\",\"kind\",\"definitionId\",\"inputSnapshotId\",\"inputProjectRevision\",\"dependencyVector\",\"definitionSetDigests\",\"implementation\",\"scope\",\"parametersHash\",\"state\",\"staleReason\",\"payloadStatus\",\"createdAtMs\",\"historicalSelectionRequired\"],\"additionalProperties\":false},\"project\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"projectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"formatVersion\":{\"const\":2}},\"required\":[\"projectId\",\"projectRevision\",\"inputSnapshotId\",\"dependencyVector\",\"formatVersion\"],\"additionalProperties\":false},\"pageBinding\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"resultId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"order\":{\"const\":\"ordinal+rowId:asc\"}},\"required\":[\"projectId\",\"resultId\",\"inputSnapshotId\",\"scope\",\"parametersHash\",\"order\"],\"additionalProperties\":false},\"row\":{\"type\":\"object\",\"properties\":{\"rowId\":{\"$ref\":\"#/$defs/id\"},\"ordinal\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"cells\":{\"type\":\"array\",\"items\":{\"oneOf\":[{\"const\":null},{\"type\":\"string\",\"maxLength\":8192},{\"type\":\"boolean\"},{\"type\":\"number\",\"minimum\":-9007199254740991,\"maximum\":9007199254740991}]},\"minItems\":0,\"maxItems\":64}},\"required\":[\"rowId\",\"ordinal\",\"cells\"],\"additionalProperties\":false},\"page\":{\"type\":\"object\",\"properties\":{\"binding\":{\"$ref\":\"#/$defs/pageBinding\"},\"rows\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/row\"},\"minItems\":0,\"maxItems\":200},\"nextCursor\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"binding\",\"rows\",\"nextCursor\"],\"additionalProperties\":false},\"cursorRecord\":{\"type\":\"object\",\"properties\":{\"token\":{\"$ref\":\"#/$defs/id\"},\"binding\":{\"$ref\":\"#/$defs/pageBinding\"},\"pageSize\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":200},\"lastOrdinal\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"lastRowId\":{\"$ref\":\"#/$defs/id\"},\"expiresAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"token\",\"binding\",\"pageSize\",\"lastOrdinal\",\"lastRowId\",\"expiresAtMs\"],\"additionalProperties\":false},\"listBinding\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"listSnapshotId\":{\"$ref\":\"#/$defs/id\"},\"filter\":{\"enum\":[\"all\",\"active\",\"terminal\"]},\"order\":{\"const\":\"createdAtMs+jobId:asc\"}},\"required\":[\"projectId\",\"listSnapshotId\",\"filter\",\"order\"],\"additionalProperties\":false},\"jobList\":{\"type\":\"object\",\"properties\":{\"binding\":{\"$ref\":\"#/$defs/listBinding\"},\"jobs\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/job\"},\"minItems\":0,\"maxItems\":100},\"nextCursor\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"binding\",\"jobs\",\"nextCursor\"],\"additionalProperties\":false},\"commitMarker\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"planHash\":{\"$ref\":\"#/$defs/hash\"},\"projectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"beforeSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"afterSnapshotId\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"projectId\",\"operationId\",\"jobId\",\"planHash\",\"projectRevision\",\"beforeSnapshotId\",\"afterSnapshotId\"],\"additionalProperties\":false},\"subscription\":{\"type\":\"object\",\"properties\":{\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"seq\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"subscriptionId\",\"projectId\",\"jobId\",\"stateVersion\",\"seq\"],\"additionalProperties\":false},\"jobInput\":{\"type\":\"object\",\"properties\":{\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"definitionId\":{\"$ref\":\"#/$defs/name\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"derivedResultIds\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/id\"},\"minItems\":0,\"maxItems\":32},\"preparedPlanRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/hash\"}]}},\"required\":[\"inputSnapshotId\",\"scope\",\"definitionId\",\"parametersHash\",\"derivedResultIds\",\"preparedPlanRef\"],\"additionalProperties\":false},\"params_hello\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":99},\"minItems\":1,\"maxItems\":8},\"clientId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"supportedVersions\",\"clientId\"],\"additionalProperties\":false},\"result_hello\":{\"type\":\"object\",\"properties\":{\"selectedVersion\":{\"const\":2},\"engineVersion\":{\"$ref\":\"#/$defs/name\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"capabilities\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/name\"},\"minItems\":0,\"maxItems\":32},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"registryHash\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"selectedVersion\",\"engineVersion\",\"engineSessionId\",\"capabilities\",\"limits\",\"registryHash\"],\"additionalProperties\":false},\"params_health\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false},\"result_health\":{\"type\":\"object\",\"properties\":{\"status\":{\"const\":\"ok\"},\"engineVersion\":{\"$ref\":\"#/$defs/name\"}},\"required\":[\"status\",\"engineVersion\"],\"additionalProperties\":false},\"params_session.ping\":{\"type\":\"object\",\"properties\":{\"nonce\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"nonce\"],\"additionalProperties\":false},\"result_session.ping\":{\"type\":\"object\",\"properties\":{\"nonce\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"nonce\"],\"additionalProperties\":false},\"params_project.get\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\"],\"additionalProperties\":false},\"result_project.get\":{\"$ref\":\"#/$defs/project\"},\"params_job.create\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"capability\":{\"enum\":[\"test.read\",\"test.atomic\",\"test.rounds\",\"query.execute\",\"reasoning.execute\",\"validation.execute\",\"mapping.commit\",\"changeset.commit\",\"behavior.test\",\"scenario.run\"]},\"input\":{\"$ref\":\"#/$defs/jobInput\"},\"confirmationRef\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"projectId\",\"operationId\",\"capability\",\"input\",\"confirmationRef\"],\"additionalProperties\":false},\"result_job.create\":{\"$ref\":\"#/$defs/job\"},\"params_job.get\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"jobId\"],\"additionalProperties\":false},\"result_job.get\":{\"$ref\":\"#/$defs/job\"},\"params_job.cancel\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"jobId\"],\"additionalProperties\":false},\"result_job.cancel\":{\"type\":\"object\",\"properties\":{\"jobId\":{\"$ref\":\"#/$defs/id\"},\"disposition\":{\"enum\":[\"accepted\",\"alreadyRequested\",\"alreadyTerminal\"]},\"state\":{\"enum\":[\"queued\",\"running\",\"cancelling\",\"succeeded\",\"failed\",\"cancelled\"]},\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991}},\"required\":[\"jobId\",\"disposition\",\"state\",\"stateVersion\"],\"additionalProperties\":false},\"params_job.list\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"filter\":{\"enum\":[\"all\",\"active\",\"terminal\"]},\"pageSize\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":100},\"listSnapshotId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]},\"cursor\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"projectId\",\"filter\",\"pageSize\",\"listSnapshotId\",\"cursor\"],\"additionalProperties\":false},\"result_job.list\":{\"$ref\":\"#/$defs/jobList\"},\"params_job.subscribe\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"jobId\"],\"additionalProperties\":false},\"result_job.subscribe\":{\"$ref\":\"#/$defs/subscription\"},\"params_job.unsubscribe\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"subscriptionId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"jobId\",\"subscriptionId\"],\"additionalProperties\":false},\"result_job.unsubscribe\":{\"type\":\"object\",\"properties\":{\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"unsubscribed\":{\"const\":true}},\"required\":[\"subscriptionId\",\"unsubscribed\"],\"additionalProperties\":false},\"params_result.get\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"resultId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"resultId\"],\"additionalProperties\":false},\"result_result.get\":{\"$ref\":\"#/$defs/result\"},\"params_result.current\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"kind\":{\"enum\":[\"query\",\"reasoning\",\"validation\",\"behavior\",\"scenario\",\"test\"]},\"definitionId\":{\"$ref\":\"#/$defs/name\"},\"scope\":{\"$ref\":\"#/$defs/scope\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"}},\"required\":[\"projectId\",\"kind\",\"definitionId\",\"scope\",\"parametersHash\",\"implementation\"],\"additionalProperties\":false},\"result_result.current\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/result\"}]},\"params_result.page\":{\"type\":\"object\",\"properties\":{\"binding\":{\"$ref\":\"#/$defs/pageBinding\"},\"pageSize\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":200},\"cursor\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"binding\",\"pageSize\",\"cursor\"],\"additionalProperties\":false},\"result_result.page\":{\"$ref\":\"#/$defs/page\"},\"params_operation.get\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"operationId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"operationId\"],\"additionalProperties\":false},\"result_operation.get\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/commitMarker\"}]},\"changeSet\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"baseProjectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"operationId\":{\"$ref\":\"#/$defs/id\"},\"planRef\":{\"$ref\":\"#/$defs/hash\"},\"diffRef\":{\"$ref\":\"#/$defs/hash\"},\"confirmationRef\":{\"$ref\":\"#/$defs/id\"},\"intent\":{\"enum\":[\"edit\",\"restore-managed-value\",\"restore-historical-manual-value\",\"undo-one-changeset\"]},\"beforeSnapshotId\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"projectId\",\"baseProjectRevision\",\"operationId\",\"planRef\",\"diffRef\",\"confirmationRef\",\"intent\",\"beforeSnapshotId\"],\"additionalProperties\":false},\"runConfig\":{\"type\":\"object\",\"properties\":{\"maxRounds\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":1000},\"maxActionsPerRound\":{\"const\":1000},\"parametersRef\":{\"$ref\":\"#/$defs/hash\"},\"eventsRef\":{\"$ref\":\"#/$defs/hash\"},\"ruleVersions\":{\"$ref\":\"#/$defs/vector\"},\"behaviorVersions\":{\"$ref\":\"#/$defs/vector\"},\"initialSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"eventConsumptionRef\":{\"$ref\":\"#/$defs/hash\"},\"semantics\":{\"const\":\"E.1-E.2-one-stage-v1\"},\"roundOrder\":{\"const\":\"events>pre-inference>freeze-conflicts>behavior>resources>post-inference-metrics-commit\"},\"triggerOrder\":{\"const\":\"priority:desc,behaviorId:asc,eventInputOrdinal:asc,eventId:asc,actionOrdinal:asc\"}},\"required\":[\"maxRounds\",\"maxActionsPerRound\",\"parametersRef\",\"eventsRef\",\"ruleVersions\",\"behaviorVersions\",\"initialSnapshotId\",\"eventConsumptionRef\",\"semantics\",\"roundOrder\",\"triggerOrder\"],\"additionalProperties\":false},\"request\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"const\":null},\"method\":{\"const\":\"hello\"},\"params\":{\"$ref\":\"#/$defs/params_hello\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"params\":{\"$ref\":\"#/$defs/params_health\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"params\":{\"$ref\":\"#/$defs/params_session.ping\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"params\":{\"$ref\":\"#/$defs/params_project.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"params\":{\"$ref\":\"#/$defs/params_job.create\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"params\":{\"$ref\":\"#/$defs/params_job.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"params\":{\"$ref\":\"#/$defs/params_job.cancel\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"params\":{\"$ref\":\"#/$defs/params_job.list\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"params\":{\"$ref\":\"#/$defs/params_job.subscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"params\":{\"$ref\":\"#/$defs/params_job.unsubscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"params\":{\"$ref\":\"#/$defs/params_result.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"params\":{\"$ref\":\"#/$defs/params_result.current\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"params\":{\"$ref\":\"#/$defs/params_result.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"params\":{\"$ref\":\"#/$defs/params_operation.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false}]},\"response\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]},\"method\":{\"const\":\"hello\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_hello\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]},\"method\":{\"const\":\"hello\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_health\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_session.ping\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_project.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.create\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.cancel\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.list\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.subscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.unsubscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.current\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_operation.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"const\":null},\"method\":{\"enum\":[\"health\",\"session.ping\",\"project.get\",\"job.create\",\"job.get\",\"job.cancel\",\"job.list\",\"job.subscribe\",\"job.unsubscribe\",\"result.get\",\"result.current\",\"result.page\",\"operation.get\"]},\"ok\":{\"const\":false},\"error\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VERSION_INCOMPATIBLE\"},\"messageKey\":{\"const\":\"protocol.versionIncompatible\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"const\":2},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedVersions\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"HANDSHAKE_REQUIRED\"},\"messageKey\":{\"const\":\"protocol.handshakeRequired\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false}]}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false}]},\"notification\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":2},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"job.progress\"},\"data\":{\"type\":\"object\",\"properties\":{\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"progress\":{\"$ref\":\"#/$defs/progress\"}},\"required\":[\"stateVersion\",\"progress\"],\"additionalProperties\":false}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"subscriptionId\",\"projectId\",\"jobId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":2},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"job.state\"},\"data\":{\"$ref\":\"#/$defs/job\"}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"subscriptionId\",\"projectId\",\"jobId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":2},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"session.status\"},\"data\":{\"type\":\"object\",\"properties\":{\"status\":{\"enum\":[\"ready\",\"stopping\"]}},\"required\":[\"status\"],\"additionalProperties\":false}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false}]},\"envelope\":{\"oneOf\":[{\"$ref\":\"#/$defs/request\"},{\"$ref\":\"#/$defs/response\"},{\"$ref\":\"#/$defs/notification\"}]},\"jobListCursorRecord\":{\"type\":\"object\",\"properties\":{\"token\":{\"$ref\":\"#/$defs/id\"},\"binding\":{\"$ref\":\"#/$defs/listBinding\"},\"pageSize\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":100},\"lastCreatedAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"lastJobId\":{\"$ref\":\"#/$defs/id\"},\"expiresAtMs\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"token\",\"binding\",\"pageSize\",\"lastCreatedAtMs\",\"lastJobId\",\"expiresAtMs\"],\"additionalProperties\":false},\"definitionIdentity\":{\"type\":\"object\",\"properties\":{\"family\":{\"enum\":[\"ontology\",\"mapping\",\"constraint\",\"rule\",\"behavior\",\"scenario\",\"query\",\"model\"]},\"id\":{\"$ref\":\"#/$defs/name\"},\"version\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"references\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/dependencyKey\"},\"minItems\":0,\"maxItems\":4096}},\"required\":[\"family\",\"id\",\"version\",\"references\"],\"additionalProperties\":false},\"validationDerivedLayers\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"resultId\":{\"$ref\":\"#/$defs/id\"},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"factsRef\":{\"$ref\":\"#/$defs/hash\"},\"axiomsRef\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"projectId\",\"inputSnapshotId\",\"resultId\",\"implementation\",\"factsRef\",\"axiomsRef\"],\"additionalProperties\":false},\"validationProjection\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"projectionVersion\":{\"const\":1},\"projectionPolicy\":{\"const\":\"selected-facts-v1\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"inputProjectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"assertedFactsRef\":{\"$ref\":\"#/$defs/hash\"},\"ontologyAxiomsRef\":{\"$ref\":\"#/$defs/hash\"},\"constraintDefinitionId\":{\"$ref\":\"#/$defs/name\"},\"constraintsRef\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"const\":\"asserted\"},\"derived\":{\"const\":null},\"inputSelection\":{\"enum\":[\"current\",\"historical\"]}},\"required\":[\"projectionVersion\",\"projectionPolicy\",\"projectId\",\"inputSnapshotId\",\"inputProjectRevision\",\"implementation\",\"assertedFactsRef\",\"ontologyAxiomsRef\",\"constraintDefinitionId\",\"constraintsRef\",\"scope\",\"derived\",\"inputSelection\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"projectionVersion\":{\"const\":1},\"projectionPolicy\":{\"const\":\"selected-facts-v1\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"inputProjectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"implementation\":{\"$ref\":\"#/$defs/implementation\"},\"assertedFactsRef\":{\"$ref\":\"#/$defs/hash\"},\"ontologyAxiomsRef\":{\"$ref\":\"#/$defs/hash\"},\"constraintDefinitionId\":{\"$ref\":\"#/$defs/name\"},\"constraintsRef\":{\"$ref\":\"#/$defs/hash\"},\"scope\":{\"const\":\"asserted+derived\"},\"derived\":{\"$ref\":\"#/$defs/validationDerivedLayers\"},\"inputSelection\":{\"enum\":[\"current\",\"historical\"]}},\"required\":[\"projectionVersion\",\"projectionPolicy\",\"projectId\",\"inputSnapshotId\",\"inputProjectRevision\",\"implementation\",\"assertedFactsRef\",\"ontologyAxiomsRef\",\"constraintDefinitionId\",\"constraintsRef\",\"scope\",\"derived\",\"inputSelection\"],\"additionalProperties\":false}]},\"validationResourceBinding\":{\"type\":\"object\",\"properties\":{\"ref\":{\"$ref\":\"#/$defs/hash\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"role\":{\"enum\":[\"assertedFacts\",\"ontologyAxioms\",\"constraints\",\"derivedFacts\",\"derivedAxioms\"]},\"resultId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]},\"implementation\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/implementation\"}]},\"resultKind\":{\"oneOf\":[{\"const\":null},{\"enum\":[\"reasoning\",\"query\",\"validation\",\"behavior\",\"scenario\",\"receipt\",\"test\"]}]},\"payloadStatus\":{\"oneOf\":[{\"const\":null},{\"enum\":[\"available\",\"evicted\"]}]},\"resultState\":{\"oneOf\":[{\"const\":null},{\"enum\":[\"current\",\"stale\",\"historical\"]}]},\"constraintDefinitionId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/name\"}]}},\"required\":[\"ref\",\"projectId\",\"inputSnapshotId\",\"role\",\"resultId\",\"implementation\",\"resultKind\",\"payloadStatus\",\"resultState\",\"constraintDefinitionId\"],\"additionalProperties\":false},\"validationResources\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/validationResourceBinding\"},\"minItems\":3,\"maxItems\":5},\"project3\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"projectRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"dependencyVector\":{\"$ref\":\"#/$defs/vector\"},\"formatVersion\":{\"const\":3}},\"required\":[\"projectId\",\"projectRevision\",\"inputSnapshotId\",\"dependencyVector\",\"formatVersion\"],\"additionalProperties\":false},\"result_project.get3\":{\"$ref\":\"#/$defs/project3\"},\"result_hello3\":{\"type\":\"object\",\"properties\":{\"selectedVersion\":{\"const\":3},\"engineVersion\":{\"$ref\":\"#/$defs/name\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"capabilities\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/name\"},\"minItems\":0,\"maxItems\":32},\"limits\":{\"$ref\":\"#/$defs/limits\"},\"registryHash\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"selectedVersion\",\"engineVersion\",\"engineSessionId\",\"capabilities\",\"limits\",\"registryHash\"],\"additionalProperties\":false},\"error3\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INVALID_REQUEST\"},\"messageKey\":{\"const\":\"protocol.invalidRequest\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"field\":{\"enum\":[\"envelope\",\"params\",\"identity\",\"config\",\"cursor\",\"dependency\",\"kind\"]}},\"required\":[\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"METHOD_NOT_ALLOWED\"},\"messageKey\":{\"const\":\"protocol.methodNotAllowed\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VERSION_INCOMPATIBLE\"},\"messageKey\":{\"const\":\"protocol.versionIncompatible\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"const\":3},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedVersions\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"HANDSHAKE_REQUIRED\"},\"messageKey\":{\"const\":\"protocol.handshakeRequired\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SESSION_MISMATCH\"},\"messageKey\":{\"const\":\"protocol.sessionMismatch\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"NOT_FOUND\"},\"messageKey\":{\"const\":\"resource.notFound\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resource\":{\"enum\":[\"project\",\"job\",\"result\",\"snapshot\",\"operation\",\"subscription\",\"cursor\"]}},\"required\":[\"resource\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"PERMISSION_DENIED\"},\"messageKey\":{\"const\":\"permission.denied\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"UNSUPPORTED_CAPABILITY\"},\"messageKey\":{\"const\":\"capability.unsupported\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"QUEUE_FULL\"},\"messageKey\":{\"const\":\"job.queueFull\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"retryAfterMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000}},\"required\":[\"retryAfterMs\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"TIMEOUT\"},\"messageKey\":{\"const\":\"job.timeout\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"phase\":{\"enum\":[\"startup\",\"handshake\",\"request\",\"total\",\"heartbeat\",\"cancel\"]}},\"required\":[\"phase\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"ENGINE_EXITED\"},\"messageKey\":{\"const\":\"engine.exited\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"REVISION_CONFLICT\"},\"messageKey\":{\"const\":\"project.revisionConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"expected\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"actual\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991}},\"required\":[\"expected\",\"actual\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"OWNERSHIP_CONFLICT\"},\"messageKey\":{\"const\":\"project.ownershipConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"detailRef\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"detailRef\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"IDENTITY_CONFLICT\"},\"messageKey\":{\"const\":\"operation.identityConflict\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_BUSY\"},\"messageKey\":{\"const\":\"storage.busy\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"retryAfterMs\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":60000}},\"required\":[\"retryAfterMs\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_FAILURE\"},\"messageKey\":{\"const\":\"storage.failure\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"operationId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"CURSOR_MISMATCH\"},\"messageKey\":{\"const\":\"result.cursorMismatch\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"CURSOR_EXPIRED\"},\"messageKey\":{\"const\":\"result.cursorExpired\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"PAYLOAD_EVICTED\"},\"messageKey\":{\"const\":\"result.payloadEvicted\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resultId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"resultId\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INVALID_STATE\"},\"messageKey\":{\"const\":\"protocol.invalidState\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"MAPPING_VALUE_INVALID\"},\"messageKey\":{\"const\":\"mapping.valueInvalid\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"worksheetId\":{\"$ref\":\"#/$defs/id\"},\"row\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":1048576},\"column\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":16384},\"field\":{\"enum\":[\"key\",\"value\",\"type\",\"reference\"]},\"detailRef\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"worksheetId\",\"row\",\"column\",\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INTERNAL_ERROR\"},\"messageKey\":{\"const\":\"engine.internal\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SEMANTIC_INPUT_INVALID\"},\"messageKey\":{\"const\":\"semantics.inputInvalid\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"field\":{\"enum\":[\"syntax\",\"query\",\"rule\",\"constraint\"]}},\"required\":[\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"NETWORK_FORBIDDEN\"},\"messageKey\":{\"const\":\"semantics.networkForbidden\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"UNSUPPORTED_CONSTRUCT\"},\"messageKey\":{\"const\":\"semantics.unsupportedConstruct\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"construct\":{\"enum\":[\"rdfBlankNode\",\"sparqlForm\",\"ruleChain\",\"ruleRecursion\",\"shaclPath\",\"shaclAdvanced\",\"owlExpression\",\"rdfFormat\",\"rdfConstruct\",\"rdfsConstruct\",\"datatype\",\"literalValue\",\"queryFunction\",\"queryOrder\",\"querySlice\",\"ruleOutput\",\"validationScope\"]}},\"required\":[\"construct\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"RESOURCE_LIMIT\"},\"messageKey\":{\"const\":\"resource.limitExceeded\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"resource\":{\"enum\":[\"memory\",\"actions\",\"rounds\",\"frame\",\"page\",\"semanticInput\",\"semanticResult\",\"semanticWork\"]}},\"required\":[\"resource\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false}]},\"error_bootstrap3\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VERSION_INCOMPATIBLE\"},\"messageKey\":{\"const\":\"protocol.versionIncompatible\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"const\":3},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedVersions\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"VERSION_INCOMPATIBLE\"},\"messageKey\":{\"const\":\"protocol.versionIncompatible\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedVersions\":{\"type\":\"array\",\"items\":{\"const\":2},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedVersions\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INVALID_REQUEST\"},\"messageKey\":{\"const\":\"protocol.invalidRequest\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"field\":{\"const\":\"params\"}},\"required\":[\"field\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"SESSION_MISMATCH\"},\"messageKey\":{\"const\":\"protocol.sessionMismatch\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false}]},\"request3\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"const\":null},\"method\":{\"const\":\"hello\"},\"params\":{\"$ref\":\"#/$defs/params_hello\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"params\":{\"$ref\":\"#/$defs/params_health\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"params\":{\"$ref\":\"#/$defs/params_session.ping\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"params\":{\"$ref\":\"#/$defs/params_project.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"params\":{\"$ref\":\"#/$defs/params_job.create\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"params\":{\"$ref\":\"#/$defs/params_job.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"params\":{\"$ref\":\"#/$defs/params_job.cancel\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"params\":{\"$ref\":\"#/$defs/params_job.list\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"params\":{\"$ref\":\"#/$defs/params_job.subscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"params\":{\"$ref\":\"#/$defs/params_job.unsubscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"params\":{\"$ref\":\"#/$defs/params_result.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"params\":{\"$ref\":\"#/$defs/params_result.current\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"params\":{\"$ref\":\"#/$defs/params_result.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"params\":{\"$ref\":\"#/$defs/params_operation.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.preview\"},\"params\":{\"$ref\":\"#/$defs/params_changeset.preview\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.diff.page\"},\"params\":{\"$ref\":\"#/$defs/params_changeset.diff.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"request\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.confirm\"},\"params\":{\"$ref\":\"#/$defs/params_changeset.confirm\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"params\"],\"additionalProperties\":false}]},\"response3\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"hello\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_hello3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":2},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"const\":null},\"method\":{\"const\":\"hello\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error_bootstrap3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_health\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"health\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_session.ping\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"session.ping\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_project.get3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"project.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.create\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.create\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.cancel\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.cancel\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.list\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.list\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.subscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.subscribe\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_job.unsubscribe\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"job.unsubscribe\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.current\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.current\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_result.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"result.page\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_operation.get\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"operation.get\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.preview\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_changeset.preview\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.preview\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.diff.page\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_changeset.diff.page\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.diff.page\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.confirm\"},\"ok\":{\"const\":true},\"result\":{\"$ref\":\"#/$defs/result_changeset.confirm\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"result\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"response\"},\"protocolVersion\":{\"const\":3},\"id\":{\"$ref\":\"#/$defs/id\"},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"method\":{\"const\":\"changeset.confirm\"},\"ok\":{\"const\":false},\"error\":{\"$ref\":\"#/$defs/error3\"}},\"required\":[\"kind\",\"protocolVersion\",\"id\",\"engineSessionId\",\"method\",\"ok\",\"error\"],\"additionalProperties\":false}]},\"notification3\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":3},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"job.progress\"},\"data\":{\"type\":\"object\",\"properties\":{\"stateVersion\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"progress\":{\"$ref\":\"#/$defs/progress\"}},\"required\":[\"stateVersion\",\"progress\"],\"additionalProperties\":false}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"subscriptionId\",\"projectId\",\"jobId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":3},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"subscriptionId\":{\"$ref\":\"#/$defs/id\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"jobId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"job.state\"},\"data\":{\"$ref\":\"#/$defs/job\"}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"subscriptionId\",\"projectId\",\"jobId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"notification\"},\"protocolVersion\":{\"const\":3},\"engineSessionId\":{\"$ref\":\"#/$defs/id\"},\"seq\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":9007199254740991},\"event\":{\"const\":\"session.status\"},\"data\":{\"type\":\"object\",\"properties\":{\"status\":{\"enum\":[\"ready\",\"stopping\"]}},\"required\":[\"status\"],\"additionalProperties\":false}},\"required\":[\"kind\",\"protocolVersion\",\"engineSessionId\",\"seq\",\"event\",\"data\"],\"additionalProperties\":false}]},\"envelope3\":{\"oneOf\":[{\"$ref\":\"#/$defs/request3\"},{\"$ref\":\"#/$defs/response3\"},{\"$ref\":\"#/$defs/notification3\"}]},\"error_startup\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"PROJECT_FORMAT_UNSUPPORTED\"},\"messageKey\":{\"const\":\"project.formatUnsupported\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{\"supportedFormats\":{\"type\":\"array\",\"items\":{\"const\":3},\"minItems\":1,\"maxItems\":1}},\"required\":[\"supportedFormats\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_BUSY\"},\"messageKey\":{\"const\":\"storage.busy\"},\"retryable\":{\"const\":true},\"params\":{\"type\":\"object\",\"properties\":{\"retryAfterMs\":{\"const\":250}},\"required\":[\"retryAfterMs\"],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"STORAGE_FAILURE\"},\"messageKey\":{\"const\":\"storage.failure\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"code\":{\"const\":\"INTERNAL_ERROR\"},\"messageKey\":{\"const\":\"engine.internal\"},\"retryable\":{\"const\":false},\"params\":{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}},\"required\":[\"code\",\"messageKey\",\"retryable\",\"params\"],\"additionalProperties\":false}]},\"startupFailure\":{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"startupFailure\"},\"diagnosticVersion\":{\"const\":1},\"engineSessionId\":{\"const\":null},\"registryHash\":{\"$ref\":\"#/$defs/hash\"},\"error\":{\"$ref\":\"#/$defs/error_startup\"}},\"required\":[\"kind\",\"diagnosticVersion\",\"engineSessionId\",\"registryHash\",\"error\"],\"additionalProperties\":false},\"changeSetDefinitionReference\":{\"type\":\"object\",\"properties\":{\"layer\":{\"enum\":[\"ontology\",\"mapping\",\"constraint\",\"rule\",\"behavior\",\"scenario\",\"query\",\"model\"]},\"id\":{\"$ref\":\"#/$defs/name\"}},\"required\":[\"layer\",\"id\"],\"additionalProperties\":false},\"changeSetTriple\":{\"type\":\"object\",\"properties\":{\"subject\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"predicate\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"object\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144}},\"required\":[\"subject\",\"predicate\",\"object\"],\"additionalProperties\":false},\"changeSetOntologyValue\":{\"type\":\"object\",\"properties\":{\"triples\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetTriple\"},\"minItems\":0,\"maxItems\":4096},\"singleValuedPredicates\":{\"type\":\"array\",\"items\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"minItems\":0,\"maxItems\":4096},\"references\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetDefinitionReference\"},\"minItems\":0,\"maxItems\":4096}},\"required\":[],\"additionalProperties\":false},\"changeSetDefinition\":{\"type\":\"object\",\"properties\":{\"layer\":{\"const\":\"ontology\"},\"id\":{\"$ref\":\"#/$defs/name\"},\"value\":{\"$ref\":\"#/$defs/changeSetOntologyValue\"}},\"required\":[\"layer\",\"id\",\"value\"],\"additionalProperties\":false},\"changeSetDefinitionRemoval\":{\"type\":\"object\",\"properties\":{\"layer\":{\"const\":\"ontology\"},\"id\":{\"$ref\":\"#/$defs/name\"}},\"required\":[\"layer\",\"id\"],\"additionalProperties\":false},\"changeSetFact\":{\"type\":\"object\",\"properties\":{\"id\":{\"$ref\":\"#/$defs/hash\"},\"subject\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"predicate\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"object\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144}},\"required\":[\"id\",\"subject\",\"predicate\",\"object\"],\"additionalProperties\":false},\"changeSetPlan\":{\"type\":\"object\",\"properties\":{\"definitions\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetDefinition\"},\"minItems\":0,\"maxItems\":4096},\"remove_definitions\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetDefinitionRemoval\"},\"minItems\":0,\"maxItems\":4096},\"manual\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetFact\"},\"minItems\":0,\"maxItems\":4096},\"edits\":{\"type\":\"object\",\"propertyNames\":{\"$ref\":\"#/$defs/hash\"},\"additionalProperties\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":262144},\"maxProperties\":4096},\"remove\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/hash\"},\"minItems\":0,\"maxItems\":4096}},\"required\":[],\"additionalProperties\":false},\"changeSetSegmentDescriptor\":{\"type\":\"object\",\"properties\":{\"ordinal\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":511},\"byteOffset\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":16777215},\"rawByteLength\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":32768},\"sha256\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"ordinal\",\"byteOffset\",\"rawByteLength\",\"sha256\"],\"additionalProperties\":false},\"changeSetSegment\":{\"type\":\"object\",\"properties\":{\"ordinal\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":511},\"byteOffset\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":16777215},\"rawByteLength\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":32768},\"sha256\":{\"$ref\":\"#/$defs/hash\"},\"dataBase64\":{\"type\":\"string\",\"maxLength\":43692,\"pattern\":\"^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$\"}},\"required\":[\"ordinal\",\"byteOffset\",\"rawByteLength\",\"sha256\",\"dataBase64\"],\"additionalProperties\":false},\"changeSetManifest\":{\"type\":\"object\",\"properties\":{\"documentKind\":{\"enum\":[\"diff\",\"undo-impact\"]},\"documentHash\":{\"$ref\":\"#/$defs/hash\"},\"totalBytes\":{\"type\":\"integer\",\"minimum\":2,\"maximum\":16777216},\"segmentCount\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":512},\"segments\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetSegmentDescriptor\"},\"minItems\":1,\"maxItems\":512}},\"required\":[\"documentKind\",\"documentHash\",\"totalBytes\",\"segmentCount\",\"segments\"],\"additionalProperties\":false},\"params_changeset.preview\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"baseRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"intent\":{\"const\":\"change\"},\"plan\":{\"$ref\":\"#/$defs/changeSetPlan\"}},\"required\":[\"projectId\",\"baseRevision\",\"intent\",\"plan\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"baseRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"intent\":{\"const\":\"undo\"},\"targetOperationId\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"baseRevision\",\"intent\",\"targetOperationId\"],\"additionalProperties\":false}]},\"result_changeset.preview\":{\"oneOf\":[{\"type\":\"object\",\"properties\":{\"status\":{\"const\":\"ready\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"baseRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"preparedPlanRef\":{\"$ref\":\"#/$defs/hash\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"},\"intent\":{\"enum\":[\"change\",\"undo\"]},\"targetOperationId\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]},\"summary\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":512},\"manifest\":{\"$ref\":\"#/$defs/changeSetManifest\"}},\"required\":[\"status\",\"projectId\",\"baseRevision\",\"previewHash\",\"preparedPlanRef\",\"inputSnapshotId\",\"parametersHash\",\"intent\",\"targetOperationId\",\"summary\",\"manifest\"],\"additionalProperties\":false},{\"type\":\"object\",\"properties\":{\"status\":{\"const\":\"conflict\"},\"projectId\":{\"$ref\":\"#/$defs/id\"},\"baseRevision\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":9007199254740991},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"targetOperationId\":{\"$ref\":\"#/$defs/id\"},\"summary\":{\"type\":\"string\",\"minLength\":1,\"maxLength\":512},\"impactComplete\":{\"type\":\"boolean\"},\"manifest\":{\"$ref\":\"#/$defs/changeSetManifest\"}},\"required\":[\"status\",\"projectId\",\"baseRevision\",\"previewHash\",\"targetOperationId\",\"summary\",\"impactComplete\",\"manifest\"],\"additionalProperties\":false}]},\"params_changeset.diff.page\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"documentKind\":{\"enum\":[\"diff\",\"undo-impact\"]},\"pageSize\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":200},\"cursor\":{\"oneOf\":[{\"const\":null},{\"$ref\":\"#/$defs/id\"}]}},\"required\":[\"projectId\",\"previewHash\",\"documentKind\",\"pageSize\",\"cursor\"],\"additionalProperties\":false},\"changeSetPage\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"documentKind\":{\"enum\":[\"diff\",\"undo-impact\"]},\"documentHash\":{\"$ref\":\"#/$defs/hash\"},\"segments\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/$defs/changeSetSegment\"},\"minItems\":0,\"maxItems\":200},\"nextCursor\":{\"$ref\":\"#/$defs/id\"},\"complete\":{\"type\":\"boolean\"}},\"required\":[\"projectId\",\"previewHash\",\"documentKind\",\"documentHash\",\"segments\",\"nextCursor\",\"complete\"],\"additionalProperties\":false},\"result_changeset.diff.page\":{\"$ref\":\"#/$defs/changeSetPage\"},\"params_changeset.confirm\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"completionCursor\":{\"$ref\":\"#/$defs/id\"}},\"required\":[\"projectId\",\"previewHash\",\"completionCursor\"],\"additionalProperties\":false},\"result_changeset.confirm\":{\"type\":\"object\",\"properties\":{\"projectId\":{\"$ref\":\"#/$defs/id\"},\"previewHash\":{\"$ref\":\"#/$defs/hash\"},\"preparedPlanRef\":{\"$ref\":\"#/$defs/hash\"},\"confirmationRef\":{\"$ref\":\"#/$defs/id\"},\"inputSnapshotId\":{\"$ref\":\"#/$defs/hash\"},\"parametersHash\":{\"$ref\":\"#/$defs/hash\"}},\"required\":[\"projectId\",\"previewHash\",\"preparedPlanRef\",\"confirmationRef\",\"inputSnapshotId\",\"parametersHash\"],\"additionalProperties\":false}}"),
	$ref: "#/$defs/envelope"
};
var registry_default = {
	schemaVersion: 2,
	productRuntime: ["health"],
	v2Runtime: [
		"hello",
		"health",
		"session.ping",
		"project.get",
		"job.create",
		"job.get",
		"job.cancel",
		"job.list",
		"job.subscribe",
		"job.unsubscribe",
		"result.get",
		"result.current",
		"result.page",
		"operation.get"
	],
	capabilities: /* @__PURE__ */ JSON.parse("{\"hello\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_hello\",\"resultSchema\":\"#/$defs/result_hello\",\"scope\":\"session\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"health\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_health\",\"resultSchema\":\"#/$defs/result_health\",\"scope\":\"session\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"session.ping\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_session.ping\",\"resultSchema\":\"#/$defs/result_session.ping\",\"scope\":\"session\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"project.get\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_project.get\",\"resultSchema\":\"#/$defs/result_project.get\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.create\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_job.create\",\"resultSchema\":\"#/$defs/result_job.create\",\"scope\":\"project\",\"effect\":\"schedule\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.get\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_job.get\",\"resultSchema\":\"#/$defs/result_job.get\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.cancel\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_job.cancel\",\"resultSchema\":\"#/$defs/result_job.cancel\",\"scope\":\"project\",\"effect\":\"control\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.list\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_job.list\",\"resultSchema\":\"#/$defs/result_job.list\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.subscribe\":{\"owner\":\"main\",\"paramsSchema\":\"#/$defs/params_job.subscribe\",\"resultSchema\":\"#/$defs/result_job.subscribe\",\"scope\":\"project\",\"effect\":\"control\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"job.unsubscribe\":{\"owner\":\"main\",\"paramsSchema\":\"#/$defs/params_job.unsubscribe\",\"resultSchema\":\"#/$defs/result_job.unsubscribe\",\"scope\":\"project\",\"effect\":\"control\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"result.get\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_result.get\",\"resultSchema\":\"#/$defs/result_result.get\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"result.current\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_result.current\",\"resultSchema\":\"#/$defs/result_result.current\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"result.page\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_result.page\",\"resultSchema\":\"#/$defs/result_result.page\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"operation.get\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_operation.get\",\"resultSchema\":\"#/$defs/result_operation.get\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"not-applicable\",\"dependencyPolicy\":null,\"dataScopes\":[]},\"test.read\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"test-only\",\"implementation\":\"test-runtime\",\"limitProfile\":\"read\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":null,\"dataScopes\":[\"asserted\"]},\"test.atomic\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"formal-write\",\"requiresChangeSet\":true,\"requiresConfirmation\":true,\"agentEligible\":false,\"exposure\":\"test-only\",\"implementation\":\"test-runtime\",\"limitProfile\":\"atomic\",\"cancelBoundary\":\"whole-transaction\",\"dependencyPolicy\":null,\"dataScopes\":[\"asserted\"]},\"test.rounds\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"isolated-write\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"test-only\",\"implementation\":\"test-runtime\",\"limitProfile\":\"rounds\",\"cancelBoundary\":\"uncommitted-round\",\"dependencyPolicy\":null,\"dataScopes\":[\"scenario\"]},\"query.execute\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"read\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":\"query.execute\",\"dataScopes\":[\"asserted\",\"asserted+derived\"]},\"reasoning.execute\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"read\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":\"reasoning.execute\",\"dataScopes\":[\"asserted\"]},\"validation.execute\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"read\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":\"validation.execute\",\"dataScopes\":[\"asserted\",\"asserted+derived\"]},\"mapping.commit\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"formal-write\",\"requiresChangeSet\":true,\"requiresConfirmation\":true,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"atomic\",\"cancelBoundary\":\"whole-transaction\",\"dependencyPolicy\":\"mapping.commit\",\"dataScopes\":[\"asserted\"]},\"changeset.commit\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"formal-write\",\"requiresChangeSet\":true,\"requiresConfirmation\":true,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"atomic\",\"cancelBoundary\":\"whole-transaction\",\"dependencyPolicy\":\"changeset.commit\",\"dataScopes\":[\"asserted\"]},\"behavior.test\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"isolated-write\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"rounds\",\"cancelBoundary\":\"uncommitted-round\",\"dependencyPolicy\":\"behavior.test\",\"dataScopes\":[\"scenario\"]},\"scenario.run\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/jobInput\",\"resultSchema\":\"#/$defs/job\",\"scope\":\"project\",\"effect\":\"isolated-write\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":true,\"exposure\":\"business-named-bridge-only\",\"implementation\":\"design-only\",\"limitProfile\":\"rounds\",\"cancelBoundary\":\"uncommitted-round\",\"dependencyPolicy\":\"scenario.run\",\"dataScopes\":[\"scenario\"]},\"changeset.preview\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_changeset.preview\",\"resultSchema\":\"#/$defs/result_changeset.preview\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"internal-business3-trusted-host-only\",\"implementation\":\"explicit-internal-business3-runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":null,\"dataScopes\":[\"asserted\"]},\"changeset.diff.page\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_changeset.diff.page\",\"resultSchema\":\"#/$defs/result_changeset.diff.page\",\"scope\":\"project\",\"effect\":\"read\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"internal-business3-trusted-host-only\",\"implementation\":\"explicit-internal-business3-runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":null,\"dataScopes\":[\"asserted\"]},\"changeset.confirm\":{\"owner\":\"coordinator\",\"paramsSchema\":\"#/$defs/params_changeset.confirm\",\"resultSchema\":\"#/$defs/result_changeset.confirm\",\"scope\":\"project\",\"effect\":\"confirmation\",\"requiresChangeSet\":false,\"requiresConfirmation\":false,\"agentEligible\":false,\"exposure\":\"internal-business3-trusted-host-only\",\"implementation\":\"explicit-internal-business3-runtime\",\"limitProfile\":\"control\",\"cancelBoundary\":\"discard-unpublished-result\",\"dependencyPolicy\":null,\"dataScopes\":[\"asserted\"]}}"),
	foundationProfiles: { "business3": {
		"bootstrapVersion": 2,
		"businessVersion": 3,
		"databaseFormatVersion": 3,
		"state": "explicit-internal-opt-in-default2",
		"methods": [
			"hello",
			"health",
			"session.ping",
			"project.get",
			"job.create",
			"job.get",
			"job.cancel",
			"job.list",
			"job.subscribe",
			"job.unsubscribe",
			"result.get",
			"result.current",
			"result.page",
			"operation.get",
			"changeset.preview",
			"changeset.diff.page",
			"changeset.confirm"
		],
		"newSourceOrLearningMethods": [],
		"capabilityImplementations": { "changeset.commit": "explicit-internal-business3-runtime" }
	} },
	startupDiagnostic: {
		"diagnosticVersion": 1,
		"profile": "business3",
		"phase": "pre-hello-only",
		"schema": "#/$defs/startupFailure",
		"errorSchema": "#/$defs/error_startup",
		"maxPayloadBytes": 1024,
		"payloadLength": "raw-before-CR-removal-excluding-LF",
		"singlePerAttempt": true
	}
};
var errors_default = {
	schemaVersion: 2,
	maxEncodedBytes: 2048,
	codes: {
		"INVALID_REQUEST": {
			"messageKey": "protocol.invalidRequest",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "field": { "enum": [
					"envelope",
					"params",
					"identity",
					"config",
					"cursor",
					"dependency",
					"kind"
				] } },
				"required": ["field"],
				"additionalProperties": false
			}
		},
		"METHOD_NOT_ALLOWED": {
			"messageKey": "protocol.methodNotAllowed",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"VERSION_INCOMPATIBLE": {
			"messageKey": "protocol.versionIncompatible",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "supportedVersions": {
					"type": "array",
					"items": { "const": 2 },
					"minItems": 1,
					"maxItems": 1
				} },
				"required": ["supportedVersions"],
				"additionalProperties": false
			}
		},
		"HANDSHAKE_REQUIRED": {
			"messageKey": "protocol.handshakeRequired",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"SESSION_MISMATCH": {
			"messageKey": "protocol.sessionMismatch",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"NOT_FOUND": {
			"messageKey": "resource.notFound",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "resource": { "enum": [
					"project",
					"job",
					"result",
					"snapshot",
					"operation",
					"subscription",
					"cursor"
				] } },
				"required": ["resource"],
				"additionalProperties": false
			}
		},
		"PERMISSION_DENIED": {
			"messageKey": "permission.denied",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"UNSUPPORTED_CAPABILITY": {
			"messageKey": "capability.unsupported",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"QUEUE_FULL": {
			"messageKey": "job.queueFull",
			"retryable": true,
			"paramsSchema": {
				"type": "object",
				"properties": { "retryAfterMs": {
					"type": "integer",
					"minimum": 1,
					"maximum": 6e4
				} },
				"required": ["retryAfterMs"],
				"additionalProperties": false
			}
		},
		"TIMEOUT": {
			"messageKey": "job.timeout",
			"retryable": true,
			"paramsSchema": {
				"type": "object",
				"properties": { "phase": { "enum": [
					"startup",
					"handshake",
					"request",
					"total",
					"heartbeat",
					"cancel"
				] } },
				"required": ["phase"],
				"additionalProperties": false
			}
		},
		"ENGINE_EXITED": {
			"messageKey": "engine.exited",
			"retryable": true,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"REVISION_CONFLICT": {
			"messageKey": "project.revisionConflict",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {
					"expected": {
						"type": "integer",
						"minimum": 0,
						"maximum": 9007199254740991
					},
					"actual": {
						"type": "integer",
						"minimum": 0,
						"maximum": 9007199254740991
					}
				},
				"required": ["expected", "actual"],
				"additionalProperties": false
			}
		},
		"OWNERSHIP_CONFLICT": {
			"messageKey": "project.ownershipConflict",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "detailRef": { "$ref": "#/$defs/id" } },
				"required": ["detailRef"],
				"additionalProperties": false
			}
		},
		"IDENTITY_CONFLICT": {
			"messageKey": "operation.identityConflict",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"STORAGE_BUSY": {
			"messageKey": "storage.busy",
			"retryable": true,
			"paramsSchema": {
				"type": "object",
				"properties": { "retryAfterMs": {
					"type": "integer",
					"minimum": 1,
					"maximum": 6e4
				} },
				"required": ["retryAfterMs"],
				"additionalProperties": false
			}
		},
		"STORAGE_FAILURE": {
			"messageKey": "storage.failure",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "operationId": { "$ref": "#/$defs/id" } },
				"required": [],
				"additionalProperties": false
			}
		},
		"CURSOR_MISMATCH": {
			"messageKey": "result.cursorMismatch",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"CURSOR_EXPIRED": {
			"messageKey": "result.cursorExpired",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"PAYLOAD_EVICTED": {
			"messageKey": "result.payloadEvicted",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "resultId": { "$ref": "#/$defs/id" } },
				"required": ["resultId"],
				"additionalProperties": false
			}
		},
		"INVALID_STATE": {
			"messageKey": "protocol.invalidState",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"MAPPING_VALUE_INVALID": {
			"messageKey": "mapping.valueInvalid",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {
					"worksheetId": { "$ref": "#/$defs/id" },
					"row": {
						"type": "integer",
						"minimum": 1,
						"maximum": 1048576
					},
					"column": {
						"type": "integer",
						"minimum": 1,
						"maximum": 16384
					},
					"field": { "enum": [
						"key",
						"value",
						"type",
						"reference"
					] },
					"detailRef": { "$ref": "#/$defs/id" }
				},
				"required": [
					"worksheetId",
					"row",
					"column",
					"field"
				],
				"additionalProperties": false
			}
		},
		"INTERNAL_ERROR": {
			"messageKey": "engine.internal",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"SEMANTIC_INPUT_INVALID": {
			"messageKey": "semantics.inputInvalid",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "field": { "enum": [
					"syntax",
					"query",
					"rule",
					"constraint"
				] } },
				"required": ["field"],
				"additionalProperties": false
			}
		},
		"NETWORK_FORBIDDEN": {
			"messageKey": "semantics.networkForbidden",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": {},
				"required": [],
				"additionalProperties": false
			}
		},
		"UNSUPPORTED_CONSTRUCT": {
			"messageKey": "semantics.unsupportedConstruct",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "construct": { "enum": [
					"rdfBlankNode",
					"sparqlForm",
					"ruleChain",
					"ruleRecursion",
					"shaclPath",
					"shaclAdvanced",
					"owlExpression",
					"rdfFormat",
					"rdfConstruct",
					"rdfsConstruct",
					"datatype",
					"literalValue",
					"queryFunction",
					"queryOrder",
					"querySlice",
					"ruleOutput",
					"validationScope"
				] } },
				"required": ["construct"],
				"additionalProperties": false
			}
		},
		"RESOURCE_LIMIT": {
			"messageKey": "resource.limitExceeded",
			"retryable": false,
			"paramsSchema": {
				"type": "object",
				"properties": { "resource": { "enum": [
					"memory",
					"actions",
					"rounds",
					"frame",
					"page",
					"semanticInput",
					"semanticResult",
					"semanticWork"
				] } },
				"required": ["resource"],
				"additionalProperties": false
			}
		}
	},
	parameterMeanings: {
		"INVALID_REQUEST": {
			"envelope": "Known request envelope fields or their decoded structure.",
			"params": "Known method parameter structure.",
			"identity": "Request/resource identity fields or their required agreement.",
			"config": "Run or operation configuration structure.",
			"cursor": "Service cursor structure, before stateful cursor matching.",
			"dependency": "Dependency reference, closure or definition membership.",
			"kind": "Public result kind outside its finite allowlist."
		},
		"NOT_FOUND": {
			"project": "Authorized project does not exist.",
			"job": "Authorized durable job identity does not exist.",
			"result": "Authorized result metadata does not exist; payload eviction is separate.",
			"snapshot": "Authorized immutable snapshot does not exist.",
			"operation": "Authorized operation identity does not exist; a missing marker may instead be a successful null read.",
			"subscription": "Authorized notification subscription does not exist.",
			"cursor": "Authorized cursor identity does not exist; expired or mismatched cursors have separate codes."
		},
		"TIMEOUT": {
			"startup": "Coordinator process startup deadline.",
			"handshake": "Version/session negotiation deadline.",
			"request": "One request-response deadline; a write may already be committed.",
			"total": "Overall job execution deadline.",
			"heartbeat": "Session liveness heartbeat deadline.",
			"cancel": "Cancellation cleanup deadline; durable commits remain authoritative."
		},
		"MAPPING_VALUE_INVALID": {
			"key": "Worksheet key value cannot satisfy the selected mapping.",
			"value": "Worksheet cell value cannot satisfy the selected mapping.",
			"type": "Worksheet value type conflicts with the selected mapping.",
			"reference": "Worksheet reference cannot be resolved under the selected mapping."
		},
		"SEMANTIC_INPUT_INVALID": {
			"syntax": "Semantic document syntax is invalid.",
			"query": "Query input is malformed or invalid under supported query semantics.",
			"rule": "Rule input is malformed or invalid under supported rule semantics.",
			"constraint": "Constraint input is malformed or invalid under supported constraint semantics."
		},
		"UNSUPPORTED_CONSTRUCT": {
			"rdfBlankNode": "Blank-node construction outside the selected supported template subset.",
			"sparqlForm": "A syntactically valid query form outside SELECT/ASK.",
			"ruleChain": "Custom rule output used as a further custom-rule input.",
			"ruleRecursion": "Recursive custom-rule evaluation outside the finite candidate.",
			"shaclPath": "A valid SHACL path outside the supported direct-property path subset.",
			"shaclAdvanced": "Any valid SHACL constraint or feature outside the selected whitelist, not only advanced rules.",
			"owlExpression": "A valid OWL expression or axiom outside the selected finite subset.",
			"rdfFormat": "A serialization format outside the selected parser format, not malformed Turtle.",
			"rdfConstruct": "A well-formed RDF construct outside the selected finite subset; never a malformed triple.",
			"rdfsConstruct": "A well-formed RDFS construct outside the selected finite subset; never a guessed syntax failure.",
			"datatype": "A valid datatype outside the selected template or literal datatype whitelist.",
			"literalValue": "A lexically valid literal value category outside the selected finite semantics, such as non-finite values.",
			"queryFunction": "A valid query function or aggregate outside the selected deterministic subset.",
			"queryOrder": "A valid query ordering expression outside the selected ordering subset.",
			"querySlice": "A valid query LIMIT/OFFSET slice outside the selected query semantics; unrelated to service pagination.",
			"ruleOutput": "A valid rule-head construct outside domain facts/class membership, including schema axioms or arbitrary predicates.",
			"validationScope": "An explicitly requested validation scope unsupported by the actual implementation, not an adapter mixing graph layers."
		},
		"RESOURCE_LIMIT": {
			"memory": "Worker memory budget.",
			"actions": "Appendix E behavior-action budget.",
			"rounds": "Appendix E run-round budget.",
			"frame": "Encoded transport frame byte budget.",
			"page": "Encoded service page budget.",
			"semanticInput": "Actual semantic input text/blob byte or graph-size budget, never a type error or transport limit.",
			"semanticResult": "Total semantic result rows/triples/evidence payload budget, never just one page.",
			"semanticWork": "Cumulative closure/matching work or intermediate match-set budget, never behavior actions/rounds."
		}
	},
	foundationProfiles: { "business3": {
		"supportedVersions": [3],
		"legacyIncompatibleDiagnosis": [2],
		"nullSessionHelloCodes": [
			"VERSION_INCOMPATIBLE",
			"INVALID_REQUEST",
			"SESSION_MISMATCH"
		],
		"invalidRequestField": "params",
		"startupFailure": "no successful hello; bounded local startup diagnosis required before runtime activation"
	} },
	startup: {
		"diagnosticVersion": 1,
		"profile": "business3",
		"maxPayloadBytes": 1024,
		"codes": {
			"PROJECT_FORMAT_UNSUPPORTED": {
				"messageKey": "project.formatUnsupported",
				"retryable": false,
				"paramsSchema": {
					"type": "object",
					"properties": { "supportedFormats": {
						"type": "array",
						"items": { "const": 3 },
						"minItems": 1,
						"maxItems": 1
					} },
					"required": ["supportedFormats"],
					"additionalProperties": false
				}
			},
			"STORAGE_BUSY": {
				"messageKey": "storage.busy",
				"retryable": true,
				"paramsSchema": {
					"type": "object",
					"properties": { "retryAfterMs": { "const": 250 } },
					"required": ["retryAfterMs"],
					"additionalProperties": false
				}
			},
			"STORAGE_FAILURE": {
				"messageKey": "storage.failure",
				"retryable": false,
				"paramsSchema": {
					"type": "object",
					"properties": {},
					"required": [],
					"additionalProperties": false
				}
			},
			"INTERNAL_ERROR": {
				"messageKey": "engine.internal",
				"retryable": false,
				"paramsSchema": {
					"type": "object",
					"properties": {},
					"required": [],
					"additionalProperties": false
				}
			}
		}
	}
};
var states_default = {
	schemaVersion: 2,
	terminal: [
		"succeeded",
		"failed",
		"cancelled"
	],
	transitions: {
		"queued": [
			"running",
			"cancelled",
			"failed"
		],
		"running": [
			"cancelling",
			"succeeded",
			"failed"
		],
		"cancelling": [
			"cancelled",
			"failed",
			"succeeded"
		],
		"succeeded": [],
		"failed": [],
		"cancelled": []
	},
	queuedFailure: "admission accepted durably but coordinator recovery cannot safely start; no replay",
	cancellingSuccessRequires: "whole task final result/commit and terminal evidence persisted before cancellation linearization; partial rounds insufficient",
	stateVersion: "strictly increases on every durable transition; repeated identical terminal query is a read, not a transition"
};
//#endregion
//#region ../../packages/contracts/src/states-v2.ts
function permitsTransition(from, to, beforeVersion, afterVersion, finalPersistedBeforeCancel) {
	return !!states_default.transitions[from]?.includes(to) && Number.isSafeInteger(beforeVersion) && beforeVersion >= 1 && Number.isSafeInteger(afterVersion) && afterVersion > beforeVersion && !(from === "cancelling" && to === "succeeded" && !finalPersistedBeforeCancel);
}
//#endregion
//#region ../../packages/contracts/src/v2.ts
/** Shared v2 value validators. Transport additionally validates raw JSONL bytes. */
var definitions = schema_default.$defs;
function utf8(value) {
	if (typeof value === "number") return 32;
	if (Array.isArray(value)) return 2 + Math.max(0, value.length - 1) + value.reduce((n, v) => n + utf8(v), 0);
	if (value && typeof value === "object") {
		const entries = Object.entries(value);
		return 2 + Math.max(0, entries.length - 1) + entries.reduce((n, [k, v]) => n + utf8(k) + 1 + utf8(v), 0);
	}
	return new TextEncoder().encode(JSON.stringify(value)).byteLength;
}
var fail = () => {
	throw new Error("INVALID_REQUEST");
};
var keywords = /* @__PURE__ */ new Set([
	"$ref",
	"const",
	"enum",
	"oneOf",
	"type",
	"properties",
	"required",
	"additionalProperties",
	"propertyNames",
	"minProperties",
	"maxProperties",
	"items",
	"minItems",
	"maxItems",
	"minLength",
	"maxLength",
	"pattern",
	"minimum",
	"maximum"
]);
function compile(s) {
	if (Object.keys(s).some((key) => !keywords.has(key))) return fail();
	if (s.$ref) {
		if (!s.$ref.startsWith("#/$defs/") || !definitions[s.$ref.slice(8)]) return fail();
		return compile(definitions[s.$ref.slice(8)]);
	}
	if ("const" in s) return unknown().refine((v) => v === s.const);
	if (s.enum) return unknown().refine((v) => s.enum.includes(v));
	if (s.oneOf) {
		const alternatives = s.oneOf.map(compile);
		return unknown().refine((v) => alternatives.filter((schema) => schema.safeParse(v).success).length === 1);
	}
	if (s.type === "object") {
		const shape = Object.fromEntries(Object.entries(s.properties ?? {}).map(([key, value]) => [key, (s.required ?? []).includes(key) ? compile(value) : compile(value).optional()]));
		const object$1 = s.additionalProperties === false ? object(shape).strict() : object(shape).catchall(typeof s.additionalProperties === "object" ? compile(s.additionalProperties) : unknown());
		const keys = s.propertyNames ? compile(s.propertyNames) : null;
		return object$1.refine((v) => Object.keys(v).length >= (s.minProperties ?? 0) && Object.keys(v).length <= (s.maxProperties ?? Infinity) && (!keys || Object.keys(v).every((key) => keys.safeParse(key).success)));
	}
	if (s.type === "array") return array(compile(s.items)).min(s.minItems ?? 0).max(s.maxItems ?? 1e5);
	if (s.type === "string") return string().refine((v) => [...v].length >= (s.minLength ?? 0) && [...v].length <= (s.maxLength ?? Infinity) && [...v].every((c) => c.codePointAt(0) < 55296 || c.codePointAt(0) > 57343) && (!s.pattern || new RegExp(s.pattern).exec(v)?.[0] === v));
	if (s.type === "boolean") return boolean();
	if (s.type === "integer") return number().int().min(s.minimum ?? -Number.MAX_SAFE_INTEGER).max(s.maximum ?? Number.MAX_SAFE_INTEGER);
	if (s.type === "number") return number().finite().min(s.minimum ?? -Number.MAX_SAFE_INTEGER).max(s.maximum ?? Number.MAX_SAFE_INTEGER);
	return fail();
}
var compiled = /* @__PURE__ */ new Map();
var v2Registry = registry_default;
Object.keys(definitions);
function semantic(value) {
	if (Array.isArray(value)) return value.every(semantic);
	if (!value || typeof value !== "object") return true;
	const v = value;
	if (v.projectionVersion === 1 && v.projectionPolicy === "selected-facts-v1" && v.derived) {
		const derived = v.derived;
		const expected = v.implementation;
		const actual = derived.implementation;
		if (derived.projectId !== v.projectId || derived.inputSnapshotId !== v.inputSnapshotId || Object.keys(expected).some((key) => expected[key] !== actual[key])) return false;
	}
	if ("code" in v && "messageKey" in v && utf8(v) > errors_default.maxEncodedBytes) return false;
	if (typeof v.completed === "number" && typeof v.total === "number" && v.completed > v.total) return false;
	if ("staleReason" in v) {
		const reasons = v.staleReason;
		const vector = v.dependencyVector;
		const sets = v.definitionSetDigests;
		if (!Object.hasOwn(vector, "facts:asserted") || new Set(reasons.map((r) => r.dependency)).size !== reasons.length) return false;
		if (reasons.some((r) => Object.hasOwn(vector, r.dependency) ? vector[r.dependency] !== r.before : r.before !== 0 || r.after < 1 || !Object.hasOwn(sets, r.dependency.split(":")[0]))) return false;
		if (v.state === "stale" !== reasons.length > 0 || reasons.some((r) => r.before === r.after)) return false;
		if (v.state === "current" && (v.payloadStatus !== "available" || v.historicalSelectionRequired !== false)) return false;
		if (v.state === "historical" && v.historicalSelectionRequired !== true) return false;
		if (v.kind === "receipt" && v.state !== "historical") return false;
	}
	if ("createdAtMs" in v && "updatedAtMs" in v && Number(v.updatedAtMs) < Number(v.createdAtMs)) return false;
	if (typeof v.finishedAtMs === "number" && v.finishedAtMs < Number(v.createdAtMs)) return false;
	if (typeof v.finishedAtMs === "number" && v.finishedAtMs !== v.updatedAtMs) return false;
	if ("supportedVersions" in v && new Set(v.supportedVersions).size !== v.supportedVersions.length) return false;
	if ("capabilities" in v && new Set(v.capabilities).size !== v.capabilities.length) return false;
	if ("disposition" in v) {
		const terminal = [
			"succeeded",
			"failed",
			"cancelled"
		].includes(String(v.state));
		if (v.disposition === "alreadyTerminal" !== terminal) return false;
		if (v.disposition === "alreadyRequested" && v.state !== "cancelling") return false;
	}
	if (v.event === "job.state") {
		const data = v.data;
		if (data.projectId !== v.projectId || data.jobId !== v.jobId) return false;
	}
	if (v.kind === "response" && v.method === "hello" && v.ok) {
		const r = v.result;
		if (v.engineSessionId !== r.engineSessionId) return false;
	}
	if (v.method === "job.list" && v.kind === "request") {
		const p = v.params;
		if (p.cursor === null !== (p.listSnapshotId === null)) return false;
	}
	if (v.method === "job.create" && v.kind === "request") {
		const p = v.params;
		const c = registry_default.capabilities[p.capability];
		const i = p.input;
		if (!c.dataScopes.includes(String(i.scope))) return false;
		if (c.requiresConfirmation && (p.confirmationRef === null || i.preparedPlanRef === null)) return false;
		if (!c.requiresConfirmation && (p.confirmationRef !== null || i.preparedPlanRef !== null)) return false;
	}
	if ("capability" in v && "commitProgress" in v) {
		const c = registry_default.capabilities[v.capability];
		if (!c.dataScopes.includes(String(v.scope))) return false;
		if (!Object.hasOwn(v.dependencyVector, "facts:asserted")) return false;
		const input = v.input;
		if ([
			"inputSnapshotId",
			"scope",
			"parametersHash"
		].some((k) => v[k] !== input[k])) return false;
		if (c.requiresConfirmation ? v.confirmationRef === null || input.preparedPlanRef === null : v.confirmationRef !== null || input.preparedPlanRef !== null) return false;
		const commit = v.commitProgress;
		const mode = commit.mode;
		if ((c.cancelBoundary === "whole-transaction" ? "atomic" : c.cancelBoundary === "uncommitted-round" ? "rounds" : "none") !== mode) return false;
		if (mode === "atomic" && commit.operationId !== v.operationId) return false;
		if (v.state === "queued" && (mode === "atomic" && commit.marker !== null || mode === "rounds" && commit.committedProgress !== null)) return false;
		if (v.state === "succeeded" && (mode === "atomic" && commit.marker === null || mode === "rounds" && commit.committedProgress === null)) return false;
		if (v.resultRef && v.resultRef.inputSnapshotId !== v.inputSnapshotId) return false;
	}
	if ("rows" in v && "binding" in v) {
		const rows = v.rows;
		if (utf8(v) > 131072 || new Set(rows.map((r) => r.rowId)).size !== rows.length || rows.some((r, i) => i > 0 && (r.ordinal < rows[i - 1].ordinal || r.ordinal === rows[i - 1].ordinal && r.rowId <= rows[i - 1].rowId))) return false;
	}
	if ("jobs" in v && "binding" in v) {
		const jobs = v.jobs;
		const binding = v.binding;
		if (new Set(jobs.map((j) => j.jobId)).size !== jobs.length || jobs.some((j, i) => j.projectId !== binding.projectId || binding.filter === "active" && [
			"succeeded",
			"failed",
			"cancelled"
		].includes(j.state) || binding.filter === "terminal" && ![
			"succeeded",
			"failed",
			"cancelled"
		].includes(j.state) || i > 0 && (j.createdAtMs < jobs[i - 1].createdAtMs || j.createdAtMs === jobs[i - 1].createdAtMs && j.jobId <= jobs[i - 1].jobId))) return false;
	}
	return Object.values(v).every(semantic);
}
function validateV2(name, value) {
	if (!Object.hasOwn(definitions, name)) return false;
	if (!compiled.has(name)) compiled.set(name, compile(definitions[name]));
	if (!compiled.get(name).safeParse(value).success || !semantic(value) || utf8(value) > 262144) return false;
	if (!changeSetSemantics(name, value)) return false;
	if (name === "params_job.create" || name === "params_job.list") return semantic({
		kind: "request",
		method: name.slice(7),
		params: value
	});
	return true;
}
function changeSetSemantics(name, value) {
	const v = value;
	if ([
		"request3",
		"response3",
		"envelope3"
	].includes(name)) {
		if (v.kind === "response" && v.ok && String(v.method).startsWith("changeset.")) return changeSetSemantics(`result_${v.method}`, v.result);
		return true;
	}
	if (name === "changeSetManifest") {
		const parts = v.segments;
		let offset = 0;
		if (parts.length !== v.segmentCount) return false;
		for (const [ordinal, part] of parts.entries()) {
			if (part.ordinal !== ordinal || part.byteOffset !== offset) return false;
			offset += part.rawByteLength;
		}
		return offset === v.totalBytes;
	}
	if (name === "result_changeset.preview") {
		const manifest = v.manifest;
		return changeSetSemantics("changeSetManifest", manifest) && (v.status === "conflict" ? manifest.documentKind === "undo-impact" : manifest.documentKind === "diff" && (v.intent === "change" ? v.targetOperationId === null : v.targetOperationId !== null));
	}
	if (name === "changeSetSegment") {
		const encoded = v.dataBase64;
		const padding = encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0;
		return encoded.length / 4 * 3 - padding === v.rawByteLength;
	}
	if (name === "changeSetPage" || name === "result_changeset.diff.page") {
		const parts = v.segments;
		return parts.every((part, index) => changeSetSemantics("changeSetSegment", part) && (index === 0 || part.ordinal === parts[index - 1].ordinal + 1 && part.byteOffset === parts[index - 1].byteOffset + parts[index - 1].rawByteLength));
	}
	return true;
}
/** A value check only: provenance, pre-hello, profile and once belong to the supervisor. */
function validateStartupError(value) {
	try {
		return validateV2("error_startup", value);
	} catch {
		return false;
	}
}
/** payloadByteLength must come from the transport's original bytes, never re-encoding. */
function validateStartupFailure(value, payloadByteLength, expectedRegistryHash) {
	return Number.isSafeInteger(payloadByteLength) && payloadByteLength > 0 && payloadByteLength <= errors_default.startup.maxPayloadBytes && typeof expectedRegistryHash === "string" && /^[0-9a-f]{64}$/.test(expectedRegistryHash) && validateV2("startupFailure", value) && value.registryHash === expectedRegistryHash;
}
/** Strict explicit profile validation. It never selects runtime or attests readiness. */
function validateBusiness3(name, value) {
	const profiles = {
		request: "request3",
		response: "response3",
		notification: "notification3",
		envelope: "envelope3",
		error: "error3",
		bootstrapError: "error_bootstrap3",
		project: "project3",
		"result_project.get": "result_project.get3",
		result_hello: "result_hello3"
	};
	try {
		return validateV2(profiles[name] ?? name, value);
	} catch {
		return false;
	}
}
/** Correlate a pending request; this does not attest Store/Job readiness. */
function matchesBusiness3Response(request, response, expectedRegistryHash) {
	if (!validateV2("hash", expectedRegistryHash) || !validateBusiness3("request", request) || !validateBusiness3("response", response)) return false;
	const q = request;
	const r = response;
	if (q.id !== r.id || q.method !== r.method) return false;
	if (String(q.method).startsWith("changeset.")) {
		if (q.engineSessionId !== r.engineSessionId) return false;
		if (!r.ok) return true;
		const p = q.params;
		const data = r.result;
		if (p.projectId !== data.projectId) return false;
		if (q.method === "changeset.preview") return p.baseRevision === data.baseRevision && (p.intent === "change" ? data.status === "ready" && data.intent === "change" && data.targetOperationId === null : data.targetOperationId === p.targetOperationId && (data.status === "conflict" || data.intent === "undo"));
		if (p.previewHash !== data.previewHash) return false;
		if (q.method === "changeset.diff.page") return p.documentKind === data.documentKind && data.segments.length <= p.pageSize;
		return q.method === "changeset.confirm";
	}
	if (q.method === "hello" && r.ok) {
		const offered = q.params.supportedVersions;
		const result = r.result;
		if (!offered.includes(3) || result.registryHash !== expectedRegistryHash || !result.capabilities.every((c) => registry_default.foundationProfiles.business3.methods.includes(c))) return false;
		return true;
	}
	const projectedRequest = structuredClone(q);
	const projectedResponse = structuredClone(r);
	projectedRequest.protocolVersion = projectedResponse.protocolVersion = 2;
	if (q.method === "hello") {
		projectedRequest.params.supportedVersions = [2];
		if (r.ok) projectedResponse.result.selectedVersion = 2;
	}
	if (q.method === "project.get" && r.ok) projectedResponse.result.formatVersion = 2;
	if (!r.ok) {
		const error = projectedResponse.error;
		if (error.code === "VERSION_INCOMPATIBLE") error.params = { supportedVersions: [2] };
	}
	return matchesResponse(projectedRequest, projectedResponse);
}
function acceptsBusiness3JobEvent(value, binding) {
	if (!validateBusiness3("notification", value)) return false;
	const projected = structuredClone(value);
	projected.protocolVersion = 2;
	return acceptsJobEvent(projected, binding);
}
function acceptsJobEvent(value, binding) {
	if (!binding || typeof binding !== "object" || Object.keys(binding).sort().join(",") !== "engineSessionId,jobId,lastSeq,projectId,state,stateVersion,subscriptionId" || ![
		"engineSessionId",
		"projectId",
		"jobId",
		"subscriptionId"
	].every((key) => validateV2("id", binding[key])) || !Number.isSafeInteger(binding.lastSeq) || binding.lastSeq < 0 || !Number.isSafeInteger(binding.stateVersion) || binding.stateVersion < 1 || ![
		"queued",
		"running",
		"cancelling",
		"succeeded",
		"failed",
		"cancelled"
	].includes(binding.state)) return false;
	if (!validateV2("notification", value)) return false;
	const v = value;
	if (v.event === "session.status") return false;
	const data = v.data;
	if (!([
		"engineSessionId",
		"projectId",
		"jobId",
		"subscriptionId"
	].every((key) => v[key] === binding[key]) && Number(v.seq) === binding.lastSeq + 1 && ![
		"succeeded",
		"failed",
		"cancelled"
	].includes(binding.state))) return false;
	if (v.event === "job.progress") return Number(data.stateVersion) === binding.stateVersion;
	if (Number(data.stateVersion) !== binding.stateVersion + 1) return false;
	return data.state === binding.state || permitsTransition(binding.state, String(data.state), binding.stateVersion, Number(data.stateVersion), false);
}
function matchesResponse(request, response) {
	if (!validateV2("request", request) || !validateV2("response", response)) return false;
	const q = request, r = response;
	if (q.id !== r.id || q.method !== r.method) return false;
	if (q.method !== "hello" && q.engineSessionId !== r.engineSessionId) return false;
	if (!r.ok) return true;
	const p = q.params, data = r.result;
	if (q.method === "hello") return p.supportedVersions.includes(2) && data.capabilities.every((c) => registry_default.v2Runtime.includes(c));
	if (!data) return true;
	if (p.projectId && data.projectId && p.projectId !== data.projectId) return false;
	if (p.jobId && data.jobId && p.jobId !== data.jobId) return false;
	if (p.resultId && data.resultId && p.resultId !== data.resultId) return false;
	if (q.method === "operation.get" && p.operationId !== data.operationId) return false;
	if (q.method === "job.unsubscribe" && p.subscriptionId !== data.subscriptionId) return false;
	if (q.method === "job.create") {
		const input = p.input;
		const actual = data.input;
		if (p.confirmationRef !== data.confirmationRef || Object.keys(input).some((k) => Array.isArray(input[k]) ? JSON.stringify(input[k]) !== JSON.stringify(actual[k]) : input[k] !== actual[k])) return false;
		if (p.operationId !== data.operationId || p.capability !== data.capability || [
			"inputSnapshotId",
			"scope",
			"parametersHash"
		].some((k) => input[k] !== data[k])) return false;
	}
	if (q.method === "result.current") {
		if (data.state !== "current" || [
			"kind",
			"definitionId",
			"scope",
			"parametersHash"
		].some((k) => p[k] !== data[k])) return false;
		const expected = p.implementation, actual = data.implementation;
		if (Object.keys(expected).some((k) => expected[k] !== actual[k])) return false;
	}
	if (q.method === "session.ping" && p.nonce !== data.nonce) return false;
	if (q.method === "result.page") return data.rows.length <= Number(p.pageSize) && Object.keys(p.binding).every((key) => p.binding[key] === data.binding[key]);
	if (q.method === "job.list") {
		const b = data.binding;
		if (data.jobs.length > Number(p.pageSize)) return false;
		if (b.projectId !== p.projectId || b.filter !== p.filter || p.listSnapshotId && p.listSnapshotId !== b.listSnapshotId) return false;
		if (data.jobs.some((job) => job.projectId !== p.projectId)) return false;
	}
	return true;
}
var healthSchema = object({
	protocolVersion: literal(2),
	engineVersion: string().min(1).max(128),
	status: literal("ok"),
	capabilities: array(literal("health")).max(1)
}).strict();
union([healthSchema, healthSchema.extend({ protocolVersion: literal(3) }).strict()]);
var internalError = {
	code: "INTERNAL_ERROR",
	messageKey: "engine.internal",
	params: {},
	retryable: false
};
function safeError(value) {
	return validateV2("error", value) ? structuredClone(value) : structuredClone(internalError);
}
function safeBusiness3Error(value) {
	return validateBusiness3("error", value) ? structuredClone(value) : structuredClone(internalError);
}
function safeStartupError(value) {
	return validateStartupError(value) ? structuredClone(value) : structuredClone(internalError);
}
function safeDisplayError(value) {
	return validateV2("error", value) || validateBusiness3("error", value) || validateStartupError(value) ? structuredClone(value) : structuredClone(internalError);
}
var generationSchema = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var jobViewSchema = custom((value) => validateV2("job", value));
var taskViewSchema = object({
	generation: generationSchema,
	project: custom((value) => validateV2("result_project.get", value) || validateBusiness3("result_project.get", value)).nullable(),
	jobs: array(jobViewSchema).max(16)
}).strict().refine((view) => new Set(view.jobs.map((job) => job.jobId)).size === view.jobs.length && view.jobs.every((job) => job.projectId === view.project?.projectId));
union([
	object({
		kind: literal("job"),
		generation: generationSchema,
		job: jobViewSchema,
		progress: custom((value) => validateV2("progress", value)).optional()
	}).strict(),
	object({
		kind: literal("restored"),
		generation: generationSchema,
		view: taskViewSchema
	}).strict().refine((update) => update.view.generation === update.generation),
	object({
		kind: literal("connection"),
		generation: generationSchema,
		projectId: string().uuid(),
		state: _enum(["reconnecting", "offline"]),
		attempt: number().int().min(0).max(3),
		error: custom((value) => validateV2("error", value) || validateBusiness3("error", value) || validateStartupError(value))
	}).strict().refine((update) => update.state !== "offline" || update.attempt === 3)
]);
//#endregion
//#region src/main/jsonl.ts
/** Strict raw JSON decoding, before any decoded-value schema validation. */
function parseStrictJson(text, maxDepth = 32) {
	let at = 0;
	const bad = () => {
		throw new Error("INVALID_JSON_FRAME");
	};
	const space = () => {
		while (/[\x20\t\r\n]/.test(text[at] ?? "\0")) at++;
	};
	const string = () => {
		const start = at++;
		while (at < text.length) {
			const char = text[at++];
			if (char === "\\") {
				at++;
				continue;
			}
			if (char === "\"") {
				const value = JSON.parse(text.slice(start, at));
				if (typeof value !== "string" || [...value].some((c) => {
					const cp = c.codePointAt(0);
					return cp >= 55296 && cp <= 57343;
				})) return bad();
				return value;
			}
		}
		return bad();
	};
	const value = (depth) => {
		space();
		const char = text[at];
		if (char === "\"") return string();
		if (char === "{" || char === "[") {
			if (depth >= maxDepth) return bad();
			at++;
			space();
			const end = char === "{" ? "}" : "]";
			const keys = /* @__PURE__ */ new Set();
			const object = Object.create(null);
			const array = [];
			if (text[at] === end) {
				at++;
				return char === "{" ? object : array;
			}
			while (at < text.length) {
				if (char === "{") {
					if (text[at] !== "\"") return bad();
					const key = string();
					if (keys.has(key)) return bad();
					keys.add(key);
					space();
					if (text[at++] !== ":") return bad();
					object[key] = value(depth + 1);
				} else array.push(value(depth + 1));
				space();
				const separator = text[at++];
				if (separator === end) return char === "{" ? object : array;
				if (separator !== ",") return bad();
				space();
			}
			return bad();
		}
		const match = /^(?:true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/.exec(text.slice(at));
		if (!match) return bad();
		at += match[0].length;
		const result = JSON.parse(match[0]);
		if (typeof result === "number" && (!Number.isFinite(result) || Math.abs(result) > Number.MAX_SAFE_INTEGER)) return bad();
		return result;
	};
	const result = value(0);
	space();
	if (at !== text.length) return bad();
	return result;
}
/** Each LF delimits a frame. Bytes are bounded before copying, including partial UTF-8. */
var JsonlReader = class {
	frame;
	failure;
	maxBytes;
	buffer;
	size = 0;
	ended = false;
	constructor(frame, failure, maxBytes = 262144) {
		this.frame = frame;
		this.failure = failure;
		this.maxBytes = maxBytes;
		if (!Number.isInteger(maxBytes) || maxBytes < 1 || maxBytes > 262144) throw new Error("INVALID_FRAME_LIMIT");
		this.buffer = Buffer.allocUnsafe(maxBytes);
	}
	get bufferedBytes() {
		return this.size;
	}
	get terminal() {
		return this.ended;
	}
	stop() {
		this.ended = true;
		this.buffer = void 0;
		this.size = 0;
	}
	/** Negotiation may lower the frame budget; it cannot enlarge allocated storage. */
	restrictLimit(limit) {
		if (this.ended) return;
		if (!Number.isSafeInteger(limit) || limit < 1 || limit > this.maxBytes) throw new Error("INVALID_FRAME_LIMIT");
		this.maxBytes = limit;
		if (this.size > limit) this.fail("frame");
	}
	fail(reason) {
		this.stop();
		this.failure(reason);
	}
	push(chunk) {
		if (this.ended) return;
		const input = Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength);
		let start = 0;
		while (start < input.length && !this.ended) {
			const newline = input.indexOf(10, start);
			const end = newline < 0 ? input.length : newline;
			const length = end - start;
			if (this.size + length > this.maxBytes) {
				this.fail("frame");
				return;
			}
			if (length) {
				input.copy(this.buffer, this.size, start, end);
				this.size += length;
			}
			if (newline < 0) return;
			const payloadByteLength = this.size;
			let bytes = this.buffer.subarray(0, this.size);
			this.size = 0;
			if (bytes[bytes.length - 1] === 13) bytes = bytes.subarray(0, -1);
			try {
				const text = new TextDecoder("utf-8", {
					fatal: true,
					ignoreBOM: true
				}).decode(bytes);
				this.frame(parseStrictJson(text), Object.freeze({ payloadByteLength }));
			} catch {
				this.fail("json");
				return;
			}
			start = newline + 1;
		}
	}
	end() {
		if (this.ended) return;
		if (this.size) this.fail("json");
		else this.stop();
	}
};
//#endregion
//#region src/main/engine.ts
function getEngineCommand(location) {
	const executable = process.platform === "win32" ? "ontolearn-engine.exe" : "ontolearn-engine";
	if (location.packaged) return {
		command: (0, node_path.join)(location.resourcesPath, "engine", executable),
		args: []
	};
	const root = (0, node_path.resolve)(location.appPath, "../..");
	return {
		command: process.platform === "win32" ? (0, node_path.join)(root, ".venv", "Scripts", "python.exe") : (0, node_path.join)(root, ".venv", "bin", "python"),
		args: [
			"-I",
			"-m",
			"ontolearn_engine"
		]
	};
}
var EngineError = class extends Error {
	error;
	constructor(error) {
		super(error.code);
		this.error = error;
		this.name = "EngineError";
	}
};
function exited() {
	return new EngineError({
		code: "ENGINE_EXITED",
		messageKey: "engine.exited",
		params: {},
		retryable: true
	});
}
function invalid$1() {
	return new EngineError({
		code: "INVALID_REQUEST",
		messageKey: "protocol.invalidRequest",
		params: { field: "envelope" },
		retryable: false
	});
}
function timeout(phase) {
	return new EngineError({
		code: "TIMEOUT",
		messageKey: "job.timeout",
		params: { phase },
		retryable: true
	});
}
/** No inherited credentials, proxies, executable search paths or loader injection.
* Engine and worker executables are absolute paths. Only OS directories/locale
* are inherited; project authority is issued separately by the main process.
*/
function getEngineEnvironment(source, options = {}, platform = process.platform) {
	const common = [
		"HOME",
		"TMPDIR",
		"TMP",
		"TEMP",
		"LANG",
		"LC_ALL",
		"LC_CTYPE",
		"TZ"
	];
	const names = platform === "win32" ? [
		...common,
		"SystemRoot",
		"WINDIR",
		"USERPROFILE",
		"LOCALAPPDATA"
	] : common;
	const canonical = new Map(names.map((name) => [platform === "win32" ? name.toUpperCase() : name, name]));
	const env = {};
	for (const [key, value] of Object.entries(source)) {
		const accepted = canonical.get(platform === "win32" ? key.toUpperCase() : key);
		if (accepted && typeof value === "string") env[accepted] = value;
	}
	if (options.dataPath) env.ONTOLEARN_DB_PATH = options.dataPath;
	env.ONTOLEARN_ALLOWED_PROJECTS = JSON.stringify(options.allowedProjects ?? []);
	if (options.testMode === true) env.ONTOLEARN_TEST_MODE = "1";
	return env;
}
function bounded(value, fallback, maximum) {
	if (value === void 0) return fallback;
	if (!Number.isSafeInteger(value) || value < 1 || value > maximum) throw invalid$1();
	return value;
}
/** Owns transport only. Durable job outcomes always come from SQLite queries. */
var EngineSupervisor = class {
	/** Runtime brand check: legacy transport adapters never acquire startup authority. */
	static owns(value) {
		return !!value && typeof value === "object" && #origins in value;
	}
	#origins = /* @__PURE__ */ new WeakMap();
	#operations = /* @__PURE__ */ new WeakMap();
	#connections = /* @__PURE__ */ new WeakMap();
	#profile;
	get profile() {
		return this.#profile;
	}
	#location;
	#options;
	#session;
	#starting;
	#generation = 0;
	#stopped = false;
	#starts = [];
	#retryAt = 0;
	#failures = 0;
	#listeners = /* @__PURE__ */ new Set();
	#connectionListeners = /* @__PURE__ */ new Set();
	#startupMs;
	#handshakeMs;
	#requestMs;
	#heartbeatMs;
	#maxPending;
	constructor(location, options = {}) {
		if (options.profile !== void 0 && !["legacy2", "business3"].includes(options.profile)) throw invalid$1();
		this.#profile = options.profile ?? "legacy2";
		this.#location = { ...location };
		this.#options = {
			...options,
			allowedProjects: options.allowedProjects ? [...options.allowedProjects] : void 0,
			command: options.command ? {
				command: options.command.command,
				args: [...options.command.args]
			} : void 0
		};
		this.#startupMs = bounded(options.startupMs, 1e4, 6e4);
		this.#handshakeMs = bounded(options.handshakeMs, 5e3, 6e4);
		this.#requestMs = bounded(options.requestMs, 5e3, 6e4);
		this.#heartbeatMs = bounded(options.heartbeatMs, 1e4, 6e4);
		this.#maxPending = bounded(options.maxPending, 128, 128);
	}
	get engineSessionId() {
		return this.#session?.hello?.engineSessionId;
	}
	onNotification(listener) {
		this.#listeners.add(listener);
		return () => this.#listeners.delete(listener);
	}
	/** Events only: callers subscribe before starting a connection. No automatic replay. */
	onConnectionState(listener) {
		this.#connectionListeners.add(listener);
		return () => this.#connectionListeners.delete(listener);
	}
	#connectionState(session, state) {
		for (const listener of [...this.#connectionListeners]) try {
			const delivered = structuredClone(state);
			this.#connections.set(delivered, {
				session,
				state: structuredClone(state)
			});
			listener(delivered);
		} catch {
			this.#diagnostic("listenerFailed");
		}
	}
	/** Projection authenticates the original rejection and the actual public operation promise. */
	projectFailure(cause, originatingPromise) {
		const issued = this.#operations.get(originatingPromise);
		if (issued && issued.cause === cause && this.#origins.get(issued.cause) === issued.origin) {
			const origin = issued.origin;
			return origin.provenance === "startup3" ? safeStartupError(origin.value) : origin.provenance === "bootstrap2" ? safeError(origin.value) : origin.provenance === "bootstrap3" || origin.profile === "business3" ? safeBusiness3Error(origin.value) : safeError(origin.value);
		}
		try {
			return safeError(cause?.error);
		} catch {
			return safeError(null);
		}
	}
	projectConnectionFailure(event) {
		if (!event || typeof event !== "object") return void 0;
		const issued = this.#connections.get(event);
		if (!issued || issued.state.state !== "disconnected") return void 0;
		return structuredClone(issued.state);
	}
	#sign(session, error, provenance = "local") {
		if (this.#origins.get(error)) return error;
		const value = provenance === "startup3" ? safeStartupError(error.error) : provenance === "bootstrap2" ? safeError(error.error) : provenance === "bootstrap3" || session.profile === "business3" ? safeBusiness3Error(error.error) : safeError(error.error);
		this.#origins.set(error, Object.freeze({
			session,
			profile: session.profile,
			generation: session.generation,
			preHello: !session.hello,
			startupPromise: session.startupPromise,
			provenance,
			value: structuredClone(value)
		}));
		return error;
	}
	#operation(work) {
		const promise = Promise.resolve().then(work).catch((cause) => {
			if (cause && typeof cause === "object") {
				const origin = this.#origins.get(cause);
				if (origin) this.#operations.set(promise, {
					cause,
					origin
				});
			}
			throw cause;
		});
		return promise;
	}
	#validate(session, name, value) {
		return session.profile === "business3" ? validateBusiness3(name, value) : validateV2(name, value);
	}
	#diagnostic(event) {
		try {
			this.#options.onDiagnostic?.(event);
		} catch {}
	}
	#current(session) {
		return !session.terminal && this.#session === session && session.generation === this.#generation;
	}
	#finish(session, error) {
		if (session.terminal) return;
		error = session.startupCause ?? this.#sign(session, error);
		if (!session.hello) session.startupCause = error;
		session.terminal = true;
		session.reader.stop();
		session.rejectStart(error);
		clearTimeout(session.startupTimer);
		clearTimeout(session.heartbeat);
		for (const pending of session.pending.values()) {
			clearTimeout(pending.timer);
			pending.reject(error);
		}
		session.pending.clear();
		if (this.#session === session) {
			this.#session = void 0;
			this.#failures++;
			this.#retryAt = Date.now() + Math.min(2e3, 100 * 2 ** Math.min(this.#failures - 1, 5));
		}
		session.child.kill();
		const killTimer = setTimeout(() => {
			if (session.child.exitCode === null && session.child.signalCode === null) session.child.kill("SIGKILL");
		}, 1e3);
		killTimer.unref();
		session.child.once("close", () => clearTimeout(killTimer));
		if (!this.#stopped && session.hello) this.#connectionState(session, {
			state: "disconnected",
			generation: session.generation,
			engineSessionId: session.hello.engineSessionId,
			error: session.profile === "business3" ? safeBusiness3Error(error.error) : safeError(error.error)
		});
	}
	stop() {
		this.#stopped = true;
		this.#generation++;
		if (this.#session) this.#finish(this.#session, exited());
		this.#listeners.clear();
		this.#connectionListeners.clear();
	}
	async #ensure() {
		if (this.#stopped) throw exited();
		if (this.#session?.hello && this.#current(this.#session)) return this.#session;
		if (this.#starting) return this.#starting;
		this.#starting = this.#start().finally(() => {
			this.#starting = void 0;
		});
		return this.#starting;
	}
	async #start() {
		const delay = this.#retryAt - Date.now();
		if (delay > 0) await new Promise((resolveDelay) => setTimeout(resolveDelay, delay));
		if (this.#stopped) throw exited();
		const now = Date.now();
		this.#starts = this.#starts.filter((time) => now - time < 6e4);
		if (this.#starts.length >= 5) throw exited();
		this.#starts.push(now);
		let registryHash;
		try {
			const path = this.#options.registryPath ?? (this.#location.packaged ? (0, node_path.join)(this.#location.resourcesPath, "contracts", "v2", "registry.json") : (0, node_path.resolve)(this.#location.appPath, "../../packages/contracts/v2/registry.json"));
			const bytes = (0, node_fs.readFileSync)(path);
			if (bytes.length > 262144 || JSON.stringify(parseStrictJson(new TextDecoder("utf-8", {
				fatal: true,
				ignoreBOM: true
			}).decode(bytes))) !== JSON.stringify(v2Registry)) throw invalid$1();
			registryHash = (0, node_crypto.createHash)("sha256").update(bytes).digest("hex");
		} catch {
			throw exited();
		}
		const selected = this.#options.command ?? getEngineCommand(this.#location);
		const command = selected.command;
		const args = [...selected.args];
		if (this.profile === "business3") {
			const database = this.#options.dataPath;
			if (database && !(0, node_path.isAbsolute)(database)) throw invalid$1();
			args.push("--t01-internal-profile=business3");
			if (database) args.push(`--t01-internal-backup=${(0, node_path.join)((0, node_path.dirname)(database), `.t01-backup-${(0, node_crypto.randomUUID)()}.sqlite`)}`);
		}
		const env = getEngineEnvironment(process.env, this.#options);
		let child;
		try {
			child = (0, node_child_process.spawn)(command, args, {
				shell: false,
				windowsHide: true,
				stdio: [
					"pipe",
					"pipe",
					"pipe"
				],
				env
			});
		} catch {
			throw exited();
		}
		let resolveStart;
		let rejectStart;
		const startupPromise = new Promise((resolve, reject) => {
			resolveStart = resolve;
			rejectStart = reject;
		});
		const session = {
			child,
			profile: this.profile,
			startupPromise,
			resolveStart,
			rejectStart,
			generation: ++this.#generation,
			pending: /* @__PURE__ */ new Map(),
			terminal: false,
			anomalies: 0,
			stderrBytes: 0,
			expectedRegistryHash: registryHash,
			reader: new JsonlReader((value, metadata) => this.#receive(session, value, metadata.payloadByteLength), (reason) => {
				this.#diagnostic("invalidFrame");
				this.#finish(session, reason === "frame" ? new EngineError({
					code: "RESOURCE_LIMIT",
					messageKey: "resource.limitExceeded",
					params: { resource: "frame" },
					retryable: false
				}) : invalid$1());
			})
		};
		this.#session = session;
		child.stdout.on("data", (chunk) => {
			if (this.#current(session)) session.reader.push(chunk);
		});
		child.stdout.once("end", () => {
			session.reader.end();
			this.#finish(session, exited());
		});
		child.stderr.on("data", (chunk) => {
			if (!this.#current(session) || session.stderrBytes >= 16384) return;
			if (session.stderrBytes === 0) this.#diagnostic("stderrDiscarded");
			session.stderrBytes = Math.min(16384, session.stderrBytes + chunk.byteLength);
		});
		child.stdin.on("error", () => this.#finish(session, exited()));
		const fail = (error) => this.#finish(session, error);
		session.startupTimer = setTimeout(() => fail(timeout("startup")), this.#startupMs);
		child.once("error", () => fail(exited()));
		child.once("close", () => fail(exited()));
		child.once("spawn", () => {
			if (!this.#current(session)) {
				fail(exited());
				return;
			}
			this.#send(session, "hello", {
				supportedVersions: [session.profile === "business3" ? 3 : 2],
				clientId: (0, node_crypto.randomUUID)()
			}, this.#handshakeMs, "handshake").then((value) => {
				const hello = value;
				if (!this.#current(session) || hello.registryHash !== registryHash) {
					fail(invalid$1());
					return;
				}
				clearTimeout(session.startupTimer);
				this.#failures = 0;
				this.#scheduleHeartbeat(session);
				session.resolveStart(session);
			}, fail);
		});
		return startupPromise;
	}
	#scheduleHeartbeat(session) {
		if (!this.#current(session)) return;
		const interval = Math.min(this.#heartbeatMs, session.hello.limits.heartbeatMs);
		session.heartbeat = setTimeout(() => {
			if (!this.#current(session)) return;
			this.#send(session, "session.ping", { nonce: (0, node_crypto.randomUUID)() }, interval, "heartbeat", true).then(() => this.#scheduleHeartbeat(session), () => this.#finish(session, timeout("heartbeat")));
		}, interval);
		session.heartbeat.unref();
	}
	#receive(session, value, payloadByteLength) {
		if (!this.#current(session)) return;
		if (value && typeof value === "object" && value.kind === "startupFailure") {
			if (session.profile === "business3" && !session.hello && !session.startupCause && validateStartupFailure(value, payloadByteLength, session.expectedRegistryHash)) {
				const error = this.#sign(session, new EngineError(value.error), "startup3");
				session.startupCause = error;
				this.#finish(session, error);
			} else this.#finish(session, invalid$1());
			return;
		}
		if (this.#validate(session, "notification", value)) {
			const event = value;
			if (!session.hello || event.engineSessionId !== session.hello.engineSessionId) {
				if (session.profile === "business3") this.#finish(session, invalid$1());
				return;
			}
			for (const listener of this.#listeners) try {
				listener(value);
			} catch {
				this.#diagnostic("listenerFailed");
			}
			return;
		}
		const response = value;
		const pending = response && session.pending.get(String(response.id));
		const incompatible3 = session.profile === "legacy2" && !session.hello && pending?.request.method === "hello" && response.ok === false && response.error?.code === "VERSION_INCOMPATIBLE" && matchesBusiness3Response(pending.request, value, session.expectedRegistryHash);
		if (!incompatible3 && !this.#validate(session, "response", value)) {
			this.#finish(session, invalid$1());
			return;
		}
		if (!pending || !(incompatible3 || (session.profile === "business3" ? matchesBusiness3Response(pending.request, value, session.expectedRegistryHash) : matchesResponse(pending.request, value)))) {
			this.#diagnostic("unmatchedResponse");
			if (session.profile === "business3" || ++session.anomalies >= 3) this.#finish(session, invalid$1());
			return;
		}
		if (response.ok && pending.request.method === "hello") {
			const hello = response.result;
			if (hello.registryHash !== session.expectedRegistryHash) {
				this.#finish(session, invalid$1());
				return;
			}
			session.reader.restrictLimit(hello.limits.maxFrameBytes);
			session.hello = hello;
			this.#connectionState(session, {
				state: "ready",
				generation: session.generation,
				engineSessionId: hello.engineSessionId
			});
		}
		clearTimeout(pending.timer);
		session.pending.delete(String(response.id));
		if (response.ok) pending.resolve(response.result);
		else {
			const error = this.#sign(session, new EngineError(response.error), incompatible3 ? "bootstrap3" : pending.request.method === "hello" && response.error.code === "VERSION_INCOMPATIBLE" && response.error.params.supportedVersions instanceof Array && response.error.params.supportedVersions[0] === 2 ? "bootstrap2" : session.profile === "business3" ? "business3" : "business2");
			pending.reject(error);
			if (pending.request.method === "hello") this.#finish(session, error);
		}
	}
	#send(session, method, params, duration, phase, reservedControl = false) {
		if (!this.#current(session)) return Promise.reject(exited());
		if (session.pending.size >= this.#maxPending + (reservedControl ? 1 : 0)) return Promise.reject(new EngineError({
			code: "QUEUE_FULL",
			messageKey: "job.queueFull",
			params: { retryAfterMs: 100 },
			retryable: true
		}));
		const request = {
			kind: "request",
			id: (0, node_crypto.randomUUID)(),
			protocolVersion: method === "hello" ? 2 : session.profile === "business3" ? 3 : 2,
			engineSessionId: method === "hello" ? null : session.hello?.engineSessionId,
			method,
			params
		};
		if (!this.#validate(session, "request", request)) return Promise.reject(this.#sign(session, invalid$1()));
		const encoded = Buffer.from(JSON.stringify(request) + "\n", "utf8");
		if (encoded.length - 1 > (session.hello?.limits.maxFrameBytes ?? 262144)) return Promise.reject(new EngineError({
			code: "RESOURCE_LIMIT",
			messageKey: "resource.limitExceeded",
			params: { resource: "frame" },
			retryable: false
		}));
		return new Promise((resolveRequest, rejectRequest) => {
			const timer = setTimeout(() => {
				session.pending.delete(request.id);
				rejectRequest(this.#sign(session, timeout(phase)));
			}, duration);
			session.pending.set(request.id, {
				request: parseStrictJson(encoded.subarray(0, -1).toString("utf8")),
				resolve: resolveRequest,
				reject: rejectRequest,
				timer
			});
			session.child.stdin.write(encoded, (error) => {
				if (error) this.#finish(session, exited());
			});
		});
	}
	request(method, params) {
		return this.#operation(async () => {
			if (method === "hello") throw new EngineError({
				code: "INVALID_STATE",
				messageKey: "protocol.invalidState",
				params: {},
				retryable: false
			});
			const session = await this.#ensure();
			return this.#send(session, method, params, Math.min(this.#requestMs, session.hello.limits.requestMs), "request");
		});
	}
	health() {
		return this.#operation(async () => {
			const session = await this.#ensure();
			const value = await this.#send(session, "health", {}, Math.min(this.#requestMs, session.hello.limits.requestMs), "request");
			if (!this.#current(session)) throw this.#sign(session, exited());
			const hello = session.hello;
			if (value.engineVersion !== hello.engineVersion) throw this.#sign(session, invalid$1());
			return {
				protocolVersion: hello.selectedVersion,
				...value,
				capabilities: hello.capabilities.filter((capability) => capability === "health")
			};
		});
	}
};
//#endregion
//#region src/main/task-service.ts
var id = string().uuid();
var denied = {
	code: "PERMISSION_DENIED",
	messageKey: "permission.denied",
	params: {},
	retryable: false
};
var invalid = {
	code: "INVALID_REQUEST",
	messageKey: "protocol.invalidRequest",
	params: { field: "params" },
	retryable: false
};
var TaskService = class {
	engine;
	#supervisor;
	#caught = /* @__PURE__ */ new WeakMap();
	#outcomes = /* @__PURE__ */ new WeakMap();
	validate(name, value) {
		return this.#supervisor?.profile === "business3" ? validateBusiness3(name, value) : validateV2(name, value);
	}
	projectId = null;
	generation = 0;
	projectRevision;
	projectRefresh = /* @__PURE__ */ new Map();
	projectTransition;
	watches = /* @__PURE__ */ new Map();
	remembered = /* @__PURE__ */ new Set();
	earlyBytes = 0;
	earlyEvents = /* @__PURE__ */ new Map();
	cancelledSubscriptions = /* @__PURE__ */ new Set();
	dirtyWatches = /* @__PURE__ */ new WeakSet();
	reconciliations = /* @__PURE__ */ new Map();
	pendingSubscriptions = /* @__PURE__ */ new Map();
	release;
	releaseConnection;
	recovery;
	connection = "ready";
	engineGeneration = -1;
	lastReadySession;
	disconnectedSession;
	disposed = false;
	sink;
	constructor(engine) {
		this.engine = engine;
		this.#supervisor = EngineSupervisor.owns(engine) ? engine : void 0;
		this.lastReadySession = engine.engineSessionId;
		this.release = engine.onNotification((value) => this.receive(value));
		this.releaseConnection = engine.onConnectionState((value) => this.connectionChanged(value));
	}
	selectProject(projectId, jobs = []) {
		id.parse(projectId);
		if (jobs.length > 16 || jobs.some((job) => !id.safeParse(job).success)) throw new Error("INVALID_REQUEST");
		this.detachView();
		this.projectId = projectId;
		this.projectRevision = void 0;
		this.remembered = new Set(jobs);
	}
	attachView(sink) {
		this.detachView();
		this.sink = sink;
	}
	cancelRecovery() {
		const recovery = this.recovery;
		if (recovery) {
			recovery.cancelled = true;
			recovery.wake?.();
		}
		this.recovery = void 0;
	}
	clearView(remoteUnsubscribe, cancelRecovery) {
		if (cancelRecovery) this.cancelRecovery();
		this.projectTransition = void 0;
		this.generation++;
		this.sink = void 0;
		for (const watch of this.watches.values()) if (remoteUnsubscribe && this.engine.engineSessionId === watch.binding.engineSessionId) this.engine.request("job.unsubscribe", {
			projectId: watch.binding.projectId,
			jobId: watch.binding.jobId,
			subscriptionId: watch.binding.subscriptionId
		}).catch(() => {});
		this.watches.clear();
		this.earlyEvents.clear();
		this.earlyBytes = 0;
	}
	detachView() {
		this.clearView(true, true);
	}
	fenceConnection(remoteUnsubscribe = false) {
		const sink = this.sink;
		this.clearView(remoteUnsubscribe, false);
		this.sink = sink;
		if (this.recovery) this.recovery.generation = this.generation;
	}
	dispose() {
		this.disposed = true;
		this.detachView();
		this.release();
		this.releaseConnection();
	}
	connectionChanged(event) {
		if (this.#supervisor && event.state === "disconnected") {
			const issued = this.#supervisor.projectConnectionFailure(event);
			if (!issued) return;
			event = issued;
		}
		if (this.disposed || !Number.isSafeInteger(event.generation) || event.generation < this.engineGeneration || !id.safeParse(event.engineSessionId).success) return;
		this.engineGeneration = event.generation;
		if (event.state === "ready") {
			const previous = this.lastReadySession;
			this.lastReadySession = event.engineSessionId;
			if (this.recovery || !previous || previous === event.engineSessionId) return;
			if (this.projectId && this.sink) {
				this.connection = "reconnecting";
				this.fenceConnection();
				this.beginRecovery(safeError({
					code: "ENGINE_EXITED",
					messageKey: "engine.exited",
					params: {},
					retryable: true
				}));
			}
			return;
		}
		if (event.engineSessionId !== this.lastReadySession || this.disconnectedSession === event.engineSessionId || !this.validate("error", event.error)) return;
		this.disconnectedSession = event.engineSessionId;
		this.connection = "reconnecting";
		this.fenceConnection();
		if (this.recovery) {
			this.recovery.error = safeDisplayError(event.error);
			return;
		}
		if (this.projectId && this.sink) this.beginRecovery(safeDisplayError(event.error));
	}
	alive(recovery) {
		return !this.disposed && !recovery.cancelled && this.recovery === recovery && this.projectId === recovery.projectId && this.generation === recovery.generation;
	}
	connectionUpdate(recovery, state) {
		if (this.alive(recovery)) this.sink?.({
			kind: "connection",
			generation: this.generation,
			projectId: recovery.projectId,
			state,
			attempt: recovery.attempt,
			error: safeDisplayError(recovery.error)
		});
	}
	beginRecovery(error) {
		if (this.connection !== "offline" && this.recovery && this.alive(this.recovery)) return this.recovery.promise;
		this.cancelRecovery();
		const recovery = {
			projectId: this.project(),
			generation: this.generation,
			attempt: 0,
			cancelled: false,
			error
		};
		this.recovery = recovery;
		this.connection = "reconnecting";
		recovery.promise = Promise.resolve().then(() => this.recover(recovery)).finally(() => {
			if (this.recovery === recovery) this.recovery = void 0;
		});
		this.connectionUpdate(recovery, "reconnecting");
		return recovery.promise;
	}
	async recover(recovery) {
		for (let attempt = 1; attempt <= 3; attempt++) {
			if (!this.alive(recovery)) return {
				ok: false,
				error: safeError(denied)
			};
			if (attempt > 1) {
				await new Promise((done) => {
					const timer = setTimeout(done, 250 * 2 ** (attempt - 2));
					recovery.wake = () => {
						clearTimeout(timer);
						done();
					};
				});
				recovery.wake = void 0;
				if (!this.alive(recovery)) return {
					ok: false,
					error: safeError(denied)
				};
			}
			recovery.attempt = attempt;
			this.connectionUpdate(recovery, "reconnecting");
			let timer;
			const result = await Promise.race([this.restoreOnce(true), new Promise((done) => {
				timer = setTimeout(() => done({
					ok: false,
					error: safeError({
						code: "TIMEOUT",
						messageKey: "job.timeout",
						params: { phase: "request" },
						retryable: true
					})
				}), 15e3);
			})]);
			clearTimeout(timer);
			if (!this.alive(recovery)) return {
				ok: false,
				error: safeError(denied)
			};
			if (result.ok) {
				this.connection = "ready";
				this.sink?.({
					kind: "restored",
					generation: result.data.generation,
					view: result.data
				});
				return result;
			}
			recovery.error = result.error;
			this.fenceConnection(!!this.engine.engineSessionId);
			if (attempt === 3) {
				this.connection = "offline";
				this.connectionUpdate(recovery, "offline");
				return result;
			}
		}
		return {
			ok: false,
			error: safeError(denied)
		};
	}
	async call(method, params) {
		if (!this.validate(`params_${method}`, params)) throw { error: invalid };
		const generation = this.generation;
		const requestedSession = this.engine.engineSessionId;
		const operation = this.engine.request(method, params);
		let result;
		try {
			result = await operation;
		} catch (cause) {
			if (generation !== this.generation) throw { error: denied };
			if (this.#supervisor) {
				const token = Object.freeze({});
				this.#caught.set(token, {
					value: this.#supervisor.projectFailure(cause, operation),
					generation,
					projectId: this.projectId
				});
				throw token;
			}
			throw cause;
		}
		if (generation !== this.generation) {
			if (method === "job.subscribe" && this.engine.engineSessionId && (!requestedSession || requestedSession === this.engine.engineSessionId) && this.validate("result_job.subscribe", result)) {
				const sub = result;
				this.engine.request("job.unsubscribe", {
					...params,
					subscriptionId: sub.subscriptionId
				}).catch(() => {});
			}
			throw { error: denied };
		}
		if (!this.validate(`result_${method}`, result)) throw new Error("INVALID_RESPONSE");
		if (result && typeof result === "object") {
			const record = result;
			for (const key of [
				"projectId",
				"jobId",
				"resultId",
				"operationId"
			]) if (key in params && key in record && params[key] !== record[key]) throw new Error("INVALID_RESPONSE");
		}
		return result;
	}
	project() {
		if (!this.projectId) throw { error: denied };
		return this.projectId;
	}
	guard(action) {
		let source;
		try {
			source = action();
		} catch (cause) {
			source = Promise.reject(cause);
		}
		const promise = source.then((data) => ({
			ok: true,
			data
		}), (cause) => {
			const context = cause && typeof cause === "object" ? this.#caught.get(cause) : void 0;
			const current = context && context.generation === this.generation && context.projectId === this.projectId;
			const result = {
				ok: false,
				error: current ? safeDisplayError(context.value) : context ? safeError(denied) : safeError(cause?.error)
			};
			if (current) this.#outcomes.set(result, {
				context,
				promises: new WeakSet([promise])
			});
			return result;
		});
		return promise;
	}
	forwardFailure(result, originatingPromise) {
		const issued = this.#outcomes.get(result);
		if (issued && issued.promises.has(originatingPromise)) {
			if (issued.context.generation !== this.generation || issued.context.projectId !== this.projectId) throw { error: denied };
			const token = Object.freeze({});
			this.#caught.set(token, issued.context);
			throw token;
		}
		throw { error: safeError(result.error) };
	}
	observeProject(project, alreadyFenced = false) {
		if (this.projectRevision !== void 0 && project.projectRevision < this.projectRevision) throw { error: {
			code: "INVALID_STATE",
			messageKey: "protocol.invalidState",
			params: {},
			retryable: false
		} };
		const advanced = this.projectRevision !== void 0 && project.projectRevision > this.projectRevision;
		this.projectRevision = project.projectRevision;
		if (advanced && !alreadyFenced) {
			if (this.recovery) this.fenceConnection(true);
			else {
				const sink = this.sink;
				this.detachView();
				this.sink = sink;
			}
		}
		return advanced;
	}
	async restoreJobs() {
		const jobs = [];
		for (const jobId of this.remembered) {
			const operation = this.subscribeJob(jobId);
			const response = await operation;
			if (!response.ok) this.forwardFailure(response, operation);
			jobs.push(response.data);
		}
		return jobs.map((job) => this.watches.get(job.jobId)?.job ?? job);
	}
	activeProject() {
		return this.guard(async () => {
			if (!this.projectId) return null;
			const project = await this.call("project.get", { projectId: this.projectId });
			if (this.observeProject(project)) {
				const generation = this.generation;
				await this.restoreJobs();
				if (generation !== this.generation) throw { error: denied };
			}
			return project;
		});
	}
	getJob(jobId) {
		return this.guard(() => this.call("job.get", {
			projectId: this.project(),
			jobId
		}));
	}
	listJobs(options) {
		return this.guard(async () => {
			if (!object({
				filter: _enum([
					"all",
					"active",
					"terminal"
				]),
				pageSize: number().int().min(1).max(100),
				listSnapshotId: id.nullable(),
				cursor: id.nullable()
			}).strict().safeParse(options).success) throw { error: invalid };
			return this.call("job.list", {
				...options,
				projectId: this.project()
			});
		});
	}
	cancelJob(jobId) {
		return this.guard(() => this.call("job.cancel", {
			projectId: this.project(),
			jobId
		}));
	}
	subscribeJob(jobId) {
		if (!id.safeParse(jobId).success) return Promise.resolve({
			ok: false,
			error: safeError(invalid)
		});
		const key = `${this.generation}:${jobId}`;
		const pending = this.pendingSubscriptions.get(key);
		if (pending) return pending;
		if (this.pendingSubscriptions.size >= 16) return Promise.resolve({
			ok: false,
			error: safeError({
				code: "RESOURCE_LIMIT",
				messageKey: "resource.limitExceeded",
				params: { resource: "memory" },
				retryable: false
			})
		});
		const operation = this.doSubscribe(jobId, key);
		const request = operation.finally(() => {
			this.pendingSubscriptions.delete(key);
			this.cancelledSubscriptions.delete(key);
			this.dropEarly(key);
		});
		request.then((result) => {
			const issued = this.#outcomes.get(result);
			if (issued?.promises.has(operation)) issued.promises.add(request);
		}, () => {});
		this.pendingSubscriptions.set(key, request);
		return request;
	}
	doSubscribe(jobId, key) {
		return this.guard(async () => {
			const projectId = this.project();
			if (!id.safeParse(jobId).success) throw { error: invalid };
			if (!this.remembered.has(jobId) && this.remembered.size >= 16) throw { error: {
				code: "RESOURCE_LIMIT",
				messageKey: "resource.limitExceeded",
				params: { resource: "memory" },
				retryable: false
			} };
			const previous = this.watches.get(jobId);
			this.watches.delete(jobId);
			if (previous && previous.binding.engineSessionId === this.engine.engineSessionId) await this.call("job.unsubscribe", {
				projectId,
				jobId,
				subscriptionId: previous.binding.subscriptionId
			});
			for (let attempt = 0; attempt < 3; attempt++) {
				const job = await this.call("job.get", {
					projectId,
					jobId
				});
				if (previous && (job.stateVersion < previous.binding.stateVersion || job.stateVersion === previous.binding.stateVersion && job.state !== previous.binding.state)) throw { error: {
					code: "INVALID_STATE",
					messageKey: "protocol.invalidState",
					params: {},
					retryable: false
				} };
				if (this.cancelledSubscriptions.has(key)) throw { error: denied };
				const subscription = await this.call("job.subscribe", {
					projectId,
					jobId
				});
				if (this.cancelledSubscriptions.has(key)) {
					await this.call("job.unsubscribe", {
						projectId,
						jobId,
						subscriptionId: subscription.subscriptionId
					});
					throw { error: denied };
				}
				const session = this.engine.engineSessionId;
				if (session && subscription.stateVersion === job.stateVersion) {
					this.watches.set(jobId, {
						job,
						binding: {
							engineSessionId: session,
							projectId,
							jobId,
							subscriptionId: subscription.subscriptionId,
							lastSeq: subscription.seq,
							stateVersion: job.stateVersion,
							state: job.state
						}
					});
					this.remembered.add(jobId);
					const events = this.earlyEvents.get(key) ?? [];
					this.dropEarly(key);
					for (const event of events) this.receive(event);
					const active = this.watches.get(jobId);
					if (!active) throw { error: denied };
					return active.job;
				}
				await this.call("job.unsubscribe", {
					projectId,
					jobId,
					subscriptionId: subscription.subscriptionId
				});
			}
			throw { error: {
				code: "INVALID_STATE",
				messageKey: "protocol.invalidState",
				params: {},
				retryable: false
			} };
		});
	}
	unsubscribeView(request) {
		const parsed = object({
			jobId: id,
			generation: number().int().min(0).max(Number.MAX_SAFE_INTEGER)
		}).strict().safeParse(request);
		if (!parsed.success) return Promise.resolve({
			ok: false,
			error: safeError(invalid)
		});
		if (parsed.data.generation !== this.generation) return Promise.resolve({
			ok: false,
			error: safeError(denied)
		});
		return this.unsubscribeJob(parsed.data.jobId);
	}
	unsubscribeJob(jobId) {
		return this.guard(async () => {
			if (!id.safeParse(jobId).success) throw { error: invalid };
			const key = `${this.generation}:${jobId}`;
			if (this.pendingSubscriptions.has(key)) this.cancelledSubscriptions.add(key);
			const watch = this.watches.get(jobId);
			this.watches.delete(jobId);
			if (watch && watch.binding.engineSessionId === this.engine.engineSessionId) await this.call("job.unsubscribe", {
				projectId: watch.binding.projectId,
				jobId: watch.binding.jobId,
				subscriptionId: watch.binding.subscriptionId
			});
			return null;
		});
	}
	restore() {
		if (this.projectId && this.connection !== "ready") {
			if (!this.recovery || this.connection === "offline") this.fenceConnection(!!this.engine.engineSessionId);
			return this.beginRecovery(safeError({
				code: "ENGINE_EXITED",
				messageKey: "engine.exited",
				params: {},
				retryable: true
			}));
		}
		return this.restoreOnce();
	}
	restoreOnce(reconcileMarkers = false, alreadyFenced = false) {
		return this.guard(async () => {
			let requiredRevision = 0;
			let requiredSnapshot;
			for (let attempt = 0; attempt < 3; attempt++) {
				const project = this.projectId ? await this.call("project.get", { projectId: this.projectId }) : null;
				if (project) this.observeProject(project, alreadyFenced);
				const generation = this.generation;
				const session = this.engine.engineSessionId;
				try {
					let jobs = await this.restoreJobs();
					if (reconcileMarkers) await this.reconcileMarkers(jobs);
					if (generation !== this.generation) throw { error: denied };
					jobs = jobs.map((job) => this.watches.get(job.jobId)?.job ?? job);
					let conflictingSnapshot = false;
					for (const job of jobs) {
						const commit = job.commitProgress;
						if (commit.mode !== "atomic" || !commit.marker) continue;
						const marker = commit.marker;
						if (marker.projectRevision > requiredRevision) {
							requiredRevision = marker.projectRevision;
							requiredSnapshot = marker.afterSnapshotId;
						} else if (marker.projectRevision === requiredRevision) {
							if (requiredSnapshot && requiredSnapshot !== marker.afterSnapshotId) conflictingSnapshot = true;
							requiredSnapshot = marker.afterSnapshotId;
						}
					}
					if (conflictingSnapshot || project?.projectRevision === requiredRevision && requiredSnapshot && project.inputSnapshotId !== requiredSnapshot) {
						this.fenceConnection(true);
						throw { error: {
							code: "INVALID_STATE",
							messageKey: "protocol.invalidState",
							params: {},
							retryable: false
						} };
					}
					if (!project || project.projectRevision >= requiredRevision) return {
						generation,
						project,
						jobs
					};
					const transition = this.projectTransition;
					const continuesTransition = transition && transition.to === generation && transition.projectId === project.projectId && transition.session === session;
					this.fenceConnection(true);
					if (continuesTransition) {
						transition.to = this.generation;
						this.projectTransition = transition;
					}
					alreadyFenced = true;
				} catch (error) {
					const transition = this.projectTransition;
					if (transition && transition.from === generation && transition.to === this.generation && transition.projectId === project?.projectId && transition.projectId === this.projectId && transition.session === session && session === this.engine.engineSessionId) {
						const view = await transition.view;
						if (view && this.projectTransition === transition && view.generation === this.generation && this.projectId === transition.projectId && this.engine.engineSessionId === session) return view;
					}
					throw error;
				}
			}
			throw { error: {
				code: "INVALID_STATE",
				messageKey: "protocol.invalidState",
				params: {},
				retryable: false
			} };
		});
	}
	async reconcileMarkers(jobs) {
		for (const job of jobs) {
			const marker = await this.call("operation.get", {
				projectId: job.projectId,
				operationId: job.operationId
			});
			if (marker && marker.jobId !== job.jobId) throw { error: invalid };
			const commit = job.commitProgress;
			if (commit.mode === "atomic" && (commit.marker === null !== (marker === null) || commit.marker && marker && Object.keys(commit.marker).some((key) => commit.marker[key] !== marker[key]))) throw { error: invalid };
		}
	}
	getResult(resultId) {
		return this.guard(() => this.call("result.get", {
			projectId: this.project(),
			resultId
		}));
	}
	getResultPage(options) {
		return this.guard(async () => {
			if (!object({
				resultId: id,
				pageSize: number().int().min(1).max(200),
				cursor: id.nullable()
			}).strict().safeParse(options).success) throw { error: invalid };
			const result = await this.call("result.get", {
				projectId: this.project(),
				resultId: options.resultId
			});
			return this.call("result.page", {
				binding: {
					projectId: this.project(),
					resultId: options.resultId,
					inputSnapshotId: result.inputSnapshotId,
					scope: result.scope,
					parametersHash: result.parametersHash,
					order: "ordinal+rowId:asc"
				},
				pageSize: options.pageSize,
				cursor: options.cursor
			});
		});
	}
	getOperation(operationId) {
		return this.guard(() => this.call("operation.get", {
			projectId: this.project(),
			operationId
		}));
	}
	dropEarly(key) {
		for (const value of this.earlyEvents.get(key) ?? []) this.earlyBytes -= Buffer.byteLength(JSON.stringify(value));
		this.earlyEvents.delete(key);
	}
	refreshProject(watch) {
		if (this.projectRefresh.has(this.generation) || this.projectRefresh.size >= 16) return;
		const { projectId, engineSessionId } = watch.binding;
		const fromGeneration = this.generation;
		const reconcileMarkers = !!this.recovery;
		this.fenceConnection(true);
		const generation = this.generation;
		const refresh = Promise.resolve().then(async () => {
			if (this.projectId !== projectId || this.generation !== generation || this.engine.engineSessionId !== engineSessionId) return;
			const restored = await this.restoreOnce(reconcileMarkers, true);
			if (!restored.ok || this.projectId !== projectId || this.generation !== restored.data.generation || this.engine.engineSessionId !== engineSessionId || !restored.data.jobs.length) return;
			const restoredView = restored.data;
			this.sink?.({
				kind: "restored",
				generation: restoredView.generation,
				view: restoredView
			});
			return restoredView;
		}).catch(() => void 0).finally(() => {
			this.projectRefresh.delete(generation);
		});
		this.projectRefresh.set(generation, refresh);
		this.projectTransition = {
			from: fromGeneration,
			to: generation,
			projectId,
			session: engineSessionId,
			view: refresh
		};
	}
	reconcile(watch) {
		const generation = this.generation;
		const { jobId, projectId, engineSessionId } = watch.binding;
		const key = `${generation}:${jobId}`;
		this.dirtyWatches.add(watch);
		if (this.reconciliations.has(key) || this.reconciliations.size >= 16) return;
		const recovery = Promise.resolve().then(async () => {
			const pending = this.pendingSubscriptions.get(key);
			if (pending) await pending;
			let target = watch;
			for (let attempt = 0; attempt < 3; attempt++) {
				if (this.generation !== generation || this.projectId !== projectId || this.engine.engineSessionId !== engineSessionId || this.watches.get(jobId) !== target || this.cancelledSubscriptions.has(key) || [
					"succeeded",
					"failed",
					"cancelled"
				].includes(target.binding.state)) return;
				this.dirtyWatches.delete(target);
				const result = await this.subscribeJob(jobId);
				const current = this.watches.get(jobId);
				if (!result.ok || this.generation !== generation || this.projectId !== projectId || this.engine.engineSessionId !== engineSessionId || !current) return;
				if (this.dirtyWatches.has(current)) {
					target = current;
					continue;
				}
				this.sink?.({
					kind: "job",
					generation,
					job: structuredClone(result.data)
				});
				return;
			}
		}).catch(() => {}).finally(() => this.reconciliations.delete(key));
		this.reconciliations.set(key, recovery);
	}
	receive(value) {
		if (!this.validate("notification", value)) return;
		const event = value;
		if (event.projectId !== this.projectId || event.engineSessionId !== this.engine.engineSessionId) return;
		const watch = this.watches.get(event.jobId);
		const key = `${this.generation}:${event.jobId}`;
		if (!watch && this.pendingSubscriptions.has(key)) {
			const events = this.earlyEvents.get(key) ?? [];
			const bytes = Buffer.byteLength(JSON.stringify(value));
			if (events.length < 8 && this.earlyBytes + bytes <= 1048576) {
				this.earlyBytes += bytes;
				events.push(value);
				this.earlyEvents.set(key, events);
			}
			return;
		}
		if (!watch || this.engine.engineSessionId !== watch.binding.engineSessionId || event.engineSessionId !== watch.binding.engineSessionId || event.projectId !== watch.binding.projectId || event.jobId !== watch.binding.jobId || event.subscriptionId !== watch.binding.subscriptionId) return;
		if ([
			"succeeded",
			"failed",
			"cancelled"
		].includes(watch.binding.state)) return;
		const commit = event.event === "job.state" ? event.data.commitProgress : void 0;
		if (commit?.mode === "atomic" && commit.marker && (this.projectRevision === void 0 || commit.marker.projectRevision > this.projectRevision)) {
			this.refreshProject(watch);
			return;
		}
		if (!(this.#supervisor?.profile === "business3" ? acceptsBusiness3JobEvent(value, watch.binding) : acceptsJobEvent(value, watch.binding))) {
			if (event.seq > watch.binding.lastSeq || event.data.stateVersion > watch.binding.stateVersion) this.reconcile(watch);
			return;
		}
		watch.binding.lastSeq = event.seq;
		if (event.event === "job.progress") {
			this.sink?.({
				kind: "job",
				generation: this.generation,
				job: structuredClone(watch.job),
				progress: structuredClone(event.data.progress)
			});
			return;
		}
		if (event.event !== "job.state") return;
		watch.binding.stateVersion = event.data.stateVersion;
		watch.binding.state = event.data.state;
		watch.job = event.data;
		this.sink?.({
			kind: "job",
			generation: this.generation,
			job: structuredClone(event.data)
		});
	}
};
//#endregion
//#region src/main/trusted-document.ts
function isTrustedDocument(candidate, trusted) {
	try {
		const actual = new URL(candidate);
		const expected = new URL(trusted);
		actual.hash = "";
		expected.hash = "";
		return actual.href === expected.href;
	} catch {
		return false;
	}
}
//#endregion
//#region src/csp.ts
function contentSecurityPolicy(development) {
	const directives = {
		"default-src": ["'self'"],
		"script-src": ["'self'"],
		"style-src": ["'self'"],
		"img-src": ["'self'", "data:"],
		"connect-src": ["'none'"],
		"object-src": ["'none'"],
		"base-uri": ["'none'"],
		"frame-src": ["'none'"],
		"form-action": ["'none'"]
	};
	if (development) {
		const origin = new URL(development.origin);
		if (origin.origin !== "http://127.0.0.1:5173" || !/^[\w+/=-]+$/.test(development.nonce)) throw new Error("INVALID_DEVELOPMENT_CSP");
		directives["script-src"].push(`'nonce-${development.nonce}'`);
		directives["style-src"].push("'unsafe-inline'");
		directives["connect-src"] = [origin.origin, "ws://127.0.0.1:5173"];
	}
	return Object.entries(directives).map(([name, values]) => `${name} ${values.join(" ")}`).join("; ");
}
//#endregion
//#region src/main/window-security.ts
function securePreferences(preload) {
	return {
		preload,
		contextIsolation: true,
		nodeIntegration: false,
		nodeIntegrationInWorker: false,
		nodeIntegrationInSubFrames: false,
		sandbox: true,
		webviewTag: false,
		webSecurity: true,
		allowRunningInsecureContent: false
	};
}
function hardenWebContents(contents) {
	contents.setWindowOpenHandler(() => ({ action: "deny" }));
	contents.on("will-navigate", (event) => event.preventDefault());
	contents.on("will-frame-navigate", (event) => event.preventDefault());
	contents.on("will-redirect", (event) => event.preventDefault());
	contents.on("will-attach-webview", (event) => event.preventDefault());
}
//#endregion
//#region src/main/window-recovery.ts
function installWindowRecovery(window, reopen, isQuitting) {
	let prompting = false;
	let responsive = true;
	let gone = false;
	const prompt = async (reason) => {
		if (prompting || isQuitting() || window.isDestroyed()) return;
		prompting = true;
		try {
			const { response } = await electron.dialog.showMessageBox(window, {
				type: "warning",
				title: "OntoLearn Studio 窗口恢复",
				message: reason === "crashed" ? "显示窗口已停止运行。" : "显示窗口暂时没有响应。",
				detail: "渲染进程异常或繁忙。可以重新打开窗口；已提交的本地数据不受窗口重建影响，未提交的界面输入可能丢失。恢复后将查询任务的持久状态并重建订阅，不会重新执行写任务；后台任务不会因窗口重建而取消。",
				buttons: ["重新打开窗口", "暂不恢复"],
				defaultId: 1,
				cancelId: 1,
				noLink: true
			});
			if (response === 0 && !isQuitting() && !window.isDestroyed() && (gone || !responsive)) reopen();
		} catch {} finally {
			prompting = false;
		}
	};
	window.webContents.on("render-process-gone", (_event, details) => {
		if (details.reason === "clean-exit") return;
		gone = true;
		prompt("crashed");
	});
	window.webContents.on("did-finish-load", () => {
		gone = false;
		responsive = true;
	});
	window.on("unresponsive", () => {
		responsive = false;
		prompt("unresponsive");
	});
	window.on("responsive", () => {
		responsive = true;
	});
}
//#endregion
//#region src/main/view-navigation.ts
function installViewNavigation(contents, replaceDocument) {
	contents.on("did-start-navigation", (details) => {
		if (details.isMainFrame && !details.isSameDocument) replaceDocument();
	});
}
//#endregion
//#region src/main/index.ts
electron.app.enableSandbox();
var quitting = false;
electron.app.on("before-quit", () => {
	quitting = true;
	tasks?.dispose();
	supervisor?.stop();
});
var window = null;
var supervisor;
var tasks;
var devURL = !electron.app.isPackaged ? process.env.ELECTRON_RENDERER_URL : void 0;
var rendererPath = (0, node_path.join)(__dirname, "../renderer/index.html");
var trustedURL = devURL ?? (0, node_url.pathToFileURL)(rendererPath).href;
function createWindow() {
	window = new electron.BrowserWindow({
		width: 1280,
		height: 860,
		minWidth: 1024,
		minHeight: 720,
		title: "OntoLearn Studio",
		backgroundColor: "#F5F9F7",
		webPreferences: securePreferences((0, node_path.join)(__dirname, "../preload/index.js"))
	});
	const created = window;
	const attach = () => tasks.attachView((update) => {
		if (!created.isDestroyed() && window === created) created.webContents.send("tasks:update", update);
	});
	attach();
	installViewNavigation(created.webContents, () => {
		if (window === created) attach();
	});
	created.webContents.on("render-process-gone", () => {
		if (window === created) tasks.detachView();
	});
	installWindowRecovery(created, () => {
		createWindow();
		created.destroy();
	}, () => quitting);
	window.on("closed", () => {
		if (window === created) {
			tasks.detachView();
			window = null;
		}
	});
	if (devURL) window.loadURL(devURL);
	else window.loadFile(rendererPath);
}
electron.app.on("web-contents-created", (_event, contents) => hardenWebContents(contents));
electron.app.whenReady().then(async () => {
	electron.session.defaultSession.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
	electron.session.defaultSession.setPermissionCheckHandler(() => false);
	if (devURL) {
		const policy = contentSecurityPolicy({
			nonce: "eNJ14YDNJcsNdg55DpQO6rrF",
			origin: devURL
		});
		electron.session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
			callback({ responseHeaders: {
				...details.responseHeaders,
				"Content-Security-Policy": [policy]
			} });
		});
	}
	const fixturePath = process.argv.find((arg) => arg.startsWith("--i04-test-fixture="))?.slice(19);
	const fixture = fixturePath && (0, node_path.isAbsolute)(fixturePath) && process.env.I04_TEST_FIXTURE === fixturePath ? object({
		projectId: string().uuid(),
		jobIds: array(string().uuid()).max(16),
		databasePath: string().refine(node_path.isAbsolute),
		startRequests: array(record(string(), unknown()).refine((value) => validateV2("params_job.create", value) && [
			"test.read",
			"test.atomic",
			"test.rounds"
		].includes(String(value.capability)))).max(2).optional()
	}).strict().parse(JSON.parse((0, node_fs.readFileSync)(fixturePath, "utf8"))) : void 0;
	supervisor = new EngineSupervisor({
		packaged: electron.app.isPackaged,
		appPath: electron.app.getAppPath(),
		resourcesPath: process.resourcesPath
	}, {
		profile: !electron.app.isPackaged && process.argv.includes("--t01-internal-business3") ? "business3" : "legacy2",
		dataPath: fixture?.databasePath ?? (0, node_path.join)(electron.app.getPath("userData"), "engine.sqlite"),
		...fixture ? {
			allowedProjects: [fixture.projectId],
			testMode: true
		} : {}
	});
	tasks = new TaskService(supervisor);
	if (fixture) {
		const jobIds = [...fixture.jobIds];
		for (const request of fixture.startRequests ?? []) {
			if (request.projectId !== fixture.projectId) throw new Error("INVALID_TEST_FIXTURE");
			const job = await supervisor.request("job.create", request);
			jobIds.push(job.jobId);
		}
		tasks.selectProject(fixture.projectId, jobIds);
	}
	function trusted(event) {
		return !!window && event.sender === window.webContents && event.senderFrame === window.webContents.mainFrame && isTrustedDocument(event.senderFrame.url, trustedURL);
	}
	const permission = () => ({
		ok: false,
		error: safeError({
			code: "PERMISSION_DENIED",
			messageKey: "permission.denied",
			params: {},
			retryable: false
		})
	});
	electron.ipcMain.handle("engine:health", async (event) => {
		if (!trusted(event)) return permission();
		const operation = supervisor.health();
		try {
			return {
				ok: true,
				data: await operation
			};
		} catch (error) {
			return {
				ok: false,
				error: supervisor.projectFailure(error, operation)
			};
		}
	});
	const routes = {
		"tasks:restore": () => tasks.restore(),
		"project:active": () => tasks.activeProject(),
		"job:get": (id) => tasks.getJob(id),
		"job:list": (options) => tasks.listJobs(options),
		"job:cancel": (id) => tasks.cancelJob(id),
		"job:subscribe": (id) => tasks.subscribeJob(id),
		"job:unsubscribe": (request) => tasks.unsubscribeView(request),
		"result:get": (id) => tasks.getResult(id),
		"result:page": (options) => tasks.getResultPage(options),
		"operation:get": (id) => tasks.getOperation(id)
	};
	for (const [channel, handler] of Object.entries(routes)) electron.ipcMain.handle(channel, (event, argument) => trusted(event) ? handler(argument) : permission());
	createWindow();
	electron.app.on("activate", () => {
		if (electron.BrowserWindow.getAllWindows().length === 0) createWindow();
	});
});
electron.app.on("window-all-closed", () => {
	if (process.platform !== "darwin") electron.app.quit();
});
//#endregion
