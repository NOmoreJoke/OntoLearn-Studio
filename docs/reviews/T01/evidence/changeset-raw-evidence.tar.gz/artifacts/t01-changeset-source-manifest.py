from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
products = [
"packages/engine/src/ontolearn_engine/project/domain_changesets.py",
"packages/engine/src/ontolearn_engine/job_store.py",
"packages/engine/src/ontolearn_engine/coordinator.py",
*["packages/contracts/v2/" + p + ".json" for p in ["schema", "registry", "fixtures", "binding-regressions"]],
"packages/contracts/src/v2.ts", "packages/contracts/src/index.ts", "packages/contracts/python/contract_v2.py",
]
tests = ["packages/engine/tests/test_project_changeset_service.py", "packages/engine/tests/test_project_changeset_stdio.py", "tests/unit/t01-changeset-canonical.test.ts", "tests/unit/t01-changeset-runtime.test.ts"]
def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
assert len(products) == 10 and len(tests) == 4
output = root / "docs/reviews/T01/evidence/changeset-final-source.json"
document = {"baseHead": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), "scope": "Authorized formal ChangeSet implementation: ten products/four new tests; excludes protected AGENTS, all prior tests, desktop, dependencies and CI", "products": {p: identity((root/p).read_bytes()) for p in products}, "tests": {p: identity((root/p).read_bytes()) for p in tests}}
if output.exists():
    assert json.loads(output.read_text()) == document, "Frozen candidate changed"
else:
    output.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(output.with_suffix(".zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for p in products + tests:
            z.writestr(p, (root/p).read_bytes())
print(json.dumps({"manifest": identity(output.read_bytes()), "sourceArchive": identity(output.with_suffix('.zip').read_bytes()), "products": len(products), "tests": len(tests)}, ensure_ascii=False))
