from pathlib import Path
p=Path('packages/contracts/src/v2.ts');s=p.read_text();needle='  if (name === \'params_job.create\' || name === \'params_job.list\')\n';assert needle in s;s=s.replace(needle,'''  if (!changeSetSemantics(name, value)) return false
'''+needle)
mark='/** A value check only: provenance, pre-hello, profile and once belong to the supervisor. */'
i=s.index(mark)
s=s[:i]+'''// Additional invariants apply only to the new typed ChangeSet definitions/strict3 methods.
function changeSetSemantics(name: string, value: unknown): boolean {
  const v = value as Record<string, unknown>
  if (['request3', 'response3', 'envelope3'].includes(name)) {
    if (v.kind === 'response' && v.ok && String(v.method).startsWith('changeset.'))
      return changeSetSemantics(`result_${v.method}`, v.result)
    return true
  }
  if (name === 'changeSetManifest') {
    const parts = v.segments as Array<Record<string, unknown>>
    let offset = 0
    if (parts.length !== v.segmentCount) return false
    for (const [ordinal, part] of parts.entries()) {
      if (part.ordinal !== ordinal || part.byteOffset !== offset) return false
      offset += part.rawByteLength as number
    }
    return offset === v.totalBytes
  }
  if (name === 'result_changeset.preview') {
    const manifest = v.manifest as Record<string, unknown>
    return (
      changeSetSemantics('changeSetManifest', manifest) &&
      (v.status === 'conflict'
        ? manifest.documentKind === 'undo-impact'
        : manifest.documentKind === 'diff' &&
          (v.intent === 'change' ? v.targetOperationId === null : v.targetOperationId !== null))
    )
  }
  if (name === 'changeSetSegment') {
    const encoded = v.dataBase64 as string
    const padding = encoded.endsWith('==') ? 2 : encoded.endsWith('=') ? 1 : 0
    return (encoded.length / 4) * 3 - padding === v.rawByteLength
  }
  if (name === 'changeSetPage' || name === 'result_changeset.diff.page') {
    const parts = v.segments as Array<Record<string, unknown>>
    return parts.every(
      (part, index) =>
        changeSetSemantics('changeSetSegment', part) &&
        (index === 0 ||
          (part.ordinal === (parts[index - 1].ordinal as number) + 1 &&
            part.byteOffset ===
              (parts[index - 1].byteOffset as number) + (parts[index - 1].rawByteLength as number))),
    )
  }
  return true
}

''' +s[i:]
needle="  if (q.id !== r.id || q.method !== r.method) return false\n";start=s.index('export function matchesBusiness3Response');i=s.index(needle,start)+len(needle)
s=s[:i]+'''  if (String(q.method).startsWith('changeset.')) {
    if (q.engineSessionId !== r.engineSessionId) return false
    if (!r.ok) return true
    const p = q.params as Record<string, unknown>
    const data = r.result as Record<string, unknown>
    if (p.projectId !== data.projectId) return false
    if (q.method === 'changeset.preview')
      return (
        p.baseRevision === data.baseRevision &&
        (p.intent === 'change'
          ? data.status === 'ready' && data.intent === 'change' && data.targetOperationId === null
          : data.targetOperationId === p.targetOperationId &&
            (data.status === 'conflict' || data.intent === 'undo'))
      )
    if (p.previewHash !== data.previewHash) return false
    if (q.method === 'changeset.diff.page')
      return (
        p.documentKind === data.documentKind &&
        (data.segments as unknown[]).length <= (p.pageSize as number)
      )
    return q.method === 'changeset.confirm'
  }
''' +s[i:];p.write_text(s)
p=Path('packages/contracts/python/contract_v2.py');s=p.read_text();needle='        if valid and name in {"params_job.create", "params_job.list"}:\n';assert needle in s;s=s.replace(needle,'''        if valid and not _changeset_semantics(name, value):
            return False
'''+needle)
mark='def validate_startup_failure(';i=s.index(mark)
s=s[:i]+'''def _changeset_semantics(name, value):
    if name in {"request3", "response3", "envelope3"}:
        if (
            value["kind"] == "response"
            and value["ok"]
            and value["method"].startswith("changeset.")
        ):
            return _changeset_semantics("result_" + value["method"], value["result"])
        return True
    if name == "changeSetManifest":
        parts = value["segments"]
        if len(parts) != value["segmentCount"]:
            return False
        offset = 0
        for ordinal, part in enumerate(parts):
            if part["ordinal"] != ordinal or part["byteOffset"] != offset:
                return False
            offset += part["rawByteLength"]
        return offset == value["totalBytes"]
    if name == "result_changeset.preview":
        manifest = value["manifest"]
        return _changeset_semantics("changeSetManifest", manifest) and (
            manifest["documentKind"] == "undo-impact"
            if value["status"] == "conflict"
            else manifest["documentKind"] == "diff"
            and (
                value["targetOperationId"] is None
                if value["intent"] == "change"
                else value["targetOperationId"] is not None
            )
        )
    if name == "changeSetSegment":
        encoded = value["dataBase64"]
        padding = 2 if encoded.endswith("==") else 1 if encoded.endswith("=") else 0
        return len(encoded) // 4 * 3 - padding == value["rawByteLength"]
    if name in {"changeSetPage", "result_changeset.diff.page"}:
        parts = value["segments"]
        return all(
            _changeset_semantics("changeSetSegment", part)
            and (
                index == 0
                or part["ordinal"] == parts[index - 1]["ordinal"] + 1
                and part["byteOffset"]
                == parts[index - 1]["byteOffset"] + parts[index - 1]["rawByteLength"]
            )
            for index, part in enumerate(parts)
        )
    return True


''' +s[i:]
needle='    if any(request[k] != response[k] for k in ("id", "method")):\n        return False\n';start=s.index('def matches_business3_response(');i=s.index(needle,start)+len(needle)
s=s[:i]+'''    if request["method"].startswith("changeset."):
        if request["engineSessionId"] != response["engineSessionId"]:
            return False
        if not response["ok"]:
            return True
        p, data = request["params"], response["result"]
        if p["projectId"] != data["projectId"]:
            return False
        if request["method"] == "changeset.preview":
            return p["baseRevision"] == data["baseRevision"] and (
                data["status"] == "ready"
                and data["intent"] == "change"
                and data["targetOperationId"] is None
                if p["intent"] == "change"
                else data["targetOperationId"] == p["targetOperationId"]
                and (data["status"] == "conflict" or data["intent"] == "undo")
            )
        if p["previewHash"] != data["previewHash"]:
            return False
        if request["method"] == "changeset.diff.page":
            return p["documentKind"] == data["documentKind"] and len(data["segments"]) <= p["pageSize"]
        return request["method"] == "changeset.confirm"
''' +s[i:];p.write_text(s)
