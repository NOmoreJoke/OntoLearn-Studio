"""Actual unsigned frozen engine formal service; never launches Electron."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from uuid import uuid4

ROOT = Path.cwd()
EXE = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2])
sys.path.insert(0, str(ROOT / "packages/engine/src"))
spec = importlib.util.spec_from_file_location(
    "formal_stdio_probe", ROOT / "packages/engine/tests/test_project_changeset_stdio.py"
)
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
digest = lambda data: hashlib.sha256(data).hexdigest()
report = {"scope": "Frozen engine CLI only; testMode=false; no Electron/UI/native/human-confirmation claim", "executable": str(EXE), "executableSHA256": digest(EXE.read_bytes())}
resources = subprocess.run([str(EXE), "--protocol-resources"], capture_output=True, timeout=20)
report["resourcesProcess"] = {"exit": resources.returncode, "stdout": resources.stdout.decode(), "stderr": resources.stderr.decode()}
assert resources.returncode == 0 and not resources.stderr
manifest = json.loads(resources.stdout)
expected = {"python/contract_v2.py": digest((ROOT / "packages/contracts/python/contract_v2.py").read_bytes())}
expected.update({"v2/" + p.name: digest(p.read_bytes()) for p in (ROOT / "packages/contracts/v2").glob("*.json")})
assert manifest["frozen"] and manifest["resources"] == expected
assert manifest["registryHash"] == expected["v2/registry.json"]
assert manifest["implementation"]["dependencyLockHash"] == digest((ROOT / "uv.lock").read_bytes())
report["resources"] = manifest
try:
    with tempfile.TemporaryDirectory(prefix="t01-changeset-packaged-") as tmp:
        path, project = Path(tmp) / "formal.sqlite", str(uuid4())
        store = T.JobStore(path, contract=T.CONTRACT, target_format=3)
        store.create_project(project)
        store.close()
        session = T.Session(path, project, executable=EXE)
        try:
            definition = T.ontology("Asset")
            first, first_job, first_diff = session.submit(session.preview({"definitions": [definition], "manual": [T.fact()]}))
            assert first_diff == [
                {"resource": ["definition", "ontology", "Asset"], "before": None, "after": T.record(definition)},
                {"resource": ["fact", T.fact()["id"]], "before": None, "after": {**T.fact(), "owner": None, "source_row": None, "managed_value": None}},
            ]
            first_terminal = session.terminal(first_job)
            assert first_terminal["state"] == "succeeded"
            other = T.fact('"B"', "urn:asset:B")
            second, second_job, _ = session.submit(session.preview({"manual": [other]}))
            assert session.terminal(second_job)["state"] == "succeeded"
            undo = session.call("changeset.preview", {"projectId": project, "baseRevision": 2, "intent": "undo", "targetOperationId": first["operationId"]})
            reversed_, reversed_job, undo_diff = session.submit(undo)
            assert undo_diff == [{**item, "before": item["after"], "after": item["before"]} for item in first_diff]
            assert session.terminal(reversed_job)["state"] == "succeeded"
            assert session.call("project.get", {"projectId": project})["projectRevision"] == 3
        finally:
            session.close()
        session = T.Session(path, project, executable=EXE)
        try:
            for request, job in [(first, first_job), (second, second_job), (reversed_, reversed_job)]:
                assert session.call("job.create", request)["jobId"] == job["jobId"]
                assert session.call("operation.get", {"projectId": project, "operationId": request["operationId"]})["jobId"] == job["jobId"]
            stale = session.exchange("job.create", {**first, "operationId": str(uuid4())})
            assert not stale["ok"] and stale["error"]["code"] == "IDENTITY_CONFLICT"
        finally:
            session.close()
        store = T.JobStore(path, contract=T.CONTRACT, target_format=3)
        try:
            state = store.state(store._project(project))
            assert state["definitions"] == []
            assert state["facts"] == [{**other, "owner": None, "source_row": None, "managed_value": None}]
            checkpoint = store.project_checkpoint(store._project(project))
            assert checkpoint["operationSequence"] == 3
        finally:
            store.close()
        with sqlite3.connect(path) as db:
            assert db.execute("SELECT count(*) FROM operation_claims").fetchone()[0] == 3
            assert db.execute("SELECT count(*) FROM app_receipts").fetchone()[0] == 3
        report["actual"] = {"projectId": project, "first": first, "firstJob": first_terminal, "second": second, "undo": reversed_, "firstDiff": first_diff, "undoDiff": undo_diff, "state": state, "checkpoint": checkpoint, "claims": 3, "applicationReceipts": 3}
finally:
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"report": str(OUT), "bytes": OUT.stat().st_size, "sha256": digest(OUT.read_bytes()), "resources": len(expected), "revision": 3, "formalJobs": 3}))
