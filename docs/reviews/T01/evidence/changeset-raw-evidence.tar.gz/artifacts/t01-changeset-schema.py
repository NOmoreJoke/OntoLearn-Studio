import json,copy
from pathlib import Path
root=Path('packages/contracts/v2')
p=root/'schema.json';s=json.loads(p.read_text());d=s['$defs']
def ref(n): return {'$ref':'#/$defs/'+n}
def obj(properties,required=None): return {'type':'object','properties':properties,'required':list(properties) if required is None else required,'additionalProperties':False}
def arr(items,maximum=4096,minimum=0): return {'type':'array','items':items,'minItems':minimum,'maxItems':maximum}
def integer(maximum=9007199254740991,minimum=0): return {'type':'integer','minimum':minimum,'maximum':maximum}
def text(maximum=262144,minimum=1): return {'type':'string','minLength':minimum,'maxLength':maximum}
def const(x): return {'const':x}
families=['ontology','mapping','constraint','rule','behavior','scenario','query','model']
d['changeSetDefinitionReference']=obj({'layer':{'enum':families},'id':ref('name')})
d['changeSetTriple']=obj({'subject':text(),'predicate':text(),'object':text()})
d['changeSetOntologyValue']=obj({'triples':arr(ref('changeSetTriple')),'singleValuedPredicates':arr(text()),'references':arr(ref('changeSetDefinitionReference'))},[])
d['changeSetDefinition']=obj({'layer':const('ontology'),'id':ref('name'),'value':ref('changeSetOntologyValue')})
d['changeSetDefinitionRemoval']=obj({'layer':const('ontology'),'id':ref('name')})
d['changeSetFact']=obj({'id':ref('hash'),'subject':text(),'predicate':text(),'object':text()})
d['changeSetPlan']=obj({'definitions':arr(ref('changeSetDefinition')),'remove_definitions':arr(ref('changeSetDefinitionRemoval')),'manual':arr(ref('changeSetFact')),'edits':{'type':'object','propertyNames':ref('hash'),'additionalProperties':text(),'maxProperties':4096},'remove':arr(ref('hash'))},[])
d['changeSetSegmentDescriptor']=obj({'ordinal':integer(511),'byteOffset':integer(16777215),'rawByteLength':integer(32768,1),'sha256':ref('hash')})
d['changeSetSegment']=copy.deepcopy(d['changeSetSegmentDescriptor']);d['changeSetSegment']['properties']['dataBase64']={'type':'string','maxLength':43692,'pattern':'^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$'};d['changeSetSegment']['required'].append('dataBase64')
d['changeSetManifest']=obj({'documentKind':{'enum':['diff','undo-impact']},'documentHash':ref('hash'),'totalBytes':integer(16777216,2),'segmentCount':integer(512,1),'segments':arr(ref('changeSetSegmentDescriptor'),512,1)})
d['params_changeset.preview']={'oneOf':[obj({'projectId':ref('id'),'baseRevision':integer(),'intent':const('change'),'plan':ref('changeSetPlan')}),obj({'projectId':ref('id'),'baseRevision':integer(),'intent':const('undo'),'targetOperationId':ref('id')})]}
ready=obj({'status':const('ready'),'projectId':ref('id'),'baseRevision':integer(),'previewHash':ref('hash'),'preparedPlanRef':ref('hash'),'inputSnapshotId':ref('hash'),'parametersHash':ref('hash'),'intent':{'enum':['change','undo']},'targetOperationId':{'oneOf':[const(None),ref('id')]},'summary':text(512),'manifest':ref('changeSetManifest')})
conflict=obj({'status':const('conflict'),'projectId':ref('id'),'baseRevision':integer(),'previewHash':ref('hash'),'targetOperationId':ref('id'),'summary':text(512),'impactComplete':{'type':'boolean'},'manifest':ref('changeSetManifest')})
d['result_changeset.preview']={'oneOf':[ready,conflict]}
d['params_changeset.diff.page']=obj({'projectId':ref('id'),'previewHash':ref('hash'),'documentKind':{'enum':['diff','undo-impact']},'pageSize':integer(200,1),'cursor':{'oneOf':[const(None),ref('id')]}})
d['changeSetPage']=obj({'projectId':ref('id'),'previewHash':ref('hash'),'documentKind':{'enum':['diff','undo-impact']},'documentHash':ref('hash'),'segments':arr(ref('changeSetSegment'),200),'nextCursor':ref('id'),'complete':{'type':'boolean'}})
d['result_changeset.diff.page']=ref('changeSetPage')
d['params_changeset.confirm']=obj({'projectId':ref('id'),'previewHash':ref('hash'),'completionCursor':ref('id')})
d['result_changeset.confirm']=obj({'projectId':ref('id'),'previewHash':ref('hash'),'preparedPlanRef':ref('hash'),'confirmationRef':ref('id'),'inputSnapshotId':ref('hash'),'parametersHash':ref('hash')})
for method in ['changeset.preview','changeset.diff.page','changeset.confirm']:
 request=copy.deepcopy(d['request3']['oneOf'][1]);request['properties']['method']=const(method);request['properties']['params']=ref('params_'+method);d['request3']['oneOf'].append(request)
 for old in d['response3']['oneOf'][2:4]:
  response=copy.deepcopy(old);response['properties']['method']=const(method)
  if response['properties']['ok']['const']:response['properties']['result']=ref('result_'+method)
  d['response3']['oneOf'].append(response)
p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
