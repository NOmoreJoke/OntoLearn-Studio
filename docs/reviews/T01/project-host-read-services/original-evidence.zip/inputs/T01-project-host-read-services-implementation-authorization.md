# T01：可信项目宿主的一致读取服务实施

2026-10-21。原T01会话可继续独立实施真实Store上的有限目录/工作区读取，同时准备创建与只读对账的精确合同。不是整份H1–H3开工，不授任意位置IO、公开协议、main/preload/UI或默认生产3启用。

## 已决定的边界与依据

根全文读固定 `427ba7da6cc51016e98c15347e8b91a63f2c9232` 的29575B主计划/SHA `f7ee5b859e07f2fb37f101e089387cf6a1eb06a64073f60d43df4bfd0af6f64d`、16976B供方独审及根独审14032B/SHA `d02578f1cece68e88104cb0f3def8dc87d278bcc8bd6e665df32b1adf6747938`。16docs固定Git=current并根快照，14成员ZIP安全，计划层可接受；位置能力/创建claim/真实生命周期尚未ready。

采用真实**一库多项目、本地SQLite库文件**模型，不改为一项目一文件。库级catalog/create权限与单项目写scope必须分开，未来只由main实际位置能力/真实Store解析给scope，renderer UUID或picker结果不授权限。现961ce77仅metadata/contentIo unsupported不能授权首次header/catalog/Store/backup IO。I06另做真实project-open/create用途与inventory/生命周期合同；这不阻塞本内部读取服务。

unknown恢复选择**优先复用现有operation_claims/完整持久Job context的只读resolution**，不新增main意图账本、不重放写请求。若现有字段无法充分归因，必须在精确合同列缺口并保持unknown，不能用null marker/remembered猜未受理。创建采用engine分配真实公开UUID，完整原业务请求与单claim/单receipt同唯一Store事务；不借metadata操作伪装创建。具体claim命名空间/版本验证或最小DDL本阶段仅提交合同，未批准写实现。

## 独立新树及继承输入

核空后新建 `.worktrees/T01-project-host-read-services`、`feature/weekly-t01-project-host-read-services`，从批准 `5f910b52c69d86a1076b2032e5d3c63e715947f3` 开分支。只按 `T01-project-host-services-fixed-foundation-inputs.json`（12166B/SHA `d0c242de45aec840258b7b6f7f4ba4eb6fbdc35b8969a0cf69630d5b0123e1c6`）逐48路径采用固定5de内部T01源/测试组合，再只读保护。不得whole-commit复制其他私有产品/配置/证据或他树环境；5de和427ba原树继续冻结。

48继承项包含历史T01已根收口的task-runtime版本，仅用于本固定组合，不转回该测试维护权；当前唯一维护者仍I05。新树本阶段不能改任何继承项。AGENTS78df/common e437全文读取/同步，保护指南不stage。依赖/cache/build/log/临时DB独立；原5f锁/构建配置不变，root未批准新依赖。

## 只允许两条新代码/测试路径

1. `packages/engine/src/ontolearn_engine/project/project_host.py`：私有一致读取服务及必要有限DTO、校验、内存分页管理。
2. `packages/engine/tests/test_project_host_read_services.py`：真实SQLite/Store3测试。

可新增 `docs/iterations/T01/project-host-read-services.md`、`docs/iterations/T01/project-create-and-resolution-contract.md` 与 `docs/reviews/T01/project-host-read-services/` 实施/合同/独审/原件。其他共享产品、旧测试、storage/job_store/coordinator/format3/applications、canonical/errors、worker/resources、main/preload/App/构建/锁/CI均只读；实际必要额外路径先给反例和最小申请。

本模块只消费**已经由可信宿主持有的真实Store3连接**，不接收路径、不打开/创建/迁移库、不注册能力/RPC或制造许可对象。测试直接调用真实服务只证明服务机制，不证明用户位置许可或人类选择。

## 读取行为与验收

- 目录完整读取实际public_projects/projects/app_projects的一致集合；同名项目按真实公开UUID区分，包含真实archived元数据，不补公开映射、不自动修缺行、不伪造名称或项目。缺映射、悬空/不一致或损坏证据明确失败。冻结有限完整目录快照再分页，每页来自同一快照，不混入后续项目/metadata变化；不跨请求持长SQLite事务、不新增数据库连接。快照/页/游标/TTL/总留存必须有明确有限工程界和操作前计费/拒绝，满额整体失败，不静默截断；边界、单位、释放和取消语义在实现文档写实，不冒充Q5容量或性能通过。
- 工作区在同一只读事务核公开UUID→真实内部项目、domainRevision/既有inputSnapshot、metadataVersion/完整白名单metadata、operationSequence/既有checkpoint，以及**指定editor**的真实draft存在状态、generation/present/boundDomainRevision/contentHash/完整有界内容。未创建与持久墓碑、JSON null与SQL NULL分别表达，不从当前revision伪造草稿代次/墓碑；boundDomainRevision不充当CAS。无需返回完整domain事实或learning/audit数组。
- 根实际读到 `Store.snapshot/_snapshot` 会INSERT OR IGNORE，`JobStore.project_get`调用它，`public_project`也可补映射；本读取模块不得调用这些写路径。只读既有正确checkpoint/snapshot证据并验证与同事务状态一致；缺证据明确错误，不创建snapshot/placeholder补齐。完整DB逻辑dump和SQLite authorizer实际禁止INSERT/UPDATE/DELETE/DDL时仍能完成合法读取，作为零写证据；不只断言返回值。
- 私有输入/DTO用精确类型/有限字段、稳定顺序和完整编码预算；跨项目/reader实例/过期/伪造cursor、乱序/重放、末页释放、资源耗尽、metadata/draft损坏及后页失败均有真实反例。游标仅快照定位，不成为公开项目/文件/写授权。错误只传有限安全reason，无原路径/SQLite原异常/原内容。
- 至少真实多项目分页、同名/archived/metadata更新后旧快照不混页、缺映射拒绝且零补写、同读事务workspace身份一致、草稿缺失/墓碑/null/大内容及hash完整性、重开真实UUID稳定、资源/过期/错误零写；新服务/只读合同需要独立审查。正常 `npm run check`、必要source核验和新候选原件/失败保留按原要求，未改旧组合不重测旧树。

## 并行的创建/resolution精确合同

同一会话可拆独立docs任务，基于实际48组合冻结：库/项目/op身份、完整create业务请求/原子genesis+公开映射+唯一claim/receipt、精确重试与异请求拒绝、跨退出/重开验证、既有kind/context验证需改的最小字段/路径；若现操作表可承载就复用，不另建可变账本。现app_format.migration_id仅为逻辑证据，不能代真实位置/物理文件能力。

resolution只读真实claim/Job/context/receipt的充分投影，明确queued无marker、未知jobId/完整发现、当前项目许可/原请求归因、缺失/不完整保持unknown、跨Session只恢复原Job且绝不重放。若必须补持久字段/验证，列最小方案、完整预算/旧格式兼容及测试，等根精确批准。此docs不写创建、resolution、DDL、公共DTO或启动/宿主实现。

最终候选诚实列48精确继承+2新代码/测试及授权docs，逐原Git/hash/归档核同，独审冻结后不改。源读取服务可用不等于包、IPC、人类位置/完整Diff或FR完成；I06真实能力/生命周期、四入口/T09完整内容、编辑/Agent/全restore/学习及原44/57P0保留。指定同版双模型新审、CI/正常develop合并/远端门不变。无本机GUI/Electron/e2e/native/HMR/审查应用，无push/PR/merge或Goal重建。
