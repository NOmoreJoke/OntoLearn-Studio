"""Private producer catalog and identity constants owned by the original writer.

No public capability, permission, alternate Store or dispatcher is defined here.
"""

import json

from ontolearn_engine.storage import digest

PROFILE = "T01-store-profile/3"
READER = "t01-profile-reader/1"
FEATURES = {
    "profileRule": 1,
    "semanticJob": 1,
    "profileOrigin": 1,
    "entityMetadata": "absent",
    "ontologyPreparedProof": "absent",
}

TABLES = [
    (
        "profile_job_cache",
        "CREATE TABLE profile_job_cache("
        "job TEXT PRIMARY KEY NOT NULL REFERENCES jobs(id),"
        "state TEXT NOT NULL CHECK(state IN ('available','evicted')),"
        "manifest BLOB NOT NULL CHECK(typeof(manifest)='blob' "
        "AND length(manifest) BETWEEN 1 AND 262144))",
    ),
    (
        "profile_job_payload",
        "CREATE TABLE profile_job_payload("
        "job TEXT NOT NULL REFERENCES profile_job_cache(job),"
        "role TEXT NOT NULL CHECK(role IN "
        "('input-preimage','source-preimage','definitions-material')),"
        "ordinal INTEGER NOT NULL CHECK(typeof(ordinal)='integer' "
        "AND ordinal BETWEEN 0 AND 255),"
        "byte_offset INTEGER NOT NULL CHECK(typeof(byte_offset)='integer' "
        "AND byte_offset=ordinal*32768),"
        "chunk BLOB NOT NULL CHECK(typeof(chunk)='blob' "
        "AND length(chunk) BETWEEN 1 AND 32768 "
        "AND byte_offset+length(chunk)<=8388608),"
        "chunk_hash TEXT NOT NULL CHECK(typeof(chunk_hash)='text' "
        "AND length(chunk_hash)=64 AND instr(chunk_hash,char(0))=0 "
        "AND chunk_hash NOT GLOB '*[^0-9a-f]*'),"
        "PRIMARY KEY(job,role,ordinal))",
    ),
    (
        "profile_result_cache",
        "CREATE TABLE profile_result_cache("
        "result TEXT PRIMARY KEY NOT NULL REFERENCES job_results(id),"
        "job TEXT NOT NULL UNIQUE REFERENCES jobs(id),"
        "state TEXT NOT NULL CHECK(state IN ('available','evicted')),"
        "manifest BLOB NOT NULL CHECK(typeof(manifest)='blob' "
        "AND length(manifest) BETWEEN 1 AND 262144),"
        "origin BLOB NOT NULL CHECK(typeof(origin)='blob' "
        "AND length(origin) BETWEEN 1 AND 16777216))",
    ),
    (
        "profile_result_payload",
        "CREATE TABLE profile_result_payload("
        "result TEXT NOT NULL REFERENCES profile_result_cache(result),"
        "role TEXT NOT NULL CHECK(role IN ('payload-json','rows-json','worker-capture')),"
        "ordinal INTEGER NOT NULL CHECK(typeof(ordinal)='integer' "
        "AND ordinal BETWEEN 0 AND 255),"
        "byte_offset INTEGER NOT NULL CHECK(typeof(byte_offset)='integer' "
        "AND byte_offset=ordinal*32768),"
        "chunk BLOB NOT NULL CHECK(typeof(chunk)='blob' "
        "AND length(chunk) BETWEEN 1 AND 32768 "
        "AND byte_offset+length(chunk)<=8388608),"
        "chunk_hash TEXT NOT NULL CHECK(typeof(chunk_hash)='text' "
        "AND length(chunk_hash)=64 AND instr(chunk_hash,char(0))=0 "
        "AND chunk_hash NOT GLOB '*[^0-9a-f]*'),"
        "PRIMARY KEY(result,role,ordinal))",
    ),
]
TRIGGERS = []
for table in ("profile_job_payload", "profile_result_payload"):
    TRIGGERS.append(
        (
            f"immutable_{table}_UPDATE",
            f"CREATE TRIGGER immutable_{table}_UPDATE BEFORE UPDATE ON {table} "
            "BEGIN SELECT RAISE(ABORT,'immutable profile payload'); END",
        )
    )
for table, key in (("profile_job_cache", "job"), ("profile_result_cache", "result")):
    extra = " OR NEW.origin IS NOT OLD.origin OR NEW.job IS NOT OLD.job" if key == "result" else ""
    TRIGGERS.append(
        (
            f"immutable_{table}_UPDATE",
            f"CREATE TRIGGER immutable_{table}_UPDATE BEFORE UPDATE ON {table} "
            f"WHEN NEW.{key} IS NOT OLD.{key} OR NEW.manifest IS NOT OLD.manifest{extra} "
            "OR OLD.state='evicted' OR NEW.state!='evicted' "
            "BEGIN SELECT RAISE(ABORT,'immutable profile identity'); END",
        )
    )
    TRIGGERS.append(
        (
            f"immutable_{table}_DELETE",
            f"CREATE TRIGGER immutable_{table}_DELETE BEFORE DELETE ON {table} "
            "BEGIN SELECT RAISE(ABORT,'immutable profile history'); END",
        )
    )


def catalog_descriptor():
    from ontolearn_engine.job_store import JOB3_CATALOG, JOB3_SCHEMA
    from ontolearn_engine.project.format3 import TABLES as APP_TABLES
    from ontolearn_engine.project.format3 import TRIGGERS as APP_TRIGGERS

    return {
        "version": PROFILE,
        "features": dict(FEATURES),
        "reader": READER,
        "application": APP_TABLES + APP_TRIGGERS,
        "jobs": JOB3_SCHEMA + JOB3_CATALOG,
        "profile": TABLES + TRIGGERS,
        "storage": {
            "roles": "canonical-utf8-blob/1",
            "display": "canonical-utf8-blob/1",
            "checkpoint": 1,
            "applicationSchema": 1,
            "physicalFormat": 3,
        },
    }


def catalog_hash():
    return digest(catalog_descriptor())


def source_binding(store, project, snapshot_id, *, checkpoint_ref=None):
    """Bind only actual original Store material, including the complete CP1."""
    if getattr(store, "_profile", None) != PROFILE:
        raise ValueError("PROFILE_NOT_ENABLED")
    internal = store._project(project)
    snapshot = store._project_snapshot(snapshot_id, internal)
    checkpoint = store.project_checkpoint(internal, checkpoint_ref)
    return {
        "profileDefinitionSourceVersion": 1,
        "projectId": project,
        "internalProject": internal,
        "snapshot": snapshot_id,
        "revision": snapshot["projectRevision"],
        "vector": snapshot["dependencyVector"],
        "manifests": [
            {
                "layer": row["layer"],
                "id": row["id"],
                "payloadDigest": digest(json.loads(row["payload"])),
            }
            for row in snapshot["state"]["definitions"]
        ],
        "checkpointRef": digest(checkpoint),
        "checkpoint": checkpoint,
        "catalog": catalog_hash(),
    }


def validate_private_request(store, request):
    """A separate exact private grammar; the public ontology schema is unchanged."""
    from ontolearn_engine.project.profile_material import validate_definition

    if getattr(store, "_profile", None) != PROFILE or type(request) is not dict:
        raise ValueError("PROFILE_NOT_ENABLED")
    required = {"projectId", "baseRevision", "intent", "plan", "targetOperationId"}
    if (
        set(request) != required
        or request["intent"] != "change"
        or request["targetOperationId"] is not None
    ):
        raise ValueError("INVALID_PROFILE_PLAN")
    plan = request["plan"]
    if type(plan) is not dict or set(plan) - {"definitions", "manual", "remove_definitions"}:
        raise ValueError("INVALID_PROFILE_PLAN")
    for entry in plan.get("definitions", []):
        if type(entry) is not dict or set(entry) != {"layer", "id", "value"}:
            raise ValueError("INVALID_PROFILE_PLAN")
        if entry["layer"] not in {"rule", "query", "constraint"}:
            raise ValueError("INVALID_PROFILE_PLAN")
        validate_definition(entry["layer"], entry["id"], entry["value"])
    for entry in plan.get("manual", []):
        if type(entry) is not dict or set(entry) != {"id", "subject", "predicate", "object"}:
            raise ValueError("INVALID_PROFILE_PLAN")
        store._fact(entry)
    for entry in plan.get("remove_definitions", []):
        if (
            type(entry) is not dict
            or set(entry) != {"layer", "id"}
            or entry["layer"] not in {"rule", "query", "constraint"}
        ):
            raise ValueError("INVALID_PROFILE_PLAN")


def _profile_plan(plan):
    return any(
        row.get("layer") in {"rule", "query", "constraint"}
        for row in plan.get("definitions", []) or []
    ) or any(
        row.get("layer") in {"rule", "query", "constraint"}
        for row in plan.get("remove_definitions", []) or []
    )


def _plan_digest(plan):
    value = {key: plan.get(key) for key in ("definitions", "manual", "edits", "remove", "mapping")}
    if plan.get("remove_definitions") is not None:
        value["remove_definitions"] = plan["remove_definitions"]
    return digest(value)


def check_definition_write(store, project, base, plan, *, operation, job, preview_identity):
    """New reserved definitions require the original preview/accepted-Job scope."""
    if getattr(store, "_profile", None) != PROFILE:
        return
    if not _profile_plan(plan):
        return
    scope = getattr(store, "_profile_definition_scope", None)
    if scope != (project, base, _plan_digest(plan), operation, job, preview_identity):
        raise ValueError("PROFILE_DEFINITION_SCOPE_REQUIRED")
    from ontolearn_engine.project.profile_material import validate_definition

    vector = store.vector(project)
    for row in plan.get("definitions", []) or []:
        layer, identity, value = row["layer"], row["id"], row["value"]
        if layer not in {"rule", "query", "constraint"}:
            raise ValueError("INVALID_PROFILE_PLAN")
        old = store._db.execute(
            "SELECT payload FROM definitions WHERE project=? AND layer=? AND id=?",
            (project, layer, identity),
        ).fetchone()
        unchanged = old is not None and digest(json.loads(old[0])) == digest(value)
        revision = vector.get(layer + ":" + identity, 0) + (0 if unchanged else 1)
        validate_definition(layer, identity, value, revision=revision if layer == "rule" else None)


def reserved_compensation_changes(before, desired, current_retirements):
    """Compare original resolved state, without interpreting an undo selector.

    The actual Store owns shape/reference validation and all borrowed records'
    admission. This predicate neither resolves history nor grants a write.
    """
    layers = {"rule", "query", "constraint"}

    def definitions(state):
        return {
            (record["layer"], record["id"]): record["payload"]
            for record in state["definitions"]
            if record["layer"] in layers
        }

    def retirements(records):
        return {(layer, identity) for layer, identity in records if layer in layers}

    return definitions(before) != definitions(desired) or retirements(
        current_retirements
    ) != retirements(desired["retirements"])


def check_compensation_write(store, project, before, desired):
    if getattr(store, "_profile", None) == PROFILE and reserved_compensation_changes(
        before, desired, store.retirement_control(project)
    ):
        # An ordinary ontology/manual compensation remains valid. Reserved
        # effects need a separately specified confirmed Job/revision policy.
        raise ValueError("PROFILE_COMPENSATION_NOT_SUPPORTED")


class DefinitionScope:
    """Internal call scope: a preview rolls back; a commit needs the real Job."""

    def __init__(
        self, store, project, base, plan, *, job=None, operation=None, preview_identity=None
    ):
        from uuid import uuid4

        self.store, self.project, self.base, self.plan, self.job = store, project, base, plan, job
        self._write_operation = str(uuid4()) if job is None else operation
        self._write_job = str(uuid4()) if job is None else job
        self._preview_identity = preview_identity
        self.previous = None
        self.savepoint = None
        self._installed_scope = False

    @property
    def operation(self):
        return self._write_operation

    @property
    def write_job(self):
        return self._write_job

    def __enter__(self):
        from ontolearn_engine.storage import canonical

        if self._installed_scope:
            raise ValueError("PROFILE_SCOPE_ALREADY_ACTIVE")
        if getattr(self.store, "_profile", None) != PROFILE or not _profile_plan(self.plan):
            return self
        if self.job is not None:
            from ontolearn_engine.project.domain_changesets import (
                _current_profile_source,
                accepted_plan,
                unpack,
            )

            actual = self.store._job(self.job)
            context = self.store.job_context(self.job)
            if actual["state"] != "running" or context["capability"] != "changeset.commit":
                raise ValueError("PROFILE_DEFINITION_JOB_REQUIRED")
            envelope = accepted_plan(
                self.store,
                actual["projectId"],
                context["input"],
                context["confirmationRef"],
                context["snapshot"],
            )
            preview = unpack(envelope["preview"])
            if envelope.get("preparedChangeSetVersion") != 3 or (
                preview.project,
                preview.base,
                preview.plan_json,
            ) != (self.project, self.base, canonical(self.plan)):
                raise ValueError("PROFILE_DEFINITION_JOB_REQUIRED")
            if (
                self._write_operation != actual["operationId"]
                or self._write_job != actual["jobId"]
                or self._preview_identity != preview.identity
            ):
                raise ValueError("PROFILE_DEFINITION_JOB_REQUIRED")
            _current_profile_source(self.store, envelope)
        else:
            from uuid import uuid4

            if not self.store._db.in_transaction:
                raise ValueError("PROFILE_PREVIEW_TRANSACTION_REQUIRED")
            self.savepoint = "profile_preview_" + uuid4().hex
            self.store._db.execute("SAVEPOINT " + self.savepoint)
        self.previous = getattr(self.store, "_profile_definition_scope", None)
        self.store._profile_definition_scope = (
            self.project,
            self.base,
            _plan_digest(self.plan),
            self._write_operation,
            self._write_job,
            self._preview_identity,
        )
        self._installed_scope = True
        return self

    def __exit__(self, exc_type, first, traceback):
        if self._installed_scope:
            try:
                if self.savepoint is not None:
                    self.store._db.execute("ROLLBACK TO " + self.savepoint)
                    self.store._db.execute("RELEASE " + self.savepoint)
            except BaseException as cleanup:
                if first is None:
                    raise
                first.add_note("PROFILE_PREVIEW_CLEANUP_FAILED")
                self.store._cleanup_failures = getattr(self.store, "_cleanup_failures", []) + [
                    ("profilePreview", cleanup)
                ]
            finally:
                self.store._profile_definition_scope = self.previous
                self._installed_scope = False


def install_catalog(store, hook):
    """Called only by JobStore's private profile constructor after its front gate.

    New DDL and catalog signature changes share the original Store transaction.
    The original migration identity and historical schema constants are retained.
    """
    from ontolearn_engine.job_store import JOB3_HASH
    from ontolearn_engine.project.format3 import SCHEMA_HASH, Format3Fault, _schema

    if getattr(store, "_profile", None) != PROFILE:
        raise ValueError("PROFILE_NOT_ENABLED")
    app = store._db.execute("SELECT schema_hash FROM app_format WHERE singleton=1").fetchone()
    job = store._db.execute("SELECT schema_hash FROM job_format WHERE singleton=1").fetchone()
    expected = catalog_hash()
    if app is None or job is None:
        raise Format3Fault("structure")
    if (app[0], job[0]) == (expected, expected):
        for name, ddl in TABLES + TRIGGERS:
            row = store._db.execute(
                "SELECT sql FROM sqlite_master WHERE name=?", (name,)
            ).fetchone()
            if row is None or _schema(row[0]) != _schema(ddl):
                raise Format3Fault("structure")
        return
    if (app[0], job[0]) != (SCHEMA_HASH, JOB3_HASH):
        raise Format3Fault("structure")
    # A namespace collision is refused before any catalog alteration. Old opaque
    # material is never certified into profile identity by this DDL migration.
    for name, _ in TABLES + TRIGGERS:
        if store._db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (name,)).fetchone():
            raise Format3Fault("structure")
    with store._transaction(lambda phase: hook("profile_" + phase)):
        for name, sql in TABLES + TRIGGERS:
            store._db.execute(sql)
            hook("profile_ddl:" + name)
        for table in ("app_format", "job_format"):
            trigger = "immutable_" + table + "_UPDATE"
            original = store._db.execute(
                "SELECT sql FROM sqlite_master WHERE name=?", (trigger,)
            ).fetchone()
            if original is None:
                raise Format3Fault("structure")
            store._db.execute("DROP TRIGGER " + trigger)
            store._db.execute(
                "UPDATE " + table + " SET schema_hash=? WHERE singleton=1", (expected,)
            )
            store._db.execute(original[0])
            hook("profile_catalog:" + table)
        hook("profile_catalog_complete")


# Finite installed source layout for this private editable-source provider.
PROVIDER_FILES = (
    "packages/engine/src/ontolearn_engine/__init__.py",
    "packages/engine/src/ontolearn_engine/__main__.py",
    "packages/engine/src/ontolearn_engine/contract_probe.py",
    "packages/engine/src/ontolearn_engine/coordinator.py",
    "packages/engine/src/ontolearn_engine/invalidation.py",
    "packages/engine/src/ontolearn_engine/job_store.py",
    "packages/engine/src/ontolearn_engine/memory_guard.py",
    "packages/engine/src/ontolearn_engine/process_environment.py",
    "packages/engine/src/ontolearn_engine/profile_worker.py",
    "packages/engine/src/ontolearn_engine/project/__init__.py",
    "packages/engine/src/ontolearn_engine/project/applications.py",
    "packages/engine/src/ontolearn_engine/project/compensation.py",
    "packages/engine/src/ontolearn_engine/project/domain_changesets.py",
    "packages/engine/src/ontolearn_engine/project/draft_plan.py",
    "packages/engine/src/ontolearn_engine/project/format3.py",
    "packages/engine/src/ontolearn_engine/project/profile_artifacts.py",
    "packages/engine/src/ontolearn_engine/project/profile_budget.py",
    "packages/engine/src/ontolearn_engine/project/profile_jobs.py",
    "packages/engine/src/ontolearn_engine/project/profile_material.py",
    "packages/engine/src/ontolearn_engine/project/project_host.py",
    "packages/engine/src/ontolearn_engine/project/project_lifecycle.py",
    "packages/engine/src/ontolearn_engine/project/source_content.py",
    "packages/engine/src/ontolearn_engine/project/transactions.py",
    "packages/engine/src/ontolearn_engine/project/workspace.py",
    "packages/engine/src/ontolearn_engine/protocol.py",
    "packages/engine/src/ontolearn_engine/quality/__init__.py",
    "packages/engine/src/ontolearn_engine/quality/rule_calendar.py",
    "packages/engine/src/ontolearn_engine/quality/rule_comparator.py",
    "packages/engine/src/ontolearn_engine/quality/rule_firing.py",
    "packages/engine/src/ontolearn_engine/quality/rule_numbers.py",
    "packages/engine/src/ontolearn_engine/quality/rule_profile.py",
    "packages/engine/src/ontolearn_engine/quality/rule_revalidation.py",
    "packages/engine/src/ontolearn_engine/quality/rule_terms.py",
    "packages/engine/src/ontolearn_engine/rdf_snapshot.py",
    "packages/engine/src/ontolearn_engine/resources.py",
    "packages/engine/src/ontolearn_engine/semantic.py",
    "packages/engine/src/ontolearn_engine/semantic_error_adapter.py",
    "packages/engine/src/ontolearn_engine/semantic_execution.py",
    "packages/engine/src/ontolearn_engine/semantic_offline.py",
    "packages/engine/src/ontolearn_engine/semantic_profile_input.py",
    "packages/engine/src/ontolearn_engine/semantic_profile_probe.py",
    "packages/engine/src/ontolearn_engine/semantic_profile_production.py",
    "packages/engine/src/ontolearn_engine/semantic_profile_restore.py",
    "packages/engine/src/ontolearn_engine/semantic_profile_restore_budget.py",
    "packages/engine/src/ontolearn_engine/semantic_query.py",
    "packages/engine/src/ontolearn_engine/semantic_samples.py",
    "packages/engine/src/ontolearn_engine/semantic_scopes.py",
    "packages/engine/src/ontolearn_engine/semantic_turtle.py",
    "packages/engine/src/ontolearn_engine/storage.py",
    "packages/engine/src/ontolearn_engine/storage_probe.py",
    "packages/engine/src/ontolearn_engine/worker.py",
    "packages/contracts/python/contract_v2.py",
    "packages/contracts/v2/binding-regressions.json",
    "packages/contracts/v2/dependencies.json",
    "packages/contracts/v2/errors.json",
    "packages/contracts/v2/fixtures.json",
    "packages/contracts/v2/frame-fixtures.json",
    "packages/contracts/v2/registry.json",
    "packages/contracts/v2/schema.json",
    "packages/contracts/v2/states.json",
    "packages/engine/pyproject.toml",
    "uv.lock",
)


def resolve_provider(budget):
    """Resolve the installed internal source provider, without trusting caller IDs.

    Packaged T03 provenance and other target OS builds remain separate gates.
    This first private entry only accepts its bounded local source layout.
    """
    import hashlib
    import stat
    import sys

    from ontolearn_engine.project.profile_artifacts import ADAPTER_VERSION
    from ontolearn_engine.project.profile_budget import ProfileBudget
    from ontolearn_engine.resources import ROOT, semantic_identity
    from ontolearn_engine.semantic_profile_input import MATERIAL_VERSION
    from ontolearn_engine.semantic_profile_restore import FULL_RESULT_VERSION

    if type(budget) is not ProfileBudget or getattr(sys, "frozen", False):
        raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
    root = ROOT.parents[1].resolve()
    manifest = []
    holdings = []
    total = 0
    try:
        budget.debit("read_work", 32768 * len(PROVIDER_FILES), phase="provider:metadata")
        holdings.append(budget.hold("parent", 1048576, 16384, phase="provider:manifest"))
        for name in PROVIDER_FILES:
            path = root / name
            if not path.resolve().is_relative_to(root):
                raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
            before = path.lstat()
            if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= 8388608:
                raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
            total += before.st_size
            if total > 33554432:
                raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
            budget.debit("read_work", 16 * (before.st_size + 1), phase="provider:read-hash")
            held = budget.hold("parent", 2 * before.st_size + 4096, 16, phase="provider:file")
            holdings.append(held)
            with path.open("rb") as source:
                data = source.read(before.st_size + 1)
                after = source.fileno()
                import os

                actual = os.fstat(after)
            if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                actual.st_dev,
                actual.st_ino,
                actual.st_size,
                actual.st_mtime_ns,
            ) or len(data) != before.st_size:
                raise ValueError("PROFILE_PROVIDER_CHANGED")
            manifest.append(
                {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            )
            data = None
            holdings.pop()
            budget.release(held, phase="provider:file-dropped")
        implementation = semantic_identity(profile=True)
        if implementation["executionSemanticsVersion"] != "i05-finite-7":
            raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
        lock = next(row for row in manifest if row["path"] == "uv.lock")
        if lock["sha256"] != implementation["dependencyLockHash"]:
            raise ValueError("PROFILE_PROVIDER_CHANGED")
        descriptor = {
            "version": "t01-profile-provider/1",
            "profile": PROFILE,
            "implementation": implementation,
            "sourceLayout": "editable-source/1",
            "materialVersion": MATERIAL_VERSION,
            "captureVersion": "t01-profile-worker-capture/1",
            "fullviewVersion": FULL_RESULT_VERSION,
            "adapterVersion": ADAPTER_VERSION,
            "codeManifest": manifest,
        }
        from ontolearn_engine.storage import canonical

        budget.debit("read_work", 64 * 1048576, phase="provider:descriptor")
        encoded = canonical(descriptor).encode()
        if len(encoded) > 1048576:
            raise ValueError("PROFILE_PROVIDER_UNSUPPORTED")
        return descriptor, implementation, tuple(holdings)
    except BaseException as error:
        error.provider_holdings = tuple(holdings)
        raise


def decode_profile_capture(raw, material, budget):
    """Bounded capture-envelope codec; it never recomputes or invents original L.

    The original owned-process handle establishes origin separately. This checks
    bytes/types/actual admitted definitions and preserves the captured allocation.
    Full firing revalidation remains the original I05 restore operation.
    """
    import hashlib

    from ontolearn_engine.quality.rule_profile import BUDGET_VERSION, ProfileLimits
    from ontolearn_engine.semantic_execution import _profile_json_bytes, _ProfileProjection
    from ontolearn_engine.semantic_profile_restore import (
        _LIMITS,
        ChildAllocation,
        OriginalAllocation,
    )
    from ontolearn_engine.storage import canonical

    if type(raw) is not bytes or len(raw) > 8388608:
        raise ValueError("INVALID_PROFILE_CAPTURE")
    budget.debit("read_work", 64 * (len(raw) + 1), phase="capture:decode")
    held = budget.hold(
        "parent", 32 * len(raw) + 8192, 4 * min(len(raw), 65536) + 4096, phase="capture:decoded"
    )
    try:
        quoted = escaped = False
        depth = nodes = 0
        for char in raw:
            if quoted:
                if escaped:
                    escaped = False
                elif char == 92:
                    escaped = True
                elif char == 34:
                    quoted = False
            elif char == 34:
                quoted = True
                nodes += 1
            elif char in (91, 123):
                depth += 1
                nodes += 1
                if depth > 32:
                    raise ValueError("INVALID_PROFILE_CAPTURE")
            elif char in (93, 125):
                depth -= 1
                if depth < 0:
                    raise ValueError("INVALID_PROFILE_CAPTURE")
            elif char in (44, 58):
                nodes += 1
            if nodes > 65536:
                raise ValueError("INVALID_PROFILE_CAPTURE")
        if quoted or depth != 0:
            raise ValueError("INVALID_PROFILE_CAPTURE")

        def pairs(items):
            value = {}
            for key, item in items:
                if key in value:
                    raise ValueError("INVALID_PROFILE_CAPTURE")
                value[key] = item
            return value

        def invalid(_):
            raise ValueError("INVALID_PROFILE_CAPTURE")

        value = json.loads(
            raw,
            object_pairs_hook=pairs,
            parse_int=invalid,
            parse_float=invalid,
            parse_constant=invalid,
        )
        if (
            canonical(value).encode() != raw
            or type(value) is not dict
            or set(value)
            != {"version", "allocation", "actualDefinitions", "actualCatalog", "captureReceipt"}
            or value["version"] != "t01-profile-worker-capture/1"
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        allocation = value["allocation"]
        if (
            type(allocation) is not dict
            or set(allocation) != {"budgetVersion", "ruleIds", "disabledRuleIds", "children"}
            or allocation["budgetVersion"] != BUDGET_VERSION
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        if allocation["ruleIds"] != [spec.rule_id for spec in material.rules] or (
            allocation["disabledRuleIds"] != list(material.disabled_rule_ids)
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        children = allocation["children"]
        if type(children) is not list or len(children) != max(1, len(material.rules)):
            raise ValueError("INVALID_PROFILE_CAPTURE")

        def integer(item, maximum):
            if type(item) is not dict or set(item) != {"integerHex"}:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            text = item["integerHex"]
            if type(text) is not str or not text.startswith("0x") or not 3 <= len(text) <= 8194:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            if any(c not in "0123456789abcdef" for c in text[2:]):
                raise ValueError("INVALID_PROFILE_CAPTURE")
            number = int(text[2:], 16)
            if number > maximum or hex(number) != text:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            return number

        native = []
        for child in children:
            if type(child) is not dict or set(child) != {"ruleId", "definitionOrdinal", "limits"}:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            limits = child["limits"]
            if type(limits) is not dict or set(limits) != {"recordType", *[n for n, _ in _LIMITS]}:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            if limits["recordType"] != "ProfileLimits":
                raise ValueError("INVALID_PROFILE_CAPTURE")
            values = {name: integer(limits[name], maximum) for name, maximum in _LIMITS}
            ordinal = child["definitionOrdinal"]
            if ordinal is not None:
                ordinal = integer(ordinal, 99)
                if (
                    ordinal >= len(material.rules)
                    or child["ruleId"] != material.rules[ordinal].rule_id
                ):
                    raise ValueError("INVALID_PROFILE_CAPTURE")
            elif child["ruleId"] is not None or material.rules:
                raise ValueError("INVALID_PROFILE_CAPTURE")
            native.append(ChildAllocation(child["ruleId"], ordinal, ProfileLimits(**values)))
        ordered = tuple(sorted(enumerate(material.rules), key=lambda pair: pair[1].rule_id))
        expected_slots = [(ordinal, spec.rule_id) for ordinal, spec in ordered] or [(None, None)]
        if [(child.definition_ordinal, child.rule_id) for child in native] != expected_slots:
            raise ValueError("INVALID_PROFILE_CAPTURE")
        actual = _ProfileProjection().value(ordered)
        if actual != value["actualDefinitions"]:
            raise ValueError("INVALID_PROFILE_CAPTURE")
        catalog = value["actualCatalog"]
        if (
            type(catalog) is not dict
            or set(catalog) != {"recordType", "classes", "object_properties", "data_properties"}
            or catalog["recordType"] != "Catalog"
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        for key in ("classes", "object_properties", "data_properties"):
            if (
                type(catalog[key]) is not list
                or len(catalog[key]) > 4096
                or any(type(term) is not str or not 0 < len(term) <= 16384 for term in catalog[key])
            ):
                raise ValueError("INVALID_PROFILE_CAPTURE")
        from ontolearn_engine.semantic_profile_input import _LIVE, _WORK, CAPTURE_BUDGET_VERSION

        receipt = value["captureReceipt"]
        if (
            type(receipt) is not dict
            or set(receipt)
            != {
                "usage",
                "retained",
                "peaks",
                "caps",
                "stage_visits",
                "stage_bounds",
                "version",
                "retention_owner",
            }
            or receipt["version"] != CAPTURE_BUDGET_VERSION
            or (receipt["retention_owner"] != "receiving caller; raw/native references remain live")
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")

        def counters(items, names):
            if type(items) is not list or len(items) != len(names):
                raise ValueError("INVALID_PROFILE_CAPTURE")
            result = {}
            for pair, name in zip(items, names, strict=True):
                if type(pair) is not list or len(pair) != 2 or pair[0] != name:
                    raise ValueError("INVALID_PROFILE_CAPTURE")
                result[name] = integer(pair[1], (1 << 64) - 1)
            return result

        used = counters(receipt["usage"], _WORK)
        retained = counters(receipt["retained"], _LIVE)
        peaks = counters(receipt["peaks"], _LIVE)
        caps = counters(receipt["caps"], _WORK + _LIVE)
        if any(used[name] > caps[name] for name in _WORK) or any(
            not retained[name] <= peaks[name] <= caps[name] for name in _LIVE
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        visits, bounds = receipt["stage_visits"], receipt["stage_bounds"]
        if (
            type(visits) is not list
            or type(bounds) is not list
            or len(visits) != 8
            or len(bounds) != 8
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        visits = [integer(item, 805306368) for item in visits]
        bounds = [integer(item, 805306368) for item in bounds]
        if any(visit > bound for visit, bound in zip(visits, bounds, strict=True)) or (
            sum(visits) != used["traversal"]
        ):
            raise ValueError("INVALID_PROFILE_CAPTURE")
        original = OriginalAllocation(
            tuple(allocation["ruleIds"]),
            tuple(allocation["disabledRuleIds"]),
            tuple(native),
            allocation["budgetVersion"],
        )
        catalog_digest = hashlib.sha256(_profile_json_bytes(catalog)).hexdigest()
        return value, original, catalog_digest, held
    except BaseException as error:
        error.capture_holding = held
        raise


ROLE_GROUPS = {
    "job": ("input-preimage", "source-preimage", "definitions-material"),
    "result": ("payload-json", "rows-json", "worker-capture"),
}
ROLE_CHUNK = 32768
ROLE_MAX = 8388608
MANIFEST_MAX = 262144


def _role_require(condition):
    if not condition:
        raise ValueError("INVALID_PROFILE_ROLE_PACKET")


def encode_role_packet(roles, *, group, budget):
    """Copy bounded borrowed bytes into the exact persisted chunk representation.

    This is a data codec, not a SQL loader or an authorization receipt. The
    caller retains the original input holding. Returned tuples, manifest and
    failure tracebacks retain the transferred receipts until their owner drops
    every alias. Work is never refunded on invalid material.
    """
    import hashlib

    from ontolearn_engine.project.profile_budget import ProfileBudget
    from ontolearn_engine.storage import canonical

    holdings = []
    try:
        _role_require(type(budget) is ProfileBudget)
        _role_require(type(group) is str and len(group) <= 6 and group in ROLE_GROUPS)
        _role_require(type(roles) is dict and len(roles) == 3)
        _role_require(all(type(key) is str and len(key) <= 32 for key in roles))
        _role_require(set(roles) == set(ROLE_GROUPS[group]))
        _role_require(all(type(raw) is bytes and len(raw) <= ROLE_MAX for raw in roles.values()))
        size = sum(len(raw) for raw in roles.values())
        count = sum((len(raw) + ROLE_CHUNK - 1) // ROLE_CHUNK for raw in roles.values())
        budget.debit("read_work", 12 * (size + 1) + 2097152, phase="roles:encode-hash-copy")
        holdings.append(
            budget.hold("parent", 2 * size + 4194304, 64 * count + 8192, phase="roles:encoded")
        )
        manifest, rows = [], []
        for role in ROLE_GROUPS[group]:
            raw = roles[role]
            chunks = []
            for ordinal, offset in enumerate(range(0, len(raw), ROLE_CHUNK)):
                chunk = raw[offset : offset + ROLE_CHUNK]
                sha = hashlib.sha256(chunk).hexdigest()
                chunks.append(
                    {"ordinal": ordinal, "offset": offset, "bytes": len(chunk), "sha256": sha}
                )
                rows.append((role, ordinal, offset, chunk, sha))
            manifest.append(
                {
                    "role": role,
                    "bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "chunks": chunks,
                }
            )
        encoded = canonical(
            {"version": "t01-profile-role-manifest/1", "group": group, "roles": manifest}
        ).encode("utf-8", "strict")
        _role_require(len(encoded) <= MANIFEST_MAX)
        return encoded, tuple(rows), tuple(holdings)
    except BaseException as error:
        error.role_holdings = tuple(holdings)
        raise


def decode_role_packet(manifest, rows, *, group, budget):
    """Verify exact rows returned by a separately admitted bounded SQL reader.

    No cursor is advanced here. SQL work, native row buffers and the borrowed
    manifest/chunks require their own front-door reservations before this call.
    Missing, reordered, duplicate, trailing and altered chunks are corruption;
    legitimate eviction is decided by the original Store's cache-state branch.
    """
    import hashlib
    from types import MappingProxyType

    from ontolearn_engine.project.profile_budget import ProfileBudget
    from ontolearn_engine.storage import canonical

    holdings = []
    try:
        _role_require(type(budget) is ProfileBudget)
        _role_require(type(group) is str and len(group) <= 6 and group in ROLE_GROUPS)
        _role_require(type(manifest) is bytes and len(manifest) <= MANIFEST_MAX)
        _role_require(type(rows) is tuple and len(rows) <= 768)
        budget.debit("read_work", 64 * (len(manifest) + 1), phase="roles:manifest-decode")
        holdings.append(budget.hold("parent", 33554432, 131072, phase="roles:manifest"))
        depth = nodes = 0
        quoted = escaped = False
        for byte in manifest:
            if quoted:
                if escaped:
                    escaped = False
                elif byte == 92:
                    escaped = True
                elif byte == 34:
                    quoted = False
            elif byte == 34:
                quoted = True
                nodes += 1
            elif byte in (91, 123):
                depth += 1
                nodes += 1
                _role_require(depth <= 6)
            elif byte in (93, 125):
                depth -= 1
                _role_require(depth >= 0)
            elif byte in (44, 58):
                nodes += 1
            _role_require(nodes <= 20000)
        _role_require(not quoted and depth == 0)

        def pairs(items):
            value = {}
            for key, item in items:
                _role_require(key not in value)
                value[key] = item
            return value

        def integer(text):
            _role_require(len(text) <= 8 and text.isascii() and text.isdigit())
            return int(text)

        def invalid(_):
            raise ValueError("INVALID_PROFILE_ROLE_PACKET")

        value = json.loads(
            manifest,
            object_pairs_hook=pairs,
            parse_int=integer,
            parse_float=invalid,
            parse_constant=invalid,
        )
        _role_require(type(value) is dict and set(value) == {"version", "group", "roles"})
        _role_require(value["version"] == "t01-profile-role-manifest/1" and value["group"] == group)
        entries = value["roles"]
        _role_require(type(entries) is list and len(entries) == 3)
        size = count = 0
        hexchars = frozenset("0123456789abcdef")

        def sha256(value):
            _role_require(type(value) is str and len(value) == 64 and set(value) <= hexchars)

        for entry, role in zip(entries, ROLE_GROUPS[group], strict=True):
            _role_require(
                type(entry) is dict and set(entry) == {"role", "bytes", "sha256", "chunks"}
            )
            _role_require(entry["role"] == role)
            length = entry["bytes"]
            _role_require(type(length) is int and 0 <= length <= ROLE_MAX)
            sha256(entry["sha256"])
            chunks = entry["chunks"]
            _role_require(
                type(chunks) is list and len(chunks) == (length + ROLE_CHUNK - 1) // ROLE_CHUNK
            )
            for ordinal, chunk in enumerate(chunks):
                _role_require(
                    type(chunk) is dict and set(chunk) == {"ordinal", "offset", "bytes", "sha256"}
                )
                _role_require(all(type(chunk[k]) is int for k in ("ordinal", "offset", "bytes")))
                _role_require(
                    chunk["ordinal"] == ordinal and chunk["offset"] == ordinal * ROLE_CHUNK
                )
                _role_require(chunk["bytes"] == min(ROLE_CHUNK, length - ordinal * ROLE_CHUNK))
                sha256(chunk["sha256"])
            size += length
            count += len(chunks)
        _role_require(len(rows) == count and canonical(value).encode("utf-8", "strict") == manifest)
        budget.debit("read_work", 12 * (size + 1) + 4096 * count, phase="roles:verify-hash-copy")
        holdings.append(
            budget.hold("parent", 2 * size + 4096 * count + 4096, count + 64, phase="roles:decoded")
        )
        output, index = {}, 0
        for entry in entries:
            parts = []
            for chunk in entry["chunks"]:
                row = rows[index]
                index += 1
                _role_require(type(row) is tuple and len(row) == 5)
                role, ordinal, offset, raw, sha = row
                _role_require(type(role) is str and len(role) <= 32)
                _role_require(type(sha) is str and len(sha) == 64)
                _role_require(type(ordinal) is int and type(offset) is int)
                _role_require(
                    (role, ordinal, offset) == (entry["role"], chunk["ordinal"], chunk["offset"])
                )
                _role_require(
                    type(raw) is bytes and len(raw) == chunk["bytes"] and sha == chunk["sha256"]
                )
                _role_require(hashlib.sha256(raw).hexdigest() == sha)
                parts.append(raw)
            raw = b"".join(parts)
            _role_require(
                len(raw) == entry["bytes"] and hashlib.sha256(raw).hexdigest() == entry["sha256"]
            )
            output[entry["role"]] = raw
        return MappingProxyType(output), tuple(holdings)
    except BaseException as error:
        error.role_holdings = tuple(holdings)
        raise
