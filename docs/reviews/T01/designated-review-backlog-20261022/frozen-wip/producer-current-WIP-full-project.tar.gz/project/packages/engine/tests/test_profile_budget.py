"""Private owner accounting boundaries, independent of producer output."""

import pytest
from ontolearn_engine.project.profile_budget import (
    BOOK_SCALAR,
    BOOK_WORK,
    LIMITS,
    MAX_EVENTS,
    MAX_EXPORTS,
    Holding,
    ProfileBudget,
    ProfileLimit,
)


def test_business_exhaustion_does_not_consume_terminal_or_cancel():
    cost = ProfileBudget()
    cost.debit("raw", LIMITS["raw"], phase="input")
    with pytest.raises(ProfileLimit):
        cost.debit("raw", 1, phase="retry")
    cost.control("cancel", 1)
    cost.control("terminal", 1)
    assert cost.snapshot()["spent"]["raw"] == LIMITS["raw"]
    assert cost.snapshot()["control"]["terminal"] == 1


def test_holdings_are_owner_identity_and_work_is_never_refunded():
    cost = ProfileBudget()
    cost.debit("read_work", 42, phase="read")
    held = cost.hold("parent", 17, 3, phase="raw")
    with pytest.raises(ValueError, match="FOREIGN"):
        cost.release(Holding(held.ordinal, held.actor, held.scalar, held.objects), phase="fake")
    with pytest.raises(ValueError, match="REMAIN"):
        cost.close()
    cost.release(held, phase="dropped")
    with pytest.raises(ValueError, match="FOREIGN"):
        cost.release(held, phase="again")
    assert cost.snapshot()["spent"]["read_work"] == 42
    assert cost.snapshot()["held"]["parent"] == 0
    cost.close()


@pytest.mark.parametrize("amount", [-1, True, 1.0, None])
def test_costs_are_exact_unsigned_integers(amount):
    with pytest.raises(ValueError):
        ProfileBudget().debit("raw", amount, phase="input")


def test_library_holding_intersection_precedes_allocation():
    cost = ProfileBudget()
    first = cost.hold("parent", LIMITS["parent"] - BOOK_SCALAR, 0, phase="parent")
    second = cost.hold("worker", LIMITS["worker"], 0, phase="worker")
    with pytest.raises(ProfileLimit):
        cost.hold("worker", 1, 0, phase="overflow")
    cost.release(second, phase="child-exit")
    cost.release(first, phase="parent-drop")
    cost.close()


def test_zero_work_journal_is_finite_and_accounting_is_reserved():
    cost = ProfileBudget()
    for _ in range(1000):
        cost.debit("raw", 0, phase="zero")
        receipt = cost.hold("parent", 0, 0, phase="zero")
        cost.release(receipt, phase="zero")
    state = cost.snapshot()
    assert len(state["events"]) == 3000
    assert state["accounting"]["usedWork"] > 0
    assert state["accounting"]["totalHeldParent"] == BOOK_SCALAR
    assert state["accounting"]["totalReadWorkReservation"] == BOOK_WORK
    assert state is cost.snapshot()
    with pytest.raises(TypeError):
        state["held"]["parent"] = -1
    with pytest.raises(ValueError):
        cost.debit("raw", 0, phase="x" * 129)
    for _ in range(MAX_EVENTS):
        try:
            cost.debit("raw", 0, phase="fill")
        except ProfileLimit:
            break
    else:
        pytest.fail("journal did not stop")
    # Saturated business journal does not consume the three first control slots.
    cost.control("start", 1)
    cost.control("cancel", 1)
    cost.control("terminal", 1)


def test_snapshot_export_is_bounded_and_read_work_cannot_spend_audit_reserve():
    cost = ProfileBudget()
    for _ in range(MAX_EXPORTS):
        cost.debit("raw", 0, phase="state")
        cost.snapshot()
    cost.debit("raw", 0, phase="last")
    with pytest.raises(ProfileLimit):
        cost.snapshot()
    other = ProfileBudget()
    other.debit("read_work", LIMITS["read_work"] - BOOK_WORK, phase="business")
    with pytest.raises(ProfileLimit):
        other.debit("read_work", 1, phase="overflow")
    other.control("terminal", 1)


def test_outstanding_release_slots_survive_business_journal_saturation():
    cost = ProfileBudget()
    receipt = cost.hold("parent", 1, 1, phase="original")
    for _ in range(MAX_EVENTS):
        try:
            cost.debit("raw", 0, phase="fill")
        except ProfileLimit:
            break
    cost.release(receipt, phase="actual-drop")
    cost.control("terminal", 1)
    assert cost.snapshot()["held"]["parent"] == 0


def test_snapshot_normal_constructor_cannot_mutate_cached_evidence():
    cost = ProfileBudget()
    state = cost.snapshot()
    for view in (state, state["spent"], state["held"], state["accounting"]):
        with pytest.raises(TypeError, match="IMMUTABLE"):
            view.__init__({"raw": 23})
    assert cost.snapshot() is state
    assert state["spent"]["raw"] == 0


def test_control_is_one_whole_phase_prepayment_and_never_business_refill():
    from ontolearn_engine.project.profile_budget import CONTROL

    cost = ProfileBudget()
    cost.control("terminal", CONTROL["terminal"])
    for _ in range(MAX_EVENTS):
        try:
            cost.debit("raw", 0, phase="fill")
        except ProfileLimit:
            break
    # Duplicate issuance is invalid under the explicit single-phase contract,
    # rather than an audit-cap failure with purported cumulative quota left.
    with pytest.raises(ValueError, match="ALREADY_ISSUED"):
        cost.control("terminal", 1)
    cost.control("cancel", CONTROL["cancel"])
    cost.control("start", CONTROL["start"])
    state = cost.snapshot()
    assert state["control"] == dict(CONTROL)
    assert "whole-phase" in state["accounting"]["controlPolicy"]
    with pytest.raises(ValueError):
        ProfileBudget().control("terminal", 0)
