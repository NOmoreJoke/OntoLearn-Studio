"""Private catalog/provider units; no private Store readiness is fabricated."""

import hashlib
import json

from ontolearn_engine.job_store import JOB3_HASH
from ontolearn_engine.project.format3 import SCHEMA_HASH
from ontolearn_engine.project.profile_budget import ProfileBudget
from ontolearn_engine.project.profile_jobs import (
    FEATURES,
    PROFILE,
    PROVIDER_FILES,
    TABLES,
    catalog_descriptor,
    catalog_hash,
    resolve_provider,
)
from ontolearn_engine.resources import ROOT, semantic_identity
from ontolearn_engine.storage import digest


def test_catalog_is_one_exact_subset_with_original_history_hashes():
    app, job = SCHEMA_HASH, JOB3_HASH
    descriptor = catalog_descriptor()
    assert descriptor["version"] == PROFILE
    assert (
        descriptor["features"]
        == FEATURES
        == {
            "profileRule": 1,
            "semanticJob": 1,
            "profileOrigin": 1,
            "entityMetadata": "absent",
            "ontologyPreparedProof": "absent",
        }
    )
    assert descriptor["storage"] == {
        "roles": "canonical-utf8-blob/1",
        "display": "canonical-utf8-blob/1",
        "checkpoint": 1,
        "applicationSchema": 1,
        "physicalFormat": 3,
    }
    assert len(TABLES) == 4 and all("REFERENCES" in ddl for _, ddl in TABLES)
    assert catalog_hash() == digest(descriptor) not in {app, job}
    assert (SCHEMA_HASH, JOB3_HASH) == (app, job)


def test_provider_uses_installed_code_and_lock_and_transfers_live_receipt(tmp_path):
    budget = ProfileBudget()
    descriptor, implementation, holdings = resolve_provider(budget)
    assert implementation == semantic_identity(profile=True)
    assert descriptor["implementation"] == implementation
    rows = descriptor["codeManifest"]
    assert [row["path"] for row in rows] == list(PROVIDER_FILES)
    root = ROOT.parents[1]
    for row in rows:
        actual = (root / row["path"]).read_bytes()
        assert len(actual) == row["bytes"]
        assert hashlib.sha256(actual).hexdigest() == row["sha256"]
    assert len(holdings) == 1 and budget.snapshot()["held"]["parent"] > 0
    (tmp_path / "actual-provider.json").write_text(
        json.dumps(descriptor, ensure_ascii=False, indent=2) + "\n"
    )
    (tmp_path / "actual-cost.json").write_text(json.dumps(budget.snapshot(), indent=2) + "\n")
    # Drop real manifest/descriptor aliases before the explicit original release.
    descriptor = rows = implementation = actual = None
    held = holdings[0]
    holdings = None
    budget.release(held, phase="provider-descriptor-dropped")
    assert budget.snapshot()["held"]["parent"] == 0
    assert budget.snapshot()["accounting"]["totalHeldParent"] > 0


def test_capture_codec_preserves_actual_three_child_allocation_and_catalog(tmp_path):
    from ontolearn_engine.profile_worker import _capture
    from ontolearn_engine.project.profile_jobs import decode_profile_capture
    from ontolearn_engine.resources import CONTRACT
    from ontolearn_engine.semantic_profile_input import prepare_profile_material
    from ontolearn_engine.semantic_profile_production import execute_admitted_profile_job
    from test_semantic_profile_restore import rule, turtle

    material = prepare_profile_material(
        turtle(("20", "5")),
        (rule("z"), rule("a"), rule("disabled")),
        disabled_rule_ids=("disabled",),
    )
    production = execute_admitted_profile_job(
        material,
        error_catalog=CONTRACT.ERROR_CATALOG,
        error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
    )
    raw = _capture(production)
    budget = ProfileBudget()
    captured, allocation, catalog_digest, held = decode_profile_capture(raw, material, budget)
    assert allocation == production.original_allocation
    assert catalog_digest == hashlib.sha256(production.catalog_json).hexdigest()
    assert captured["actualDefinitions"]
    assert len(allocation.children) == 3
    assert all(len(child.limits.__dataclass_fields__) == 17 for child in allocation.children)
    (tmp_path / "actual-capture.json").write_bytes(raw)
    (tmp_path / "actual-cost.json").write_text(json.dumps(budget.snapshot(), indent=2) + "\n")
    assert held.actor == "parent" and budget.snapshot()["held"]["parent"] > 0


def test_capture_codec_rejects_receipt_and_slot_corruption():
    import copy

    import pytest
    from ontolearn_engine.profile_worker import _capture
    from ontolearn_engine.project.profile_jobs import decode_profile_capture
    from ontolearn_engine.resources import CONTRACT
    from ontolearn_engine.semantic_profile_input import prepare_profile_material
    from ontolearn_engine.semantic_profile_production import execute_admitted_profile_job
    from test_semantic_profile_restore import rule, turtle

    material = prepare_profile_material(turtle(), (rule("z"), rule("a")))
    produced = execute_admitted_profile_job(
        material,
        error_catalog=CONTRACT.ERROR_CATALOG,
        error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
    )
    original = json.loads(_capture(produced))
    changes = []
    bad = copy.deepcopy(original)
    bad["captureReceipt"]["version"] = "unknown"
    changes.append(bad)
    bad = copy.deepcopy(original)
    bad["captureReceipt"]["usage"][0][1] = {"integerHex": "0xffffffffffffffff"}
    changes.append(bad)
    bad = copy.deepcopy(original)
    bad["allocation"]["children"][1] = bad["allocation"]["children"][0]
    changes.append(bad)
    for value in changes:
        budget = ProfileBudget()
        raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
        with pytest.raises(ValueError) as caught:
            decode_profile_capture(raw, material, budget)
        assert caught.value.capture_holding.actor == "parent"
        assert budget.snapshot()["spent"]["read_work"] > 0


def test_role_packet_roundtrip_preserves_binary_bytes_and_exact_chunk_boundaries(tmp_path):
    from ontolearn_engine.project.profile_jobs import decode_role_packet, encode_role_packet

    budget = ProfileBudget()
    roles = {
        "input-preimage": b"\x00\xff" * 16384 + b"\x80",
        "source-preimage": "原始非空源\r\n".encode() * 4096,
        "definitions-material": b'{"rules":[]}',
    }
    manifest, rows, encoding_holds = encode_role_packet(roles, group="job", budget=budget)
    assert tuple(row[1:3] for row in rows if row[0] == "input-preimage") == ((0, 0), (1, 32768))
    assert all(len(row[3]) <= 32768 for row in rows)
    restored, decoding_holds = decode_role_packet(manifest, rows, group="job", budget=budget)
    assert dict(restored) == roles
    parsed = json.loads(manifest)
    for role in parsed["roles"]:
        assert role["sha256"] == hashlib.sha256(roles[role["role"]]).hexdigest()
        assert role["bytes"] == len(roles[role["role"]])
    (tmp_path / "actual-role-manifest.json").write_bytes(manifest)
    before = budget.snapshot()
    assert before["spent"]["read_work"] > sum(map(len, roles.values()))
    assert before["held"]["parent"] > 0
    holds = encoding_holds + decoding_holds
    manifest = rows = restored = parsed = role = encoding_holds = decoding_holds = None
    for held in holds:
        budget.release(held, phase="test:role-packet-dropped")
    assert budget.snapshot()["held"]["parent"] == 0


def test_role_packet_rejects_missing_reordered_duplicate_and_corrupt_chunks():
    import pytest
    from ontolearn_engine.project.profile_jobs import decode_role_packet, encode_role_packet
    from ontolearn_engine.storage import canonical

    roles = {"payload-json": b"x" * 32769, "rows-json": b"[]", "worker-capture": b"{}"}
    manifest, rows, _ = encode_role_packet(roles, group="result", budget=ProfileBudget())
    bad_rows = [rows[:-1], rows[::-1], rows + rows[:1], rows[:1] + rows[:1] + rows[2:]]
    first = rows[0]
    bad_rows.append(((first[0], first[1], first[2], b"y" + first[3][1:], first[4]),) + rows[1:])
    cases = [(manifest, value) for value in bad_rows]
    bad = json.loads(manifest)
    bad["roles"][0]["sha256"] = "0" * 64
    cases.append((canonical(bad).encode(), rows))
    bad = json.loads(manifest)
    bad["roles"][0]["chunks"][1]["offset"] += 1
    cases.append((canonical(bad).encode(), rows))
    cases.append((manifest + b" ", rows))
    cases.append((manifest.replace(b'"group":"result"', b'"group":"job"'), rows))
    cases.append((manifest.replace(b'"bytes":32769', b'"bytes":true', 1), rows))
    cases.append(
        (manifest.replace(b'"group":"result"', b'"group":"result","group":"result"'), rows)
    )
    for raw, row_values in cases:
        budget = ProfileBudget()
        with pytest.raises(ValueError) as caught:
            decode_role_packet(raw, row_values, group="result", budget=budget)
        assert caught.value.role_holdings
        assert budget.snapshot()["spent"]["read_work"] > 0


def test_role_packet_empty_and_full_single_role_with_limit_rejection():
    import pytest
    from ontolearn_engine.project.profile_jobs import (
        ROLE_MAX,
        decode_role_packet,
        encode_role_packet,
    )

    for size in (0, 32767, 32768, 32769, ROLE_MAX):
        budget = ProfileBudget()
        roles = {"input-preimage": b"a" * size, "source-preimage": b"", "definitions-material": b""}
        manifest, rows, _ = encode_role_packet(roles, group="job", budget=budget)
        restored, _ = decode_role_packet(manifest, rows, group="job", budget=budget)
        assert dict(restored) == roles
    roles["input-preimage"] += b"a"
    budget = ProfileBudget()
    with pytest.raises(ValueError) as caught:
        encode_role_packet(roles, group="job", budget=budget)
    assert caught.value.role_holdings == ()
    assert budget.snapshot()["spent"]["read_work"] == 0


def test_profile_wait_silent_operation_observes_cancel_and_retains_owned_task():
    import asyncio

    from ontolearn_engine.coordinator import _wait_profile_task

    async def case():
        waiting = asyncio.create_task(asyncio.Event().wait())
        observations = []

        def checkpoint():
            observations.append(True)
            if len(observations) == 3:
                raise asyncio.CancelledError()

        try:
            await _wait_profile_task(waiting, checkpoint=checkpoint, take=lambda _: None)
            raise AssertionError("silent task ignored cancellation")
        except asyncio.CancelledError:
            assert not waiting.done()
            assert len(observations) == 3
        finally:
            waiting.cancel()
            await asyncio.gather(waiting, return_exceptions=True)

    asyncio.run(case())


def test_profile_wait_takes_completed_value_before_rejecting_final_fence():
    import asyncio

    import pytest
    from ontolearn_engine.coordinator import _wait_profile_task

    async def case():
        value = object()
        owned = []

        async def completed():
            return value

        pending = asyncio.create_task(completed())
        await pending

        def checkpoint():
            assert owned == [value]
            raise asyncio.CancelledError()

        with pytest.raises(asyncio.CancelledError):
            await _wait_profile_task(pending, checkpoint=checkpoint, take=owned.append)
        assert pending.result() is value
        assert owned == [value]

    asyncio.run(case())


def test_profile_wait_startup_timeout_keeps_launch_task_for_original_owner_join():
    import asyncio
    import time

    import pytest
    from ontolearn_engine.coordinator import ServiceFault, _wait_profile_task

    async def case():
        pending = asyncio.create_task(asyncio.Event().wait())
        try:
            with pytest.raises(ServiceFault) as caught:
                await _wait_profile_task(
                    pending,
                    checkpoint=lambda: None,
                    take=lambda _: None,
                    phase_deadline=time.monotonic() - 1,
                )
            assert caught.value.code == "TIMEOUT"
            assert caught.value.params == {"phase": "startup"}
            assert not pending.done()
        finally:
            pending.cancel()
            await asyncio.gather(pending, return_exceptions=True)

    asyncio.run(case())


def test_role_packet_rejects_foreign_python_labels_without_invoking_equality():
    import pytest
    from ontolearn_engine.project.profile_jobs import decode_role_packet, encode_role_packet

    calls = []

    class ForeignText(str):
        __hash__ = str.__hash__

        def __eq__(self, other):
            calls.append(True)
            return True

    budget = ProfileBudget()
    foreign = {
        ForeignText(name): b""
        for name in ("input-preimage", "source-preimage", "definitions-material")
    }
    calls.clear()
    with pytest.raises(ValueError):
        encode_role_packet(foreign, group="job", budget=budget)
    assert calls == [] and budget.snapshot()["spent"]["read_work"] == 0
    manifest, rows, _ = encode_role_packet(
        {"payload-json": b"{}", "rows-json": b"[]", "worker-capture": b"{}"},
        group="result",
        budget=ProfileBudget(),
    )
    for index in (0, 4):
        row = list(rows[0])
        row[index] = ForeignText("wrong")
        calls.clear()
        with pytest.raises(ValueError):
            decode_role_packet(
                manifest, (tuple(row),) + rows[1:], group="result", budget=ProfileBudget()
            )
        assert calls == []
    with pytest.raises(ValueError):
        encode_role_packet({}, group="invalid-group", budget=ProfileBudget())


def test_role_packet_rejects_long_keys_before_set_copy(monkeypatch):
    import pytest
    from ontolearn_engine.project import profile_jobs

    calls = []

    def forbidden(*args):
        calls.append(True)
        raise AssertionError("set entered before key length bound")

    monkeypatch.setattr(profile_jobs, "set", forbidden, raising=False)
    budget = ProfileBudget()
    with pytest.raises(ValueError):
        profile_jobs.encode_role_packet(
            {"x" * 33: b"", "source-preimage": b"", "definitions-material": b""},
            group="job",
            budget=budget,
        )
    assert calls == [] and budget.snapshot()["spent"]["read_work"] == 0


def test_compensation_guard_compares_actual_reserved_effects_and_retirements():
    from copy import deepcopy

    from ontolearn_engine.project.profile_jobs import reserved_compensation_changes

    before = {
        "definitions": [
            {"layer": "rule", "id": "r", "payload": '{"revision":"2"}'},
            {"layer": "query", "id": "q", "payload": '{"text":"SELECT"}'},
            {"layer": "constraint", "id": "c", "payload": '{"enabled":false}'},
            {"layer": "ontology", "id": "o", "payload": '{"triples":[]}'},
        ],
        "facts": [],
    }
    desired = {**deepcopy(before), "retirements": [["ontology", "old"]]}
    desired["definitions"][-1]["payload"] = '{"triples":["changed ontology"]}'
    desired["facts"] = ["changed manual material"]
    assert not reserved_compensation_changes(before, desired, [])
    for layer in ("rule", "query", "constraint"):
        changed = deepcopy(desired)
        next(row for row in changed["definitions"] if row["layer"] == layer)["payload"] = "{}"
        assert reserved_compensation_changes(before, changed, [])
        removed = deepcopy(desired)
        removed["definitions"] = [row for row in removed["definitions"] if row["layer"] != layer]
        assert reserved_compensation_changes(before, removed, [])
        retired = deepcopy(desired)
        retired["retirements"].append([layer, "x"])
        assert reserved_compensation_changes(before, retired, [])
        assert reserved_compensation_changes(before, desired, [[layer, "x"]])
    stable = deepcopy(desired)
    stable["retirements"].append(["rule", "retired"])
    assert not reserved_compensation_changes(before, stable, [["rule", "retired"]])
