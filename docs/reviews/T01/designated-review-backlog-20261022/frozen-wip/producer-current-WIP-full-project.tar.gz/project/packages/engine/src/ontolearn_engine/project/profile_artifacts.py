"""Bounded immutable display/cache material, without Job or SQL authority.

The real owner validates claims, capture, scope and process termination. These
functions only transform already supplied data. Every holding (including failed
attempts retained by tracebacks) transfers to that owner; nothing is released
here. Dropping a Python local is not evidence that another reference disappeared.
"""

import hashlib
import json
import math
import re
from dataclasses import dataclass

from .profile_budget import Holding, ProfileBudget

ADAPTER_VERSION = "t01-profile-display-row/1"
CACHE_DOMAIN = "t01-profile-cache-key/1"
PRIVATE_IDENTITY_VERSION = "t01-profile-private-identity/1"
MAX_ROWS = 10000
MAX_CELLS = 64
MAX_CELL_SCALARS = 8192
MAX_BYTES = 8 * 1024 * 1024
MAX_SAFE = 9007199254740991
MAX_DEPENDENCIES = 4096
IDENTITY_KEYS = frozenset(
    {
        "version",
        "mode",
        "contextFingerprint",
        "providerDescriptorDigest",
        "inputDigest",
        "sourceDigest",
        "definitionsDigest",
        "payloadDigest",
        "privateRowsDigest",
        "displayDigest",
        "consumerSelection",
    }
)
IMPLEMENTATION_KEYS = frozenset(
    {"executionSemanticsVersion", "engineVersion", "dependencyLockHash"}
)
_UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
_HEX = frozenset("0123456789abcdef")


class ArtifactError(ValueError):
    """Private finite diagnostic; retained receipts are not release instructions."""

    def __init__(self, reason):
        super().__init__("INVALID_PROFILE_ARTIFACT")
        self.reason = reason
        self.artifact_holdings = ()


@dataclass(frozen=True, slots=True)
class DisplayArtifact:
    display_bytes: bytes
    display_digest: str
    private_rows_digest: str
    adapter_version: str
    row_count: int
    cell_count: int
    holdings: tuple[Holding, ...]


@dataclass(frozen=True, slots=True)
class CacheKeyArtifact:
    key: str
    canonical_bytes: bytes
    holdings: tuple[Holding, ...]


def _require(condition, reason):
    if not condition:
        raise ArtifactError(reason)


def _text(value, maximum, *, empty=False):
    _require(type(value) is str and (empty or bool(value)) and len(value) <= maximum, "TEXT")
    _require(all(not 0xD800 <= ord(c) <= 0xDFFF and c != "\0" for c in value), "UNICODE")


def _digest(value):
    _require(type(value) is str and len(value) == 64 and all(c in _HEX for c in value), "DIGEST")


def _encode(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8", "strict")


def _reject_object(_pairs):
    # Reject objects, including duplicate keys, before any public-row conversion.
    raise ArtifactError("ROW_OBJECT")


def _reject_constant(_value):
    raise ArtifactError("NUMBER")


def _integer(text):
    _require(len(text) <= 17, "NUMBER")
    value = int(text)
    _require(abs(value) <= MAX_SAFE, "NUMBER")
    return value


def _float(text):
    _require(len(text) <= 64, "NUMBER")
    value = float(text)
    _require(math.isfinite(value) and abs(value) <= MAX_SAFE, "NUMBER")
    return value


def _shape(raw):
    """One prepaid byte scan, no Unicode decode or materialized token collection.

    This is a depth/shape/count fence, not a second JSON decoder. The strict
    decoder still checks all JSON grammar. Quoted brackets and escaped quotes
    never affect depth; arrays below cells and every object are rejected here.
    """
    depth = rows = cells = row_cells = 0
    quoted = escaped = started = ended = False
    pending = True
    for byte in raw:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
            continue
        if byte in (9, 10, 13, 32):
            continue
        _require(not ended, "JSON")
        if byte == 91:
            _require(depth < 2, "DEPTH")
            if depth == 0:
                _require(not started, "JSON")
                started = True
            else:
                rows += 1
                _require(rows <= MAX_ROWS, "ROWS")
                row_cells, pending = 0, True
            depth += 1
        elif byte == 93:
            _require(depth > 0, "JSON")
            depth -= 1
            ended = depth == 0
        elif byte == 44:
            _require(depth in (1, 2), "JSON")
            if depth == 2:
                pending = True
        else:
            _require(depth == 2 and byte not in (123, 125), "ROW_SHAPE")
            if pending:
                cells += 1
                row_cells += 1
                _require(row_cells <= MAX_CELLS, "CELLS")
                pending = False
            if byte == 34:
                quoted = True
    _require(started and ended and not quoted and not escaped and depth == 0, "JSON")
    return rows, cells


def _cells(rows):
    _require(type(rows) is list and len(rows) <= MAX_ROWS, "ROWS")
    count = 0
    for row in rows:
        _require(type(row) is list and len(row) <= MAX_CELLS, "CELLS")
        count += len(row)
        for cell in row:
            kind = type(cell)
            if kind is str:
                _require(len(cell) <= MAX_CELL_SCALARS, "CELL_LENGTH")
                _require(all(not 0xD800 <= ord(c) <= 0xDFFF for c in cell), "UNICODE")
            elif kind in (int, float):
                _require(math.isfinite(cell) and abs(cell) <= MAX_SAFE, "NUMBER")
            else:
                _require(cell is None or kind is bool, "CELL_TYPE")
    return count


def adapt_display(rows_json: bytes, *, job_id, kind, budget):
    """Preserve private cells; return independently encoded public object rows.

    r/c come from the prepaid non-materializing scan. J=M+90r+32c bounds a
    public encoding even for invalid short-exponent numeric input: a bounded
    float may expand to <=24 characters before canonical equality rejects it.
    Canonical successful input has exactly its original cell encoding. Work,
    copy and hash are separate monotone events in the common read_work domain;
    SQL, persistence, later pages and the borrowed input's holding are NOT paid
    by this helper. Returned receipts retain a conservative allocation bound.
    """
    _require(type(budget) is ProfileBudget, "BUDGET")
    _require(type(rows_json) is bytes and len(rows_json) <= MAX_BYTES, "RAW_BYTES")
    holdings = []
    try:
        budget.debit("read_work", 4096, phase="display:identity")
        _require(type(job_id) is str and len(job_id) == 36 and _UUID.fullmatch(job_id), "JOB_ID")
        _text(kind, 128)
        size = len(rows_json)
        budget.debit("read_work", 16 * (size + 1), phase="display:syntax")
        holdings.append(budget.hold("parent", 4096, 64, phase="display:syntax"))
        rows_count, cell_count = _shape(rows_json)
        upper = size + 90 * rows_count + 32 * cell_count
        total = size + upper + 1
        budget.debit(
            "read_work", 64 * total + 256 * (rows_count + cell_count), phase="display:work"
        )
        budget.debit("read_work", 16 * total + 256 * rows_count, phase="display:copy")
        budget.debit("read_work", 4 * total + 256 * rows_count, phase="display:hash")
        holdings.append(
            budget.hold(
                "parent",
                8 * total + 1024 * rows_count,
                16 * (rows_count + cell_count) + 4096,
                phase="display:material",
            )
        )
        try:
            rows = json.loads(
                rows_json,
                object_pairs_hook=_reject_object,
                parse_constant=_reject_constant,
                parse_int=_integer,
                parse_float=_float,
            )
        except (UnicodeError, ValueError) as error:
            if isinstance(error, ArtifactError):
                raise
            raise ArtifactError("JSON") from None
        _require(_cells(rows) == cell_count and len(rows) == rows_count, "ROW_SHAPE")
        canonical = _encode(rows)
        _require(canonical == rows_json, "NONCANONICAL")
        private_digest = hashlib.sha256(rows_json).hexdigest()
        seed = (ADAPTER_VERSION + "\0" + job_id + "\0" + kind + "\0" + private_digest).encode()
        prefix = hashlib.sha256(seed).digest()[:12]
        public = []
        for ordinal, row in enumerate(rows):
            raw_id = bytearray(prefix + ordinal.to_bytes(4, "big"))
            raw_id[6] = (raw_id[6] & 15) | 64
            raw_id[8] = (raw_id[8] & 63) | 128
            hex_id = raw_id.hex()
            row_id = "-".join((hex_id[:8], hex_id[8:12], hex_id[12:16], hex_id[16:20], hex_id[20:]))
            public.append({"rowId": row_id, "ordinal": ordinal, "cells": row})
        encoded = _encode(public)
        _require(len(encoded) <= upper and len(encoded) <= MAX_BYTES, "DISPLAY_BYTES")
        return DisplayArtifact(
            encoded,
            hashlib.sha256(encoded).hexdigest(),
            private_digest,
            ADAPTER_VERSION,
            rows_count,
            cell_count,
            tuple(holdings),
        )
    except BaseException as error:
        error.artifact_holdings = tuple(holdings)
        raise


def _exact(value, keys):
    _require(type(value) is dict and len(value) == len(keys), "KEY_SHAPE")
    _require(all(type(k) is str for k in value) and set(value) == keys, "KEY_SHAPE")


def profile_cache_key(
    *,
    project,
    kind,
    snapshot,
    dependencies,
    implementation,
    adapter_version,
    trusted_private_identity,
    budget,
):
    """Canonical CL-01 content isolation only; the owner authenticates all inputs.

    The three material digests mean input-preimage/source-preimage/definitions-
    material, NOT the I05 payload's internal definitions digest. Producer only;
    consumer identity and its selection require a separately authorized version.
    No origin/cache key is an input to its own digest. No Store canonical helper
    or constructor is called, and no caller-owned dict survives in the output.
    """
    _require(type(budget) is ProfileBudget, "BUDGET")
    _require(
        type(dependencies) is dict and 0 < len(dependencies) <= MAX_DEPENDENCIES, "DEPENDENCIES"
    )
    holdings = []
    try:
        budget.debit("read_work", 4096 + 128 * len(dependencies), phase="cache:shape")
        holdings.append(
            budget.hold(
                "parent",
                256 * len(dependencies) + 4096,
                16 * len(dependencies) + 4096,
                phase="cache:shape",
            )
        )
        _exact(implementation, IMPLEMENTATION_KEYS)
        _exact(trusted_private_identity, IDENTITY_KEYS)
        names = [project, kind, snapshot, adapter_version]
        names.extend(dependencies)
        names.extend(implementation.values())
        names.extend(v for v in trusted_private_identity.values() if type(v) is str)
        _require(all(type(v) is str and len(v) <= 16384 for v in names), "KEY_TEXT")
        upper = 4096 + 6 * sum(len(v) for v in names) + 256 * len(dependencies)
        _require(upper <= MAX_BYTES, "KEY_BYTES")
        for category, amount in (
            ("work", 64 * (upper + 1)),
            ("copy", 16 * (upper + 1)),
            ("hash", 4 * (upper + 1)),
        ):
            budget.debit("read_work", amount, phase="cache:" + category)
        holdings.append(
            budget.hold(
                "parent", 8 * (upper + 1), 128 * len(dependencies) + 4096, phase="cache:material"
            )
        )
        _text(project, 16384)
        _text(kind, 128)
        _digest(snapshot)
        _require(adapter_version == ADAPTER_VERSION, "ADAPTER_VERSION")
        for name, version in dependencies.items():
            _text(name, 16384)
            _require(type(version) is int and 0 <= version <= MAX_SAFE, "DEPENDENCIES")
        for value in implementation.values():
            _text(value, 16384)
        _digest(implementation["dependencyLockHash"])
        identity = trusted_private_identity
        _require(
            type(identity["version"]) is str and identity["version"] == PRIVATE_IDENTITY_VERSION,
            "IDENTITY_VERSION",
        )
        _require(
            type(identity["mode"]) is str
            and identity["mode"] == "producer"
            and identity["consumerSelection"] is None,
            "MODE",
        )
        for name in IDENTITY_KEYS - {"version", "mode", "consumerSelection"}:
            _digest(identity[name])
        body = {
            "domain": CACHE_DOMAIN,
            "project": project,
            "kind": kind,
            "snapshot": snapshot,
            "dependencies": dependencies,
            "implementation": implementation,
            "adapterVersion": adapter_version,
            "trustedPrivateIdentity": identity,
        }
        encoded = _encode(body)
        _require(len(encoded) <= upper, "KEY_BYTES")
        return CacheKeyArtifact(hashlib.sha256(encoded).hexdigest(), encoded, tuple(holdings))
    except BaseException as error:
        error.artifact_holdings = tuple(holdings)
        raise
