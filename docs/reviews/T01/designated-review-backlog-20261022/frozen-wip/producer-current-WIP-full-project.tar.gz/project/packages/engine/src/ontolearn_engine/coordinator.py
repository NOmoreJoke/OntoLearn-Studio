"""Single application writer; isolated workers never open the SQLite source of truth."""

import asyncio
import json
import os
import queue
import signal
import sqlite3
import sys
import tempfile
import threading
import time
from collections import deque
from pathlib import Path
from uuid import uuid4

from ontolearn_engine import __version__
from ontolearn_engine.job_store import JobFault, JobStore
from ontolearn_engine.memory_guard import MEMORY_LIMIT_EXIT, resident_bytes
from ontolearn_engine.process_environment import worker_environment
from ontolearn_engine.protocol import JsonlReader, ProtocolFault
from ontolearn_engine.resources import CONTRACT, IMPLEMENTATION, LIMITS, REGISTRY_HASH, safe_error
from ontolearn_engine.storage import Conflict, UnsupportedProjectFormat
from ontolearn_engine.worker import worker_owner_arguments

TERMINAL = {"succeeded", "failed", "cancelled"}
_JOB_READY = object()


class StartupInitializationFailure(Exception):
    """Internal carrier created only after initialization cleanup was attempted."""

    def __init__(self, cause, cleanup_failures=(), reader_state=None):
        super().__init__("STARTUP_INITIALIZATION_FAILED")
        self.cause = cause
        self.cleanup_failures = tuple(cleanup_failures)
        self.reader_state = dict(reader_state or {})


def startup_code(error):
    from ontolearn_engine.project.format3 import Format3Fault

    if isinstance(error, UnsupportedProjectFormat):
        return "PROJECT_FORMAT_UNSUPPORTED"
    if isinstance(error, Format3Fault):
        if error.category == "leaseBusy":
            return "STORAGE_BUSY"
        if error.category == "structure":
            return "STORAGE_FAILURE"
    if isinstance(error, JobFault) and error.code == "STORAGE_BUSY":
        return "STORAGE_BUSY"
    if isinstance(error, sqlite3.Error):
        primary = getattr(error, "sqlite_errorcode", 0) & 0xFF
        if primary in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}:
            return "STORAGE_BUSY"
        if primary in {
            sqlite3.SQLITE_IOERR,
            sqlite3.SQLITE_FULL,
            sqlite3.SQLITE_READONLY,
            sqlite3.SQLITE_CORRUPT,
        }:
            return "STORAGE_FAILURE"
    return "INTERNAL_ERROR"


class ServiceFault(Exception):
    def __init__(self, code: str, params: dict | None = None):
        self.code = code
        self.params = params
        self.error = safe_error(code, params)


async def _wait_profile_task(task, *, checkpoint, take, phase_deadline=None):
    """Poll a real owned task without cancelling or abandoning its ownership.

    The caller retains and joins the exact task on failure. Take its completed
    value before the final fence: a concurrently completed child or handle must
    remain reachable even if cancellation/deadline rejects its business result.
    This is a waiting primitive, not a Store/worker or resource admission gate.
    """
    while not task.done():
        checkpoint()
        if phase_deadline is not None and time.monotonic() >= phase_deadline:
            raise ServiceFault("TIMEOUT", {"phase": "startup"})
        await asyncio.wait({task}, timeout=0.02)
    value = task.result()
    take(value)
    checkpoint()
    if phase_deadline is not None and time.monotonic() >= phase_deadline:
        raise ServiceFault("TIMEOUT", {"phase": "startup"})
    return value


def classify(
    error: Exception, *, resource: str = "job", field: str = "params", profile="legacy2"
) -> dict:
    formatter = CONTRACT.business3_error if profile == "business3" else safe_error
    if isinstance(error, ServiceFault):
        return formatter(error.code, error.params)
    if isinstance(error, (JobFault, Conflict)):
        return formatter(error.code, error.params)
    if isinstance(error, sqlite3.Error):
        primary = getattr(error, "sqlite_errorcode", 0) & 0xFF
        if primary in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}:
            return formatter("STORAGE_BUSY", {"retryAfterMs": 250})
        if primary in {
            sqlite3.SQLITE_IOERR,
            sqlite3.SQLITE_FULL,
            sqlite3.SQLITE_READONLY,
            sqlite3.SQLITE_CORRUPT,
        }:
            return formatter("STORAGE_FAILURE")
        return formatter("INTERNAL_ERROR")
    return formatter("INTERNAL_ERROR")


def worker_command() -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--worker"]
    return [sys.executable, "-I", "-m", "ontolearn_engine.worker"]


class Coordinator:
    def __init__(
        self,
        store,
        *,
        test_mode: bool = False,
        allowed_projects: set | None = None,
        limits: dict | None = None,
        emit=None,
        profile="legacy2",
        _ready=None,
    ):
        if profile not in {"legacy2", "business3"}:
            raise ValueError("INVALID_PROFILE")
        version = 3 if profile == "business3" else 2
        if getattr(store, "actual_format", 2) != version or (
            version == 3 and (_ready is not _JOB_READY or not isinstance(store, JobStore))
        ):
            raise ServiceFault("INVALID_STATE")
        self.profile = profile
        self.version = version
        self.validate = CONTRACT.validate_business3 if version == 3 else CONTRACT.validate
        self.methods = (
            CONTRACT.REGISTRY["foundationProfiles"]["business3"]["methods"]
            if version == 3
            else CONTRACT.REGISTRY["v2Runtime"]
        )
        self.store = store
        self.test_mode = test_mode
        self.allowed_projects = allowed_projects or set()
        self.limits = LIMITS | (limits or {})
        if not CONTRACT.validate("limits", self.limits):
            raise ValueError("INVALID_LIMITS")
        self.session = None
        # Attribution of the trusted stdio client, never proof of human consent.
        self.host_client_id = None
        self.seen = set()
        self.subscriptions = {}
        self.queued = deque()
        self.active = {}
        self.closed = False
        self._output = emit or self._emit
        self.emit = self._validated_emit
        self.tasks = set()

    @classmethod
    def profile_owner(cls, store, *, allowed_projects, emit=None):
        """Private real owner; no public RPC, test-mode or caller-ready boolean."""
        from ontolearn_engine.project.profile_jobs import PROFILE, catalog_hash

        if (
            not isinstance(store, JobStore)
            or getattr(store, "_profile", None) != PROFILE
            or not getattr(store, "_profile_installed", False)
            or getattr(store, "_profile_coordinator", None) is not None
        ):
            raise ServiceFault("INVALID_STATE")
        row = store._db.execute("SELECT schema_hash FROM app_format WHERE singleton=1").fetchone()
        if row is None or row[0] != catalog_hash():
            raise ServiceFault("INVALID_STATE")
        owner = cls(
            store,
            test_mode=False,
            allowed_projects=allowed_projects,
            emit=emit,
            profile="business3",
            _ready=_JOB_READY,
        )
        owner._profile_generation = (uuid4().int & ((1 << 63) - 1)) or 1
        store._profile_coordinator = owner
        return owner

    def create_profile_job(self, project, operation, input_):
        """Internal producer entry; implementation and original material are resolved by Store."""
        self._authorize({"projectId": project})
        if (
            self.closed
            or self.test_mode
            or getattr(self.store, "_profile_coordinator", None) is not self
        ):
            raise ServiceFault("INVALID_STATE")
        if len(self.queued) >= self.limits["maxQueuedJobs"] and not self.store.has_operation_claim(
            operation
        ):
            raise ServiceFault("QUEUE_FULL", {"retryAfterMs": 250})
        job = self.store.create_profile_job(
            self,
            project,
            operation,
            input_,
            self.limits,
            owner_generation=self._profile_generation,
        )
        if (
            job["state"] == "queued"
            and job["jobId"] not in self.queued
            and job["jobId"] not in self.active
        ):
            self.queued.append(job["jobId"])
        return job

    def _validated_emit(self, value):
        if not self.validate("envelope", value):
            raise ProtocolFault()
        self._output(value)

    @staticmethod
    def _emit(value: dict) -> None:
        raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
        if len(raw) > LIMITS["maxFrameBytes"]:
            raise ProtocolFault()
        sys.stdout.buffer.write(raw + b"\n")
        sys.stdout.buffer.flush()

    def _authorize(self, params: dict) -> str | None:
        project = params.get("projectId", params.get("binding", {}).get("projectId"))
        if project and project not in self.allowed_projects:
            raise ServiceFault("PERMISSION_DENIED")
        return project

    def _progress(self, job: dict, stage: str, subscription: str | None = None) -> None:
        # Progress is a disposable execution hint, never a persistent job state
        # or a guessed amount of work. Share the subscription sequence with state.
        if job["state"] in TERMINAL:
            return
        for identity, binding in list(self.subscriptions.items()):
            if (
                (subscription is None or identity == subscription)
                and binding["projectId"] == job["projectId"]
                and binding["jobId"] == job["jobId"]
                and binding["stateVersion"] == job["stateVersion"]
            ):
                binding["seq"] += 1
                self.emit(
                    {
                        "kind": "notification",
                        "protocolVersion": self.version,
                        "engineSessionId": self.session,
                        "subscriptionId": identity,
                        "projectId": job["projectId"],
                        "jobId": job["jobId"],
                        "seq": binding["seq"],
                        "event": "job.progress",
                        "data": {
                            "stateVersion": job["stateVersion"],
                            "progress": {"stage": stage, "completed": None, "total": None},
                        },
                    }
                )

    def _stage(self, identity: str, stage: str) -> None:
        active = self.active.get(identity)
        if active is None:
            return
        job = self.store.get_job(active["project"], identity)
        if job["state"] in TERMINAL:
            active.pop("stage", None)
            return
        if job["state"] == "cancelling":
            stage = "reconciling"
        if active.get("stage") != stage:
            active["stage"] = stage
            self._progress(job, stage)

    def _notify(self, job: dict) -> None:
        if job["state"] in TERMINAL:
            self.active.get(job["jobId"], {}).pop("stage", None)
        for identity, binding in list(self.subscriptions.items()):
            if binding["projectId"] == job["projectId"] and binding["jobId"] == job["jobId"]:
                if job["stateVersion"] <= binding["stateVersion"]:
                    continue
                binding["stateVersion"] = job["stateVersion"]
                binding["seq"] += 1
                self.emit(
                    {
                        "kind": "notification",
                        "protocolVersion": self.version,
                        "engineSessionId": self.session,
                        "subscriptionId": identity,
                        "projectId": job["projectId"],
                        "jobId": job["jobId"],
                        "seq": binding["seq"],
                        "event": "job.state",
                        "data": job,
                    }
                )

    def request(self, value: object) -> dict:
        # Unknown envelope/method/id is session-fatal: never reflect unknown wire data.
        if self.version == 3 and self.closed:
            raise ProtocolFault()
        if not isinstance(value, dict) or not CONTRACT.validate("id", value.get("id")):
            raise ProtocolFault()
        method = value.get("method")
        if not isinstance(method, str) or method not in self.methods:
            raise ProtocolFault()
        if value["id"] in self.seen or len(self.seen) >= 65536:
            raise ProtocolFault()
        self.seen.add(value["id"])
        required = {"kind", "id", "protocolVersion", "engineSessionId", "method", "params"}
        if set(value) != required or value["kind"] != "request":
            raise ProtocolFault()
        if self.version == 3 and (
            (method == "hello" and self.session is not None)
            or (
                method != "hello"
                and (
                    self.session is None
                    or value["engineSessionId"] != self.session
                    or type(value["protocolVersion"]) is not int
                    or value["protocolVersion"] != 3
                )
            )
        ):
            self.closed = True
            raise ProtocolFault()
        response = {
            "kind": "response",
            "id": value["id"],
            "method": method,
            "protocolVersion": 2 if method == "hello" else self.version,
            "engineSessionId": self.session,
        }
        try:
            expected = 2 if method == "hello" else self.version
            if type(value["protocolVersion"]) is not int or value["protocolVersion"] != expected:
                raise ServiceFault("VERSION_INCOMPATIBLE", {"supportedVersions": [self.version]})
            if method != "hello" and self.session is None:
                raise ServiceFault("HANDSHAKE_REQUIRED")
            if not self.validate("params_" + method, value["params"]):
                raise ServiceFault("INVALID_REQUEST", {"field": "params"})
            if method == "hello":
                if self.session is not None:
                    raise ServiceFault("INVALID_STATE")
                if value["engineSessionId"] is not None:
                    raise ServiceFault("SESSION_MISMATCH")
                if self.version not in value["params"]["supportedVersions"]:
                    raise ServiceFault(
                        "VERSION_INCOMPATIBLE", {"supportedVersions": [self.version]}
                    )
                if self.version == 3 and not self.validate("request", value):
                    raise ServiceFault("INVALID_REQUEST", {"field": "params"})
                self.session = str(uuid4())
                self.host_client_id = value["params"]["clientId"]
                response["engineSessionId"] = self.session
                data = {
                    "selectedVersion": self.version,
                    "engineVersion": __version__,
                    "engineSessionId": self.session,
                    "capabilities": self.methods,
                    "limits": self.limits,
                    "registryHash": REGISTRY_HASH,
                }
            else:
                if self.session is None:
                    raise ServiceFault("HANDSHAKE_REQUIRED")
                if value["engineSessionId"] != self.session:
                    raise ServiceFault("SESSION_MISMATCH")
                if self.version == 3 and not self.validate("request", value):
                    raise ServiceFault("INVALID_REQUEST", {"field": "params"})
                self._authorize(value["params"])
                data = self.dispatch(method, value["params"])
                if (
                    method in {"result.page", "job.list"}
                    and CONTRACT.encoded_size(data) > self.limits["maxPageBytes"]
                ):
                    raise ServiceFault("RESOURCE_LIMIT", {"resource": "page"})
            response.update(ok=True, result=data)
        except Exception as error:
            response.update(
                ok=False,
                error=classify(
                    error,
                    profile=self.profile,
                    resource="project"
                    if method == "project.get"
                    else "result"
                    if method.startswith("result.")
                    else "job",
                ),
            )
        if not self.validate("response", response):
            raise ProtocolFault()
        if self.version == 3 and method == "hello" and not response["ok"]:
            self.closed = True  # No second hello after a rejected3 bootstrap.
        return response

    def dispatch(self, method: str, p: dict):
        if method == "health":
            return {"status": "ok", "engineVersion": __version__}
        if method == "session.ping":
            return {"nonce": p["nonce"]}
        if method == "project.get":
            return self.store.project_get(p["projectId"])
        if method in {"changeset.preview", "changeset.diff.page", "changeset.confirm"}:
            if self.version != 3 or self.host_client_id is None or self.session is None:
                raise ServiceFault("METHOD_NOT_ALLOWED")
            origin = {
                "host_client_id": self.host_client_id,
                "engine_session_id": self.session,
            }
            if method == "changeset.preview":
                return self.store.preview_changeset(
                    p["projectId"], p["baseRevision"], p, limits=self.limits, **origin
                )
            if method == "changeset.diff.page":
                return self.store.changeset_diff_page(
                    p["projectId"],
                    p["previewHash"],
                    p["documentKind"],
                    p["pageSize"],
                    p["cursor"],
                    limits=self.limits,
                    **origin,
                )
            return self.store.confirm_changeset(
                p["projectId"], p["previewHash"], p["completionCursor"], **origin
            )
        if method == "job.get":
            return self.store.get_job(p["projectId"], p["jobId"])
        if method == "job.create":
            formal = self.version == 3 and p["capability"] == "changeset.commit"
            if not formal and (
                not self.test_mode
                or p["capability"]
                not in {
                    "test.read",
                    "test.atomic",
                    "test.rounds",
                }
            ):
                raise ServiceFault("UNSUPPORTED_CAPABILITY")
            if len(self.queued) >= self.limits[
                "maxQueuedJobs"
            ] and not self.store.has_operation_claim(p["operationId"]):
                raise ServiceFault("QUEUE_FULL", {"retryAfterMs": 250})
            if formal:
                job = self.store.create_changeset_job(
                    p["projectId"],
                    p["operationId"],
                    p["input"],
                    p["confirmationRef"],
                    IMPLEMENTATION,
                    self.limits,
                    host_client_id=self.host_client_id,
                    engine_session_id=self.session,
                )
            else:
                job = self.store.create_job(
                    p["projectId"],
                    p["operationId"],
                    p["capability"],
                    p["input"],
                    p["confirmationRef"],
                    IMPLEMENTATION,
                    self.limits,
                )
            if job["state"] == "queued" and job["jobId"] not in self.queued:
                self.queued.append(job["jobId"])
            return job
        if method == "job.cancel":
            answer = self.store.cancel_job(p["projectId"], p["jobId"])
            job = self.store.get_job(p["projectId"], p["jobId"])
            self._notify(job)
            if job["state"] == "cancelling":
                self._stage(job["jobId"], "reconciling")
            if job["state"] == "cancelled":
                try:
                    self.queued.remove(job["jobId"])
                except ValueError:
                    pass
            return answer  # Preserve exact cancellation linearization snapshot.
        if method == "job.subscribe":
            if len(self.subscriptions) >= 128:
                raise ServiceFault("RESOURCE_LIMIT", {"resource": "memory"})
            job = self.store.get_job(p["projectId"], p["jobId"])
            identity = str(uuid4())
            binding = {
                "subscriptionId": identity,
                "projectId": p["projectId"],
                "jobId": p["jobId"],
                "stateVersion": job["stateVersion"],
                "seq": 0,
            }
            self.subscriptions[identity] = binding
            # The stage snapshot may reach the consumer before this response.
            # Preserve seq=0 in the response; the first buffered hint is seq=1.
            response = dict(binding)
            stage = (
                "queued"
                if job["state"] == "queued"
                else self.active.get(job["jobId"], {}).get("stage")
            )
            if stage:
                self._progress(job, stage, identity)
            return response
        if method == "job.unsubscribe":
            binding = self.subscriptions.get(p["subscriptionId"])
            if binding is None or any(binding[k] != p[k] for k in ("projectId", "jobId")):
                raise ServiceFault("NOT_FOUND", {"resource": "subscription"})
            del self.subscriptions[p["subscriptionId"]]
            return {"subscriptionId": p["subscriptionId"], "unsubscribed": True}
        if method in {"job.list", "result.page"} and p["pageSize"] > self.limits["maxPageItems"]:
            raise ServiceFault("RESOURCE_LIMIT", {"resource": "page"})
        if method == "job.list":
            return self.store.job_list(**self._snake(p))
        if method == "result.get":
            return self.store.result_get(p["projectId"], p["resultId"])
        if method == "result.current":
            return self.store.result_current(**self._snake(p))
        if method == "result.page":
            return self.store.result_page(**self._snake(p))
        if method == "operation.get":
            return self.store.operation_get(p["projectId"], p["operationId"])
        raise ServiceFault("METHOD_NOT_ALLOWED")

    @staticmethod
    def _snake(p: dict) -> dict:
        names = {
            "projectId": "project",
            "resultId": "result_id",
            "pageSize": "page_size",
            "listSnapshotId": "list_snapshot_id",
            "definitionId": "definition_id",
            "parametersHash": "parameters_hash",
        }
        return {names.get(k, k): v for k, v in p.items()}

    async def tick(self) -> None:
        # Global concurrency and project single-writer are enforced before launch.
        if getattr(self.store, "_profile_coordinator", None) is self and self.closed:
            return
        occupied = {a["project"] for a in self.active.values() if a.get("writing", True)}
        for identity in list(self.queued):
            if (
                getattr(self.store, "_profile_coordinator", None) is self
                and identity in self.active
            ):
                self.queued.remove(identity)
                continue
            if len(self.active) >= self.limits["maxConcurrentJobs"]:
                break
            context = self.store.job_context(identity)
            job = context["job"]
            if int(time.time() * 1000) - job["createdAtMs"] >= job["limits"]["totalMs"]:
                self.queued.remove(identity)
                self._notify(
                    self.store.fail_job(identity, safe_error("TIMEOUT", {"phase": "total"}))
                )
                continue
            writing = CONTRACT.REGISTRY["capabilities"][job["capability"]]["effect"] != "read"
            if writing and job["projectId"] in occupied:
                continue
            self.queued.remove(identity)
            if writing:
                occupied.add(job["projectId"])
            active = {"project": job["projectId"], "process": None, "writing": writing}
            self.active[identity] = active
            task = asyncio.create_task(self.execute(identity, context, active))
            if getattr(self.store, "_profile_coordinator", None) is self:
                active["task"] = task
            self.tasks.add(task)
            task.add_done_callback(self.tasks.discard)

    async def execute_changeset(self, identity: str, context: dict, active: dict) -> None:
        """Execute a confirmed deterministic transaction in the sole writer.

        Acceptance is already durable. A normal dispatcher turn precedes the
        commit gate; an input-thread read alone never linearizes cancellation.
        No worker computation, test parameters or fabricated rows are involved.
        """
        try:
            job = self.store.start_job(identity)
            self._notify(job)
            self._stage(identity, "loading")
            deadline = (
                (job["createdAtMs"] + job["limits"]["totalMs"]) / 1000
                - time.time()
                + time.monotonic()
            )
            await asyncio.sleep(0)

            def boundary(_phase):
                current = self.store.get_job(active["project"], identity)
                if current["state"] == "cancelling":
                    raise asyncio.CancelledError()
                if time.monotonic() >= deadline:
                    raise ServiceFault("TIMEOUT", {"phase": "total"})

            boundary("before")
            self._stage(identity, "committing")
            job = self.store.commit_job(identity, hook=boundary)
            self._notify(job)
        except asyncio.CancelledError:
            job = self.store.get_job(active["project"], identity)
            if job["state"] in TERMINAL:
                self._notify(job)
            elif job["state"] == "cancelling":
                self._notify(self.store.cancelled_job(identity))
            else:
                self._notify(
                    self.store.fail_job(
                        identity, classify(ServiceFault("ENGINE_EXITED"), profile=self.profile)
                    )
                )
        except Exception as error:
            # A boundary may fail after COMMIT. Never rewrite persisted success.
            job = self.store.get_job(active["project"], identity)
            if job["state"] in TERMINAL:
                self._notify(job)
            else:
                self._notify(self.store.fail_job(identity, classify(error, profile=self.profile)))
        finally:
            self.active.pop(identity, None)

    async def execute(self, identity: str, context: dict, active: dict) -> None:
        if context.get("semanticInput", {}).get("version") == "t01-profile-semantic-input/1":
            await self.execute_profile(identity, context, active)
            return
        if context["capability"] == "changeset.commit":
            await self.execute_changeset(identity, context, active)
            return
        process = None
        try:
            job = self.store.start_job(identity)
            self._notify(job)
            self._stage(identity, "loading")
            parameters = context["parameters"]
            if job["capability"] == "test.rounds":
                self.store.start_job_run(identity, context["runConfig"])
            deadline = time.monotonic() + max(
                0, (job["createdAtMs"] + job["limits"]["totalMs"] - int(time.time() * 1000)) / 1000
            )

            def commit_boundary(_phase):
                if time.monotonic() >= deadline:
                    raise ServiceFault("TIMEOUT", {"phase": "total"})

            async def controlled(work, phase, maximum_ms, on_completed=None):
                pending = asyncio.create_task(work)
                phase_deadline = time.monotonic() + maximum_ms / 1000
                try:
                    while not pending.done():
                        if self.store.get_job(active["project"], identity)["state"] == "cancelling":
                            raise asyncio.CancelledError()
                        commit_boundary("waiting")
                        if time.monotonic() >= phase_deadline:
                            raise ServiceFault("TIMEOUT", {"phase": phase})
                        await asyncio.wait({pending}, timeout=0.02)
                    result = pending.result()
                    if on_completed:
                        on_completed(result)  # Take ownership before a deadline can reject it.
                    commit_boundary("completed")
                    return result
                finally:
                    if not pending.done():
                        pending.cancel()
                    await asyncio.gather(pending, return_exceptions=True)

            process = await controlled(
                asyncio.create_subprocess_exec(
                    *worker_command(),
                    *worker_owner_arguments(),
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL,
                    env=worker_environment(),
                    limit=self.limits["maxFrameBytes"] + 1,
                ),
                "startup",
                self.limits["startupMs"],
                lambda child: active.update(process=child),
            )
            active["process"] = process
            raw = json.dumps(
                {
                    "capability": job["capability"],
                    "parameters": parameters,
                    "memoryBytes": self.limits["maxWorkerMemoryBytes"],
                }
            ).encode()
            if len(raw) > self.limits["maxFrameBytes"]:
                raise ServiceFault("RESOURCE_LIMIT", {"resource": "frame"})
            process.stdin.write(raw + b"\n")
            await controlled(process.stdin.drain(), "startup", self.limits["startupMs"])
            process.stdin.close()
            self._stage(identity, "computing")
            reader = JsonlReader(self.limits["maxFrameBytes"])
            complete = False
            rows = None
            state = None
            read_task = asyncio.create_task(process.stdout.read(16384))
            try:
                while not complete:
                    job = self.store.get_job(active["project"], identity)
                    if job["state"] == "cancelling":
                        raise asyncio.CancelledError()
                    if time.monotonic() >= deadline:
                        raise ServiceFault("TIMEOUT", {"phase": "total"})
                    if sys.platform == "darwin" and process.returncode is None:
                        try:
                            if resident_bytes(process.pid) > job["limits"]["maxWorkerMemoryBytes"]:
                                raise ServiceFault("RESOURCE_LIMIT", {"resource": "memory"})
                        except ProcessLookupError:
                            pass  # Child exit is reconciled through its actual exit status.
                    done, _ = await asyncio.wait({read_task}, timeout=0.02)
                    if not done:
                        continue
                    chunk = read_task.result()
                    if not chunk:
                        reader.finish()
                        await controlled(process.wait(), "total", self.limits["totalMs"])
                        if process.returncode == MEMORY_LIMIT_EXIT:
                            raise ServiceFault("RESOURCE_LIMIT", {"resource": "memory"})
                        raise ServiceFault("ENGINE_EXITED")
                    framing_error = None
                    try:
                        messages = reader.feed(chunk)
                    except ProtocolFault as error:
                        messages, framing_error = error.frames, error
                    for message in messages:
                        if not isinstance(message, dict):
                            raise ProtocolFault()
                        if message.get("type") == "failure":
                            raise ServiceFault("INTERNAL_ERROR")
                        if message.get("type") == "round" and job["capability"] == "test.rounds":
                            if (
                                set(message) != {"type", "round", "state"}
                                or type(message["round"]) is not int
                                or not isinstance(message["state"], dict)
                            ):
                                raise ProtocolFault()
                            progress = self.store.get_job(active["project"], identity)[
                                "commitProgress"
                            ]["committedProgress"]
                            if (
                                message["round"]
                                != (progress["lastCommittedRound"] if progress else 0) + 1
                            ):
                                raise ProtocolFault()
                            state = message["state"]
                            self._stage(identity, "committing")
                            self.store.commit_job_round(identity, state, hook=commit_boundary)
                            self._notify(self.store.get_job(active["project"], identity))
                            self._stage(identity, "computing")
                            await asyncio.sleep(
                                0
                            )  # Allow control requests between committed rounds.
                        elif message.get("type") == "ready" and job["capability"] != "test.rounds":
                            if set(message) != {"type", "rows"} or not isinstance(
                                message["rows"], list
                            ):
                                raise ProtocolFault()
                            rows = message["rows"]
                        elif message == {"type": "complete"}:
                            complete = True
                            break  # No event after a worker terminal frame is applied.
                        else:
                            raise ProtocolFault()
                    if framing_error and not complete:
                        raise framing_error
                    if not complete:
                        read_task = asyncio.create_task(process.stdout.read(16384))
                reader.stop()
            finally:
                if not read_task.done():
                    read_task.cancel()
                await asyncio.gather(read_task, return_exceptions=True)
            self._stage(identity, "reconciling")
            exit_task = asyncio.create_task(process.wait())
            while process.returncode is None:
                if self.store.get_job(active["project"], identity)["state"] == "cancelling":
                    raise asyncio.CancelledError()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ServiceFault("TIMEOUT", {"phase": "total"})
                await asyncio.wait({exit_task}, timeout=min(0.02, remaining))
            if process.returncode != 0:
                raise ServiceFault("ENGINE_EXITED")
            if self.store.get_job(active["project"], identity)["state"] == "cancelling":
                raise asyncio.CancelledError()

            commit_boundary("before")
            self._stage(identity, "committing")
            if job["capability"] == "test.atomic":
                job = self.store.commit_job(identity, hook=commit_boundary)
            elif job["capability"] == "test.rounds":
                if state is None:
                    raise ProtocolFault()
                job = self.store.finish_job_run(
                    identity,
                    pending_events=state["pendingEvents"],
                    event_consumption=state["consumedEvents"],
                    hook=commit_boundary,
                )
            else:
                if rows is None:
                    raise ProtocolFault()
                job = self.store.finish_read_job(identity, rows, hook=commit_boundary)
            self._notify(job)
        except asyncio.CancelledError:
            process = process or active["process"]
            if process and process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), self.limits["cancelGraceMs"] / 1000)
                except TimeoutError:
                    process.kill()
                    await process.wait()
            job = self.store.get_job(active["project"], identity)
            if job["state"] == "cancelling":
                self._notify(self.store.cancelled_job(identity))
            else:
                self._notify(self.store.fail_job(identity, safe_error("ENGINE_EXITED")))
        except Exception as error:
            process = process or active["process"]
            if process and process.returncode is None:
                process.kill()
                await process.wait()
            self._notify(self.store.fail_job(identity, classify(error, profile=self.profile)))
        finally:
            self.active.pop(identity, None)

    async def execute_profile(self, identity, context, active):
        # Retain an unresolved record on bookkeeping or cleanup failure. Task
        # completion alone proves neither durable Job terminal nor released
        # resource ownership. stop/recovery must reconcile that same record.
        reconciled = False
        try:
            await self._execute_profile_owned(identity, context, active)
            reconciled = True
        finally:
            if reconciled and self.active.get(identity) is active:
                self.active.pop(identity, None)

    async def _execute_profile_owned(self, identity, context, active):
        """Original owner lifecycle; only complete drained output reaches Store success."""
        from ontolearn_engine.profile_worker import (
            FRAME_BYTES as PROFILE_FRAME_BYTES,
        )
        from ontolearn_engine.profile_worker import (
            abandon_profile_child_reservation,
            bind_profile_child,
            consume_profile_child,
            drain_failed_profile_child,
            drop_profile_child,
            release_failed_profile_child,
            reserve_profile_child,
            run_profile_child,
        )

        process = task = work = handle = delivery = reservation = None
        binding = None
        budget = None
        failure = None
        cleanup_error = None

        def remember_cleanup(error):
            nonlocal cleanup_error
            if cleanup_error is None:
                cleanup_error = error
            elif error is not cleanup_error:
                cleanup_error.add_note("ADDITIONAL_PROFILE_CLEANUP_FAILURE")

        def cleanup(call):
            try:
                return call()
            except BaseException as error:
                remember_cleanup(error)
                return None

        try:
            if self.test_mode or getattr(self.store, "_profile_coordinator", None) is not self:
                raise ServiceFault("INVALID_STATE")
            budget = self.store.profile_budget(identity)
            job = self.store.start_job(identity)
            self._notify(job)
            deadline = time.monotonic() + max(
                0, (job["createdAtMs"] + job["limits"]["totalMs"] - int(time.time() * 1000)) / 1000
            )

            def checkpoint():
                if self.store.get_job(active["project"], identity)["state"] == "cancelling":
                    raise asyncio.CancelledError()
                if time.monotonic() >= deadline:
                    raise ServiceFault("TIMEOUT", {"phase": "total"})
                if sys.platform == "darwin" and process is not None and process.returncode is None:
                    try:
                        if resident_bytes(process.pid) > job["limits"]["maxWorkerMemoryBytes"]:
                            raise ServiceFault("RESOURCE_LIMIT", {"resource": "memory"})
                    except ProcessLookupError:
                        pass

            binding = {
                "jobId": identity,
                "operationId": job["operationId"],
                "contextFingerprint": self.store.profile_context_fingerprint(identity),
                "dispatchOwnerGeneration": self._profile_generation,
            }
            checkpoint()
            roles = self.store.profile_input_roles(identity)
            reservation = reserve_profile_child(binding=binding, budget=budget)
            active["profileReservation"] = reservation
            startup_deadline = time.monotonic() + job["limits"]["startupMs"] / 1000
            task = asyncio.create_task(
                asyncio.create_subprocess_exec(
                    *worker_command(),
                    *worker_owner_arguments(),
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    env=worker_environment(),
                    limit=PROFILE_FRAME_BYTES,
                )
            )

            def take_process(value):
                nonlocal process
                process = value
                active["process"] = value
                bind_profile_child(reservation, process=value, binding=binding, budget=budget)

            await _wait_profile_task(
                task, checkpoint=checkpoint, take=take_process, phase_deadline=startup_deadline
            )
            self._stage(identity, "computing")
            work = asyncio.create_task(
                run_profile_child(
                    process,
                    binding=binding,
                    input_roles=roles,
                    budget=budget,
                    checkpoint=checkpoint,
                    reservation=reservation,
                )
            )

            def take_handle(value):
                nonlocal handle
                handle = value

            await _wait_profile_task(work, checkpoint=checkpoint, take=take_handle)
            self._stage(identity, "committing")
            result = self.store.finish_profile_read_job(
                identity,
                handle,
                owner=self,
                process=process,
                binding=binding,
                hook=lambda _: checkpoint(),
            )
            delivery = consume_profile_child(handle, process=process, binding=binding)
            handle = None
            self._notify(result)
        except BaseException as error:
            failure = error
        finally:
            if work is not None:
                if not work.done():
                    work.cancel()
                while not work.done():
                    try:
                        await asyncio.shield(work)
                    except asyncio.CancelledError:
                        continue
                    except BaseException:
                        break
                if work.done() and not work.cancelled():
                    try:
                        value = work.result()
                        if handle is None and delivery is None:
                            handle = value
                    except BaseException:
                        pass  # Original first failure remains the business cause.
            if task is not None and process is None:
                while not task.done():
                    try:
                        await asyncio.shield(task)
                    except asyncio.CancelledError:
                        continue
                    except BaseException:
                        break
                if task.done() and not task.cancelled():
                    try:
                        process = task.result()
                        active["process"] = process
                        bind_profile_child(
                            reservation, process=process, binding=binding, budget=budget
                        )
                    except BaseException:
                        # A known process remains reachable even if bind refuses
                        # its adapter. Its uncertain resources stay charged.
                        pass
            natural_delivery = handle is not None or delivery is not None
            if failure is not None:
                current = cleanup(lambda: self.store.get_job(active["project"], identity))
                if current is not None and current["state"] not in TERMINAL:
                    if current["state"] == "cancelling":
                        current = cleanup(lambda: self.store.cancelled_job(identity))
                    else:
                        current = cleanup(
                            lambda: self.store.fail_job(
                                identity, classify(failure, profile=self.profile)
                            )
                        )
                if current is not None:
                    cleanup(lambda: self._notify(current))
                # This records the business failure, while all raw/native tickets
                # are still held. It must not claim or perform resource release.
                cleanup(
                    lambda: self.store.profile_failed_owner(
                        identity, process, binding, classify(failure, profile=self.profile)
                    )
                )
                import traceback

                traceback.clear_frames(failure.__traceback__)
                failure.__traceback__ = None
                failure.__context__ = None
                failure.__cause__ = None
                roles = None
                if handle is not None:
                    cleanup(lambda: drop_profile_child(handle, process=process, binding=binding))
                    handle = None
                if process is not None and not natural_delivery:
                    try:
                        close = asyncio.create_task(
                            drain_failed_profile_child(process, binding=binding)
                        )
                        while not close.done():
                            try:
                                await asyncio.shield(close)
                            except asyncio.CancelledError:
                                continue
                        outcome = close.result()
                        if outcome["state"] != "forced-closed":
                            active["profileCleanup"] = outcome
                            raise ServiceFault("INVALID_STATE")
                        # Keep only a fixed literal after dropping the borrowed
                        # metadata and its completed Task result. The helper's
                        # cleanup holding still owns both until release below.
                        active["profileCleanup"] = "forced-closed"
                        outcome = close = None
                        cleanup(lambda: release_failed_profile_child(process, binding=binding))
                    except BaseException as error:
                        remember_cleanup(error)
                        if process.returncode is None:
                            # Unknown adapter cannot authorize release. Stop only
                            # this exact child; do not wait on unread pipe buffers.
                            cleanup(process.kill)
                elif process is None and reservation is not None and binding is not None:
                    cleanup(
                        lambda: abandon_profile_child_reservation(
                            reservation, binding=binding, budget=budget
                        )
                    )
                    active["profileCleanup"] = "launch-unknown"
                    remember_cleanup(ServiceFault("INVALID_STATE"))
            if delivery is not None:
                holding = delivery.holding
                roles = delivery = None
                cleanup(lambda: budget.release(holding, phase="profile-owner-delivery-dropped"))
            if cleanup_error is not None:
                # Task cancellation normalizes CancelledError at gather(); keep
                # an explicit unresolved record and expose cleanup failure as a
                # non-cancellation error. The original business cause survives.
                active["profileCleanupUnresolved"] = True
                if failure is not None:
                    failure.add_note("PROFILE_CLEANUP_FAILED")
                    if isinstance(failure, asyncio.CancelledError):
                        raise cleanup_error from failure
                    raise failure from cleanup_error
                raise cleanup_error

    async def stop(self) -> None:
        self.closed = True
        if getattr(self.store, "_profile_coordinator", None) is self:
            await self._stop_profile_owner()
            return
        for task in list(self.tasks):
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.subscriptions.clear()

    async def _stop_profile_owner(self):
        """Reconcile queued ownership before cancelling a possibly unstarted Task.

        This still depends on the original Store's admitted cancellation phase.
        A failed terminal write keeps its record for recovery, rather than
        treating a cancelled Python Task as a durable Job outcome.
        """
        first = None
        settled = {}
        records = dict(self.active)
        tasks = tuple(
            dict.fromkeys(
                [*self.tasks, *(r["task"] for r in records.values() if r.get("task") is not None)]
            )
        )
        for identity in dict.fromkeys([*self.queued, *records]):
            try:
                job = self.store._job(identity)
                if job["state"] not in TERMINAL:
                    self.store.cancel_job(job["projectId"], identity)
                    job = self.store._job(identity)
                if job["state"] in TERMINAL:
                    settled[identity] = job
                    if identity in self.queued:
                        self.queued.remove(identity)
            except BaseException as error:
                if first is None:
                    first = error
                else:
                    first.add_note("ADDITIONAL_PROFILE_STOP_RECONCILIATION_FAILURE")
        for task in tasks:
            task.cancel()
        joined = asyncio.gather(*tasks, return_exceptions=True)
        while not joined.done():
            try:
                await asyncio.shield(joined)
            except asyncio.CancelledError:
                continue  # Keep all exact owned Tasks through repeated stop cancellation.
        for result in joined.result():
            if isinstance(result, BaseException) and not isinstance(result, asyncio.CancelledError):
                if first is None:
                    first = result
                elif result is not first:
                    first.add_note("ADDITIONAL_PROFILE_STOP_TASK_FAILURE")
        for identity, record in records.items():
            try:
                job = self.store._job(identity)
                if job["state"] in TERMINAL:
                    settled[identity] = job
                else:
                    settled.pop(identity, None)
                    if identity not in self.active:
                        self.active[identity] = record
                    if first is None:
                        first = ServiceFault("INVALID_STATE")
            except BaseException as error:
                settled.pop(identity, None)
                if identity not in self.active:
                    self.active[identity] = record
                if first is None:
                    first = error
                elif error is not first:
                    first.add_note("ADDITIONAL_PROFILE_STOP_FINAL_READ_FAILURE")
        for identity, record in records.items():
            task = record.get("task")
            if record.get("profileCleanupUnresolved"):
                if identity not in self.active:
                    self.active[identity] = record
                if first is None:
                    first = ServiceFault("INVALID_STATE")
                else:
                    first.add_note("PROFILE_STOP_CLEANUP_UNRESOLVED")
            if (
                identity in settled
                and not record.get("profileCleanupUnresolved")
                and task is not None
                and task.done()
                and record.get("process") is None
                and self.active.get(identity) is record
            ):
                self.active.pop(identity)
        self.subscriptions.clear()
        if first is not None:
            raise first


async def serve(*, profile="legacy2", backup_path=None) -> dict:
    if profile not in {"legacy2", "business3"}:
        raise ValueError("INVALID_PROFILE")
    if backup_path is not None and (profile != "business3" or not Path(backup_path).is_absolute()):
        raise ValueError("INVALID_BACKUP")
    from ontolearn_engine.job_store import JobStore

    inbox = queue.Queue(maxsize=64)
    stopped = threading.Event()
    thread = None
    reader_state = {
        "threadCreated": False,
        "threadStartAttempted": False,
        "threadStarted": False,
        "stopRequested": False,
        "readerCreated": False,
        "readerStopAttempted": False,
        "readerStopped": False,
        "threadFinished": False,
        "threadAlive": False,
        "settled": False,
    }

    def read() -> None:
        reader = JsonlReader()
        reader_state["readerCreated"] = True
        try:
            while not stopped.is_set():
                # The daemon may still be blocked when a session-fatal request
                # closes the transport. Raw fd reads hold no BufferedReader lock
                # that could abort interpreter shutdown; normal cleanup still runs.
                chunk = os.read(sys.stdin.fileno(), 16384)
                if not chunk:
                    reader.finish()
                    break
                framing_error = None
                try:
                    frames = reader.feed(chunk)
                except ProtocolFault as error:
                    frames, framing_error = error.frames, error
                for frame in frames:
                    while not stopped.is_set():
                        try:
                            inbox.put(frame, timeout=0.05)
                            break
                        except queue.Full:
                            continue
                if framing_error:
                    raise framing_error
        except ProtocolFault:
            pass
        finally:
            # The reading thread exclusively owns parser state. The main thread
            # only requests stop; it cannot clear the buffer during feed().
            reader_state["readerStopAttempted"] = True
            reader.stop()
            reader_state["readerStopped"] = reader.terminal
            while not stopped.is_set():
                try:
                    inbox.put(None, timeout=0.05)
                    break
                except queue.Full:
                    continue
            reader_state["threadFinished"] = True

    temporary = store = coordinator = None
    previous_signal = None
    signal_installed = False
    initialization = True
    failure = None
    cleanup_failures = []
    try:
        temporary = tempfile.TemporaryDirectory(prefix="ontolearn-session-")
        database = os.environ.get("ONTOLEARN_DB_PATH", str(Path(temporary.name) / "engine.sqlite"))
        Path(database).parent.mkdir(parents=True, exist_ok=True)
        store = JobStore(
            database,
            contract=CONTRACT,
            target_format=3 if profile == "business3" else 2,
            backup_path=backup_path,
        )
        store.reconcile_jobs()  # Same lifetime lease; no old worker can commit.
        allowed = json.loads(os.environ.get("ONTOLEARN_ALLOWED_PROJECTS", "[]"))
        if not isinstance(allowed, list) or any(not CONTRACT.validate("id", p) for p in allowed):
            raise ValueError("INVALID_PROJECT_AUTHORIZATION")
        coordinator = Coordinator(
            store,
            test_mode=os.environ.get("ONTOLEARN_TEST_MODE") == "1",
            allowed_projects=set(allowed),
            profile=profile,
            _ready=_JOB_READY,
        )
        loop = asyncio.get_running_loop()
        previous_signal = signal.signal(
            signal.SIGTERM,
            lambda *_: loop.call_soon_threadsafe(setattr, coordinator, "closed", True),
        )
        signal_installed = True
        thread = threading.Thread(target=read, daemon=True)
        reader_state["threadCreated"] = True
        reader_state["threadStartAttempted"] = True
        thread.start()
        reader_state["threadStarted"] = True
        initialization = False
        handshake_deadline = time.monotonic() + LIMITS["handshakeMs"] / 1000
        while not coordinator.closed:
            if coordinator.session is None and time.monotonic() >= handshake_deadline:
                break
            try:
                value = inbox.get_nowait()
            except queue.Empty:
                await coordinator.tick()
                await asyncio.sleep(0.005)
                continue
            if value is None:
                break
            coordinator.emit(coordinator.request(value))
            await coordinator.tick()
            await asyncio.sleep(0)
    except (ProtocolFault, BrokenPipeError) as error:
        if initialization:
            failure = error
    except BaseException as error:
        failure = error
    finally:
        stopped.set()
        reader_state["stopRequested"] = stopped.is_set()
        if thread is not None:
            # is_alive is a bounded observation, not a join or permission to
            # close user stdin. An OS read may remain blocked until process exit.
            try:
                reader_state["threadStarted"] |= getattr(thread, "ident", None) is not None
                reader_state["threadAlive"] = thread.is_alive()
            except BaseException as error:
                reader_state["threadAlive"] = None
                cleanup_failures.append(("readerObservation", error))
        reader_state["settled"] = (thread is None and not reader_state["readerCreated"]) or (
            reader_state["threadStarted"]
            and reader_state["threadFinished"]
            and reader_state["readerStopped"]
            and reader_state["threadAlive"] is False
        )
        if coordinator is not None:
            try:
                await coordinator.stop()
            except BaseException as error:
                cleanup_failures.append(("coordinator", error))
        for name, action in (
            ("store", store.close if store is not None else None),
            (
                "signal",
                (lambda: signal.signal(signal.SIGTERM, previous_signal))
                if signal_installed
                else None,
            ),
            ("temporary", temporary.cleanup if temporary is not None else None),
        ):
            if action is not None:
                try:
                    action()
                except BaseException as error:
                    cleanup_failures.append((name, error))
    if failure is not None:
        if initialization and profile == "business3" and isinstance(failure, Exception):
            raise StartupInitializationFailure(
                failure, [name for name, _ in cleanup_failures], reader_state
            ) from None
        raise failure
    if cleanup_failures:
        raise cleanup_failures[0][1]
    return dict(reader_state)  # Internal observation only; never a wire ready/cleanup receipt.
