"""Private helper transport tests, distinct from original Coordinator admission.

Real Python pipes test the actual codec/computation. Synthetic peer scripts test
transport rejection only and confer no production or owner-monitor evidence.
"""

import asyncio
import hashlib
import io
import json
import os
import sys
from dataclasses import fields
from pathlib import Path
from unittest.mock import patch

import pytest
from ontolearn_engine import profile_worker as worker
from ontolearn_engine.project.profile_budget import ProfileBudget, ProfileLimit
from ontolearn_engine.quality.rule_profile import ProfileLimits
from ontolearn_engine.resources import CONTRACT, ROOT
from ontolearn_engine.semantic_profile_input import prepare_profile_material
from ontolearn_engine.semantic_profile_production import execute_admitted_profile_job
from test_semantic_profile_restore import rule, turtle

BINDING = dict(
    jobId="job-worker-test",
    operationId="operation-worker-test",
    contextFingerprint="a" * 64,
    dispatchOwnerGeneration=1,
)
CHILD = """
import json,sys
from ontolearn_engine.profile_worker import run_child
request=json.loads(sys.stdin.buffer.readline(4096))
run_child(request,reader=sys.stdin.buffer,writer=sys.stdout.buffer)
"""


def material_roles(kind="text"):
    specs = (rule("true"), rule("false", predicate="urn:unmatched"), rule("disabled"))
    text = turtle() + "<urn:unmatched> a <http://www.w3.org/2002/07/owl#DatatypeProperty> .\n"
    if kind == "structured":
        from ontolearn_engine.quality.rule_profile import TermInput

        records = (
            (TermInput("iri", "urn:s"), TermInput("iri", "urn:p"), TermInput("literal", "literal")),
        )
        material = prepare_profile_material(records=records, rules=())
    else:
        material = prepare_profile_material(text, specs, disabled_rule_ids=("disabled",))
    return material, dict(
        zip(
            worker.INPUT_ROLES,
            (material.input_preimage, material.source_preimage, material.definition_material),
            strict=True,
        )
    )


_SPAWNS = []


@pytest.fixture(autouse=True)
def record_actual_child_argv(tmp_path):
    _SPAWNS.clear()
    yield
    rows = []
    for process, row in _SPAWNS:
        rows.append({**row, "returncode": process.returncode})
        budget = getattr(process, "_profile_test_budget", None)
        owner = worker._BOUND.get(process) or worker._FAILED.get(process)
        if budget is None and owner is not None:
            budget = owner.pending[1]
        if type(budget) is ProfileBudget:
            # Failure evidence must survive assertions that precede save().
            (tmp_path / f"actual-child-fee-{process.pid}.json").write_text(
                json.dumps(
                    {
                        "events": budget._events,
                        "spent": budget._spent,
                        "held": budget._held,
                        "objects": budget._objects,
                        "receiptOrdinals": list(budget._receipts),
                        "auditWork": budget._audit_work,
                    },
                    indent=2,
                )
                + "\n"
            )
    (tmp_path / "actual-child-argv.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2) + "\n"
    )
    _SPAWNS.clear()


async def spawn(script, *, budget):
    reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
    process = await asyncio.create_subprocess_exec(
        sys.executable,
        "-u",
        "-c",
        script,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        limit=worker.FRAME_BYTES,
        env={**os.environ, "PYTHONHASHSEED": "0"},
    )

    argv = [sys.executable, "-u", "-c", script]
    worker.bind_profile_child(reservation, process=process, binding=BINDING, budget=budget)
    process._profile_test_reservation = reservation
    process._profile_test_budget = budget
    process._profile_test_argv = argv
    _SPAWNS.append((process, {"pid": process.pid, "argv": argv, "cwd": str(Path.cwd())}))
    return process


async def cleanup(process, binding=BINDING):
    if process in worker._BOUND:
        facts = await worker.drain_failed_profile_child(process, binding=binding)
        assert facts["state"] == "forced-closed", facts
        worker.release_failed_profile_child(process, binding=binding)
    else:
        if process.returncode is None:
            process.terminate()
        await process.wait()


def save(tmp_path, budget, process, extra=None):
    (tmp_path / "worker-audit.json").write_text(
        json.dumps(
            {
                "pid": process.pid,
                "argv": process._profile_test_argv,
                "cwd": str(Path.cwd()),
                "returncode": process.returncode,
                "budget": budget.snapshot(),
                "extra": extra,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )


@pytest.mark.parametrize("kind", ["text", "structured"])
def test_real_child_exact_roles_capture_and_single_consumption(kind, tmp_path):
    async def scenario():
        budget = ProfileBudget()
        material, inputs = material_roles(kind)
        process = await spawn(CHILD, budget=budget)
        checkpoints = []
        try:
            handle = await asyncio.wait_for(
                worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=inputs,
                    budget=budget,
                    checkpoint=lambda: checkpoints.append(1),
                    reservation=process._profile_test_reservation,
                ),
                20,
            )
            delivery = worker.validate_profile_child(handle, process=process, binding=BINDING)
            actual = execute_admitted_profile_job(
                material,
                error_catalog=CONTRACT.ERROR_CATALOG,
                error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
            )
            assert delivery.roles["payload-json"] == actual.payload_json
            assert delivery.roles["rows-json"] == actual.rows_json
            assert delivery.roles["worker-capture"] == worker._capture(actual)
            capture = json.loads(delivery.roles["worker-capture"])
            assert capture["version"] == worker.CAPTURE_VERSION
            assert len(capture["allocation"]["children"]) == max(1, len(material.rules))
            for captured, child in zip(
                capture["allocation"]["children"], actual.original_allocation.children, strict=True
            ):
                assert {k: v for k, v in captured["limits"].items() if k != "recordType"} == {
                    f.name: {"integerHex": hex(getattr(child.limits, f.name))}
                    for f in fields(ProfileLimits)
                }
            assert len(worker.LIMIT_FIELDS) == 17
            assert budget.snapshot()["held"]["worker"] == 0
            assert budget.snapshot()["held"]["parent"] > 0
            with pytest.raises(TypeError):
                delivery.roles["payload-json"] = b"wrong"
            with pytest.raises(worker.ProfileWorkerFault):
                worker.validate_profile_child(handle, process=object(), binding=BINDING)
            with pytest.raises(worker.ProfileWorkerFault):
                worker.validate_profile_child(
                    handle, process=process, binding={**BINDING, "dispatchOwnerGeneration": 2}
                )
            assert (
                worker.consume_profile_child(handle, process=process, binding=BINDING) is delivery
            )
            with pytest.raises(worker.ProfileWorkerFault):
                worker.consume_profile_child(handle, process=process, binding=BINDING)
            holding = delivery.holding
            del delivery, handle
            budget.release(holding, phase="test-received-bytes-dropped")
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            assert len(checkpoints) > 20
            save(tmp_path, budget, process, {"checkpoints": len(checkpoints), "mode": kind})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_handle_constructor_and_dict_cannot_issue():
    for handle in ({"success": True}, worker.ProfileChildHandle(), True):
        with pytest.raises(worker.ProfileWorkerFault):
            worker.validate_profile_child(handle, process=object(), binding=BINDING)


@pytest.mark.parametrize("size", [0, 1, 32767, 32768, 32769, 65536])
def test_single_json_chunk_bounds_zero_roles_and_exact_manifests(size):
    data = b"a" * size
    receiver = worker._Receiver(BINDING, "input", ("input-preimage",))
    messages = list(worker._messages(BINDING, "input", "input-preimage", data))
    for message in messages:
        raw = worker._line(message)
        assert raw.count(b"\n") == 1 and len(raw) <= 69633
        if message["type"] == "chunk":
            assert len(message["data"]) <= 65536 and message["length"] <= 32768
        receiver.accept(worker._frame(raw, BINDING))
    assert receiver.values["input-preimage"] == data
    manifest = receiver.manifests[0]
    assert manifest.length == size and manifest.sha256 == hashlib.sha256(data).hexdigest()
    assert sum(c.length for c in manifest.chunks) == size
    assert len(manifest.chunks) == (size + 32767) // 32768


@pytest.mark.parametrize(
    "mutation",
    [
        "uppercase",
        "wronghash",
        "wronglength",
        "unknownkey",
        "binding",
        "duplicate",
        "noncanonical",
        "float",
        "depth",
        "header",
        "frame",
    ],
)
def test_strict_frame_mutations(mutation):
    m = list(worker._messages(BINDING, "input", "input-preimage", b"ab"))[1]
    if mutation == "uppercase":
        m["data"] = "ABCD"
    elif mutation == "wronghash":
        m["sha256"] = "0" * 64
    elif mutation == "wronglength":
        m["length"] = True
    elif mutation == "unknownkey":
        m["extra"] = None
    elif mutation == "binding":
        m["binding"] = {**BINDING, "dispatchOwnerGeneration": 2}
    raw = worker._canonical(m) + b"\n"
    if mutation == "duplicate":
        raw = raw.replace(b"{", b'{"version":"bad",', 1)
    elif mutation == "noncanonical":
        raw = b" " + raw
    elif mutation == "float":
        raw = raw.replace(b'"length":2', b'"length":2.0')
    elif mutation == "depth":
        raw = b'{"a":' + b"[" * 10 + b"0" + b"]" * 10 + b"}\n"
    elif mutation == "header":
        m["role"] = "x" * 4097
        raw = worker._canonical(m) + b"\n"
    elif mutation == "frame":
        raw = b"x" * 69634 + b"\n"
    with pytest.raises(worker.ProfileWorkerFault):
        frame = worker._frame(raw, BINDING)
        receiver = worker._Receiver(BINDING, "input", ("input-preimage",))
        receiver.accept(list(worker._messages(BINDING, "input", "input-preimage", b"ab"))[0])
        receiver.accept(frame)


# Synthetic peers exercise framing/lifecycle only. They never call production.
PEER_PREFIX = """
import json,sys,time
from ontolearn_engine import profile_worker as w
binding=json.loads(sys.stdin.buffer.readline())["binding"]
r=w._Receiver(binding,"input",w.INPUT_ROLES)
while r.position<3:
 m=w._frame(sys.stdin.buffer.readline(w.FRAME_BYTES+1),binding)
 r.accept(m)
 sys.stdout.buffer.write(w._line(w._ack(m)));sys.stdout.buffer.flush()
"""
PEER_OUTPUT = """
for role in w.OUTPUT_ROLES:
 for m in w._messages(binding,"output",role,b""):
  sys.stdout.buffer.write(w._line(m));sys.stdout.buffer.flush()
  assert w._frame(sys.stdin.buffer.readline(w.FRAME_BYTES+1),binding)==w._ack(m)
sys.stdout.buffer.write(w._line(dict(version=w.VERSION,binding=binding,type="complete",phase="output",roles=3)))
sys.stdout.buffer.flush()
assert sys.stdin.buffer.read(1)==b""
"""


@pytest.mark.parametrize(
    "failure",
    [
        "tail",
        "doublecomplete",
        "nonzero",
        "earlyeof",
        "stderr",
        "wrongack",
        "outputearly",
        "extra-role",
    ],
)
def test_no_success_prefix_on_invalid_peer(failure, tmp_path):
    async def scenario():
        budget = ProfileBudget()
        if failure == "earlyeof":
            script = PEER_PREFIX
        elif failure == "stderr":
            script = (
                PEER_PREFIX
                + 'sys.stderr.buffer.write(b"x"*65537);sys.stderr.buffer.flush();time.sleep(5)\n'
            )
        elif failure == "wrongack":
            script = PEER_PREFIX.replace("w._ack(m)", '{**w._ack(m),"offset":123}', 1)
        elif failure == "outputearly":
            script = (
                "import sys,json\nfrom ontolearn_engine import profile_worker as w\n"
                'binding=json.loads(sys.stdin.buffer.readline())["binding"]\n'
                'm=next(w._messages(binding,"output","payload-json",b""))\n'
                "sys.stdout.buffer.write(w._line(m));sys.stdout.buffer.flush()\n"
            )
        elif failure == "extra-role":
            script = (
                PEER_PREFIX
                + 'm=next(w._messages(binding,"output","input-preimage",b""))\n'
                + "sys.stdout.buffer.write(w._line(m));sys.stdout.buffer.flush()\n"
            )
        else:
            script = PEER_PREFIX + PEER_OUTPUT
            if failure == "tail":
                script += 'sys.stdout.buffer.write(b"trailing\\n");sys.stdout.buffer.flush()\n'
            elif failure == "doublecomplete":
                script += (
                    'm=dict(version=w.VERSION,binding=binding,type="complete",phase="output",roles=3)\n'
                    "sys.stdout.buffer.write(w._line(m));sys.stdout.buffer.flush()\n"
                )
            else:
                script += "raise SystemExit(9)\n"
        process = await spawn(script, budget=budget)
        try:
            with pytest.raises((worker.ProfileWorkerFault, BrokenPipeError, ConnectionResetError)):
                await asyncio.wait_for(
                    worker.run_profile_child(
                        process,
                        binding=BINDING,
                        input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                        budget=budget,
                        checkpoint=lambda: None,
                        reservation=process._profile_test_reservation,
                    ),
                    10,
                )
            assert not any(v[0] is process for v in worker._ISSUED.values())
            assert budget.snapshot()["held"]["worker"] > 0
            if process.returncode is None:
                with pytest.raises(worker.ProfileWorkerFault):
                    worker.release_failed_profile_child(process, binding=BINDING)
            await cleanup(process)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(tmp_path, budget, process, {"syntheticFailure": failure, "script": script})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_cancel_keeps_real_child_holding_until_owner_wait(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        try:
            task = asyncio.create_task(
                worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                    budget=budget,
                    checkpoint=lambda: None,
                    reservation=process._profile_test_reservation,
                )
            )
            await asyncio.sleep(0.05)
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            assert process.returncode is None and budget.snapshot()["held"]["worker"] == 1024**3
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(process, binding=BINDING)
            await cleanup(process)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(tmp_path, budget, process, {"cancelled": True})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_final_checkpoint_rejection_retains_first_and_no_handle(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn(PEER_PREFIX + PEER_OUTPUT, budget=budget)
        first = RuntimeError("deadline")

        def checkpoint():
            if process.returncode is not None:
                raise first

        try:
            with pytest.raises(RuntimeError) as got:
                await worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                    budget=budget,
                    checkpoint=checkpoint,
                    reservation=process._profile_test_reservation,
                )
            assert got.value is first and not any(v[0] is process for v in worker._ISSUED.values())
            await cleanup(process)
            save(tmp_path, budget, process, {"lastFence": True})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_child_calls_unique_actual_production_once_and_rejects_changed_source():
    material, roles = material_roles()

    class Peer(io.BytesIO):
        def __init__(self):
            super().__init__()
            self.inbound = bytearray(
                b"".join(
                    worker._line(m)
                    for role in worker.INPUT_ROLES
                    for m in worker._messages(BINDING, "input", role, roles[role])
                )
            )

        def readline(self, n=-1):
            end = self.inbound.find(b"\n") + 1
            if not end:
                return b""
            result = bytes(self.inbound[:end])
            del self.inbound[:end]
            return result[:n]

        def read(self, n=-1):
            return b""

        def write(self, raw):
            message = worker._frame(raw, BINDING)
            if message["type"] in ("begin", "chunk", "end"):
                self.inbound.extend(worker._line(worker._ack(message)))
            return super().write(raw)

    peer = Peer()
    with patch.object(
        worker, "execute_admitted_profile_job", wraps=execute_admitted_profile_job
    ) as actual:
        worker.run_child(
            dict(profileWorkerVersion=1, binding=BINDING, memoryBytes=536870912),
            reader=peer,
            writer=peer,
        )
    assert actual.call_count == 1
    assert actual.call_args.args[0].input_preimage == material.input_preimage
    changed = {**roles, "source-preimage": b"null"}
    with pytest.raises((worker.ProfileWorkerFault, ValueError)):
        worker._material(changed)


def test_budget_reservation_precedes_stdin_write():
    budget = ProfileBudget()
    receipt = budget.hold("worker", 1, 0, phase="other-live-worker")
    with pytest.raises(ProfileLimit):
        worker.reserve_profile_child(binding=BINDING, budget=budget)
    assert budget.snapshot()["held"] == {"parent": 0, "worker": 1}
    budget.release(receipt, phase="other-dropped")


@pytest.mark.parametrize(
    "change", ["reorder", "repeat", "offset", "ordinal", "endhash", "short", "end-before-begin"]
)
def test_role_state_rejects_out_of_order_or_incomplete(change):
    messages = list(worker._messages(BINDING, "output", "payload-json", b"abc"))
    receiver = worker._Receiver(BINDING, "output", worker.OUTPUT_ROLES)
    if change == "end-before-begin":
        messages = [messages[-1]]
    elif change == "reorder":
        messages[0] = {**messages[0], "role": "rows-json"}
    elif change == "repeat":
        messages.insert(1, messages[0])
    elif change == "offset":
        messages[1] = {**messages[1], "offset": 1}
    elif change == "ordinal":
        messages[1] = {**messages[1], "ordinal": 2}
    elif change == "endhash":
        messages[-1] = {**messages[-1], "sha256": "0" * 64}
    else:
        messages.pop(1)
    with pytest.raises(worker.ProfileWorkerFault):
        for message in messages:
            receiver.accept(message)
    assert receiver.position == 0 and not receiver.values


@pytest.mark.parametrize("point", ["first", "write"])
def test_checkpoint_first_object_and_failed_cleanup_binding(point, tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn(CHILD, budget=budget)
        first = RuntimeError("checkpoint")
        writes = []
        original_write = process.stdin.write

        def counted_write(raw):
            writes.append(1)
            return original_write(raw)

        def checkpoint():
            if point == "first" or writes:
                raise first

        try:
            with patch.object(process.stdin, "write", side_effect=counted_write):
                with pytest.raises(RuntimeError) as got:
                    await worker.run_profile_child(
                        process,
                        binding=BINDING,
                        input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                        budget=budget,
                        checkpoint=checkpoint,
                        reservation=process._profile_test_reservation,
                    )
            assert got.value is first
            assert len(writes) == (0 if point == "first" else 1)
            assert budget.snapshot()["held"]["worker"] == 1024**3
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(
                    process, binding={**BINDING, "operationId": "other"}
                )
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(process, binding=BINDING)
            await cleanup(process)
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(process, binding=BINDING)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(tmp_path, budget, process, {"firstExceptionIdentity": True, "point": point})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_async_line_uses_bounded_reads_and_rejects_limit_plus_one():
    class Read:
        def __init__(self, data):
            self.data = data
            self.sizes = []

        async def read(self, size):
            self.sizes.append(size)
            result = self.data[:size]
            self.data = self.data[size:]
            return result

    async def scenario():
        budget = ProfileBudget()
        reader = Read(b"x" * (worker.FRAME_BYTES - 1) + b"\n")
        lines = worker._AsyncLines(reader, budget, lambda: None)
        assert len(await lines.line()) == worker.FRAME_BYTES
        assert await lines.line() == b""
        assert max(reader.sizes) <= 4096
        reader = Read(b"x" * worker.FRAME_BYTES + b"\n")
        lines = worker._AsyncLines(reader, ProfileBudget(), lambda: None)
        with pytest.raises(worker.ProfileWorkerFault):
            await lines.line()
        assert len(lines.buffer) == worker.FRAME_BYTES

    asyncio.run(scenario())


def test_input_mapping_snapshot_and_active_process_cannot_be_reentered(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn(CHILD, budget=budget)
        _, inputs = material_roles()
        original = dict(inputs)
        changed = False

        def checkpoint():
            nonlocal changed
            if not changed:
                changed = True
                inputs["input-preimage"] = b"caller changed after reservation"

        try:
            handle = await worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=inputs,
                budget=budget,
                checkpoint=checkpoint,
                reservation=process._profile_test_reservation,
            )
            assert inputs != original
            assert budget.snapshot()["spent"]["raw"] == sum(map(len, original.values()))
            delivery = worker.consume_profile_child(handle, process=process, binding=BINDING)
            holding = delivery.holding
            del delivery, handle
            budget.release(holding, phase="test-received-bytes-dropped")
            save(tmp_path, budget, process, {"callerInputMutationIsolated": True})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_completion_alone_does_not_release_worker_or_issue_handle(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn(
            PEER_PREFIX
            + PEER_OUTPUT
            + 'time.sleep(.2)\nsys.stderr.buffer.write(b"late stderr");sys.stderr.buffer.flush()\n',
            budget=budget,
        )
        task = asyncio.create_task(
            worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=process._profile_test_reservation,
            )
        )
        try:
            await asyncio.sleep(0.1)
            assert not task.done()
            assert budget.snapshot()["held"]["worker"] == 1024**3
            assert process in worker._ACTIVE
            with pytest.raises(worker.ProfileWorkerFault):
                await worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                    budget=ProfileBudget(),
                    checkpoint=lambda: None,
                    reservation=process._profile_test_reservation,
                )
            handle = await task
            delivery = worker.consume_profile_child(handle, process=process, binding=BINDING)
            holding = delivery.holding
            del handle, delivery
            budget.release(holding, phase="test-received-bytes-dropped")
            save(tmp_path, budget, process, {"completeBeforeExitRejected": True})
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            await cleanup(process)

    asyncio.run(scenario())


@pytest.mark.parametrize(
    "key,value", [("memoryBytes", 536870911), ("profileWorkerVersion", True), ("extra", False)]
)
def test_child_request_exact_keys_no_production_on_rejection(key, value):
    request = dict(profileWorkerVersion=1, binding=BINDING, memoryBytes=536870912)
    request[key] = value
    with patch.object(worker, "execute_admitted_profile_job") as compute:
        with pytest.raises(worker.ProfileWorkerFault):
            worker.run_child(request, reader=io.BytesIO(), writer=io.BytesIO())
    compute.assert_not_called()


def test_output_charge_rejects_before_any_role_buffer():
    from ontolearn_engine.project.profile_budget import LIMITS

    budget = ProfileBudget()
    budget.debit("evidence", LIMITS["evidence"] - 2, phase="earlier-retained-evidence")
    receiver = worker._Receiver(BINDING, "output", worker.OUTPUT_ROLES, budget)
    message = next(worker._messages(BINDING, "output", "payload-json", b"abc"))
    with pytest.raises(ProfileLimit):
        receiver.accept(message)
    assert receiver.raw is None and receiver.active is None and not receiver.values
    assert budget.snapshot()["spent"]["evidence"] == LIMITS["evidence"] - 2


@pytest.mark.parametrize("remaining", [2, 3, 4])
def test_evidence_budget_exact_plus_minus_one(remaining):
    from ontolearn_engine.project.profile_budget import LIMITS

    budget = ProfileBudget()
    budget.debit("evidence", LIMITS["evidence"] - remaining, phase="earlier-evidence")
    receiver = worker._Receiver(BINDING, "output", worker.OUTPUT_ROLES, budget)
    messages = list(worker._messages(BINDING, "output", "payload-json", b"abc"))
    if remaining == 2:
        with pytest.raises(ProfileLimit):
            receiver.accept(messages[0])
        assert receiver.raw is None
    else:
        for message in messages:
            receiver.accept(message)
        assert receiver.values["payload-json"] == b"abc"
        assert budget.snapshot()["spent"]["evidence"] == LIMITS["evidence"] - remaining + 3


def test_repeated_cancellation_joins_owned_read_tasks_before_cleanup(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        original = process.stdout
        entered = asyncio.Event()
        finished = asyncio.Event()

        class SlowRead:
            async def read(self, n):
                try:
                    return await original.read(n)
                finally:
                    entered.set()
                    await asyncio.sleep(0.05)
                    finished.set()

        process.stdout = SlowRead()
        task = asyncio.create_task(
            worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=process._profile_test_reservation,
            )
        )
        try:
            await asyncio.sleep(0.02)
            task.cancel()
            await entered.wait()
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            assert finished.is_set() and process in worker._FAILED and process not in worker._ACTIVE
            assert budget.snapshot()["held"]["worker"] == 1024**3
            process.stdout = original  # restore actual registered stdlib reader before cleanup
            await cleanup(process)
            save(tmp_path, budget, process, {"repeatedCancelJoined": True})
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            process.stdout = original
            await cleanup(process)

    asyncio.run(scenario())


def test_pre_spawn_reservation_is_present_at_actual_create_subprocess(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        actual_spawn = asyncio.create_subprocess_exec
        observations = []
        parent_receipts = []

        async def observed_spawn(*args, **kwargs):
            snapshot = budget.snapshot()
            assert snapshot["held"]["worker"] == 1024**3
            assert (
                snapshot["held"]["parent"]
                == worker.PARENT_RESERVATION_BYTES + worker.CLEANUP_SCALAR
            )
            assert len([e for e in snapshot["events"] if e[0] == "hold" and e[3] == "worker"]) == 1
            observations.append(snapshot)
            pending = next(
                record for record in worker._RESERVATIONS.values() if record[1] is budget
            )
            parent_receipts.append(pending[3])
            return await actual_spawn(*args, **kwargs)

        with patch.object(asyncio, "create_subprocess_exec", side_effect=observed_spawn):
            process = await spawn(PEER_PREFIX + PEER_OUTPUT, budget=budget)
        reservation = process._profile_test_reservation
        try:
            handle = await worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=reservation,
            )
            assert len(observations) == 1
            assert (
                len([e for e in budget.snapshot()["events"] if e[0] == "hold" and e[3] == "worker"])
                == 1
            )
            with pytest.raises(worker.ProfileWorkerFault):
                await worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                    budget=budget,
                    checkpoint=lambda: None,
                    reservation=reservation,
                )
            delivery = worker.consume_profile_child(handle, process=process, binding=BINDING)
            assert delivery.holding is parent_receipts[0]
            holding = delivery.holding
            del handle, delivery
            budget.release(holding, phase="test-pre-reserved-parent-dropped")
            save(tmp_path, budget, process, {"actualSpawnObservations": observations})
        finally:
            await cleanup(process)

    asyncio.run(scenario())


@pytest.mark.parametrize(
    "kind", ["dict", "new-object", "wrong-budget", "wrong-binding", "missing", "abandoned"]
)
def test_foreign_missing_abandoned_reservations_never_allocate_or_write(kind, tmp_path):
    class Input:
        writes = 0

        def write(self, raw):
            self.writes += 1

    class Process:
        stdin = Input()
        stdout = stderr = object()

    budget = ProfileBudget()
    reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
    process = Process()
    arguments = dict(
        binding=BINDING,
        input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
        budget=budget,
        checkpoint=lambda: None,
        reservation=reservation,
    )
    if kind == "dict":
        arguments["reservation"] = {"worker": True}
    elif kind == "new-object":
        arguments["reservation"] = worker.ProfileChildReservation()
    elif kind == "wrong-budget":
        arguments["budget"] = ProfileBudget()
    elif kind == "wrong-binding":
        arguments["binding"] = {**BINDING, "dispatchOwnerGeneration": 2}
    elif kind == "missing":
        del arguments["reservation"]
    else:
        worker.abandon_profile_child_reservation(reservation, binding=BINDING, budget=budget)
    before = budget.snapshot()
    with pytest.raises((worker.ProfileWorkerFault, TypeError)):
        asyncio.run(worker.run_profile_child(process, **arguments))
    assert process.stdin.writes == 0 and budget.snapshot() == before
    worker.abandon_profile_child_reservation(reservation, binding=BINDING, budget=budget)
    worker.abandon_profile_child_reservation(reservation, binding=BINDING, budget=budget)
    assert budget.snapshot()["held"] == {
        "parent": worker.PARENT_RESERVATION_BYTES + worker.CLEANUP_SCALAR,
        "worker": 1024**3,
    }
    assert reservation in worker._RESERVATIONS
    (tmp_path / "unbound-reservation-audit.json").write_text(
        json.dumps(
            {
                "kind": kind,
                "budget": budget.snapshot(),
                "ownership": "unbound launch unknown retained; no release claimed",
            },
            indent=2,
        )
        + "\n"
    )


@pytest.mark.parametrize("difference", [-1, 0, 1])
def test_pre_spawn_parent_reservation_cap_plus_minus_one(difference, tmp_path):
    from ontolearn_engine.project.profile_budget import BOOK_SCALAR, LIMITS

    budget = ProfileBudget()
    previous = budget.hold(
        "parent",
        LIMITS["parent"]
        - BOOK_SCALAR
        - worker.PARENT_RESERVATION_BYTES
        - worker.CLEANUP_SCALAR
        + difference,
        0,
        phase="other-parent-retained",
    )
    if difference == 1:
        with pytest.raises(ProfileLimit):
            worker.reserve_profile_child(binding=BINDING, budget=budget)
        assert budget.snapshot()["held"]["worker"] == 0
    else:
        reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
        worker.abandon_profile_child_reservation(reservation, binding=BINDING, budget=budget)
        assert budget.snapshot()["held"]["worker"] == 1024**3
    budget.release(previous, phase="other-parent-dropped")
    (tmp_path / "pre-spawn-cap-audit.json").write_text(
        json.dumps(budget.snapshot(), indent=2) + "\n"
    )


def test_original_owned_worker_smoke(tmp_path):
    """Original monitor/guard + stdio; no JobStore, admission or SQL-chain claim."""
    from ontolearn_engine.coordinator import worker_command
    from ontolearn_engine.process_environment import worker_environment
    from ontolearn_engine.worker import worker_owner_arguments

    async def scenario():
        material, inputs = material_roles()
        budget = ProfileBudget()
        reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
        parent_pid = os.getpid()
        owner_arguments = worker_owner_arguments()
        assert owner_arguments[:2] == ["--coordinator-owner", str(parent_pid)]
        command = [*worker_command(), *owner_arguments]
        assert budget.snapshot()["held"]["worker"] == 1024**3
        process = await asyncio.create_subprocess_exec(
            *command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=worker_environment(),
            limit=worker.FRAME_BYTES,
        )
        worker.bind_profile_child(reservation, process=process, binding=BINDING, budget=budget)
        process._profile_test_argv = command
        process._profile_test_budget = budget
        _SPAWNS.append(
            (
                process,
                {
                    "pid": process.pid,
                    "argv": command,
                    "cwd": str(Path.cwd()),
                    "ownerPid": parent_pid,
                    "ownerArguments": owner_arguments,
                },
            )
        )
        try:
            handle = await asyncio.wait_for(
                worker.run_profile_child(
                    process,
                    binding=BINDING,
                    input_roles=inputs,
                    budget=budget,
                    checkpoint=lambda: None,
                    reservation=reservation,
                ),
                20,
            )
            delivery = worker.consume_profile_child(handle, process=process, binding=BINDING)
            actual = execute_admitted_profile_job(
                material,
                error_catalog=CONTRACT.ERROR_CATALOG,
                error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
            )
            assert delivery.roles["payload-json"] == actual.payload_json
            assert delivery.roles["rows-json"] == actual.rows_json
            assert delivery.roles["worker-capture"] == worker._capture(actual)
            assert actual.original_allocation.rule_ids == ("true", "false", "disabled")
            assert actual.original_allocation.disabled_rule_ids == ("disabled",)
            assert len(actual.original_allocation.children) == 3
            holding = delivery.holding
            del delivery, handle, actual
            budget.release(holding, phase="owned-smoke-original-output-dropped")
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
        finally:
            await cleanup(process)
            save(
                tmp_path,
                budget,
                process,
                {
                    "scope": "original owned monitor/guard plus private transport only",
                    "platform": sys.platform,
                    "ownerPid": parent_pid,
                    "darwinGuard": "original RSS sampling is not a kernel hard allocation cap",
                },
            )

    asyncio.run(scenario())


def test_drop_releases_only_after_module_delivery_reference_is_gone(tmp_path):
    import weakref
    from types import MappingProxyType

    class ObservedDelivery(worker.ProfileDelivery):
        __slots__ = ("__weakref__",)

    budget = ProfileBudget()
    holding = budget.hold("parent", 32, 4, phase="small-owned-delivery")
    process = object()
    handle = worker.ProfileChildHandle()
    delivery = ObservedDelivery(MappingProxyType({"payload-json": b"ordinary bytes"}), (), holding)
    observed = weakref.ref(delivery)
    worker._ISSUED[handle] = (process, dict(BINDING), delivery, budget)
    del delivery  # no caller alias; the only delivery owner is the issuer record
    release = budget.release
    observations = []

    def release_after_drop(receipt, *, phase):
        assert receipt is holding
        assert handle not in worker._ISSUED
        assert observed() is None
        observations.append("module-delivery-gone-before-original-release")
        release(receipt, phase=phase)

    with patch.object(budget, "release", side_effect=release_after_drop) as release_call:
        worker.drop_profile_child(handle, process=process, binding=BINDING)
    release_call.assert_called_once_with(holding, phase="worker-delivery-dropped")
    assert observations == ["module-delivery-gone-before-original-release"]
    assert budget.snapshot()["held"]["parent"] == 0
    (tmp_path / "drop-order-audit.json").write_text(
        json.dumps({"observations": observations, "budget": budget.snapshot()}, indent=2) + "\n"
    )


@pytest.mark.parametrize(
    "raw",
    [
        b'{"x":[0,0]}',
        b'{"x":{"y":{}}}',
        b"[" + b"0," * 99 + b"0]",
        json.dumps({f"k{i}": 0 for i in range(100)}, separators=(",", ":")).encode(),
    ],
)
def test_frame_shape_rejects_before_native_json_container_allocation(raw, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("native JSON decoder entered before shape rejection")

    monkeypatch.setattr(worker.json, "loads", forbidden)
    with pytest.raises(worker.ProfileWorkerFault):
        worker._json(raw)


def test_frame_shape_accepts_complete_maximum_hex_chunk():
    data = b"\x00\xff" * (worker.RAW_CHUNK // 2)
    message = {
        **worker._message(
            BINDING,
            "output",
            "payload-json",
            "chunk",
            1,
            0,
            len(data),
            hashlib.sha256(data).hexdigest(),
        ),
        "data": data.hex(),
    }
    raw = worker._line(message)
    assert len(raw) <= worker.FRAME_BYTES
    assert worker._frame(raw, BINDING) == message


def test_binding_rejects_extra_or_foreign_keys_before_set_and_callbacks(monkeypatch):
    calls = []
    original_set = set

    def observed(value):
        calls.append("set")
        return original_set(value)

    class ForeignKey(str):
        __hash__ = str.__hash__

        def __eq__(self, other):
            calls.append("equality")
            return str.__eq__(self, other)

    invalid = [
        dict(BINDING, **{f"extra{i}": 0 for i in range(100)}),
        {ForeignKey(k): v for k, v in BINDING.items()},
    ]
    invalid.append(
        {"x" * 33: BINDING["jobId"], **{k: v for k, v in BINDING.items() if k != "jobId"}}
    )
    monkeypatch.setattr(worker, "set", observed, raising=False)
    for value in invalid:
        calls.clear()
        with pytest.raises(worker.ProfileWorkerFault):
            worker._binding(value)
        assert calls == []


def test_bound_before_run_forced_close_has_no_natural_eof_or_handle(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        owner = worker._BOUND[process]
        ticket = process._profile_test_reservation
        assert ticket not in worker._RESERVATIONS
        assert (
            worker.bind_profile_child(ticket, process=process, binding=BINDING, budget=budget)
            is ticket
        )
        before = budget.snapshot()
        try:
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(process, binding=BINDING)
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "forced-closed" and facts["forced"]
            assert (
                facts["cleanupReadBytes"] == 0
                and facts["cleanupWorkPrepaid"] == worker.CLEANUP_WORK
            )
            assert not any(facts[key] for key in ("naturalStdout", "naturalStderr", "naturalStdin"))
            assert process.returncode is not None
            assert (
                process.stdout.at_eof() and process.stderr.at_eof()
            )  # forced feed_eof is not natural
            assert await worker.drain_failed_profile_child(process, binding=BINDING) is facts
            assert worker._BOUND[process].close_task is owner.close_task
            after = budget.snapshot()
            assert before["spent"] == after["spent"] and before["held"] == after["held"]
            assert not any(record[0] is process for record in worker._ISSUED.values())
            worker.release_failed_profile_child(process, binding=BINDING)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(tmp_path, budget, process, dict(facts))
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_bound_small_tail_force_close_drops_buffers_before_release(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        script = (
            "import sys,time\n"
            "sys.stdout.buffer.write(b'x'*128);sys.stdout.flush()\n"
            "sys.stderr.buffer.write(b'y'*128);sys.stderr.flush()\n"
            "time.sleep(20)\n"
        )
        process = await spawn(script, budget=budget)
        try:
            for _ in range(100):
                if process.stdout._buffer and process.stderr._buffer:
                    break
                await asyncio.sleep(0.01)
            assert len(process.stdout._buffer) == len(process.stderr._buffer) == 128
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "forced-closed"
            assert facts["cleanupReadBytes"] == 0 and facts["buffersDropped"]
            assert not process.stdout._buffer and not process.stderr._buffer
            assert not facts["naturalStdout"] and not facts["naturalStderr"]
            worker.release_failed_profile_child(process, binding=BINDING)
            save(tmp_path, budget, process, dict(facts))
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_cleanup_caller_cancel_keeps_one_owned_task_and_same_fees(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        try:
            task = asyncio.create_task(worker.drain_failed_profile_child(process, binding=BINDING))
            await asyncio.sleep(0)
            owned = worker._BOUND[process].close_task
            assert owned is not None
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            assert not owned.cancelled() and budget.snapshot()["held"]["worker"] == 1024**3
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "forced-closed" and worker._BOUND[process].close_task is owned
            events = budget.snapshot()["events"]
            assert sum(event[:2] == ("work", "worker-cleanup-package") for event in events) == 1
            worker.release_failed_profile_child(process, binding=BINDING)
            save(tmp_path, budget, process, dict(facts))
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_unknown_adapter_keeps_original_tickets_without_fallback(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        owner = worker._BOUND[process]
        original = process.stdout._limit
        try:
            process.stdout._limit = worker.FRAME_BYTES + 1  # real object, unsupported adapter state
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "unknown" and not facts["buffersDropped"]
            assert not facts["forced"] and not facts["killSent"]
            assert budget.snapshot()["held"]["worker"] == 1024**3
            with pytest.raises(worker.ProfileWorkerFault):
                worker.release_failed_profile_child(process, binding=BINDING)
            process.stdout._limit = original
            assert await worker.drain_failed_profile_child(process, binding=BINDING) is facts
            # Test-owned physical disposal is separate: it does NOT release the UNKNOWN tickets.
            process.kill()
            process.stdin.transport.abort()
            process.stdout._transport.close()
            process.stderr._transport.close()
            await process.wait()
            save(tmp_path, budget, process, dict(facts))
            assert owner.phase == "unknown" and budget.snapshot()["held"]["worker"] == 1024**3
        finally:
            process.stdout._limit = original
            if process.returncode is None:
                process.kill()
                process.stdin.transport.abort()
                process.stdout._transport.close()
                process.stderr._transport.close()
                await process.wait()

    asyncio.run(scenario())


def test_cleanup_work_spent_first_and_partial_holdings_rollback(tmp_path):
    from ontolearn_engine.project.profile_budget import BOOK_SCALAR, LIMITS

    budget = ProfileBudget()
    other = budget.hold(
        "parent",
        LIMITS["parent"] - BOOK_SCALAR - worker.PARENT_RESERVATION_BYTES,
        0,
        phase="other-parent-before-cleanup-reserve",
    )
    before = budget.snapshot()
    with pytest.raises(ProfileLimit):
        worker.reserve_profile_child(binding=BINDING, budget=budget)
    after = budget.snapshot()
    assert after["spent"]["read_work"] - before["spent"]["read_work"] == worker.CLEANUP_WORK
    assert after["held"] == before["held"] and after["objects"] == before["objects"]
    assert not any(record[1] is budget for record in worker._RESERVATIONS.values())
    budget.release(other, phase="test-drop-other-parent")
    (tmp_path / "cleanup-partial-hold-audit.json").write_text(
        json.dumps(budget.snapshot(), indent=2) + "\n"
    )


def test_original_owned_worker_bound_failure_before_first_request(tmp_path):
    from ontolearn_engine.coordinator import worker_command
    from ontolearn_engine.process_environment import worker_environment
    from ontolearn_engine.worker import worker_owner_arguments

    async def scenario():
        budget = ProfileBudget()
        reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
        command = [*worker_command(), *worker_owner_arguments()]
        process = await asyncio.create_subprocess_exec(
            *command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=worker_environment(),
            limit=worker.FRAME_BYTES,
        )
        worker.bind_profile_child(reservation, process=process, binding=BINDING, budget=budget)
        process._profile_test_argv = command
        process._profile_test_budget = budget
        _SPAWNS.append(
            (
                process,
                {
                    "pid": process.pid,
                    "argv": command,
                    "cwd": str(Path.cwd()),
                    "ownerPid": os.getpid(),
                },
            )
        )
        try:
            assert not process.stdout._buffer
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "forced-closed" and facts["cleanupReadBytes"] == 0
            assert not facts["naturalStdout"] and not facts["naturalStderr"]
            assert not any(record[0] is process for record in worker._ISSUED.values())
            worker.release_failed_profile_child(process, binding=BINDING)
            save(tmp_path, budget, process, dict(facts))
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_active_cleanup_keeps_tickets_and_prevents_success_until_run_joined(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        task = asyncio.create_task(
            worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=process._profile_test_reservation,
            )
        )
        try:
            await asyncio.sleep(0.02)
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "unknown" and facts["reason"] == "active-run-not-joined"
            assert worker._BOUND[process].close_task is None
            assert budget.snapshot()["held"]["worker"] == 1024**3
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            facts = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert facts["state"] == "forced-closed"
            worker.release_failed_profile_child(process, binding=BINDING)
            save(tmp_path, budget, process, dict(facts))
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            await cleanup(process)

    asyncio.run(scenario())


@pytest.mark.parametrize("fault", ["handle-constructor", "register-before", "register-after"])
def test_terminal_issuance_failure_keeps_original_owned_worker_recoverable(fault, tmp_path):
    import traceback
    import weakref

    from ontolearn_engine.coordinator import worker_command
    from ontolearn_engine.process_environment import worker_environment
    from ontolearn_engine.worker import worker_owner_arguments

    class ObservedDelivery(worker.ProfileDelivery):
        __slots__ = ("__weakref__",)

    async def scenario():
        budget = ProfileBudget()
        reservation = worker.reserve_profile_child(binding=BINDING, budget=budget)
        command = [*worker_command(), *worker_owner_arguments()]
        process = await asyncio.create_subprocess_exec(
            *command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=worker_environment(),
            limit=worker.FRAME_BYTES,
        )
        worker.bind_profile_child(reservation, process=process, binding=BINDING, budget=budget)
        process._profile_test_argv = command
        process._profile_test_budget = budget
        _SPAWNS.append(
            (
                process,
                {
                    "pid": process.pid,
                    "argv": command,
                    "cwd": str(Path.cwd()),
                    "ownerPid": os.getpid(),
                },
            )
        )
        _, inputs = material_roles()
        original_receipts = tuple(worker._BOUND[process].pending[index] for index in (2, 3, 5))
        first = RuntimeError("controlled terminal issuance fault: " + fault)
        refs = []
        releases = []
        release = budget.release

        def observed_delivery(*args):
            value = ObservedDelivery(*args)
            refs.append(weakref.ref(value))
            return value

        def release_once(receipt, *, phase):
            assert all(previous is not receipt for previous in releases)
            releases.append(receipt)
            release(receipt, phase=phase)

        def fail_handle():
            raise first

        class RegistrationFault(dict):
            def __setitem__(self, key, value):
                if value[0] is process:
                    if fault == "register-after":
                        super().__setitem__(key, value)
                    raise first
                super().__setitem__(key, value)

        try:
            with (
                patch.object(worker, "ProfileDelivery", side_effect=observed_delivery),
                patch.object(budget, "release", side_effect=release_once),
            ):
                injector = (
                    patch.object(worker, "ProfileChildHandle", side_effect=fail_handle)
                    if fault == "handle-constructor"
                    else patch.object(worker, "_ISSUED", RegistrationFault(worker._ISSUED))
                )
                with injector, pytest.raises(RuntimeError) as got:
                    await asyncio.wait_for(
                        worker.run_profile_child(
                            process,
                            binding=BINDING,
                            input_roles=inputs,
                            budget=budget,
                            checkpoint=lambda: None,
                            reservation=reservation,
                        ),
                        20,
                    )
                assert got.value is first and process.returncode == 0
                assert process in worker._BOUND and process in worker._FAILED
                assert process not in worker._ACTIVE and not releases
                assert not any(record[0] is process for record in worker._ISSUED.values())
                assert budget.snapshot()["held"] == {
                    "parent": worker.PARENT_RESERVATION_BYTES + worker.CLEANUP_SCALAR,
                    "worker": 1024**3,
                }
                assert len(refs) == 1 and refs[0]() is None
                assert all(
                    getattr(worker._BOUND[process], flag)
                    for flag in ("natural_stdout", "natural_stderr", "natural_stdin")
                )
                traceback.clear_frames(first.__traceback__)
                first.__traceback__ = None
                got = inputs = first = None  # drop caller raw/exception aliases before release
                facts = await worker.drain_failed_profile_child(process, binding=BINDING)
                assert facts["state"] == "forced-closed" and facts["returncode"] == 0
                assert all(facts[key] for key in ("naturalStdout", "naturalStderr", "naturalStdin"))
                # Save metadata while its explicit cleanup holding still exists.
                (tmp_path / "terminal-issuance-close.json").write_text(
                    json.dumps(dict(facts), indent=2) + "\n"
                )
                facts = None
                worker.release_failed_profile_child(process, binding=BINDING)
                assert len(releases) == 3 and all(
                    any(actual is expected for actual in releases) for expected in original_receipts
                )
                assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
                with pytest.raises(worker.ProfileWorkerFault):
                    worker.release_failed_profile_child(process, binding=BINDING)
                save(
                    tmp_path,
                    budget,
                    process,
                    {
                        "controlledFault": fault,
                        "sameFirst": True,
                        "originalReceiptsReleasedOnce": True,
                        "temporaryDeliveryDropped": True,
                    },
                )
        finally:
            await cleanup(process)

    asyncio.run(scenario())


def test_active_cleanup_exports_cached_and_paid_until_same_owner_release(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        task = asyncio.create_task(
            worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=process._profile_test_reservation,
            )
        )
        try:
            await asyncio.sleep(0.02)
            before = budget.snapshot()
            facts = [
                await worker.drain_failed_profile_child(process, binding=BINDING) for _ in range(32)
            ]
            assert len({id(value) for value in facts}) == 1
            assert worker._BOUND[process].active_evidence is facts[0]
            assert worker._BOUND[process].terminal_evidence is None
            assert worker._BOUND[process].close_task is None
            assert (
                budget.snapshot() is before
            )  # exports did not mint work/holds or new ledger exports
            with pytest.raises(TypeError):
                facts[0]["state"] = "closed"
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            terminal = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert terminal["state"] == "forced-closed" and terminal is not facts[0]
            assert await worker.drain_failed_profile_child(process, binding=BINDING) is terminal
            assert worker._BOUND[process].terminal_evidence is terminal
            assert (
                budget.snapshot()["held"]["parent"]
                == worker.PARENT_RESERVATION_BYTES + worker.CLEANUP_SCALAR
            )
            exports = [facts[0], terminal]
            (tmp_path / "cached-status-exports.json").write_text(
                json.dumps(
                    {
                        "callsWhileActive": 32,
                        "distinctActive": len({id(value) for value in facts}),
                        "totalDistinct": len({id(value) for value in exports}),
                        "objectQuantaForTwoMappings": 2 * (2 * len(terminal) + 2),
                        "cleanupHeldScalar": worker.CLEANUP_SCALAR,
                        "cleanupHeldObjects": worker.CLEANUP_OBJECTS,
                        "active": dict(facts[0]),
                        "terminal": dict(terminal),
                    },
                    indent=2,
                )
                + "\n"
            )
            facts = exports = terminal = None
            worker.release_failed_profile_child(process, binding=BINDING)
            assert process not in worker._BOUND and process not in worker._FAILED
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            with pytest.raises(worker.ProfileWorkerFault):
                await worker.drain_failed_profile_child(process, binding=BINDING)
            save(tmp_path, budget, process, {"activeExportDistinct": 1, "totalExports": 2})
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            await cleanup(process)

    asyncio.run(scenario())


def test_drain_active_and_terminal_32_limits_keep_single_cleanup_task(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        run = asyncio.create_task(
            worker.run_profile_child(
                process,
                binding=BINDING,
                input_roles=dict.fromkeys(worker.INPUT_ROLES, b""),
                budget=budget,
                checkpoint=lambda: None,
                reservation=process._profile_test_reservation,
            )
        )
        queries = []
        binding_calls = []
        original_binding = worker._binding

        def counted_binding(value):
            binding_calls.append(1)
            return original_binding(value)

        class NoLibraryScan(dict):
            def values(self):
                raise AssertionError("drain must not scan unrelated library handles")

        try:
            await asyncio.sleep(0.02)
            owner = worker._BOUND[process]
            before = budget.snapshot()
            with (
                patch.object(worker, "_binding", counted_binding),
                patch.object(worker, "_ISSUED", NoLibraryScan(worker._ISSUED)),
            ):
                active = None
                for ordinal in range(1, worker.DRAIN_ACCEPTED_PER_PHASE + 1):
                    value = await worker.drain_failed_profile_child(process, binding=BINDING)
                    if active is None:
                        active = value
                    assert value is active and owner.active_observations == ordinal
                    if ordinal in (31, 32):
                        assert len(binding_calls) == ordinal
                value = None
                assert owner.terminal_observations == 0 and owner.close_task is None
                with pytest.raises(worker.ProfileWorkerFault):
                    await worker.drain_failed_profile_child(process, binding=BINDING)
                assert owner.active_observations == 32 and len(binding_calls) == 32
                assert budget.snapshot() is before and owner.active_evidence is active
                run.cancel()
                with pytest.raises(asyncio.CancelledError):
                    await run
                # Exhausting ACTIVE never spends the separate first cleanup slot.
                for _ in range(31):
                    queries.append(
                        asyncio.create_task(
                            worker.drain_failed_profile_child(
                                process,
                                binding=BINDING,
                            )
                        )
                    )
                await asyncio.sleep(0)
                assert owner.terminal_observations == 31 and owner.close_task is not None
                actual_cleanup_task = owner.close_task
                queries.append(
                    asyncio.create_task(
                        worker.drain_failed_profile_child(
                            process,
                            binding=BINDING,
                        )
                    )
                )
                await asyncio.sleep(0)
                assert owner.terminal_observations == 32 and len(binding_calls) == 64
                with pytest.raises(worker.ProfileWorkerFault):
                    await worker.drain_failed_profile_child(process, binding=BINDING)
                assert owner.close_task is actual_cleanup_task and len(binding_calls) == 64
                replies = await asyncio.gather(*queries)
                terminal = replies[0]
                assert all(reply is terminal for reply in replies)
                assert terminal["state"] == "forced-closed" and process.returncode is not None
                with pytest.raises(worker.ProfileWorkerFault):
                    await worker.drain_failed_profile_child(process, binding=BINDING)
                assert owner.terminal_observations == 32 and len(binding_calls) == 64
                assert owner.active_evidence is active and owner.terminal_evidence is terminal
                assert budget.snapshot()["held"] == {
                    "parent": worker.PARENT_RESERVATION_BYTES + worker.CLEANUP_SCALAR,
                    "worker": 1024**3,
                }
                (tmp_path / "drain-quota-boundaries.json").write_text(
                    json.dumps(
                        {
                            "activeAccepted": owner.active_observations,
                            "terminalAccepted": owner.terminal_observations,
                            "bindingValidations": len(binding_calls),
                            "denied": 3,
                            "active31And32Accepted": True,
                            "terminal31And32Accepted": True,
                            "active33Denied": True,
                            "terminal33DeniedBeforeAndAfterClose": True,
                            "unrelatedLibraryScans": 0,
                            "cleanupTaskCount": 1,
                            "cleanupWorkPrepaid": worker.CLEANUP_WORK,
                            "cleanupParentScalar": worker.CLEANUP_SCALAR,
                            "cleanupParentObjects": worker.CLEANUP_OBJECTS,
                            "active": dict(active),
                            "terminal": dict(terminal),
                        },
                        indent=2,
                    )
                    + "\n"
                )
                active = terminal = replies = queries = actual_cleanup_task = owner = None
                await asyncio.sleep(0)
                await asyncio.sleep(0)
            worker.release_failed_profile_child(process, binding=BINDING)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(tmp_path, budget, process, {"accepted": 64, "denied": 3, "bindingChecks": 64})
        finally:
            if not run.done():
                run.cancel()
                await asyncio.gather(run, return_exceptions=True)
            if queries:
                await asyncio.gather(*queries, return_exceptions=True)
            if process in worker._BOUND:
                pending = worker._BOUND[process]
                if pending.close_task is not None:
                    await asyncio.shield(pending.close_task)
                    worker.release_failed_profile_child(process, binding=BINDING)
                else:
                    await cleanup(process)
            else:
                await cleanup(process)

    asyncio.run(scenario())


def test_drain_invalid_bindings_preserve_first_real_cleanup_and_original_receipts(tmp_path):
    async def scenario():
        budget = ProfileBudget()
        process = await spawn("import time\ntime.sleep(20)\n", budget=budget)
        receipts = tuple(worker._BOUND[process].pending[index] for index in (2, 3, 5))
        released = []
        original_release = budget.release

        def release_once(receipt, *, phase):
            assert all(old is not receipt for old in released)
            released.append(receipt)
            original_release(receipt, phase=phase)

        try:
            owner = worker._BOUND[process]
            before = budget.snapshot()
            for _ in range(32):
                with pytest.raises(worker.ProfileWorkerFault):
                    await worker.drain_failed_profile_child(
                        process, binding={**BINDING, "jobId": "other"}
                    )
            assert owner.terminal_observations == 0 and owner.active_observations == 0
            assert owner.evidence is None and owner.close_task is None
            assert budget.snapshot() is before
            terminal = await worker.drain_failed_profile_child(process, binding=BINDING)
            assert terminal["state"] == "forced-closed" and owner.terminal_observations == 1
            assert process.returncode is not None
            (tmp_path / "wrong-binding-first-real-cleanup.json").write_text(
                json.dumps(
                    {
                        "wrongBindingRejected": 32,
                        "wrongBindingAcceptedSlots": 0,
                        "firstCorrectCleanupAccepted": 1,
                        "cleanupTaskCount": 1,
                        "terminal": dict(terminal),
                    },
                    indent=2,
                )
                + "\n"
            )
            terminal = owner = None
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            with patch.object(budget, "release", release_once):
                worker.release_failed_profile_child(process, binding=BINDING)
                assert len(released) == 3 and all(
                    any(actual is expected for actual in released) for expected in receipts
                )
                with pytest.raises(worker.ProfileWorkerFault):
                    worker.release_failed_profile_child(process, binding=BINDING)
            assert budget.snapshot()["held"] == {"parent": 0, "worker": 0}
            save(
                tmp_path,
                budget,
                process,
                {
                    "invalidBindingRejected": 32,
                    "accepted": 1,
                    "originalReceiptsReleasedOnce": True,
                },
            )
        finally:
            await cleanup(process)

    asyncio.run(scenario())
