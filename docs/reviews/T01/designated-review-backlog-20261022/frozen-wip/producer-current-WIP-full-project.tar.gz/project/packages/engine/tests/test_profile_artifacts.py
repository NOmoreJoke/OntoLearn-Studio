"""Pure artifact contracts and real I05 rows; no Store/SQL/Job authority."""

import copy
import hashlib
import json
from dataclasses import FrozenInstanceError, replace
from uuid import UUID

import pytest
from ontolearn_engine.project import profile_artifacts as artifacts
from ontolearn_engine.project.profile_artifacts import (
    ADAPTER_VERSION,
    CACHE_DOMAIN,
    IDENTITY_KEYS,
    PRIVATE_IDENTITY_VERSION,
    ArtifactError,
    adapt_display,
    profile_cache_key,
)
from ontolearn_engine.project.profile_budget import BOOK_WORK, LIMITS, ProfileBudget, ProfileLimit
from ontolearn_engine.quality.rule_firing import Comparison
from ontolearn_engine.quality.rule_profile import SourceRecord
from ontolearn_engine.resources import CONTRACT, ROOT, semantic_identity
from ontolearn_engine.semantic_profile_input import prepare_profile_material
from ontolearn_engine.semantic_profile_production import execute_admitted_profile_job
from test_semantic_profile_restore import literal, rule, turtle

JOB = "00000000-0000-4000-8000-000000000001"
SCHEMA = json.loads((ROOT / "v2/schema.json").read_bytes())


def encode(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


@pytest.fixture
def budgets(tmp_path):
    ledgers = []

    def create():
        value = ProfileBudget()
        ledgers.append(value)
        return value

    yield create
    (tmp_path / "cost-events.json").write_text(
        json.dumps([x.snapshot() for x in ledgers], ensure_ascii=False, indent=2) + "\n"
    )


def adapt(raw, cost, **kwargs):
    return adapt_display(
        raw, job_id=kwargs.get("job_id", JOB), kind=kwargs.get("kind", "reasoning"), budget=cost
    )


def cache_args():
    return {
        "project": JOB,
        "kind": "reasoning",
        "snapshot": sha(b"actual snapshot bytes for pure key shape fixture"),
        "dependencies": {"facts:asserted": 1, "rule:r": 2},
        "implementation": semantic_identity(profile=True),
        "adapter_version": ADAPTER_VERSION,
        "trusted_private_identity": {
            "version": PRIVATE_IDENTITY_VERSION,
            "mode": "producer",
            **{
                k: sha(k.encode()) for k in IDENTITY_KEYS - {"version", "mode", "consumerSelection"}
            },
            "consumerSelection": None,
        },
    }


def test_real_three_rule_rows_preserve_original_bytes_and_all_cells(budgets, tmp_path):
    source = SourceRecord("definition:true", sha(b"definition material"), "1", None)
    true = rule("true", source=source)
    true = replace(
        true,
        comparisons=(Comparison(true.comparisons[0].left, "ge", literal("10")),),
        heads=(
            true.heads[0],
            replace(true.heads[0], object=replace(true.heads[0].object, lexical_form="second")),
        ),
    )
    false = rule(
        "false", comparisons=(Comparison(true.comparisons[0].left, "eq", literal("9999")),)
    )
    material = prepare_profile_material(
        turtle(("20", "5")), (true, false, rule("disabled")), disabled_rule_ids=("disabled",)
    )
    produced = execute_admitted_profile_job(
        material, error_catalog=CONTRACT.ERROR_CATALOG, error_schema=SCHEMA
    )
    cost = budgets()
    result = adapt(produced.rows_json, cost)
    public = json.loads(result.display_bytes)
    assert [row["cells"] for row in public] == json.loads(produced.rows_json)
    assert all(CONTRACT.validate("row", row) for row in public)
    assert result.private_rows_digest == sha(produced.rows_json)
    assert result.display_digest == sha(result.display_bytes)
    assert len(produced.original_allocation.children) == 3
    children = produced.native_result["mechanismBatches"]
    assert len(next(c for c in children if c["ruleId"] == "true")["batch"].firings) == 1
    assert len(next(c for c in children if c["ruleId"] == "true")["batch"].firings[0].heads) == 2
    assert next(c for c in children if c["ruleId"] == "false")["batch"].firings == ()
    assert next(c for c in children if c["ruleId"] == "disabled")["batch"] is None
    slot_fields = tuple(produced.original_allocation.children[0].limits.__dataclass_fields__)
    assert len(slot_fields) == 17
    assert all(
        type(getattr(slot.limits, k)) is int
        for slot in produced.original_allocation.children
        for k in slot_fields
    )
    (tmp_path / "actual-production.json").write_text(
        json.dumps(
            {
                "payloadBytes": len(produced.payload_json),
                "rowsBytes": len(produced.rows_json),
                "payloadDigest": sha(produced.payload_json),
                "privateRowsDigest": result.private_rows_digest,
                "displayBytes": len(result.display_bytes),
                "displayDigest": result.display_digest,
                "actualAllocations": [
                    {k: getattr(slot.limits, k) for k in slot_fields}
                    for slot in produced.original_allocation.children
                ],
                "scope": "real pure I05 computation, not actual Job/claim/process/origin authority",
            },
            indent=2,
        )
        + "\n"
    )
    assert 0 < cost.snapshot()["spent"]["read_work"] < LIMITS["read_work"]
    assert cost.snapshot()["held"]["parent"] > 0
    assert not any(event[0] == "release" for event in cost.snapshot()["events"])


@pytest.mark.parametrize(
    "cell", [None, True, False, "", "中文", "\0\n", -0.0, 1.25, -(2**53 - 1), 2**53 - 1]
)
def test_cells_keep_values_and_original_canonical_encoding(cell, budgets):
    raw = encode([[cell], []])
    result = adapt(raw, budgets())
    public = json.loads(result.display_bytes)
    assert encode([r["cells"] for r in public]) == raw
    assert [r["ordinal"] for r in public] == [0, 1]
    assert all(CONTRACT.validate("row", row) for row in public)


def test_deterministic_ids_preserve_ordinal_bits_and_do_not_depend_on_origin(budgets):
    raw = encode([["one"], ["two"]])
    first = adapt(raw, budgets())
    second = adapt(raw, budgets())
    assert first.display_bytes == second.display_bytes
    rows = json.loads(first.display_bytes)
    seed = b"t01-profile-display-row/1\0" + JOB.encode() + b"\0reasoning\0" + sha(raw).encode()
    prefix = bytearray(hashlib.sha256(seed).digest()[:12])
    prefix[6] = (prefix[6] & 15) | 64
    prefix[8] = (prefix[8] & 63) | 128
    for i, row in enumerate(rows):
        parsed = UUID(row["rowId"])
        assert parsed.version == 4 and parsed.bytes[:12] == prefix
        assert int.from_bytes(parsed.bytes[12:], "big") == i
    assert rows[0]["rowId"] != rows[1]["rowId"]
    for changed in [{"kind": "query"}, {"job_id": "00000000-0000-4000-8000-000000000002"}]:
        assert adapt(raw, budgets(), **changed).display_bytes != first.display_bytes
    assert adapt(encode([["changed"]]), budgets()).private_rows_digest != first.private_rows_digest


@pytest.mark.parametrize("char", ["a", "😀", "\x01", '"', "\\"])
def test_unicode_8192_scalar_boundary_inclusive(char, budgets):
    result = adapt(encode([[char * 8192]]), budgets())
    assert json.loads(result.display_bytes)[0]["cells"] == [char * 8192]
    assert CONTRACT.validate("row", json.loads(result.display_bytes)[0])
    with pytest.raises(ArtifactError) as error:
        adapt(encode([[char * 8193]]), budgets())
    assert error.value.reason == "CELL_LENGTH"
    assert len(error.value.artifact_holdings) == 2


@pytest.mark.parametrize(
    "raw",
    [
        b"{}",
        b'[[{"a":1,"a":2}]]',
        b'[[["nested"]]]',
        b"[[NaN]]",
        b"[[Infinity]]",
        b"[[1e309]]",
        b"[[9007199254740992]]",
        b'[["\\ud800"]]',
        b'[["\xff"]]',
        b'[["a",]]',
        b"[true]",
        b"[] []",
        b' [ [ "a" ] ] ',
        b'[["\\u0061"]]',
        b"[[1e1]]",
        b"[[01]]",
    ],
)
def test_invalid_unknown_or_noncanonical_rows_rejected_without_private_repair(raw, budgets):
    before = bytes(raw)
    with pytest.raises(ArtifactError):
        adapt(raw, budgets())
    assert raw == before


def test_depth_and_row_cell_limits_before_decoder(monkeypatch, budgets):
    def forbidden(*args, **kwargs):
        pytest.fail("decoder must not run before the shape fence")

    cases = [b"[" * 100000 + b"]" * 100000, encode([[]] * 10001), encode([[0] * 65])]
    with monkeypatch.context() as patcher:
        patcher.setattr(artifacts.json, "loads", forbidden)
        for raw in cases:
            cost = budgets()
            with pytest.raises(ArtifactError):
                adapt(raw, cost)
            assert cost.snapshot()["held"]["parent"] > 0
    assert adapt(encode([[]] * 10000), budgets()).row_count == 10000
    assert adapt(encode([[None] * 64]), budgets()).cell_count == 64
    empty = adapt(b"[]", budgets())
    assert empty.display_bytes == b"[]" and empty.row_count == empty.cell_count == 0


def test_display_cost_exact_and_one_unit_each_side(budgets):
    raw = encode([["abc", 1.25], []])
    r, c, m = 2, 2, len(raw)
    j = m + 90 * r + 32 * c
    total = m + j + 1
    required = (
        4096
        + 16 * (m + 1)
        + 64 * total
        + 256 * (r + c)
        + 16 * total
        + 256 * r
        + 4 * total
        + 256 * r
    )
    # The full 512MiB includes the 128MiB ledger book; business work has 384MiB.
    business_cap = LIMITS["read_work"] - BOOK_WORK
    for extra in (-1, 0, 1):
        cost = budgets()
        cost.debit("read_work", business_cap - required - extra, phase="other-owner-work")
        if extra < 0:
            with pytest.raises(ProfileLimit) as error:
                adapt(raw, cost)
            assert error.value.artifact_holdings
        else:
            result = adapt(raw, cost)
            assert result.row_count == 2
            assert cost.snapshot()["spent"]["read_work"] == business_cap - extra
            assert (
                cost.snapshot()["accounting"]["totalReadWorkReservation"]
                == LIMITS["read_work"] - extra
            )
    ordinary = budgets()
    adapt(raw, ordinary)
    assert ordinary.snapshot()["spent"]["read_work"] == required
    phases = {e[1] for e in ordinary.snapshot()["events"]}
    assert {"display:syntax", "display:work", "display:copy", "display:hash"} <= phases


def test_exhaustion_is_before_parse_and_does_not_refund_failed_attempt(monkeypatch, budgets):
    raw = encode([["abc"]])
    cost = budgets()
    cost.debit(
        "read_work",
        LIMITS["read_work"] - BOOK_WORK - 4096 - 16 * (len(raw) + 1),
        phase="already-spent",
    )
    with monkeypatch.context() as patcher:
        patcher.setattr(artifacts.json, "loads", lambda *a, **k: pytest.fail("unpaid decode"))
        with pytest.raises(ProfileLimit) as error:
            adapt(raw, cost)
    spent = cost.snapshot()["spent"]["read_work"]
    assert spent == LIMITS["read_work"] - BOOK_WORK and error.value.artifact_holdings
    assert cost.snapshot()["accounting"]["totalReadWorkReservation"] == LIMITS["read_work"]
    with pytest.raises(ProfileLimit):
        adapt(raw, cost)
    assert cost.snapshot()["spent"]["read_work"] == spent
    assert cost.snapshot()["held"]["parent"] > 0


def test_immutable_returns_keep_holding_until_actual_owner_drops(budgets):
    cost = budgets()
    result = adapt(b'[["a"]]', cost)
    with pytest.raises(FrozenInstanceError):
        result.row_count = 99
    receipts = result.holdings
    with pytest.raises(ValueError, match="FOREIGN"):
        cost.release(replace(receipts[0]), phase="forged")
    with pytest.raises(ValueError, match="REMAIN"):
        cost.close()
    del result
    for receipt in receipts:
        cost.release(receipt, phase="owner-dropped-result")
    cost.close()
    assert cost.snapshot()["held"]["parent"] == 0
    assert cost.snapshot()["spent"]["read_work"] > 0


def test_cache_exact_object_separates_five_old_inputs_and_private_identity(budgets):
    args = cache_args()
    before = copy.deepcopy(args)
    result = profile_cache_key(**args, budget=budgets())
    body = json.loads(result.canonical_bytes)
    assert set(body) == {
        "domain",
        "project",
        "kind",
        "snapshot",
        "dependencies",
        "implementation",
        "adapterVersion",
        "trustedPrivateIdentity",
    }
    assert body["domain"] == CACHE_DOMAIN and result.key == sha(encode(body))
    assert (
        body["implementation"] == before["implementation"]
        and body["dependencies"] == before["dependencies"]
    )
    assert args == before
    old = {
        name: body[name]
        for name in ("project", "kind", "snapshot", "dependencies", "implementation")
    }
    assert sha(encode(old)) != result.key
    args["dependencies"]["facts:asserted"] = 99
    assert json.loads(result.canonical_bytes)["dependencies"]["facts:asserted"] == 1
    with pytest.raises(FrozenInstanceError):
        result.key = "changed"


@pytest.mark.parametrize("field", sorted(IDENTITY_KEYS - {"version", "mode", "consumerSelection"}))
def test_each_actual_private_digest_changes_cache_key(field, budgets):
    args = cache_args()
    original = profile_cache_key(**args, budget=budgets()).key
    args["trusted_private_identity"][field] = sha(b"changed actual role bytes")
    assert profile_cache_key(**args, budget=budgets()).key != original


@pytest.mark.parametrize(
    "change",
    [
        "missing",
        "extra",
        "emptyDigest",
        "uppercase",
        "consumer",
        "selection",
        "origin",
        "cacheKey",
        "implementation",
        "boolVersion",
        "nonDigestSnapshot",
        "unknownAdapter",
    ],
)
def test_cache_missing_untrusted_or_consumer_shape_refused(change, budgets):
    args = cache_args()
    identity = args["trusted_private_identity"]
    if change == "missing":
        del identity["payloadDigest"]
    elif change == "extra":
        identity["extra"] = "value"
    elif change == "emptyDigest":
        identity["inputDigest"] = ""
    elif change == "uppercase":
        identity["inputDigest"] = "A" * 64
    elif change == "consumer":
        identity["mode"] = "consumer"
    elif change == "selection":
        identity["consumerSelection"] = []
    elif change in {"origin", "cacheKey"}:
        identity[change] = "circular"
    elif change == "implementation":
        args["implementation"]["adapterVersion"] = ADAPTER_VERSION
    elif change == "boolVersion":
        args["dependencies"]["facts:asserted"] = True
    elif change == "nonDigestSnapshot":
        args["snapshot"] = "not-a-snapshot-digest"
    else:
        args["adapter_version"] = "unknown"
    with pytest.raises(ArtifactError):
        profile_cache_key(**args, budget=budgets())


def test_cache_exhaustion_rejected_before_encoder(monkeypatch, budgets):
    cost = budgets()
    args = cache_args()
    cost.debit("read_work", LIMITS["read_work"] - BOOK_WORK, phase="exhausted")
    with monkeypatch.context() as patcher:
        patcher.setattr(artifacts, "_encode", lambda *a: pytest.fail("unpaid encoding"))
        with pytest.raises(ProfileLimit):
            profile_cache_key(**args, budget=cost)
