"""Finite private producer accounting; no Store, permission or SQL authority.

The ledger and every immutable diagnostic export have a bounded, prepaid owner
reservation. Work remains monotone; explicit material release is not a refund.
"""

from dataclasses import dataclass
from types import MappingProxyType

VERSION = "t01-profile-budget/1"
MIB = 1024 * 1024
LIMITS = MappingProxyType(
    {
        "jobs": 256,
        "artifacts": 128,
        "pins": 64,
        "selections": 2,
        "retries": 8,
        "history": 8 * MIB,
        "cache": 24 * MIB,
        "persistent": 32 * MIB,
        "raw": 32 * MIB,
        "evidence": 64 * MIB,
        "read_work": 512 * MIB,
        "queries": 65536,
        "metadata": 8192 * MIB,
        "exact_probe": 32768 * MIB,
        "pager": 128 * MIB,
        "parent": 512 * MIB,
        "worker": 1024 * MIB,
        "library": 1536 * MIB,
        "parent_objects": 8388608,
        "worker_objects": 16777216,
    }
)
CONTROL = MappingProxyType({"start": 65536, "cancel": 65536, "terminal": 262144})
# All event tuples/phase strings, <=256 live receipt records, and <=32 complete
# immutable snapshots remain in this reservation until the ledger/aliases die.
MAX_EVENTS = 65536
MAX_EXPORTS = 32
MAX_HOLDINGS = 256
MAX_PHASE = 128
BOOK_SCALAR = 96 * MIB
BOOK_OBJECTS = 3 * MIB
BOOK_WORK = 128 * MIB
_CLEANUP_EVENTS = MAX_HOLDINGS + len(CONTROL)
_CLEANUP_WORK = 1536 * _CLEANUP_EVENTS


class ProfileLimit(ValueError):
    def __init__(self, domain):
        super().__init__("PROFILE_RESOURCE_LIMIT")
        self.domain = domain


def _count(value):
    if type(value) is not int or value < 0 or value.bit_length() > 64:
        raise ValueError("INVALID_PROFILE_COST")
    return value


def _phase(value):
    if type(value) is not str or len(value) > MAX_PHASE:
        raise ValueError("INVALID_PROFILE_PHASE")
    if any(0xD800 <= ord(c) <= 0xDFFF for c in value):
        raise ValueError("INVALID_PROFILE_PHASE")
    return value


class _Frozen(dict):
    def __init__(self, *args, **kwargs):
        if getattr(self, "_sealed", False):
            raise TypeError("IMMUTABLE_PROFILE_SNAPSHOT")
        dict.__init__(self, *args, **kwargs)
        self._sealed = True

    def _deny(self, *args, **kwargs):
        raise TypeError("IMMUTABLE_PROFILE_SNAPSHOT")

    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = __ior__ = _deny


@dataclass(frozen=True, slots=True)
class Holding:
    ordinal: int
    actor: str
    scalar: int
    objects: int


class ProfileBudget:
    """One lifetime ledger; bookkeeping is included in the same parent/work cap."""

    def __init__(self):
        self._spent = {name: 0 for name in LIMITS}
        self._controls = {name: 0 for name in CONTROL}
        self._held = {"parent": 0, "worker": 0}
        self._objects = {"parent": 0, "worker": 0}
        self._peaks = dict(self._held)
        self._object_peaks = dict(self._objects)
        self._receipts = {}
        self._ordinal = self._revision = self._audit_work = 0
        self._events = []
        self._exports = []
        self._export_revision = -1
        self._closed = False
        self._control_reserve_used = set()

    def _event(self, event, phase, *, cleanup=False):
        cost = 1024 + 4 * len(phase)
        maximum = MAX_EVENTS if cleanup else MAX_EVENTS - _CLEANUP_EVENTS
        work = BOOK_WORK if cleanup else BOOK_WORK - _CLEANUP_WORK
        if len(self._events) >= maximum or self._audit_work + cost > work:
            raise ProfileLimit("audit")
        self._audit_work += cost
        self._events.append(event)
        self._revision += 1

    def debit(self, domain, amount, *, phase):
        _count(amount)
        _phase(phase)
        if self._closed or type(domain) is not str or domain not in self._spent:
            raise ValueError("INVALID_PROFILE_COST")
        after = self._spent[domain] + amount
        cap = LIMITS[domain] - (BOOK_WORK if domain == "read_work" else 0)
        if after > cap:
            self._event(("rejected", phase, domain, amount, self._spent[domain]), phase)
            raise ProfileLimit(domain)
        self._event(("work", phase, domain, amount, after), phase)
        self._spent[domain] = after

    def control(self, action, amount):
        """Prepay a whole bounded Job phase once, before its first operation.

        The owner supplies its proven upper cost for the ENTIRE start/cancel/
        terminal phase, including every cleanup substep. This is not a renewable
        cumulative sub-operation counter. Unused phase allowance cannot refill
        another ticket; repeated issuance is explicitly invalid independently
        of the business journal. Each phase owns one reserved event slot.
        """
        _count(amount)
        if self._closed or type(action) is not str or action not in CONTROL or amount == 0:
            raise ValueError("INVALID_PROFILE_CONTROL")
        if action in self._control_reserve_used:
            raise ValueError("PROFILE_CONTROL_ALREADY_ISSUED")
        if amount > CONTROL[action]:
            raise ProfileLimit(action)
        self._event(("control", action, amount, amount), action, cleanup=True)
        self._control_reserve_used.add(action)
        self._controls[action] = amount

    def hold(self, actor, scalar, objects, *, phase):
        _count(scalar)
        _count(objects)
        _phase(phase)
        if self._closed or type(actor) is not str or actor not in self._held:
            raise ValueError("INVALID_PROFILE_HOLDING")
        if len(self._receipts) >= MAX_HOLDINGS:
            raise ProfileLimit("holdings")
        book_scalar = BOOK_SCALAR if actor == "parent" else 0
        book_objects = BOOK_OBJECTS if actor == "parent" else 0
        if self._held[actor] + scalar + book_scalar > LIMITS[actor]:
            raise ProfileLimit(actor)
        if sum(self._held.values()) + scalar + BOOK_SCALAR > LIMITS["library"]:
            raise ProfileLimit("library")
        if self._objects[actor] + objects + book_objects > LIMITS[actor + "_objects"]:
            raise ProfileLimit(actor + "_objects")
        ordinal = self._ordinal + 1
        self._event(("hold", phase, ordinal, actor, scalar, objects), phase)
        receipt = Holding(ordinal, actor, scalar, objects)
        self._ordinal = ordinal
        self._receipts[ordinal] = receipt
        self._held[actor] += scalar
        self._objects[actor] += objects
        self._peaks[actor] = max(self._peaks[actor], self._held[actor])
        self._object_peaks[actor] = max(self._object_peaks[actor], self._objects[actor])
        return receipt

    def release(self, receipt, *, phase):
        _phase(phase)
        if type(receipt) is not Holding:
            raise ValueError("FOREIGN_PROFILE_HOLDING")
        _count(receipt.ordinal)
        if self._receipts.get(receipt.ordinal) is not receipt:
            raise ValueError("FOREIGN_PROFILE_HOLDING")
        self._event(("release", phase, receipt.ordinal), phase, cleanup=True)
        del self._receipts[receipt.ordinal]
        self._held[receipt.actor] -= receipt.scalar
        self._objects[receipt.actor] -= receipt.objects

    def snapshot(self):
        # Same immutable state returns the identical object, not another tuple.
        if self._export_revision == self._revision:
            return self._exports[-1]
        if len(self._exports) >= MAX_EXPORTS:
            raise ProfileLimit("audit-exports")
        cost = 16 * len(self._events) + 8192
        if self._audit_work + cost > BOOK_WORK - _CLEANUP_WORK:
            raise ProfileLimit("audit")
        self._audit_work += cost
        result = _Frozen(
            {
                "version": VERSION,
                "spent": _Frozen(self._spent),
                "control": _Frozen(self._controls),
                "held": _Frozen(self._held),
                "objects": _Frozen(self._objects),
                "peaks": _Frozen(self._peaks),
                "objectPeaks": _Frozen(self._object_peaks),
                "events": tuple(self._events),
                "closed": self._closed,
                "accounting": _Frozen(
                    {
                        "reservedWork": BOOK_WORK,
                        "usedWork": self._audit_work,
                        "reservedParentScalar": BOOK_SCALAR,
                        "reservedParentObjects": BOOK_OBJECTS,
                        "totalHeldParent": self._held["parent"] + BOOK_SCALAR,
                        "totalObjectsParent": self._objects["parent"] + BOOK_OBJECTS,
                        "totalReadWorkReservation": self._spent["read_work"] + BOOK_WORK,
                        "controlPolicy": "one whole-phase prepayment per Job; no cumulative refill",
                        "eventLimit": MAX_EVENTS,
                        "exportLimit": MAX_EXPORTS,
                        "exports": len(self._exports) + 1,
                        "retention": "ledger and all snapshot aliases must be dropped",
                    }
                ),
            }
        )
        self._exports.append(result)
        self._export_revision = self._revision
        return result

    def close(self):
        if self._receipts:
            raise ValueError("PROFILE_REFERENCES_REMAIN")
        self._closed = True
        self._revision += 1
