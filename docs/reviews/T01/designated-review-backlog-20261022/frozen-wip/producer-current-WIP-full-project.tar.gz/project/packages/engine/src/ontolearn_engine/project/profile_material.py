"""Private Store snapshot adapter and strict definition codec.

The I05 data-only codec remains the sole RuleSpec decoder. This adapter reads
original normalized Store records and preserves their actual snapshot locators.
It performs no matching, inference, graph normalization or source invention.
"""

import hashlib
import json
from dataclasses import replace

from ontolearn_engine.quality.rule_firing import RuleSpec
from ontolearn_engine.quality.rule_profile import SourceRecord, TermInput
from ontolearn_engine.semantic_profile_input import (
    DEFINITION_VERSION,
    CaptureLedger,
    _definitions,
    decode_rule_definitions,
    prepare_profile_material,
)
from ontolearn_engine.storage import canonical, digest

RULE_VERSION = "profile-rule-definition/1"
RULE_KEYS = frozenset(
    {
        "enabled",
        "rule_id",
        "when",
        "comparisons",
        "heads",
        "source",
        "revision",
        "definition_digest",
        "policy",
    }
)
HEX = frozenset("0123456789abcdef")


def _require(condition):
    if not condition:
        raise ValueError("INVALID_PROFILE_MATERIAL")


def rule_definition(spec, *, enabled, revision, references=()):
    """Construct typed user material; this does not preview or confirm a write."""
    _require(type(spec) is RuleSpec and type(enabled) is bool)
    _require(
        type(revision) is int and 0 < revision <= 9007199254740991 and type(references) is tuple
    )
    spec = replace(spec, revision=str(revision), definition_digest=None)
    ledger = CaptureLedger()
    ledger.begin(N=1)
    ledger.enter(3, 16777216)
    _, encoded = _definitions((spec,), () if enabled else (spec.rule_id,), ledger)
    body = json.loads(encoded)["rules"][0]
    payload = {"version": RULE_VERSION, **body, "references": list(references)}
    payload["definition_digest"] = digest(
        {
            "domain": "profile-rule-content/1",
            "definition": {k: v for k, v in payload.items() if k != "definition_digest"},
        }
    )
    validate_definition("rule", spec.rule_id, payload, revision=revision)
    return payload


def validate_definition(layer, identity, payload, *, revision=None):
    _require(type(identity) is str and 0 < len(identity) <= 16384 and type(payload) is dict)
    references = payload.get("references", [])
    _require(type(references) is list and len(references) <= 4096)
    for reference in references:
        _require(type(reference) is dict and set(reference) == {"layer", "id"})
        _require(
            type(reference["layer"]) is str
            and reference["layer"]
            in {
                "ontology",
                "rule",
                "query",
                "constraint",
                "mapping",
                "behavior",
                "scenario",
                "model",
            }
        )
        _require(type(reference["id"]) is str and 0 < len(reference["id"]) <= 16384)
    if layer == "query":
        _require(set(payload) <= {"text", "references"} and "text" in payload)
        _require(type(payload["text"]) is str and 0 < len(payload["text"]) <= 65536)
        payload["text"].encode("utf-8", "strict")
        return None
    if layer == "constraint":
        _require(set(payload) <= {"turtle", "enabled", "references"})
        _require({"turtle", "enabled"} <= set(payload))
        _require(type(payload["enabled"]) is bool and type(payload["turtle"]) is str)
        _require(0 < len(payload["turtle"]) <= 65536)
        payload["turtle"].encode("utf-8", "strict")
        return None
    _require(layer == "rule" and set(payload) == RULE_KEYS | {"version", "references"})
    _require(payload["version"] == RULE_VERSION and payload["rule_id"] == identity)
    _require(type(payload["enabled"]) is bool)
    stored_revision = payload["revision"]
    _require(
        type(stored_revision) is str
        and stored_revision.isascii()
        and stored_revision.isdigit()
        and 1 <= len(stored_revision) <= 16
        and stored_revision[0] != "0"
        and int(stored_revision) <= 9007199254740991
    )
    if revision is not None:
        _require(
            type(revision) is int
            and 0 < revision <= 9007199254740991
            and stored_revision == str(revision)
        )
    expected = digest(
        {
            "domain": "profile-rule-content/1",
            "definition": {k: v for k, v in payload.items() if k != "definition_digest"},
        }
    )
    _require(payload["definition_digest"] == expected)
    body = {k: payload[k] for k in RULE_KEYS}
    material = canonical(
        {
            "version": DEFINITION_VERSION,
            "rules": [body],
            "disabledRuleIds": [] if payload["enabled"] else [identity],
        }
    ).encode()
    return decode_rule_definitions(material).rules[0]


def _literal(text, source):
    """Decode only the original Store's finite canonical N3 literal syntax."""
    _require(type(text) is str and len(text) <= 65536 and text.startswith('"'))
    quote = '"""' if text.startswith('"""') else '"'
    index, pieces = len(quote), []
    escapes = {
        "t": "\t",
        "b": "\b",
        "n": "\n",
        "r": "\r",
        "f": "\f",
        '"': '"',
        "'": "'",
        "\\": "\\",
    }
    while index < len(text):
        if text.startswith(quote, index):
            index += len(quote)
            break
        char = text[index]
        index += 1
        _require(quote != '"' or char not in "\n\r")
        if char == "\\":
            _require(index < len(text))
            char = text[index]
            index += 1
            if char in {"u", "U"}:
                width = 4 if char == "u" else 8
                digits = text[index : index + width]
                _require(len(digits) == width and all(c.lower() in HEX for c in digits))
                value = int(digits, 16)
                _require(value <= 0x10FFFF and not 0xD800 <= value <= 0xDFFF)
                char = chr(value)
                index += width
            else:
                _require(char in escapes)
                char = escapes[char]
        _require(not 0xD800 <= ord(char) <= 0xDFFF)
        pieces.append(char)
    else:
        raise ValueError("INVALID_PROFILE_MATERIAL")
    suffix = text[index:]
    datatype = language = None
    if suffix.startswith("^^<") and suffix.endswith(">"):
        datatype = suffix[3:-1]
        _require(bool(datatype))
    elif suffix.startswith("@"):
        language = suffix[1:]
        parts = language.split("-")
        _require(
            parts[0].isascii()
            and parts[0].isalpha()
            and all(part.isascii() and part.isalnum() for part in parts[1:])
        )
    else:
        _require(suffix == "")
    return TermInput("literal", "".join(pieces), datatype, language, source)


def _term(value, source, *, object_=False):
    _require(type(value) is str and 0 < len(value) <= 65536)
    if object_ and value.startswith('"'):
        return _literal(value, source)
    if object_:
        _require(value.startswith("<") and value.endswith(">"))
        value = value[1:-1]
    _require(bool(value) and not any(c.isspace() or c in '<>"{}|^`\\' for c in value))
    return TermInput("iri", value, source=source)


def material_from_snapshot(snapshot, snapshot_id):
    """Receive a content-verified snapshot from the real owner, never current Graph."""
    _require(type(snapshot) is dict and digest(snapshot) == snapshot_id)
    state = snapshot["state"]
    rules, disabled, records = [], [], []
    for definition_ordinal, definition in enumerate(state["definitions"]):
        payload = json.loads(definition["payload"])
        layer, identity = definition["layer"], definition["id"]
        if layer == "rule":
            revision = snapshot["dependencyVector"].get("rule:" + identity)
            _require(type(revision) is int and 0 < revision <= 9007199254740991)
            spec = validate_definition(layer, identity, payload, revision=revision)
            rules.append(spec)
            if not payload["enabled"]:
                disabled.append(identity)
        elif layer in {"query", "constraint"}:
            validate_definition(layer, identity, payload)
        elif layer == "ontology":
            _require(
                type(payload) is dict
                and set(payload) <= {"triples", "references", "singleValuedPredicates"}
            )
            for triple in payload.get("triples", []):
                original = canonical(definition)
                source = SourceRecord(
                    f"store-snapshot:{snapshot_id}#/state/definitions/{definition_ordinal}",
                    hashlib.sha256(original.encode()).hexdigest(),
                    str(snapshot["dependencyVector"].get("ontology:" + identity, 0)),
                    original,
                )
                records.append(
                    (
                        _term(triple["subject"], source),
                        _term(triple["predicate"], source),
                        _term(triple["object"], source, object_=True),
                    )
                )
    for fact_ordinal, fact in enumerate(state["facts"]):
        if fact["object"] is None:
            continue
        source = SourceRecord(
            f"store-snapshot:{snapshot_id}#/state/facts/{fact_ordinal}",
            hashlib.sha256(canonical(fact).encode()).hexdigest(),
            str(snapshot["projectRevision"]),
            canonical(fact),
        )
        records.append(
            (
                _term(fact["subject"], source),
                _term(fact["predicate"], source),
                _term(fact["object"], source, object_=True),
            )
        )
    return prepare_profile_material(
        records=tuple(records), rules=tuple(rules), disabled_rule_ids=tuple(disabled)
    )
