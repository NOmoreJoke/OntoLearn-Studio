"""Private bounded profile child transport, without Store or spawn authority.

The original worker owns its monitor/physical guard; Coordinator owns spawning,
termination and waiting. This module transfers only bytes actually received from
that process. A delivery is not a production permission or a successful Job.
"""

import asyncio
import hashlib
import inspect
import json
import os
import sys
import traceback
from dataclasses import dataclass, fields
from types import MappingProxyType

from .project.profile_budget import ProfileBudget
from .quality.rule_profile import ProfileLimits, SourceRecord
from .semantic_execution import _profile_json_bytes, _ProfileProjection
from .semantic_profile_input import (
    MAX_BYTES,
    CaptureLedger,
    _encode,
    _read_syntax_json,
    _syntax_native,
    decode_rule_definitions,
    prepare_profile_material,
)
from .semantic_profile_production import execute_admitted_profile_job

VERSION = "t01-profile-worker/1"
CAPTURE_VERSION = "t01-profile-worker-capture/1"
INPUT_ROLES = ("input-preimage", "source-preimage", "definitions-material")
OUTPUT_ROLES = ("payload-json", "rows-json", "worker-capture")
RAW_CHUNK = 32768
HEADER_BYTES = 4096
FRAME_BYTES = 69633  # complete canonical JSON plus LF
STDERR_BYTES = 65536
MEMORY_BYTES = 536870912
LIMIT_FIELDS = tuple(field.name for field in fields(ProfileLimits))
_BINDING = frozenset(("jobId", "operationId", "contextFingerprint", "dispatchOwnerGeneration"))
_BASE = frozenset(
    ("version", "binding", "type", "phase", "role", "ordinal", "offset", "length", "sha256")
)
_ISSUED = {}
_FAILED = {}
_ACTIVE = set()
_RESERVATIONS = {}
_BOUND = {}
CLEANUP_WORK = 64 * 1024 * 1024
CLEANUP_SCALAR = 8 * 1024 * 1024
CLEANUP_OBJECTS = 65536
CLEANUP_ROUNDS = 256
DRAIN_ACCEPTED_PER_PHASE = 32
CLEANUP_SECONDS = 5.0
# Initial owned buffers plus one already-scheduled bounded read callback fit
# the separately-held8MiB cleanup envelope. No tail is read during failure.
INITIAL_READ_BUFFER = 512 * 1024
FINAL_READ_BUFFER = 1024 * 1024
BUFFER_ALLOCATION = 2 * 1024 * 1024
PARENT_RESERVATION_BYTES = 9 * MAX_BYTES + 1048576


class ProfileWorkerFault(ValueError):
    def __init__(self):
        super().__init__("PROFILE_WORKER_INVALID")


def _require(condition):
    if not condition:
        raise ProfileWorkerFault()


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _binding(value):
    _require(type(value) is dict and len(value) == 4)
    _require(all(type(key) is str and len(key) <= 32 for key in value) and set(value) == _BINDING)
    for key in ("jobId", "operationId"):
        _require(type(value[key]) is str and 0 < len(value[key]) <= 128)
        _require(value[key].isascii() and all(c.isalnum() or c in "-_" for c in value[key]))
    fp = value["contextFingerprint"]
    _require(type(fp) is str and len(fp) == 64 and all(c in "0123456789abcdef" for c in fp))
    generation = value["dispatchOwnerGeneration"]
    _require(type(generation) is int and 1 <= generation <= 2**63 - 1)
    return dict(value)


def _canonical(value):
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _json(raw):
    _require(type(raw) is bytes and len(raw) <= FRAME_BYTES)

    def pairs(items):
        result = {}
        for key, value in items:
            _require(key not in result)
            result[key] = value
        return result

    def invalid(_):
        raise ProfileWorkerFault()

    # Frames contain only an outer object, its binding object and primitive
    # fields. Bound native parser containers BEFORE object_pairs_hook receives
    # its already-allocated items list. A byte/depth cap alone is insufficient.
    depth = nodes = 0
    quoted = escaped = False
    for char in raw:
        if quoted:
            if escaped:
                escaped = False
            elif char == 92:
                escaped = True
            elif char == 34:
                quoted = False
        elif char == 34:
            quoted = True
            nodes += 1
        elif char == 123:
            depth += 1
            nodes += 1
            _require(depth <= 2)
        elif char == 125:
            depth -= 1
            _require(depth >= 0)
        elif char in (91, 93):
            raise ProfileWorkerFault()
        elif char in (44, 58):
            nodes += 1
        _require(nodes <= 128)
    _require(not quoted and depth == 0)
    try:
        result = json.loads(
            raw, object_pairs_hook=pairs, parse_float=invalid, parse_constant=invalid
        )
        _require(type(result) is dict and _canonical(result) == raw)
        return result
    except (UnicodeError, json.JSONDecodeError, RecursionError, ValueError):
        raise ProfileWorkerFault() from None


def _message(binding, phase, role, kind, ordinal, offset, length, digest):
    return dict(
        version=VERSION,
        binding=binding,
        type=kind,
        phase=phase,
        role=role,
        ordinal=ordinal,
        offset=offset,
        length=length,
        sha256=digest,
    )


def _ack(message):
    return {
        **{k: v for k, v in message.items() if k != "data"},
        "type": "ack",
        "ackType": message["type"],
    }


def _line(message):
    if message.get("type") == "chunk":
        _require(type(message.get("data")) is str and len(message["data"]) <= 2 * RAW_CHUNK)
        header = {**message, "data": ""}
    else:
        header = message
    _require(len(_canonical(header)) <= HEADER_BYTES)
    line = _canonical(message) + b"\n"
    _require(len(line) <= FRAME_BYTES)
    return line


def _frame(raw, binding):
    _require(type(raw) is bytes and 0 < len(raw) <= FRAME_BYTES and raw.endswith(b"\n"))
    message = _json(raw[:-1])
    kind = message.get("type")
    if kind == "complete":
        _require(set(message) == {"version", "binding", "type", "phase", "roles"})
        _require(
            message["phase"] == "output" and type(message["roles"]) is int and message["roles"] == 3
        )
    else:
        _require(kind in ("begin", "chunk", "end", "ack"))
        extra = {"data"} if kind == "chunk" else {"ackType"} if kind == "ack" else set()
        _require(set(message) == _BASE | extra)
        _require(message["phase"] in ("input", "output"))
        _require(message["role"] in INPUT_ROLES + OUTPUT_ROLES)
        for key in ("ordinal", "offset", "length"):
            _require(type(message[key]) is int and 0 <= message[key] <= MAX_BYTES)
        digest = message["sha256"]
        _require(
            type(digest) is str
            and len(digest) == 64
            and all(c in "0123456789abcdef" for c in digest)
        )
        if kind == "chunk":
            data = message["data"]
            _require(type(data) is str and len(data) == 2 * message["length"])
            _require(
                0 < message["length"] <= RAW_CHUNK and all(c in "0123456789abcdef" for c in data)
            )
        if kind == "ack":
            _require(message["ackType"] in ("begin", "chunk", "end"))
    _require(message["version"] == VERSION and _binding(message["binding"]) == binding)
    _line(message)  # independently enforces exact header/data limits
    return message


def _messages(binding, phase, role, data):
    digest = _sha(data)
    yield _message(binding, phase, role, "begin", 0, 0, len(data), digest)
    ordinal = 1
    for offset in range(0, len(data), RAW_CHUNK):
        part = data[offset : offset + RAW_CHUNK]
        yield {
            **_message(binding, phase, role, "chunk", ordinal, offset, len(part), _sha(part)),
            "data": part.hex(),
        }
        ordinal += 1
    yield _message(binding, phase, role, "end", ordinal, len(data), len(data), digest)


class _Receiver:
    def __init__(self, binding, phase, roles, budget=None):
        self.binding, self.phase, self.roles, self.budget = binding, phase, roles, budget
        self.position = 0
        self.active = None
        self.raw = None
        self.offset = self.ordinal = 0
        self.values = {}
        self.manifests = []
        self.chunks = []
        self.hasher = None

    def accept(self, message):
        _require(self.position < len(self.roles) and message["phase"] == self.phase)
        _require(message["role"] == self.roles[self.position])
        kind = message["type"]
        if kind == "begin":
            _require(self.active is None and message["ordinal"] == message["offset"] == 0)
            if self.budget is not None:
                self.budget.debit("evidence", message["length"], phase="worker-output-begin")
            self.active = message
            self.raw, self.hasher = bytearray(), hashlib.sha256()
            self.offset, self.ordinal = 0, 1
            self.chunks = []
        elif kind == "chunk":
            _require(
                self.active is not None
                and message["ordinal"] == self.ordinal
                and message["offset"] == self.offset
            )
            _require(self.offset + message["length"] <= self.active["length"])
            data = bytes.fromhex(message["data"])
            _require(_sha(data) == message["sha256"])
            self.raw.extend(data)
            self.hasher.update(data)
            self.chunks.append(Chunk(self.ordinal - 1, self.offset, len(data), message["sha256"]))
            self.offset += len(data)
            self.ordinal += 1
        else:
            _require(kind == "end" and self.active is not None)
            _require(message["ordinal"] == self.ordinal and message["offset"] == self.offset)
            _require(message["length"] == self.offset == self.active["length"])
            _require(message["sha256"] == self.active["sha256"] == self.hasher.hexdigest())
            self.values[message["role"]] = bytes(self.raw)
            self.manifests.append(
                RoleManifest(message["role"], self.offset, message["sha256"], tuple(self.chunks))
            )
            self.active = self.raw = self.hasher = None
            self.chunks = []
            self.position += 1

    def clear(self):
        self.active = self.raw = self.hasher = None
        self.values.clear()
        self.manifests.clear()
        self.chunks.clear()


@dataclass(frozen=True, slots=True)
class Chunk:
    ordinal: int
    offset: int
    length: int
    sha256: str


@dataclass(frozen=True, slots=True)
class RoleManifest:
    role: str
    length: int
    sha256: str
    chunks: tuple[Chunk, ...]


@dataclass(frozen=True, slots=True)
class ProfileDelivery:
    roles: object
    manifests: tuple[RoleManifest, ...]
    holding: object


class ProfileChildHandle:
    __slots__ = ()


class ProfileChildReservation:
    __slots__ = ()


def reserve_profile_child(*, binding, budget):
    """One pre-spawn package. Cleanup work is monotone even if reserve fails."""
    binding = _binding(binding)
    _require(type(budget) is ProfileBudget)
    budget.debit("read_work", CLEANUP_WORK, phase="worker-cleanup-package")
    parent = cleanup = worker = None
    try:
        parent = budget.hold(
            "parent", PARENT_RESERVATION_BYTES, 16384, phase="worker-pre-spawn-channel"
        )
        cleanup = budget.hold(
            "parent", CLEANUP_SCALAR, CLEANUP_OBJECTS, phase="worker-pre-spawn-cleanup"
        )
        worker = budget.hold("worker", 1024**3, 16777216, phase="worker-pre-spawn-whole-child")
        reservation = ProfileChildReservation()
        _RESERVATIONS[reservation] = [binding, budget, worker, parent, "reserved", cleanup]
    except BaseException:
        # This synchronous function never launched a child or returned a ticket.
        # Roll back only actual local holdings; work was spent and is not refunded.
        for holding in (worker, cleanup, parent):
            if holding is not None:
                budget.release(holding, phase="worker-reservation-not-issued")
        raise
    return reservation


def _reservation(reservation, binding, budget):
    _require(type(reservation) is ProfileChildReservation and reservation in _RESERVATIONS)
    record = _RESERVATIONS[reservation]
    _require(record[0] == binding and record[1] is budget)
    return record


def abandon_profile_child_reservation(reservation, *, binding, budget):
    """Record uncertain launch ownership, without releasing or asserting no child.

    No caller boolean or exception proves that an asynchronous launch created no
    process. The unbound tickets remain charged, even after repeated abandon.
    """
    record = _reservation(reservation, _binding(binding), budget)
    record[4] = "abandoned-launch-unknown"


def _registered(handle, process, binding):
    _require(type(handle) is ProfileChildHandle and handle in _ISSUED)
    record = _ISSUED[handle]
    _require(record[0] is process and record[1] == _binding(binding))
    return record


def validate_profile_child(handle, *, process, binding):
    return _registered(handle, process, binding)[2]


def consume_profile_child(handle, *, process, binding):
    delivery = _registered(handle, process, binding)[2]
    del _ISSUED[handle]
    return delivery  # same holding transfers; no release or work refund


def drop_profile_child(handle, *, process, binding):
    record = _registered(handle, process, binding)
    holding, budget = record[2].holding, record[3]
    del _ISSUED[handle]
    # Caller must first drop any value obtained through validate_profile_child.
    # Drop our own delivery/raw owner before recording its holding as released.
    record = None
    budget.release(holding, phase="worker-delivery-dropped")


@dataclass(slots=True)
class _BoundChild:
    reservation: object
    pending: list
    process: object
    phase: str = "bound"
    adapter: object = None
    close_task: object = None
    evidence: object = None
    active_evidence: object = None
    terminal_evidence: object = None
    active_observations: int = 0
    terminal_observations: int = 0
    forced: bool = False
    natural_stdout: bool = False
    natural_stderr: bool = False
    natural_stdin: bool = False
    rounds: int = 0
    kill_sent: bool = False


def _pipe_adapter(owner):
    """Exact local CPython stdio objects, with no FD reads or path access."""
    from asyncio import subprocess as subprocess_api
    from asyncio import unix_events

    process = owner.process
    _require(sys.implementation.name == "cpython" and sys.version_info[:3] == (3, 12, 12))
    _require(os.name == "posix" and type(process) is subprocess_api.Process)
    transport = process._transport
    _require(type(transport) is unix_events._UnixSubprocessTransport)
    _require(type(process._loop) is unix_events._UnixSelectorEventLoop)
    _require(transport._pending_calls is None)
    protocol = process._protocol
    _require(type(protocol) is subprocess_api.SubprocessStreamProtocol)
    _require(
        type(process.stdout) is asyncio.StreamReader
        and type(process.stderr) is asyncio.StreamReader
    )
    _require(type(process.stdin) is asyncio.StreamWriter)
    pipes = tuple(transport.get_pipe_transport(fd) for fd in (0, 1, 2))
    _require(type(pipes[0]) is unix_events._UnixWritePipeTransport)
    _require(all(type(pipe) is unix_events._UnixReadPipeTransport for pipe in pipes[1:]))
    _require(all(pipe.max_size == 262144 for pipe in pipes[1:]))
    _require(process.stdin.transport is pipes[0])
    _require(process.stdout._transport is pipes[1] and process.stderr._transport is pipes[2])
    _require(
        all(
            type(reader._limit) is int and 0 < reader._limit <= FRAME_BYTES
            for reader in (process.stdout, process.stderr)
        )
    )
    adapter = (transport, protocol, pipes, process.stdin, process.stdout, process.stderr)
    if owner.adapter is not None:
        _require(all(a is b for a, b in zip(adapter[:2], owner.adapter[:2], strict=True)))
        _require(all(a is b for a, b in zip(pipes, owner.adapter[2], strict=True)))
        _require(all(a is b for a, b in zip(adapter[3:], owner.adapter[3:], strict=True)))
    return adapter


def _buffer_gate(adapter, *, final=False):
    pipes = adapter[2]
    maximum = FINAL_READ_BUFFER if final else INITIAL_READ_BUFFER
    for reader in adapter[4:]:
        buffer = reader._buffer
        _require(type(buffer) is bytearray and len(buffer) <= maximum)
        _require(buffer.__alloc__() <= BUFFER_ALLOCATION)
    buffer = pipes[0]._buffer
    _require(type(buffer) is bytearray and len(buffer) <= FRAME_BYTES + HEADER_BYTES)
    _require(buffer.__alloc__() <= 2 * (FRAME_BYTES + HEADER_BYTES))


def _close_status(owner, state, reason):
    # At most two immutable exports per original cleanup package: active and
    # terminal. Repeated public observations never mint fresh mapping containers.
    slot = "active_evidence" if reason == "active-run-not-joined" else "terminal_evidence"
    cached = getattr(owner, slot)
    if cached is not None:
        return cached
    # Fixed metadata only; never store a foreign exception, raw text or a role.
    code = None
    if type(owner.process) is asyncio.subprocess.Process:
        try:
            value = owner.process.returncode
            if value is None or type(value) is int and value.bit_length() <= 32:
                code = value
        except Exception:
            pass
    owner.evidence = MappingProxyType(
        {
            "state": state,
            "mode": "failure-forced-close",
            "reason": reason,
            "returncode": code,
            "naturalStdout": owner.natural_stdout,
            "naturalStderr": owner.natural_stderr,
            "naturalStdin": owner.natural_stdin,
            "forced": owner.forced,
            "stdinClosed": state == "forced-closed",
            "stdoutClosed": state == "forced-closed",
            "stderrClosed": state == "forced-closed",
            "buffersDropped": state == "forced-closed",
            "killSent": owner.kill_sent,
            "cleanupRounds": owner.rounds,
            "cleanupReadBytes": 0,
            "cleanupWorkPrepaid": CLEANUP_WORK,
        }
    )
    setattr(owner, slot, owner.evidence)
    return owner.evidence


def bind_profile_child(reservation, *, process, binding, budget):
    """Sync take before owner fences; retain exact tickets even if adapter is unknown."""
    binding = _binding(binding)
    _require(type(budget) is ProfileBudget)
    _require(type(reservation) is ProfileChildReservation)
    _require(type(process) is asyncio.subprocess.Process)
    if process in _BOUND:
        owner = _BOUND[process]
        _require(
            owner.reservation is reservation
            and owner.pending[0] == binding
            and owner.pending[1] is budget
        )
        _require(owner.phase == "bound")
        return reservation
    pending = _reservation(reservation, binding, budget)
    _require(pending[4] == "reserved")
    _require(process not in _FAILED and process not in _ACTIVE)
    _require(not any(record[0] is process for record in _ISSUED.values()))
    owner = _BoundChild(reservation, pending, process)
    _BOUND[process] = owner
    del _RESERVATIONS[reservation]
    pending[4] = "bound"
    try:
        owner.adapter = _pipe_adapter(owner)
        _buffer_gate(owner.adapter)
    except Exception:
        owner.phase = "unknown"
        _FAILED[process] = owner
        _close_status(owner, "unknown", "adapter-or-initial-buffer")
        raise ProfileWorkerFault() from None
    return reservation


def _bound_process(process, binding):
    _require(type(process) is asyncio.subprocess.Process and process in _BOUND)
    owner = _BOUND[process]
    _require(owner.process is process and owner.pending[0] == _binding(binding))
    return owner


def _closed_pipes(owner):
    adapter = _pipe_adapter(owner)
    pipes = adapter[2]
    _require(
        all(pipe.is_closing() and pipe._pipe is None and pipe._protocol is None for pipe in pipes)
    )
    _require(all(owner.process._transport._pipes[fd].disconnected for fd in (0, 1, 2)))
    _buffer_gate(adapter, final=True)
    return adapter


def _drop_pipe_exceptions(adapter):
    # These are the original stdlib exception owners, not caller traceback aliases.
    for reader in adapter[4:]:
        error = reader._exception
        if error is not None:
            _require(isinstance(error, BaseException))
            traceback.clear_frames(error.__traceback__)
            error.__traceback__ = None
            reader._exception = None
        error = None
    waiter = adapter[1]._stdin_closed
    _require(waiter.done() and not waiter.cancelled())
    error = waiter.exception()
    if error is not None:
        _require(isinstance(error, BaseException))
        traceback.clear_frames(error.__traceback__)
        error.__traceback__ = None
    error = None


async def _force_close(owner):
    """Bounded known-process abort; never consumes or authenticates tail data."""
    try:
        adapter = _pipe_adapter(owner)
        _buffer_gate(adapter)
        process = owner.process
        owner.forced = True  # before close can synthesize feed_eof
        owner.phase = "closing"
        pipes = adapter[2]
        # These are exact original stdlib transport methods, no business reads.
        # abort() in this pinned stdlib is not idempotent after its close callback.
        # Already-closing writes finish through their original callback/child kill.
        if not pipes[0].is_closing():
            pipes[0].abort()
        pipes[1].close()
        pipes[2].close()
        if process.returncode is None:
            try:
                process.kill()
                owner.kill_sent = True
            except ProcessLookupError:
                pass  # wait for the actual watcher status, never invent an exit
        loop = asyncio.get_running_loop()
        deadline = loop.time() + CLEANUP_SECONDS
        for _ in range(CLEANUP_ROUNDS):
            owner.rounds += 1
            if process.returncode is not None:
                try:
                    _closed_pipes(owner)
                except ProfileWorkerFault:
                    pass
                else:
                    # FIFO barriers flush already scheduled pipe notifications.
                    await asyncio.sleep(0)
                    await asyncio.sleep(0)
                    adapter = _closed_pipes(owner)
                    code = (
                        await process.wait()
                    )  # returncode already real; cannot wait on pipe backpressure
                    _require(type(code) is int and code == process.returncode)
                    _require(adapter[1]._stdin_closed.done())
                    try:
                        await process.stdin.wait_closed()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        pass  # closure exception is failure metadata, never natural success
                    _drop_pipe_exceptions(adapter)
                    for reader in adapter[4:]:
                        reader._buffer.clear()
                    _require(all(not reader._buffer for reader in adapter[4:]))
                    _require(not pipes[0]._buffer)
                    owner.phase = "closed"
                    return _close_status(
                        owner, "forced-closed", "original-pipes-closed-and-child-reaped"
                    )
            if loop.time() >= deadline:
                break
            await asyncio.sleep(0.02)
        owner.phase = "unknown"
        return _close_status(owner, "unknown", "close-or-exit-deadline")
    except BaseException as error:
        traceback.clear_frames(error.__traceback__)
        owner.phase = "unknown"
        return _close_status(owner, "unknown", "cleanup-adapter-or-buffer")


async def drain_failed_profile_child(process, *, binding):
    """Failed only. Original pipes are forced closed; this is NOT natural EOF.

    Caller cancels/joins run first and drops its exception/raw/metadata aliases
    before release. At most two cached exports use the prepaid cleanup holding;
    concurrent/repeated calls share them and one cleanup task, with no refill.
    Each phase admits at most32 matching-binding observations. Rejected calls
    are outside the prepaid accepted work, not an unlimited free Python service.
    """
    # O(1) original-owner admission before any binding scan/copy or async shield.
    # Success removes BOUND synchronously, so a bound failure phase cannot own
    # an issued success handle. No other library/handle count controls this work.
    _require(type(process) is asyncio.subprocess.Process and process in _BOUND)
    owner = _BOUND[process]
    _require(owner.process is process)
    active = owner.phase == "running"
    _require(active == (process in _ACTIVE))
    _require(owner.phase in ("bound", "running", "failed", "closing", "closed", "unknown"))
    counter = "active_observations" if active else "terminal_observations"
    count = getattr(owner, counter)
    _require(count < DRAIN_ACCEPTED_PER_PHASE)
    checked_binding = _binding(binding)
    binding = None  # do not retain a caller-mutable mapping across the await
    _require(owner.pending[0] == checked_binding)
    checked_binding = None
    # Matching binding alone spends an accepted slot. Rejected validation work
    # is outside this accepted package and cannot starve the first real cleanup.
    setattr(owner, counter, count + 1)
    if active:
        owner.forced = True  # a failed cleanup request must never permit later success issuance
        return _close_status(owner, "unknown", "active-run-not-joined")
    _FAILED[process] = owner
    if owner.phase == "unknown" and owner.close_task is None:
        return owner.evidence
    if owner.close_task is None:
        owner.close_task = asyncio.create_task(_force_close(owner))
    return await asyncio.shield(owner.close_task)


def release_failed_profile_child(process, *, binding):
    """Caller drops all exported metadata/raw/exception aliases before release."""
    owner = _bound_process(process, binding)
    _require(_FAILED.get(process) is owner and process not in _ACTIVE)
    _require(
        owner.close_task is not None
        and owner.close_task.done()
        and not owner.close_task.cancelled()
    )
    _require(
        owner.phase == "closed" and owner.forced and owner.evidence["state"] == "forced-closed"
    )
    _require(type(process.returncode) is int)
    adapter = _closed_pipes(owner)
    _require(all(not reader._buffer and reader._exception is None for reader in adapter[4:]))
    _require(not adapter[2][0]._buffer)
    budget = owner.pending[1]
    worker, parent, cleanup = owner.pending[2], owner.pending[3], owner.pending[5]
    del _FAILED[process]
    del _BOUND[process]
    owner = adapter = None
    if worker is not None:
        budget.release(worker, phase="failed-worker-owner-reaped")
    budget.release(parent, phase="failed-worker-parent-dropped")
    if cleanup is not None:
        budget.release(cleanup, phase="failed-worker-cleanup-dropped")


def _material(roles):
    definitions = decode_rule_definitions(roles["definitions-material"])
    ledger = CaptureLedger()
    ledger.begin(Q=len(roles["input-preimage"]) + len(roles["source-preimage"]), D=0, N=0)
    ledger.enter(1, 3 * MAX_BYTES)
    source = _syntax_native(_read_syntax_json(roles["source-preimage"], ledger), ledger)
    kwargs = dict(rules=definitions.rules, disabled_rule_ids=definitions.disabled_rule_ids)
    if type(source) is SourceRecord:
        material = prepare_profile_material(
            roles["input-preimage"].decode("utf-8", "strict"),
            source_reference=source.reference,
            source_revision=source.revision,
            **kwargs,
        )
    else:
        records = _syntax_native(_read_syntax_json(roles["input-preimage"], ledger), ledger)
        material = prepare_profile_material(records=records, **kwargs)
    _require(
        material.input_preimage == roles["input-preimage"]
        and material.source_preimage == roles["source-preimage"]
        and material.definition_material == roles["definitions-material"]
    )
    # The original codec, not a JSON coincidence, fixes the exact source syntax.
    _require(_encode(source, ledger) == material.source_preimage)
    return material


def _capture(computed):
    allocation = computed.original_allocation
    _require(len(LIMIT_FIELDS) == 17)
    value = {
        "version": CAPTURE_VERSION,
        "allocation": {
            "budgetVersion": allocation.budget_version,
            "ruleIds": allocation.rule_ids,
            "disabledRuleIds": allocation.disabled_rule_ids,
            "children": tuple(
                {
                    "ruleId": child.rule_id,
                    "definitionOrdinal": child.definition_ordinal,
                    "limits": child.limits,
                }
                for child in allocation.children
            ),
        },
        "actualDefinitions": computed.actual_definitions,
        "actualCatalog": computed.actual_catalog,
        "captureReceipt": {
            field.name: getattr(computed.capture_receipt, field.name)
            for field in fields(type(computed.capture_receipt))
        },
    }
    # Only actual values; original fixed bounded projection and serializer.
    return _profile_json_bytes(_ProfileProjection().value(value))


def run_child(request, *, reader, writer):
    """Called only inside the original worker's OwnerMonitor and MemoryGuard."""
    _require(type(request) is dict and len(request) == 3)
    _require(
        all(type(key) is str and len(key) <= 32 for key in request)
        and set(request) == {"profileWorkerVersion", "binding", "memoryBytes"}
    )
    _require(type(request["profileWorkerVersion"]) is int and request["profileWorkerVersion"] == 1)
    _require(type(request["memoryBytes"]) is int and request["memoryBytes"] == MEMORY_BYTES)
    binding = _binding(request["binding"])
    receiver = _Receiver(binding, "input", INPUT_ROLES)
    while receiver.position < len(INPUT_ROLES):
        message = _frame(reader.readline(FRAME_BYTES + 1), binding)
        receiver.accept(message)
        writer.write(_line(_ack(message)))
        writer.flush()
    material = _material(receiver.values)
    from .resources import CONTRACT, ROOT

    computed = execute_admitted_profile_job(
        material,
        error_catalog=CONTRACT.ERROR_CATALOG,
        error_schema=json.loads((ROOT / "v2/schema.json").read_bytes()),
    )
    outputs = (computed.payload_json, computed.rows_json, _capture(computed))
    _require(all(type(data) is bytes and len(data) <= MAX_BYTES for data in outputs))
    for role, data in zip(OUTPUT_ROLES, outputs, strict=True):
        for message in _messages(binding, "output", role, data):
            writer.write(_line(message))
            writer.flush()
            _require(_frame(reader.readline(FRAME_BYTES + 1), binding) == _ack(message))
    writer.write(
        _line(dict(version=VERSION, binding=binding, type="complete", phase="output", roles=3))
    )
    writer.flush()
    _require(reader.read(1) == b"")  # parent closes only after every output ACK


async def _checked(awaitable, checkpoint):
    try:
        checkpoint()
    except BaseException:
        if inspect.iscoroutine(awaitable):
            awaitable.close()
        raise
    try:
        result = await awaitable
    except BaseException:
        try:
            checkpoint()
        except BaseException:
            pass  # retain the original first exception
        raise
    checkpoint()
    return result


class _AsyncLines:
    def __init__(self, reader, budget, checkpoint):
        self.reader, self.budget, self.checkpoint = reader, budget, checkpoint
        self.buffer = bytearray()

    async def line(self):
        searched = 0
        while True:
            end = self.buffer.find(b"\n", searched)
            searched = len(self.buffer)
            if end >= 0:
                _require(end + 1 <= FRAME_BYTES)
                result = bytes(self.buffer[: end + 1])
                del self.buffer[: end + 1]
                return result
            _require(len(self.buffer) < FRAME_BYTES)
            size = min(4096, FRAME_BYTES - len(self.buffer))
            self.budget.debit("read_work", 32 * size, phase="worker-stdout-pre-read")
            data = await _checked(self.reader.read(size), self.checkpoint)
            if not data:
                _require(not self.buffer)
                return b""
            self.buffer.extend(data)


async def run_profile_child(process, *, binding, input_roles, budget, checkpoint, reservation):
    """No spawn/Store: caller retains the real original owner lifecycle.

    On failure cancel/join run, use the explicit forced-close API for this bound
    process, drop caller exception/raw aliases, then release. Joining alone frees nothing.
    """
    binding = _binding(binding)
    _require(type(budget) is ProfileBudget and callable(checkpoint))
    bind_profile_child(reservation, process=process, binding=binding, budget=budget)
    owner = _bound_process(process, binding)
    _require(owner.phase == "bound")
    pending = owner.pending
    worker, parent, cleanup = pending[2], pending[3], pending[5]
    owner.phase = "running"
    _ACTIVE.add(process)
    receiver = lines = delivery = handle = None
    outstanding = None
    input_complete = False
    tasks = []
    gathered = None

    async def send(message):
        width = len(message.get("data", ""))
        budget.debit("read_work", 4 * (HEADER_BYTES + width), phase="worker-stdin-pre-write")
        raw = _line(message)
        checkpoint()
        process.stdin.write(raw)
        await _checked(process.stdin.drain(), checkpoint)

    async def inputs():
        nonlocal outstanding
        request = dict(profileWorkerVersion=1, binding=binding, memoryBytes=MEMORY_BYTES)
        budget.debit("read_work", 4 * HEADER_BYTES, phase="worker-request-pre-encode")
        raw = _canonical(request) + b"\n"
        checkpoint()
        process.stdin.write(raw)
        await _checked(process.stdin.drain(), checkpoint)
        for role in INPUT_ROLES:
            budget.debit(
                "read_work", 8 * len(input_roles[role]) + 1, phase="worker-input-pre-encode"
            )
            for message in _messages(binding, "input", role, input_roles[role]):
                _require(outstanding is None)
                future = asyncio.get_running_loop().create_future()
                outstanding = (message, future)
                await send(message)
                await _checked(future, checkpoint)

    async def outputs():
        nonlocal outstanding, input_complete
        complete = False
        while True:
            raw = await lines.line()
            if not raw:
                owner.natural_stdout = True
                _require(complete)
                return
            _require(not complete)
            message = _frame(raw, binding)
            if message["type"] == "ack":
                _require(outstanding is not None and message == _ack(outstanding[0]))
                sent, future = outstanding
                outstanding = None
                if sent["role"] == INPUT_ROLES[-1] and sent["type"] == "end":
                    input_complete = True
                future.set_result(None)
            elif message["type"] == "complete":
                _require(input_complete and receiver.position == 3 and receiver.active is None)
                complete = True
                checkpoint()
                process.stdin.close()
                await _checked(process.stdin.wait_closed(), checkpoint)
                owner.natural_stdin = True
            else:
                _require(input_complete and outstanding is None)
                receiver.accept(message)
                await send(_ack(message))

    async def stderr():
        total = 0
        while True:
            budget.debit("read_work", 4096, phase="worker-stderr-pre-read")
            data = await _checked(process.stderr.read(4096), checkpoint)
            if not data:
                owner.natural_stderr = True
                return
            total += len(data)
            _require(total <= STDERR_BYTES)

    try:
        _require(type(input_roles) is dict and len(input_roles) == 3)
        _require(
            all(type(key) is str and len(key) <= 32 for key in input_roles)
            and set(input_roles) == set(INPUT_ROLES)
        )
        for data in input_roles.values():
            _require(type(data) is bytes and len(data) <= MAX_BYTES)
        # Freeze caller mappings before the first suspension. Raw values are exact
        # immutable bytes; later caller dict mutation cannot change charged inputs.
        input_roles = {role: input_roles[role] for role in INPUT_ROLES}
        data = None
        total = sum(len(value) for value in input_roles.values())
        budget.debit("raw", total, phase="worker-input-roles")
        receiver = _Receiver(binding, "output", OUTPUT_ROLES, budget)
        lines = _AsyncLines(process.stdout, budget, checkpoint)
        checkpoint()
        tasks = [
            asyncio.create_task(inputs()),
            asyncio.create_task(outputs()),
            asyncio.create_task(stderr()),
        ]
        gathered = asyncio.gather(*tasks)
        # Caller cancellation is handled once below; it must not repeatedly
        # propagate through gather into an owned task's finally cleanup.
        await _checked(asyncio.shield(gathered), checkpoint)
        code = await _checked(process.wait(), checkpoint)
        _require(type(code) is int and code == 0 and process.returncode == 0)
        _require(owner.phase == "running" and not owner.forced)
        _require(owner.natural_stdout and owner.natural_stderr and owner.natural_stdin)
        checkpoint()
        delivery = ProfileDelivery(
            MappingProxyType(dict(receiver.values)), tuple(receiver.manifests), parent
        )
        receiver.clear()
        lines.buffer.clear()
        input_roles = None
        tasks.clear()
        gathered = None
        adapter = _closed_pipes(owner)
        _require(all(not reader._buffer and reader._exception is None for reader in adapter[4:]))
        _require(not adapter[2][0]._buffer)
        adapter = None
        # Construct/register every fallible delivery owner while all original
        # holdings and the bound failure route still exist. No await exposes it.
        handle = ProfileChildHandle()
        _ISSUED[handle] = (process, binding, delivery, budget)
        budget.release(worker, phase="worker-real-exit0-three-eof")
        pending[2] = None
        budget.release(cleanup, phase="worker-cleanup-unused-after-natural-eof")
        pending[5] = None
        owner.phase = "succeeded"
        del _BOUND[process]
        _ACTIVE.discard(process)
        return handle
    except BaseException as first:
        # Includes constructor/registration failure after actual exit0/three EOF.
        # Never publish a partial success or strand the original bound owner.
        if handle is not None and handle in _ISSUED:
            del _ISSUED[handle]
        delivery = handle = None
        for task in tasks:
            if not task.done() and not task.cancelling():
                task.cancel()
        joined = asyncio.gather(*tasks, return_exceptions=True)
        # A repeated caller cancellation must not abandon our own read tasks.
        while not joined.done():
            try:
                await asyncio.shield(joined)
            except asyncio.CancelledError:
                pass
        if gathered is not None and gathered.done() and not gathered.cancelled():
            gathered.exception()  # retrieve original gather's terminal exception
        # Finished task tracebacks must not retain temporary buffers after join.
        for task in tasks:
            if not task.cancelled() and task.exception() is not None:
                traceback.clear_frames(task.exception().__traceback__)
        traceback.clear_frames(first.__traceback__)
        if receiver is not None:
            receiver.clear()
        if lines is not None:
            lines.buffer.clear()
        outstanding = input_roles = data = None
        tasks.clear()
        _ACTIVE.discard(process)
        owner.phase = "failed"
        _FAILED[process] = owner
        raise
