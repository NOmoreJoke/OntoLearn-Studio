"""Typed definition round trips and exact stored lexical provenance."""

from copy import deepcopy

import pytest
from ontolearn_engine.project.profile_material import (
    _literal,
    material_from_snapshot,
    rule_definition,
    validate_definition,
)
from ontolearn_engine.quality.rule_firing import RuleSpec, Triple, Variable
from ontolearn_engine.quality.rule_profile import SourceRecord, TermInput
from ontolearn_engine.storage import canonical, digest


def spec():
    return RuleSpec(
        "r",
        (Triple(Variable("?s"), TermInput("iri", "urn:v"), Variable("?o")),),
        (),
        (Triple(Variable("?s"), TermInput("iri", "urn:out"), Variable("?o")),),
    )


def test_strict_definition_uses_original_codec_and_binds_enabled_revision_digest():
    payload = rule_definition(spec(), enabled=False, revision=3)
    decoded = validate_definition("rule", "r", payload, revision=3)
    assert decoded.rule_id == "r" and decoded.revision == "3"
    assert decoded.when == spec().when and decoded.heads == spec().heads
    for field, value in (("enabled", True), ("revision", "4"), ("rule_id", "other")):
        changed = deepcopy(payload)
        changed[field] = value
        with pytest.raises(ValueError):
            validate_definition("rule", "r", changed, revision=3)
    with pytest.raises(ValueError):
        validate_definition("rule", "r", {"enabled": True, "when": [], "then": []})


@pytest.mark.parametrize(
    ("raw", "lexical", "datatype", "language"),
    [
        ('"中文\\n😀"', "中文\n😀", None, None),
        ('"\\U0001F600"', "😀", None, None),
        ('"""first\nsecond"""@zh', "first\nsecond", None, "zh"),
        (
            '"01"^^<http://www.w3.org/2001/XMLSchema#integer>',
            "01",
            "http://www.w3.org/2001/XMLSchema#integer",
            None,
        ),
    ],
)
def test_store_literal_adapter_preserves_lexical_spelling(raw, lexical, datatype, language):
    source = SourceRecord("actual-snapshot", "digest", "1", raw)
    term = _literal(raw, source)
    assert (term.lexical_form, term.datatype_iri, term.language_raw) == (
        lexical,
        datatype,
        language,
    )
    assert term.source is source


@pytest.mark.parametrize("raw", ['"unclosed', '"\\uD800"', '"x"garbage', '"x"@', '"\\q"'])
def test_literal_adapter_rejects_unrepresentable_or_unknown_syntax(raw):
    with pytest.raises(ValueError):
        _literal(raw, None)


def test_snapshot_input_keeps_original_fact_source_and_disabled_record():
    payload = rule_definition(spec(), enabled=False, revision=1)
    fact = {
        "id": "fact-one",
        "subject": "urn:s",
        "predicate": "urn:v",
        "object": '"01"',
        "owner": None,
        "source_row": None,
        "managed_value": None,
    }
    snapshot = {
        "project": "p",
        "projectRevision": 1,
        "dependencyVector": {"rule:r": 1},
        "state": {
            "definitions": [{"layer": "rule", "id": "r", "payload": canonical(payload)}],
            "facts": [fact],
        },
    }
    identity = digest(snapshot)
    material = material_from_snapshot(snapshot, identity)
    assert material.disabled_rule_ids == ("r",)
    obj = material.records[0][2]
    assert obj.lexical_form == "01"
    assert obj.source.reference == f"store-snapshot:{identity}#/state/facts/0"
    assert obj.source.text == canonical(fact)


@pytest.mark.parametrize("revision", [None, 0, -1, True, 2])
def test_rule_revision_must_equal_positive_snapshot_home_version(revision):
    payload = rule_definition(spec(), enabled=True, revision=1)
    vector = {} if revision is None else {"rule:r": revision}
    snapshot = {
        "project": "p",
        "projectRevision": 2,
        "dependencyVector": vector,
        "state": {
            "definitions": [{"layer": "rule", "id": "r", "payload": canonical(payload)}],
            "facts": [],
        },
    }
    with pytest.raises(ValueError):
        material_from_snapshot(snapshot, digest(snapshot))


@pytest.mark.parametrize("revision", [0, -1, True, "1", 9007199254740992])
def test_definition_revision_is_exact_positive_safe_store_version(revision):
    with pytest.raises(ValueError):
        rule_definition(spec(), enabled=True, revision=revision)


def test_self_consistent_zero_revision_is_not_a_store_home_version():
    payload = rule_definition(spec(), enabled=True, revision=1)
    payload["revision"] = "0"
    payload["definition_digest"] = digest(
        {
            "domain": "profile-rule-content/1",
            "definition": {k: v for k, v in payload.items() if k != "definition_digest"},
        }
    )
    with pytest.raises(ValueError):
        validate_definition("rule", "r", payload, revision=0)


@pytest.mark.parametrize("raw", ['"x\ny"', '"x"@-', '"x"@zh-', '"x"@-zh'])
def test_literal_rejects_noncanonical_short_quote_and_empty_language_subtag(raw):
    with pytest.raises(ValueError):
        _literal(raw, None)
