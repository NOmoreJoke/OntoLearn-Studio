"""Private, metered profile-1 ontology source; no metadata writer or authority.

Only an already-open JobStore3 is used.  Returned material owns a retention
lease: keeping any returned container or text keeps that lease alive, including
when the top-level handle has been closed.  No T02 implementation is imported.
"""

import json
import math
import re
import sqlite3
import time
import weakref
from dataclasses import dataclass

from rdflib import Literal, URIRef

from ontolearn_engine import job_store, storage
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project import format3
from ontolearn_engine.project.applications import uuid_ref
from ontolearn_engine.project.project_host import HostReadFault, ProjectHostReader, ReadLimits
from ontolearn_engine.rdf_snapshot import iri, term
from ontolearn_engine.storage import Store, canonical, digest

MAX_WORK = 67108864
MAX_RETAINED = 8388608
MAX_SOURCE = 1048576
MAX_NODES = 65536
MAX_DEPTH = 32
MAX_RECORDS = 4096
MAX_SUPPORTS = 8192
MAX_REFERENCES = 4096
MAX_TERMS = 12288
MAX_TERM_BYTES = 1048576
MAX_TERM = 16384
MAX_QUERIES = 65536
MAX_SAFE = 9007199254740991
PROFILE = "ontology-cost-profile-v1"
_UTF16_SOURCE_ID = (
    "2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3"
)
_RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
_RDFS = "http://www.w3.org/2000/01/rdf-schema#"
_OWL = "http://www.w3.org/2002/07/owl#"
_BOOKS = weakref.WeakKeyDictionary()


class OntologyFault(Exception):
    """Finite private error. It is deliberately outside old validator catches."""

    def __init__(self, reason, *, cleanup_failed=False):
        allowed = {
            "invalid-input",
            "state",
            "resource-limit",
            "identity-conflict",
            "unsupported-source",
            "incomplete-source",
            "storage-busy",
            "storage-failure",
        }
        if reason not in allowed:
            raise ValueError("Invalid ontology reason")
        super().__init__(reason)
        self.reason = reason
        self.cleanup_failed = cleanup_failed


def _need(condition):
    if not condition:
        raise OntologyFault("incomplete-source")


def _bound(condition):
    if not condition:
        raise OntologyFault("resource-limit")


def _integer(value, maximum):
    if type(value) is not int or not 1 <= value <= maximum:
        raise OntologyFault("invalid-input")
    return value


def _sql_error(error):
    code = getattr(error, "sqlite_errorcode", None)
    fault = OntologyFault(
        "storage-busy"
        if type(code) is int and code & 255 in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}
        else "storage-failure"
    )
    fault._sqlite_code = code
    return fault


def _string_size(value):
    total = 2
    for char in value:
        code = ord(char)
        _need(code != 0 and not 0xD800 <= code <= 0xDFFF)
        total += (
            2
            if code in {8, 9, 10, 12, 13, 34, 92}
            else 6
            if code < 32
            else 1
            if code < 128
            else 2
            if code < 2048
            else 3
            if code < 65536
            else 4
        )
    return total


def _size(value, ceiling, *, depth=MAX_DEPTH, sql=False):
    """Bound scalar work before any escaping or full serialization."""
    pending, count, total = [(value, 0)], 0, 0
    while pending:
        item, level = pending.pop()
        count += 1
        _bound(count <= MAX_NODES and level <= depth)
        if isinstance(item, dict):
            _bound(len(item) <= MAX_NODES)
            total += 2 + max(0, len(item) - 1) + len(item)
            for key, child in item.items():
                _need(type(key) is str)
                pending.extend(((key, level + 1), (child, level + 1)))
        elif isinstance(item, list):
            total += 2 + max(0, len(item) - 1)
            _bound(len(item) <= MAX_NODES)
            pending.extend((child, level + 1) for child in item)
        elif isinstance(item, str):
            _bound(len(item) <= ceiling - total)
            total += 2
            for char in item:
                code = ord(char)
                _need(code != 0 and not 0xD800 <= code <= 0xDFFF)
                total += (
                    2
                    if code in {8, 9, 10, 12, 13, 34, 92}
                    else 6
                    if code < 32
                    else 1
                    if code < 128
                    else 2
                    if code < 2048
                    else 3
                    if code < 65536
                    else 4
                )
                _bound(total <= ceiling)
        elif item is None:
            total += 4
        elif type(item) is bool:
            total += 4 if item else 5
        elif type(item) is int:
            _need(-(2**63 if sql else MAX_SAFE) <= item <= (2**63 - 1 if sql else MAX_SAFE))
            total += len(str(item))
        elif not sql and type(item) is float:
            _need(math.isfinite(item) and abs(item) <= MAX_SAFE)
            total += len(canonical(item))
        else:
            raise OntologyFault("incomplete-source")
        _bound(total <= ceiling)
    return total, count


class _Book:
    def __init__(self):
        self.sessions = weakref.WeakSet()
        self.native_retained = 0
        self.native_templates = set()

    @property
    def retained(self):
        return self.native_retained + sum(session.retained for session in self.sessions)


class CostSession:
    """Trusted finite resource accounting, never a permission/binding factory."""

    def __init__(
        self,
        owner,
        *,
        work=MAX_WORK,
        retained=MAX_RETAINED,
        queries=MAX_QUERIES,
        ttl=60,
        clock=time.monotonic,
    ):
        if not isinstance(owner, JobStore) or owner._target_format != 3 or not callable(clock):
            raise OntologyFault("invalid-input")
        self.work_limit = _integer(work, MAX_WORK)
        self.retained_limit = _integer(retained, MAX_RETAINED)
        self.query_limit = _integer(queries, MAX_QUERIES)
        self.ttl = _integer(ttl, 60)
        self._clock, self._owner = clock, weakref.ref(owner)
        self.work = self.queries = self.retained = self.term_bytes = self.terms = 0
        self._locked_work = self._locked_queries = self._reads = 0
        self._busy = self.closed = False
        self._last = self._now()
        self._expires = self._last + self.ttl
        if not math.isfinite(self._expires):
            raise OntologyFault("state")
        book = _BOOKS.setdefault(owner, _Book())
        _bound(sum(not s.closed for s in book.sessions) < 4)
        self._book = book
        book.sessions.add(self)

    def _audit(self, event, **facts):
        """No production ledger retention. Tests may observe this private seam."""

    def _now(self):
        try:
            current = self._clock()
            if type(current) not in {int, float} or not math.isfinite(current):
                raise OntologyFault("state")
            if hasattr(self, "_last") and current < self._last:
                raise OntologyFault("state")
            return current
        except OntologyFault:
            raise
        except Exception:
            raise OntologyFault("state") from None

    def check(self):
        now = self._now()
        self._last = now
        if self.closed or now >= self._expires:
            raise OntologyFault("resource-limit")

    def spend(self, amount, label):
        self.check()
        _need(type(amount) is int and amount >= 0)
        if self.work + self._locked_work + amount > self.work_limit:
            self._audit(
                "work-denied",
                label=label,
                amount=amount,
                used=self.work,
                locked=self._locked_work,
                limit=self.work_limit,
            )
            raise OntologyFault("resource-limit")
        self.work += amount
        self._audit("work", label=label, amount=amount, total=self.work)

    def query(self, work, label):
        self.check()
        _bound(self.queries + self._locked_queries < self.query_limit)
        self.spend(work, label)
        self.queries += 1
        self._audit("query", label=label, total=self.queries)

    def hold(self, amount, label):
        self.check()
        _need(type(amount) is int and amount >= 0)
        _bound(self.retained + self._book.native_retained + amount <= self.retained_limit)
        _bound(self._book.retained + amount <= MAX_RETAINED)
        self.retained += amount
        self._audit("retain", label=label, amount=amount, total=self.retained)
        return _Hold(self, amount)

    def copy(self, amount, count, label):
        self.spend(count * (amount + 64), label)
        return self.hold(count * (amount + 64), label)

    def sort(self, amount, nodes, label):
        rounds = (max(1, nodes) - 1).bit_length()
        self.spend(2 * (amount + 64) * (1 + rounds), label)

    def term(self, length, count=1):
        self.check()
        _bound(self.term_bytes + length <= MAX_TERM_BYTES and self.terms + count <= MAX_TERMS)
        self.spend(16 * length + 1024 * count, "term")
        self.term_bytes += length
        self.terms += count

    def iri(self, length, count=1):
        self.spend(16 * length + 256 * count, "iri")

    def close(self):
        # Existing output/error holds are not refunded by closing the session.
        self.closed = True


class _Hold:
    def __init__(self, session, amount):
        self.session, self.amount = session, amount

    def release(self):
        if self.amount:
            amount, self.amount = self.amount, 0
            self.session.retained -= amount
            self.session._audit("release", amount=amount, total=self.session.retained)

    def __del__(self):
        self.release()


class _OwnedDict(dict):
    def _readonly(self, *_args, **_kwargs):
        raise TypeError("Read-only ontology material")

    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = __ior__ = _readonly


class _OwnedList(list):
    def _readonly(self, *_args, **_kwargs):
        raise TypeError("Read-only ontology material")

    __setitem__ = __delitem__ = append = clear = extend = insert = _readonly
    pop = remove = reverse = sort = _readonly
    __iadd__ = __imul__ = _readonly


class _OwnedText(str):
    pass


def _owned(value, hold):
    if type(value) is dict:
        result = _OwnedDict()
        result._hold = hold
        for key, child in value.items():
            dict.__setitem__(result, _owned(key, hold), _owned(child, hold))
        return result
    if type(value) is list:
        result = _OwnedList(_owned(child, hold) for child in value)
        result._hold = hold
        return result
    if type(value) is str:
        result = _OwnedText(value)
        result._hold = hold
        return result
    return value


class SourceMaterial:
    """Owner must close and drop all borrowed values before retention is freed."""

    def __init__(self, value, hold):
        self._value = _owned(value, hold)

    @property
    def value(self):
        if self._value is None:
            raise OntologyFault("state")
        return self._value

    @property
    def source(self):
        return self.value["source"]

    @property
    def source_ref(self):
        return self.value["sourceRef"]

    def close(self):
        self._value = None

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()


class _Arena:
    def __init__(self, session):
        self.session, self.holds, self.values = session, [], []

    def keep(self, value, amount, label, *, copies=1):
        hold = self.session.copy(amount, copies, label)
        self.holds.append(hold)
        self.values.append(value)
        return value

    def clear(self):
        self.values.clear()
        holds, self.holds = self.holds, []
        for hold in holds:
            hold.release()


@dataclass
class _Control:
    session: CostSession
    remaining: int = 3

    def __post_init__(self):
        s = self.session
        s.check()
        _bound(s.queries + s._locked_queries + 3 <= s.query_limit)
        _bound(s.work + s._locked_work + 768 <= s.work_limit)
        s._locked_queries += 3
        s._locked_work += 768

    def execute(self, db, sql):
        _need(self.remaining > 0 and sql in {"BEGIN", "ROLLBACK"})
        self.remaining -= 1
        self.session._locked_queries -= 1
        self.session._locked_work -= 256
        self.session.queries += 1
        self.session.work += 256
        self.session._audit(
            "control", sql=sql, queries=self.session.queries, work=self.session.work
        )
        try:
            return db.execute(sql)
        except sqlite3.Error as error:
            raise _sql_error(error) from None

    def close(self):
        self.session._locked_queries -= self.remaining
        self.session._locked_work -= 256 * self.remaining
        self.remaining = 0


def _scan_json(text):
    """Bound escaped scalars, nesting and token count before json.loads."""
    _bound(len(text) <= MAX_SOURCE)
    inside = token = False
    depth = nodes = i = 0
    while i < len(text):
        char = text[i]
        code = ord(char)
        _need(code != 0 and not 0xD800 <= code <= 0xDFFF)
        if inside:
            if char == '"':
                inside = False
            elif char == "\\":
                _need(i + 1 < len(text))
                if text[i + 1] == "u":
                    _need(i + 6 <= len(text))
                    try:
                        point = int(text[i + 2 : i + 6], 16)
                    except ValueError:
                        raise OntologyFault("incomplete-source") from None
                    _need(point != 0 and not 0xDC00 <= point <= 0xDFFF)
                    if 0xD800 <= point <= 0xDBFF:
                        _need(text[i + 6 : i + 8] == "\\u" and i + 12 <= len(text))
                        try:
                            low = int(text[i + 8 : i + 12], 16)
                        except ValueError:
                            raise OntologyFault("incomplete-source") from None
                        _need(0xDC00 <= low <= 0xDFFF)
                        i += 12
                        continue
                    i += 6
                    continue
                i += 2
                continue
            else:
                _need(code >= 32)
        elif char == '"':
            nodes += 1
            inside, token = True, False
        elif char in "[{":
            nodes += 1
            depth += 1
            token = False
            _bound(depth <= MAX_DEPTH)
        elif char in "]}":
            depth -= 1
            token = False
            _need(depth >= 0)
        elif char in ",:":
            token = False
        elif not char.isspace() and not token:
            nodes += 1
            token = True
        _bound(nodes <= MAX_NODES)
        i += 1
    _need(not inside and depth == 0)
    return nodes


class _Json:
    def __init__(self, arena):
        self.arena, self.cache = arena, {}

    def read(self, text, *, snapshot=False):
        _need(type(text) is str)
        previous = self.cache.get(id(text))
        if previous is not None and previous[0] is text:
            if snapshot:
                self._checkpoint_payloads(previous[1])
            return previous[1]
        session = self.arena.session
        session.spend(8 * (len(text) + 64), "json-lexical-scan")
        nodes = _scan_json(text)
        size = _string_size(text)
        session.spend(8 * (size - len(text)) + 128 * (nodes + 1), "json-decode")
        session.sort(size, nodes, "json-canonical-sort-bound")
        hold = session.copy(size, 2, "json-decode-buffers")
        self.arena.holds.append(hold)
        try:
            value = json.loads(text, parse_constant=lambda _v: (_ for _ in ()).throw(ValueError()))
        except (ValueError, TypeError, OverflowError, RecursionError):
            raise OntologyFault("incomplete-source") from None
        self.arena.values.extend((text, value))
        self.cache[id(text)] = (text, value)
        if snapshot:
            self._checkpoint_payloads(value)
        return value

    def _checkpoint_payloads(self, value):
        # Only a payload loaded through the real snapshots SELECT can be a
        # checkpoint carrier. Never discover carriers recursively in user data.
        if type(value) is not dict or value.get("checkpointVersion") != 1:
            return
        application = value.get("application")
        if type(application) is not dict:
            return  # The original checkpoint validator rejects the shape.
        for field in ("drafts", "learningCurrent", "assistanceAudit"):
            records = application.get(field)
            if type(records) is list:
                for record in records:
                    if type(record) is dict and type(record.get("payload")) is str:
                        self.read(record["payload"])


def _quote(name):
    return '"' + name.replace('"', '""') + '"'


_TABLE_NAMES = (
    {
        re.match(r"CREATE TABLE(?: IF NOT EXISTS)? (\w+)", sql)[1]
        for sql in storage.SCHEMA + job_store.JOB3_SCHEMA + job_store.JOB3_CATALOG
        if sql.startswith("CREATE TABLE")
    }
    | {name for name, _ in format3.TABLES}
    | {
        "sqlite_master",
        "mapping_state",
        "commit_evidence",
        "migration_log",
    }
)
_JSON_COLUMNS = {
    "payload",
    "metadata",
    "context",
    "plan",
    "implementation",
    "config",
    "evidence",
    "dependencies",
    "stale",
}


class _ReadCursor:
    def __init__(self, native, gate, *, snapshot=False):
        self.native, self.gate = native, gate
        self.snapshot = snapshot

    def _one(self, row):
        if row is not None:
            self.gate.arena.values.append(row)
            for name in row.keys():
                value = row[name]
                if name in _JSON_COLUMNS and value is not None:
                    self.gate.json.read(value, snapshot=self.snapshot and name == "payload")
        return row

    def fetchone(self):
        try:
            return self._one(self.native.fetchone())
        except sqlite3.Error as error:
            raise _sql_error(error) from None

    def fetchall(self):
        try:
            rows = self.native.fetchall()
        except sqlite3.Error as error:
            raise _sql_error(error) from None
        return [self._one(row) for row in rows]

    def fetchmany(self, count=1):
        try:
            rows = self.native.fetchmany(count)
        except sqlite3.Error as error:
            raise _sql_error(error) from None
        return [self._one(row) for row in rows]

    def __iter__(self):
        return self

    def __next__(self):
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row


class _ReadGate:
    """Same real connection. Only registered old SELECTs and fixed internal probes."""

    def __init__(self, db, arena, limits):
        self.native, self.arena, self.limits = db, arena, limits
        self.session, self.json = arena.session, _Json(arena)
        self.encoding = None
        self.columns, self.types, self.fees = {}, {}, {}
        self.guard = False
        self.evidence = 0

    @property
    def in_transaction(self):
        try:
            return self.native.in_transaction
        except sqlite3.Error as error:
            raise _sql_error(error) from None

    def _numeric(self, sql, params=(), *, columns=1, rows=1):
        self.session.query(128 + 128 * columns * rows, sql)
        hold = self.session.hold(128 * columns * rows, "sql-metadata")
        self.arena.holds.append(hold)
        try:
            return _ReadCursor(
                self.native.execute(sql, params),
                self,
                snapshot=sql == "SELECT payload FROM snapshots WHERE id=?",
            )
        except sqlite3.Error as error:
            raise _sql_error(error) from None

    def _metadata(self, sql, params=(), *, columns=1, rows=1, all_rows=False):
        try:
            cursor = self._numeric(sql, params, columns=columns, rows=rows)
            value = cursor.fetchall() if all_rows else cursor.fetchone()
            self.arena.values.append(value)
            return value
        except sqlite3.Error as error:
            raise _sql_error(error) from None

    def _column_info(self, table):
        # Only the intrinsic sqlite_schema shape is trusted before full DDL.
        _need(table == "sqlite_master")
        if table not in self.columns:
            self.columns[table] = ("type", "name", "tbl_name", "rootpage", "sql")
            self.types[table] = {
                field: {"integer", "null"} if field == "rootpage" else {"text", "null"}
                for field in self.columns[table]
            }
        return self.columns[table]

    def _schema(self, table):
        found = self._locate("sqlite_master", "WHERE type='table' AND name=?", (table,))
        _need(len(found) == 1)
        return self._fee(*found[0])


_PROJECT_TABLES = {
    "versions",
    "definitions",
    "facts",
    "mapping_state",
    "definition_retirements",
    "app_projects",
    "app_origins",
    "app_operations",
    "app_receipts",
    "app_checkpoints",
    "app_drafts",
    "app_learning",
    "app_assistance",
    "commits",
    "commit_evidence",
}


class _CacheRow(dict):
    def __iter__(self):
        return iter(dict.values(self))

    def __getitem__(self, key):
        if type(key) is int or isinstance(key, slice):
            return tuple(dict.values(self))[key]
        return dict.__getitem__(self, key)


class _CacheCursor:
    def __init__(self, rows, gate, *, snapshot=False):
        self.rows, self.gate, self.position = rows, gate, 0
        self.snapshot = snapshot

    def fetchone(self):
        if self.position >= len(self.rows):
            return None
        row = self.rows[self.position]
        self.position += 1
        self.gate.arena.values.append(row)
        for key, value in row.items():
            if key in _JSON_COLUMNS and value is not None:
                self.gate.json.read(value, snapshot=self.snapshot and key == "payload")
        return row

    def fetchall(self):
        result = []
        while (row := self.fetchone()) is not None:
            result.append(row)
        self.gate.arena.values.append(result)
        return result

    def fetchmany(self, size=1):
        return [self.fetchone() for _ in range(min(size, len(self.rows) - self.position))]

    def __iter__(self):
        return self

    def __next__(self):
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row


class _Reservation:
    def __init__(self, session, work, retained, label):
        session.check()
        _bound(session.work + session._locked_work + work <= session.work_limit)
        self.session, self.work, self.label = session, work, label
        self.hold = session.hold(retained, label)
        session._locked_work += work
        session._audit("reserve-work", amount=work, label=label, total=session._locked_work)

    def consume(self, *, retain=0, arena=None, spent=None):
        s, reserved = self.session, self.work
        work = reserved if spent is None else spent
        _need(type(work) is int and 0 <= work <= reserved)
        s._locked_work -= reserved
        s.work += work
        self.work = 0
        s._audit("work", label=self.label, amount=work, total=s.work)
        if reserved > work:
            s._audit("unused-work", label=self.label, amount=reserved - work)
        if retain:
            _need(retain <= self.hold.amount and arena is not None)
            self.hold.amount -= retain
            arena.holds.append(_Hold(s, retain))
        self.hold.release()

    def unused(self):
        self.session._locked_work -= self.work
        self.work = 0
        self.hold.release()

    def failed(self, arena, *, closed):
        s, work = self.session, self.work
        s._locked_work -= work
        s.work += work
        self.work = 0
        s._audit("work", label=self.label + "-failed", amount=work, total=s.work)
        if closed:
            self.hold.release()
        else:
            arena.holds.append(self.hold)


class _FusedTicket(_Reservation):
    def __init__(self, gate, bound, metadata_work, metadata_bytes):
        _bound(gate.evidence + gate._reserved_evidence + bound <= gate.limits.validation_bytes)
        super().__init__(gate.session, metadata_work + 8 * (bound + 64),
                         98307 + 2 * gate.page_size + metadata_bytes + 4 * (bound + 64),
                         "fused-row")
        self.gate, self.bound, self.metadata_work = gate, bound, metadata_work
        gate._reserved_evidence += bound

    def _release_evidence(self):
        self.gate._reserved_evidence -= self.bound
        self.bound = 0

    def consume(self, **kwargs):
        super().consume(**kwargs)
        self._release_evidence()

    def unused(self):
        super().unused()
        self._release_evidence()

    def failed(self, *args, **kwargs):
        super().failed(*args, **kwargs)
        self._release_evidence()


# Exact descriptors for the old registered queries. No arbitrary SQL parser.
_CACHE_SELECTS = {
    "SELECT internal FROM public_projects WHERE public=?": (
        "public_projects",
        ("internal",),
        ("public",),
        (),
    ),
    "SELECT revision FROM projects WHERE id=?": ("projects", ("revision",), ("id",), ()),
    "SELECT key,version FROM versions WHERE project=?": (
        "versions",
        ("key", "version"),
        ("project",),
        ("key",),
    ),
    "SELECT layer,id FROM definitions WHERE project=?": (
        "definitions",
        ("layer", "id"),
        ("project",),
        ("layer", "id"),
    ),
    "SELECT layer,id,payload FROM definitions WHERE project=? ORDER BY layer,id": (
        "definitions",
        ("layer", "id", "payload"),
        ("project",),
        ("layer", "id"),
    ),
    "SELECT owner FROM mapping_state WHERE project=? ORDER BY owner": (
        "mapping_state",
        ("owner",),
        ("project",),
        ("owner",),
    ),
    "SELECT generated_version FROM mapping_state WHERE project=? AND owner=?": (
        "mapping_state",
        ("generated_version",),
        ("project", "owner"),
        (),
    ),
    "SELECT layer,id FROM definition_retirements WHERE project=?": (
        "definition_retirements",
        ("layer", "id"),
        ("project",),
        ("layer", "id"),
    ),
    "SELECT layer,id FROM definition_retirements WHERE project=? ORDER BY layer,id": (
        "definition_retirements",
        ("layer", "id"),
        ("project",),
        ("layer", "id"),
    ),
    "SELECT id,subject,predicate,object,owner,source_row,managed_value FROM facts WHERE project=? ORDER BY id": (
        "facts",
        ("id", "subject", "predicate", "object", "owner", "source_row", "managed_value"),
        ("project",),
        ("id",),
    ),
    "SELECT sql FROM sqlite_master WHERE name=?": ("sqlite_master", ("sql",), ("name",), ()),
    "SELECT * FROM migration_log": ("migration_log", None, (), ()),
    "SELECT * FROM app_format": ("app_format", None, (), ()),
    "SELECT * FROM job_format": ("job_format", None, (), ()),
    "SELECT * FROM app_projects WHERE project=?": ("app_projects", None, ("project",), ()),
    "SELECT * FROM app_origins WHERE project=?": ("app_origins", None, ("project",), ()),
    "SELECT * FROM app_operations WHERE project=? ORDER BY sequence": (
        "app_operations",
        None,
        ("project",),
        ("sequence",),
    ),
    "SELECT domain_revision FROM app_operations WHERE project=? AND kind='legacy-domain' ORDER BY sequence": (
        "app_operations",
        ("domain_revision",),
        ("project", ("kind", "legacy-domain")),
        ("sequence",),
    ),
    "SELECT domain_revision FROM app_origins WHERE project=?": (
        "app_origins",
        ("domain_revision",),
        ("project",),
        (),
    ),
    "SELECT * FROM app_checkpoints WHERE id=? AND project=?": (
        "app_checkpoints",
        None,
        ("id", "project"),
        (),
    ),
    "SELECT payload FROM snapshots WHERE id=?": ("snapshots", ("payload",), ("id",), ()),
    "SELECT payload FROM app_receipts WHERE project=? AND operation=?": (
        "app_receipts",
        ("payload",),
        ("project", "operation"),
        (),
    ),
    "SELECT operation FROM commits WHERE project=?": (
        "commits",
        ("operation",),
        ("project",),
        ("operation",),
    ),
    "SELECT count(*) FROM app_receipts WHERE project=?": (
        "app_receipts",
        ("count(*)",),
        ("project",),
        (),
    ),
    "SELECT id FROM app_checkpoints WHERE project=?": (
        "app_checkpoints",
        ("id",),
        ("project",),
        (),
    ),
    "SELECT migration_id FROM app_format WHERE singleton=1": (
        "app_format",
        ("migration_id",),
        (("singleton", 1),),
        (),
    ),
    "SELECT * FROM operation_claims WHERE operation=?": (
        "operation_claims",
        None,
        ("operation",),
        (),
    ),
    "SELECT * FROM app_operations WHERE project=? AND operation=?": (
        "app_operations",
        None,
        ("project", "operation"),
        (),
    ),
    "SELECT * FROM app_receipts WHERE project=? AND operation=?": (
        "app_receipts",
        None,
        ("project", "operation"),
        (),
    ),
    "SELECT * FROM job_plans WHERE ref=? AND project=?": (
        "job_plans",
        None,
        ("ref", "project"),
        (),
    ),
    "SELECT * FROM job_confirmations WHERE id=? AND project=?": (
        "job_confirmations",
        None,
        ("id", "project"),
        (),
    ),
    "SELECT editor,generation,present,bound_revision,payload,content_hash FROM app_drafts WHERE project=? ORDER BY editor": (
        "app_drafts",
        ("editor", "generation", "present", "bound_revision", "payload", "content_hash"),
        ("project",),
        ("editor",),
    ),
    "SELECT attempt,record_version,course,task,payload FROM app_learning WHERE project=? ORDER BY attempt": (
        "app_learning",
        ("attempt", "record_version", "course", "task", "payload"),
        ("project",),
        ("attempt",),
    ),
    "SELECT sequence,attempt,event_id,payload FROM app_assistance WHERE project=? ORDER BY sequence": (
        "app_assistance",
        ("sequence", "attempt", "event_id", "payload"),
        ("project",),
        ("sequence",),
    ),
}


class _RowCacheGate(_ReadGate):
    """Trial: prepaid bounded row streams, then finite same-snapshot projections."""

    def __init__(self, db, arena, limits):
        super().__init__(db, arena, limits)
        self.row_cache, self.row_ids, self.column_rows, self.indexes = {}, {}, {}, {}
        self.record_fees = {}
        self._reserved_evidence = 0
        self._source_checked, self._schema_checked = False, False
        self.page_size = None

    def utf16_features(self):
        if self._source_checked:
            return
        actual = self._metadata("SELECT sqlite_version(),sqlite_source_id()", columns=2)
        if tuple(actual) != ("3.50.4", _UTF16_SOURCE_ID):
            raise OntologyFault("unsupported-source")
        try:
            feature = self._metadata("SELECT octet_length('x')", columns=1)[0]
        except OntologyFault as error:
            code = getattr(error, "_sqlite_code", None)
            if type(code) is int and code & 255 == sqlite3.SQLITE_ERROR:
                raise OntologyFault("unsupported-source") from None
            raise
        if feature != (1 if self.encoding == "UTF-8" else 2):
            raise OntologyFault("unsupported-source")
        self._source_checked = True

    def _setup(self):
        if self.page_size is not None:
            return
        self.utf16_features()
        ps = self._metadata("PRAGMA page_size")[0]
        pages = self._metadata("PRAGMA page_count")[0]
        _need(type(ps) is int and 512 <= ps <= 65536 and ps & (ps - 1) == 0)
        _need(type(pages) is int and 1 <= pages <= MAX_SAFE // ps)
        self.page_size, self.page_count = ps, pages

    def _stream(self, sql, columns, admission):
        """One execute step plus CPython's one-row lookahead, paid before calls."""
        self._setup()
        ps, s = self.page_size, self.session
        s.query(8192 + 2 * ps, "bounded-stream-open")
        # Every valid-prefix row admits O(1) tree pages; a final unknown path
        # stays reserved until clean EOF or is consumed on failure.
        frontier = _Reservation(s, 80 * ps, 20 * ps, "btree-frontier")
        current = ahead = None
        cursor = None
        first, closed, count = None, False, 0
        previous = None
        rows = []
        try:
            current = admission(0)
            cursor = self.native.execute(sql)
            if hasattr(admission, "prepared"):
                admission.prepared()
            while True:
                ahead = admission(count + 1)
                row = cursor.fetchone()
                if row is None:
                    current.unused()
                    current = None
                    ahead.unused()
                    ahead = None
                    break
                _bound(count < self.limits.validation_rows)
                _need(len(row) == columns)
                _need(type(row[0]) is int and (previous is None or row[0] > previous))
                previous = row[0]
                if hasattr(admission, "settle"):
                    admission.settle(row, count, current)
                else:
                    current.consume(retain=admission.retention(count), arena=self.arena)
                current = ahead
                ahead = None
                rows.append(row)
                self.arena.values.append(row)
                count += 1
        except sqlite3.Error as error:
            first = _sql_error(error)
        except BaseException as error:
            first = error
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                    closed = True
                except BaseException as error:
                    if first is None:
                        first = _sql_error(error) if isinstance(error, sqlite3.Error) else error
                    first.cleanup_failed = True
            for pending in (current, ahead):
                if pending is not None:
                    pending.failed(self.arena, closed=closed and first is None)
            if first is None:
                frontier.unused()
            else:
                frontier.failed(self.arena, closed=closed)
        if first is not None:
            raise first from None
        self.arena.values.append(rows)
        return rows

    def _capture(self, table):
        if table in self.row_cache:
            return self.row_cache[table]
        self._setup()
        if table not in _TABLE_NAMES:
            raise OntologyFault("unsupported-source")
        fields = self._column_info(table)
        # sqlite_master is the fixed intrinsic five-column table. Every other
        # table has first passed the exact immutable DDL catalog comparison.
        _need(not {name.lower() for name in fields} & {"rowid", "oid", "_rowid_"})
        reverse, s, ps = tuple(reversed(fields)), self.session, self.page_size
        ncol = len(fields)
        metadata_bytes = 128 * (2 * ncol + 2)
        small = min(32768, self.limits.validation_bytes)
        fixed = 2 + max(0, ncol - 1) + ncol + sum(_string_size(f) for f in fields)
        _bound(fixed <= small)
        # Bounded grammar only. Pay construction/prepare before assembling any
        # repeated CASE text; native statement-cache code remains owner-held.
        s.spend(128 * (ncol + 1), "template-name-inventory")
        lengths = [2 * len(field) + 2 for field in fields]
        condition_upper = 64 + sum(256 + 4 * length for length in lengths) + ncol
        template_upper = (256 + 2 * len(table) + sum(64 + 2 * length for length in lengths)
                          + (ncol + 1) * (condition_upper + 128 + 2 * max(lengths)))
        s.spend(8192 + 16 * template_upper + 2048 * (ncol + 1) ** 2, "fused-template-prepare")
        key = (table, self.encoding, small)
        native_hold = 8192 + 4 * template_upper + 512 * (ncol + 1) ** 2
        book = s._book
        if key not in book.native_templates:
            _bound(book.retained + native_hold <= MAX_RETAINED)
            _bound(s.retained + book.native_retained + native_hold <= s.retained_limit)
            book.native_retained += native_hold
            book.native_templates.add(key)
            s._audit("native-cache-retain", amount=native_hold, total=book.native_retained)
        template_scratch = s.hold(4 * template_upper + 2048 * (ncol + 1) ** 2,
                                  "template-prepare-scratch")
        # On any failure the exception arena retains this scratch conservatively.
        self.arena.holds.append(template_scratch)
        total_parts = [str(fixed)]
        for field in reverse:
            name = _quote(field)
            allowed = self.types[table][field]
            parts = ["CASE typeof(" + name + ")"]
            if "text" in allowed:
                multiplier = 6 if self.encoding == "UTF-8" else 3
                # Clip BEFORE multiplication. With <=32 fields, every summand
                # is <=small+1, so the sum is a finite SQLite int64, never REAL.
                maximum = max(0, (small - 2) // multiplier)
                parity = "" if self.encoding == "UTF-8" else " AND octet_length(" + name + ")%2=0"
                parts.append(
                    " WHEN 'text' THEN CASE WHEN octet_length(" + name + ") BETWEEN 0 AND "
                    + str(maximum) + parity + " THEN 2+" + str(multiplier)
                    + "*octet_length(" + name + ") ELSE " + str(small + 1) + " END"
                )
            if "integer" in allowed:
                parts.append(" WHEN 'integer' THEN 20")
            if "null" in allowed:
                parts.append(" WHEN 'null' THEN 4")
            parts.append(" ELSE " + str(small + 1) + " END")
            total_parts.append("".join(parts))
        condition = "(" + "+".join(total_parts) + ")<=" + str(small)
        meta = [expr for field in reverse for expr in (
            "typeof(" + _quote(field) + ")", "octet_length(" + _quote(field) + ")")]
        body = ["CASE WHEN " + condition + " THEN " + (
            "CAST(" + _quote(field) + " AS BLOB)" if "text" in self.types[table][field]
            else _quote(field)) + " ELSE NULL END" for field in reverse]
        sql = "SELECT rowid," + ",".join(meta + body + ["CASE WHEN " + condition + " THEN 1 ELSE 0 END"])
        sql += " FROM " + _quote(table) + " ORDER BY rowid LIMIT " + str(self.limits.validation_rows + 1)
        records, missing, ids = [], [], []

        def base(position):
            # UTF16 needs an extra octet_length for parity in each CASE. These
            # local copies and the oversized-header path are mutually exclusive.
            copies = (6 if self.encoding == "UTF-8" else 8) * (ncol + 1) + 4
            return max(2 * 98307, copies * ps) + (2 if position == 0 else 4) * ps + 2 * metadata_bytes * (ncol + 2)

        def admission(position):
            return _FusedTicket(self, small, base(position), metadata_bytes)

        def settle(row, position, ticket):
            rid, specs, bound = row[0], {}, fixed
            for pos, field in enumerate(reverse):
                kind, native = row[1 + 2 * pos], row[2 + 2 * pos]
                _need(kind in self.types[table][field])
                if kind == "text":
                    _need(type(native) is int and native >= 0)
                    _need(self.encoding == "UTF-8" or native % 2 == 0)
                    field_bound = 2 + native * (6 if self.encoding == "UTF-8" else 3)
                elif kind == "null":
                    _need(native is None)
                    field_bound = 4
                else:
                    _need(type(native) is int and 1 <= native <= 40)
                    field_bound = 20
                specs[field] = kind, native
                bound += field_bound
            accepted = row[-1]
            _need(type(accepted) is int and accepted in {0, 1})
            _need(bool(accepted) == (bound <= small))
            ids.append(rid)
            if not accepted:
                _need(all(value is None for value in tuple(row)[1 + 2 * ncol:-1]))
                ticket.consume(spent=ticket.metadata_work, retain=metadata_bytes, arena=self.arena)
                missing.append((position, rid, specs, bound))
                records.append(None)
                return
            values = tuple(row)[1 + 2 * ncol:-1]
            record = self._decode_record(table, rid, reverse, fields, values, specs, bound)
            records.append(record)
            ticket.consume(spent=ticket.metadata_work + 8 * (bound + 64),
                           retain=metadata_bytes + 4 * (bound + 64), arena=self.arena)

        admission.settle = settle
        _need(len(sql) <= template_upper)
        del total_parts, meta, body, condition, parts
        admission.prepared = template_scratch.release
        self._stream(sql, 3 * ncol + 2, admission)
        for position, rid, specs, bound in missing:
            _bound(self.evidence + bound <= self.limits.validation_bytes)
            # The actual rowid predicate is outside CASE and uses SeekRowid;
            # LIMIT 1 ensures CPython's lookahead goes to DONE, not a new row.
            ticket = _Reservation(s, 80 * ps + 2 * 98307 + 8 * (bound + 64),
                                  20 * ps + 98307 + 4 * (bound + 64), "fused-large-row")
            cursor, first = None, None
            try:
                s.query(8192, "fused-large-row-open")
                expressions = ["CAST(" + _quote(f) + " AS BLOB)" if "text" in self.types[table][f]
                               else _quote(f) for f in reverse]
                cursor = self.native.execute("SELECT rowid," + ",".join(expressions)
                    + " FROM " + _quote(table) + " WHERE rowid=? LIMIT 1", (rid,))
                row = cursor.fetchone()
                _need(row is not None and row[0] == rid and len(row) == ncol + 1)
                self.arena.values.append(row)
                records[position] = self._decode_record(table, rid, reverse, fields, tuple(row)[1:], specs, bound)
                ticket.consume(retain=4 * (bound + 64), arena=self.arena)
            except BaseException as error:
                first = _sql_error(error) if isinstance(error, sqlite3.Error) else error
            finally:
                if cursor is not None:
                    try:
                        cursor.close()
                    except BaseException as error:
                        if first is None:
                            first = _sql_error(error) if isinstance(error, sqlite3.Error) else error
                        first.cleanup_failed = True
                if first is not None:
                    ticket.failed(self.arena, closed=False)
            if first is not None:
                raise first from None
        self.row_cache[table], self.row_ids[table] = records, ids
        if table == "sqlite_master" and not self._schema_checked:
            self._schema_checked = True
            guarded, self.guard = self.guard, False
            try:
                _schema_catalog(_SourceView(self))
            finally:
                self.guard = guarded
        return records

    def _decode_record(self, table, rid, reverse, fields, raw, specs, bound):
        values = dict(zip(reverse, raw))
        for field, value in values.items():
            kind, native = specs[field]
            _need((kind == "text" and type(value) is bytes)
                  or (kind == "integer" and type(value) is int)
                  or (kind == "null" and value is None))
            if kind == "text":
                _need(len(value) == native)
                try:
                    values[field] = value.decode(self.encoding, errors="strict")
                except UnicodeError:
                    raise OntologyFault("incomplete-source") from None
        record = _CacheRow((field, values[field]) for field in fields)
        size, _nodes = _size(record, bound, depth=2, sql=True)
        _need(size <= bound)
        _bound(self.evidence + size <= self.limits.validation_bytes)
        self.evidence += size
        self.fees[(table, rid)] = self.record_fees[id(record)] = size
        self.session._audit("evidence-row", table=table, rowid=rid, bytes=size,
                            total=self.evidence, upper=bound)
        self.arena.values.append(record)
        return record

    def _fee(self, table, rowid):
        self._capture(table)
        _need((table, rowid) in self.fees)
        return self.fees[(table, rowid)]

    def _key(self, value):
        if value is None:
            return (0, 0)
        if type(value) is int:
            return (1, value)
        _need(type(value) is str)
        return (2, value.encode(self.encoding))

    def _lookup(self, table, constraints=()):
        records = self._capture(table)
        fields = tuple(field for field, _value in constraints)
        if fields:
            key = (table, fields)
            index = self.indexes.get(key)
            if index is None:
                total = sum(self.fees[(table, rid)] for rid in self.row_ids[table])
                self.session.spend(4 * (total + 64) + 128 * len(records), "cache-index-build")
                self.arena.holds.append(self.session.copy(total, 1, "cache-index-retention"))
                index = {}
                for row in records:
                    index.setdefault(tuple(row[f] for f in fields), []).append(row)
                self.indexes[key] = index
            params = tuple(value for _field, value in constraints)
            # SQL equality with a NULL parameter never yields TRUE.
            records = [] if None in params else index.get(params, [])
        self.session.spend(128 + 128 * len(records), "cache-filter")
        return records

    def _record_total(self, records):
        # Pay the bounded container walk before inspecting the cached scalars.
        # Full strings were metered at capture; no repeated body size scan.
        self.session.spend(128 + 128 * len(records), "cache-fee-inventory")
        return sum(self.record_fees[id(row)] for row in records)

    def _project_rows(self, table, records, projection=None, order=(), *, snapshot=False):
        fields = self.columns[table] if projection is None else projection
        total = self._record_total(records)
        self.session.query(128 + total, "cached-fixed-select")
        self.arena.holds.append(self.session.copy(total, 2, "cached-projection"))
        if order:
            self.session.sort(total, len(records), "cached-order")
            records = sorted(records, key=lambda row: tuple(self._key(row[f]) for f in order))
        result = [_CacheRow((field, row[field]) for field in fields) for row in records]
        return _CacheCursor(result, self, snapshot=snapshot)

    def _locate(self, table, where, params):
        # Internal metadata callers only. Do not parse a general WHERE string.
        mapping = {
            "": (),
            "WHERE project=?": ("project",),
            "WHERE type='table' AND name=?": ("type", "name"),
        }
        if where not in mapping:
            raise OntologyFault("unsupported-source")
        constraints = (
            tuple(zip(mapping[where], params))
            if where != "WHERE type='table' AND name=?"
            else (("type", "table"), ("name", params[0]))
        )
        records = self._lookup(table, constraints)
        by_id = {id(row): rid for rid, row in zip(self.row_ids[table], self.row_cache[table])}
        return [(table, by_id[id(row)]) for row in records]

    def scan(self, table, project=None):
        _need(table in _PROJECT_TABLES)
        records = self._lookup(table, () if project is None else (("project", project),))
        return self._project_rows(table, records).fetchall()

    def execute(self, sql, params=()):
        sql = " ".join(sql.split())
        if self.guard:
            return self._guard(sql, params)
        spec = _CACHE_SELECTS.get(sql)
        if spec is not None:
            table, projection, conditions, order = spec
            constraints, offset = [], 0
            for condition in conditions:
                if isinstance(condition, tuple):
                    constraints.append(condition)
                else:
                    _need(offset < len(params))
                    constraints.append((condition, params[offset]))
                    offset += 1
            _need(offset == len(params))
            records = self._lookup(table, tuple(constraints))
            if projection == ("count(*)",):
                self.session.query(256, "cached-count")
                return _CacheCursor([_CacheRow({"count(*)": len(records)})], self)
            return self._project_rows(
                table,
                records,
                projection,
                order,
                snapshot=sql == "SELECT payload FROM snapshots WHERE id=?",
            )
        if sql in {
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='definition_retirements'",
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='operation_claims'",
        }:
            _need(not params)
            name = (
                "definition_retirements" if "definition_retirements" in sql else "operation_claims"
            )
            records = self._lookup("sqlite_master", (("type", "table"), ("name", name)))
            self.session.query(256, "cached-exists")
            return _CacheCursor([_CacheRow({"1": 1}) for _ in records], self)
        if (
            sql
            == "SELECT owner FROM mapping_state WHERE project=? UNION SELECT owner FROM facts WHERE project=? AND owner IS NOT NULL"
        ):
            _need(len(params) == 2)
            left = self._lookup("mapping_state", (("project", params[0]),))
            right = self._lookup("facts", (("project", params[1]),))
            total = self._record_total(left) + self._record_total(right)
            self.session.query(128 + total, "cached-union")
            self.arena.holds.append(self.session.copy(total, 2, "cached-union"))
            self.session.sort(total, len(left) + len(right), "cached-union-order")
            values = {row["owner"] for row in left} | {
                row["owner"] for row in right if row["owner"] is not None
            }
            return _CacheCursor(
                [_CacheRow({"owner": v}) for v in sorted(values, key=self._key)], self
            )
        if (
            sql
            == "SELECT c.*,e.before_snapshot,e.after_snapshot FROM commits c LEFT JOIN commit_evidence e ON e.project=c.project AND e.operation=c.operation WHERE c.project=? AND c.operation=?"
        ):
            _need(len(params) == 2)
            left = self._lookup("commits", (("project", params[0]), ("operation", params[1])))
            right = self._lookup(
                "commit_evidence", (("project", params[0]), ("operation", params[1]))
            )
            total = self._record_total(left) + self._record_total(right)
            self.session.query(128 + total, "cached-left-join")
            self.arena.holds.append(self.session.copy(total, 2, "cached-left-join"))
            return _CacheCursor(
                [
                    _CacheRow(
                        {
                            **row,
                            "before_snapshot": r["before_snapshot"] if r else None,
                            "after_snapshot": r["after_snapshot"] if r else None,
                        }
                    )
                    for row in left
                    for r in (right or [None])
                ],
                self,
            )
        raise OntologyFault("unsupported-source")

    def _guard(self, sql, params):
        _need(not params)
        if sql == "SELECT count(*),coalesce(sum(length(CAST(sql AS BLOB))),0) FROM sqlite_master":
            records = self._capture("sqlite_master")
            total = self._record_total(records)
            self.session.spend(4 * (total + 64), "schema-aggregate-scan")
            size = sum(len(r["sql"].encode(self.encoding)) for r in records if r["sql"] is not None)
            self.session.query(384, "cached-schema-aggregate")
            return _CacheCursor([_CacheRow({"count(*)": len(records), "size": size})], self)
        if sql == "SELECT name FROM sqlite_master WHERE type='table'":
            return self._project_rows(
                "sqlite_master", self._lookup("sqlite_master", (("type", "table"),)), ("name",)
            )
        if sql.startswith('PRAGMA table_info("'):
            names = {f"PRAGMA table_info({_quote(t)})": t for t in _TABLE_NAMES}
            table = names.get(sql)
            if table is None:
                raise OntologyFault("unsupported-source")
            self._column_info(table)
            self.session.query(128 + 128 * 6 * len(self.column_rows[table]), "cached-table-info")
            return _CacheCursor(
                [
                    _CacheRow(
                        zip(("cid", "name", "type", "notnull", "dflt_value", "pk"), tuple(row))
                    )
                    for row in self.column_rows[table]
                ],
                self,
            )
        for table in _TABLE_NAMES:
            if sql.startswith("SELECT count(*),coalesce(sum(") and sql.endswith(
                " FROM " + _quote(table)
            ):
                records = self._capture(table)
                total = self._record_total(records)
                self.session.spend(4 * (total + 64), "table-aggregate-scan")
                size = sum(
                    len((str(v) if type(v) is int else v).encode(self.encoding))
                    for r in records
                    for v in r.values()
                    if v is not None
                )
                self.session.query(384, "cached-table-aggregate")
                return _CacheCursor([_CacheRow({"count(*)": len(records), "size": size})], self)
        raise OntologyFault("unsupported-source")

    def _column_info(self, table):
        if table in self.columns:
            return self.columns[table]
        if table == "sqlite_master":
            return super()._column_info(table)
        self._capture("sqlite_master")
        schema_fee = self._schema(table)
        # DDL is already exactly matched against the fixed approved catalog.
        self.session.query(8192 + 8 * (schema_fee + 64), "fixed-table-info")
        maximum = 2 * (schema_fee + 128 * 6 * 32 + 64)
        copy_ticket = _Reservation(self.session, maximum, maximum, "table-info-copy")
        cursor, rows, first = None, None, None
        try:
            cursor = self.native.execute(f"PRAGMA table_info({_quote(table)})")
            rows = cursor.fetchall()
            _bound(0 < len(rows) <= 32)
        except BaseException as error:
            first = _sql_error(error) if isinstance(error, sqlite3.Error) else error
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except BaseException as error:
                    if first is None:
                        first = _sql_error(error) if isinstance(error, sqlite3.Error) else error
                    first.cleanup_failed = True
            if first is not None:
                copy_ticket.failed(self.arena, closed=False)
        if first is not None:
            raise first from None
        actual_copy = 2 * (schema_fee + 128 * 6 * len(rows) + 64)
        copy_ticket.consume(spent=actual_copy, retain=actual_copy, arena=self.arena)
        self.arena.values.append(rows)
        self.column_rows[table] = rows
        self.columns[table] = tuple(row[1] for row in rows)
        types = {}
        for row in rows:
            kind = {"TEXT": "text", "INTEGER": "integer", "INT": "integer"}.get(row[2].upper())
            if kind is None:
                raise OntologyFault("unsupported-source")
            types[row[1]] = {kind} if row[3] else {kind, "null"}
        self.types[table] = types
        return self.columns[table]


class _SourceView:
    _read = Store._read
    _has_retirements = Store._has_retirements
    _project = JobStore._project
    revision = Store.revision
    state = Store.state
    mapping_status = Store.mapping_status
    marker = Store.marker
    _project_snapshot = Store._project_snapshot
    _definition = staticmethod(Store._definition)

    def __init__(self, gate):
        self._db, self.arena, self.cost = gate, gate.arena, gate.session
        self._target_format = 3
        self.state_bytes, self.state_records = 0, 0

    def _copy_state(self, label):
        self.arena.holds.append(self.cost.copy(self.state_bytes, 2, label))
        self.cost.sort(self.state_bytes, self.state_records, label + "-sort")

    def _state(self, project):
        self._copy_state("state")
        return Store._state(self, project)

    def vector(self, project):
        self._copy_state("vector")
        return Store.vector(self, project)

    def retirement_control(self, project):
        self._copy_state("retirement-control")
        return Store.retirement_control(self, project)

    def load_snapshot(self, identity):
        return Store.load_snapshot(self, identity)

    def _snapshot_state(self, state):
        # Original Store classmethod remains bound to Store; its complete inner
        # _definition/term path is prepaid here, not monkey-patched or copied.
        self.cost.spend(
            128 * (len(state["definitions"]) + len(state["facts"]) + 1), "snapshot-shape-inventory"
        )
        size, nodes = _size(state, MAX_SOURCE)
        definitions, refs, objects, iri_values, encoded_payloads = [], 0, [], [], 0
        for record in state["definitions"]:
            raw = record["payload"]
            value = self._db.json.read(raw)
            definitions.append(value)
            encoded_payloads += _string_size(raw)
            if type(value) is dict:
                refs += len(value.get("references", []))
                for triple in value.get("triples", []):
                    objects.append(triple["object"])
                    iri_values.extend((triple["subject"], triple["predicate"]))
                iri_values.extend(value.get("singleValuedPredicates", []))
        for record in state["facts"]:
            iri_values.extend((record["subject"], record["predicate"]))
            if record["owner"] is None:
                objects.append(record["object"])
            else:
                objects.append(record["managed_value"])
                if record["object"] is not None:
                    objects.append(record["object"])
        _bound(len(state["definitions"]) + len(state["facts"]) <= MAX_RECORDS)
        _bound(refs <= MAX_REFERENCES)
        for value in (*objects, *iri_values):
            _need(type(value) is str)
            _bound(len(value) <= MAX_TERM)
        lengths = [_utf8_size(value) for value in objects]
        iri_lengths = [_utf8_size(value) for value in iri_values]
        self.arena.holds.append(self.cost.copy(size, 2, "snapshot-shape-copy"))
        self.arena.holds.append(self.cost.copy(encoded_payloads, 2, "snapshot-payload-copy"))
        self.cost.sort(size, nodes, "snapshot-shape-sort")
        self.cost.term(sum(lengths), len(lengths))
        self.cost.iri(sum(iri_lengths), len(iri_lengths))
        self.cost.spend(128 * (nodes + len(definitions) + refs + 1), "snapshot-shape-nodes")
        Store._snapshot_state(state)


def _schema_catalog(view):
    if getattr(view._db, "_catalog_validated", False):
        return
    format3._domain_schema(view)
    objects = list(format3.TABLES + format3.TRIGGERS)
    objects.extend(
        (job_store._job_object_name(sql), sql)
        for sql in job_store.JOB3_SCHEMA + job_store.JOB3_CATALOG
    )
    for name, expected in objects:
        row = view._db.execute("SELECT sql FROM sqlite_master WHERE name=?", (name,)).fetchone()
        _need(row is not None and format3._schema(row[0]) == format3._schema(expected))
    view._db._catalog_validated = True


def _catalog(view):
    _schema_catalog(view)
    apps = view._db.execute("SELECT * FROM app_format").fetchall()
    jobs = view._db.execute("SELECT * FROM job_format").fetchall()
    _need(len(apps) == len(jobs) == 1)
    app, job = apps[0], jobs[0]
    _need(type(app["schema_version"]) is int and app["schema_version"] == 1)
    _need(app["schema_hash"] == format3.SCHEMA_HASH)
    _need(type(app["source_format"]) is int and app["source_format"] in {0, 1, 2})
    _need(format3._text(app["migration_id"]))
    _need(app["backup_hash"] is None or re.fullmatch(r"[a-f0-9]{64}", app["backup_hash"]))
    _need(type(job["schema_version"]) is int and job["schema_version"] == 3)
    _need(job["schema_hash"] == job_store.JOB3_HASH and job["source_kind"] in {"new", "v2"})


def _prepare_history(view, public, internal):
    """Locate material for a conservative parent-helper bound, never certify it."""
    gate = view._db
    inventories = {table: gate.scan(table, internal) for table in sorted(_PROJECT_TABLES)}
    current = sum(
        gate._fee(table, rowid)
        for table, rowid in gate.fees
        if table in {"versions", "definitions", "facts", "mapping_state", "definition_retirements"}
    )
    view.state_bytes = current
    view.state_records = sum(
        len(inventories[table])
        for table in ("definitions", "facts", "mapping_state", "versions", "definition_retirements")
    )
    references = set()
    for checkpoint in inventories["app_checkpoints"]:
        references.add(checkpoint["domain_snapshot"])
    for item in inventories["commit_evidence"]:
        references.update((item["before_snapshot"], item["after_snapshot"]))
    for reference in references:
        _need(type(reference) is str and re.fullmatch(r"[a-f0-9]{64}", reference))
        row = gate.execute("SELECT payload FROM snapshots WHERE id=?", (reference,)).fetchone()
        _need(row is not None)
    for operation in inventories["app_operations"]:
        if operation["kind"] not in {"application", "combined"}:
            continue
        claim = gate.execute(
            "SELECT * FROM operation_claims WHERE operation=?", (operation["operation"],)
        ).fetchone()
        _need(claim is not None)
        context = gate.json.read(claim["context"])
        if type(context) is dict and "projectCreateContextVersion" in context:
            continue
        _need(type(context) is dict)
        auth = context["request"]["authorization"]
        if auth["preparedPlanRef"] is not None:
            gate.execute(
                "SELECT * FROM job_plans WHERE ref=? AND project=?",
                (auth["preparedPlanRef"], public),
            ).fetchone()
            gate.execute(
                "SELECT * FROM job_confirmations WHERE id=? AND project=?",
                (auth["confirmationRef"], public),
            ).fetchone()
    material_bytes = sum(
        size for (table, _row), size in gate.fees.items() if table != "sqlite_master"
    )
    q = len(inventories["app_operations"]) + len(inventories["app_checkpoints"]) + len(references)
    # Parent pure canonical/copy/control-flow bound. Actual SQL, JSON and RDF
    # operations retain their individual, pre-execution charges as well.
    view.cost.spend(8 * (current + material_bytes + 1024) * (1 + q), "history-parent-bound")
    view.cost.sort(current + material_bytes, view.state_records + q, "history-parent-sort")
    return inventories


def _parse_object(cost, value):
    _need(type(value) is str)
    _bound(len(value) <= MAX_TERM)
    length = _utf8_size(value)
    _bound(length <= MAX_TERM)
    cost.term(length)
    result = term(value)
    _need(result.n3() == value)
    return result


def _utf8_size(value):
    total = 0
    for char in value:
        point = ord(char)
        _need(point != 0 and not 0xD800 <= point <= 0xDFFF)
        total += 1 if point < 128 else 2 if point < 2048 else 3 if point < 65536 else 4
    return total


def _literal_material(value):
    if isinstance(value, URIRef):
        return {"kind": "iri", "iri": str(value)}
    _need(isinstance(value, Literal))
    return {
        "kind": "literal",
        "text": str(value),
        "language": value.language or "",
        "datatype": str(value.datatype) if value.datatype is not None else None,
    }


def _project_material(view, source):
    cost, state = view.cost, source["state"]
    # Pay the bounded traversal/canonical profile before building any projection
    # sets, per-support records, terms, or metadata copies.
    cost.spend(8 * (view._db.evidence + 64), "source-material-scan")
    source_size, source_nodes = _size(source, MAX_SOURCE)
    cost.sort(source_size, source_nodes, "source-material-order")
    view.arena.holds.append(cost.copy(source_size, 3, "source-material-buffers"))
    supports, statements, by_statement, references, scanned = [], [], {}, [], []
    metadata_coverage = True

    def add(subject, predicate, obj, carrier, *, owner=None, row=None, managed=None):
        _bound(len(supports) < MAX_SUPPORTS)
        for value in (subject, predicate):
            _need(type(value) is str)
            _bound(len(value) <= MAX_TERM)
            size = _utf8_size(value)
            _bound(size <= MAX_TERM)
            cost.iri(size)
            iri(value)
        parsed = _parse_object(cost, obj) if obj is not None else None
        support = {
            "carrier": carrier,
            "subject": subject,
            "predicate": predicate,
            "object": obj,
            "owner": owner,
            "sourceRow": row,
            "managedValue": managed,
            "active": obj is not None,
        }
        index = len(supports)
        supports.append(support)
        if obj is None:
            return
        key = (subject, predicate, obj)
        if key not in by_statement:
            _bound(len(statements) < MAX_RECORDS)
            by_statement[key] = len(statements)
            statements.append(
                {
                    "subject": subject,
                    "predicate": predicate,
                    "object": obj,
                    "objectMaterial": _literal_material(parsed),
                    "supportIndices": [],
                }
            )
        statements[by_statement[key]]["supportIndices"].append(index)

    records = state["definitions"]
    _bound(len(records) + len(state["facts"]) <= MAX_RECORDS)
    for position, record in enumerate(records):
        payload = view._db.json.read(record["payload"])
        location = {
            "layer": record["layer"],
            "definitionId": record["id"],
            "sourcePath": ["state", "definitions", position, "payload"],
        }
        cost.spend(8 * (_string_size(record["payload"]) + 64), "metadata-payload-digest")
        entry = {**location, "payloadDigest": digest(payload)}
        known = type(payload) is dict and set(payload) <= {
            "triples",
            "singleValuedPredicates",
            "references",
        }
        if type(payload) is dict and "entityMetadata" in payload:
            metadata_coverage = False
            entry.update(
                status="coverage-unavailable",
                reason="legacy-namespace-collision",
                rawPayload=record["payload"],
            )
        elif not known:
            metadata_coverage = False
            entry.update(
                status="coverage-unavailable", reason="opaque-payload", rawPayload=record["payload"]
            )
        else:
            entry.update(status="metadata-not-recorded", namespace="absent")
        scanned.append(entry)
        if type(payload) is not dict:
            continue
        for index, ref in enumerate(payload.get("references", [])):
            _bound(len(references) < MAX_REFERENCES)
            references.append(
                {
                    "carrier": location,
                    "referenceIndex": index,
                    "layer": ref["layer"],
                    "id": ref["id"],
                }
            )
        if record["layer"] == "ontology":
            for index, triple in enumerate(payload.get("triples", [])):
                add(
                    triple["subject"],
                    triple["predicate"],
                    triple["object"],
                    {
                        "kind": "definition",
                        "layer": "ontology",
                        "definitionId": record["id"],
                        "tripleIndex": index,
                    },
                )
    for record in state["facts"]:
        add(
            record["subject"],
            record["predicate"],
            record["object"],
            {"kind": "fact", "recordId": record["id"]},
            owner=record["owner"],
            row=record["source_row"],
            managed=record["managed_value"],
        )

    candidates = {}
    role_values = {
        _RDFS + "Class": "class",
        _OWL + "Class": "class",
        _OWL + "ObjectProperty": "objectProperty",
        _OWL + "DatatypeProperty": "dataProperty",
        _OWL + "NamedIndividual": "individual",
    }
    for statement in statements:
        subject = statement["subject"]
        if subject not in candidates:
            candidates[subject] = {
                "iri": subject,
                "roles": [],
                "classTypes": [],
                "rdfTypes": [],
                "rdfLabels": [],
                "rdfDefinitions": [],
                "subClassOf": [],
                "domains": [],
                "ranges": [],
                "reasons": [],
                "constructorStatus": "metadata-not-recorded",
                "missingFields": ["identifier", "synonyms", "examples"],
            }
        entity = candidates[subject]
        pred, obj = statement["predicate"], statement["objectMaterial"]
        if pred == _RDF + "type" and obj["kind"] == "iri":
            entity["rdfTypes"].append(obj["iri"])
            role = role_values.get(obj["iri"], "individual")
            if obj["iri"] in {_RDFS + "Class", _OWL + "Class"}:
                entity["classTypes"].append("rdfs" if obj["iri"] == _RDFS + "Class" else "owl")
            if role not in entity["roles"]:
                entity["roles"].append(role)
        elif pred in {_RDFS + "label", _RDFS + "comment"}:
            field = "rdfLabels" if pred == _RDFS + "label" else "rdfDefinitions"
            entity[field].append(
                {**obj, "term": statement["object"], "supportIndices": statement["supportIndices"]}
            )
            if obj["kind"] != "literal" or obj["datatype"] is not None:
                entity["reasons"].append("typed-or-nonliteral-label")
        elif pred in {_RDFS + "subClassOf", _RDFS + "domain", _RDFS + "range"}:
            field = {
                _RDFS + "subClassOf": "subClassOf",
                _RDFS + "domain": "domains",
                _RDFS + "range": "ranges",
            }[pred]
            entity[field].append(
                {"object": statement["object"], "supportIndices": statement["supportIndices"]}
            )
    for entity in candidates.values():
        if len(entity["roles"]) > 1:
            entity["reasons"].append("multiple-rdf-roles")
        if len(entity["classTypes"]) > 1:
            entity["reasons"].append("multiple-class-declarations")
        if not entity["roles"]:
            entity["reasons"].append("rdf-role-unselected")
        zh = [
            label
            for label in entity["rdfLabels"]
            if label["kind"] == "literal"
            and label["language"] == "zh"
            and label["datatype"] is None
        ]
        entity["primaryName"] = (
            {"status": "selected", "value": zh[0]}
            if len(zh) == 1
            else {"status": "primary-name-unselected", "candidates": entity["rdfLabels"]}
        )
        if entity["reasons"] or not metadata_coverage:
            entity["constructorStatus"] = "coverage-unavailable"
    metadata = {
        "metadataEvidenceVersion": 1,
        "readerSemantics": 1,
        "profileSignature": format3.SCHEMA_HASH,
        "status": "metadata-not-recorded" if metadata_coverage else "coverage-unavailable",
        "scannedDefinitions": scanned,
        "referenceCoverage": "explicit-definition-references-only",
    }
    metadata_size, _nodes = _size(metadata, MAX_SOURCE)
    _bound(source_size + metadata_size <= MAX_SOURCE)
    return {
        "metadata": metadata,
        "statementSources": supports,
        "statements": statements,
        "entityInputs": list(candidates.values()),
        "factInputs": [
            statement
            for statement in statements
            if statement["predicate"]
            not in {
                _RDF + "type",
                _RDFS + "label",
                _RDFS + "comment",
                _RDFS + "subClassOf",
                _RDFS + "domain",
                _RDFS + "range",
            }
        ],
        "references": references,
    }


def _read_material(view, public):
    gate, cost = view._db, view.cost
    _catalog(view)
    internal = view._project(public)
    _need(type(internal) is str)
    inventory = _prepare_history(view, public, internal)
    receipts, checkpoints, current = format3._history(view, internal)
    del receipts
    _need(
        current["domainSnapshotRef"]
        in {row["domain_snapshot"] for row in inventory["app_checkpoints"]}
    )
    source_ref = current["domainSnapshotRef"]
    source = view._project_snapshot(source_ref, internal)
    cost.spend(8 * (gate.evidence + 64), "source-current-comparison")
    current_source = {
        "project": internal,
        "projectRevision": view.revision(internal),
        "dependencyVector": view.vector(internal),
        "state": view.state(internal),
    }
    b, n = _size(current_source, MAX_SOURCE)
    view.arena.holds.append(cost.copy(b, 2, "current-canonical-compare"))
    cost.sort(b, n, "current-canonical-compare-sort")
    _need(set(source) == {"project", "projectRevision", "dependencyVector", "state"})
    _need(canonical(source) == canonical(current_source) and digest(source) == source_ref)
    projected = _project_material(view, source)
    control = view.retirement_control(internal)
    return {
        "ontologySourceVersion": 1,
        "sourceRef": source_ref,
        "source": source,
        "projectIdentity": {"publicProjectId": public, "internalProject": internal},
        "checkpointRef": next(key for key, value in checkpoints.items() if value is current),
        "retirementControl": control,
        "projectionPolicy": "ontology-profile1-lossless-v1",
        "costProfile": PROFILE,
        **projected,
    }


def read_ontology_source(owner, publicProjectId, *, readerLimits, costSession):
    """Read one fresh consistent source. Caller owns both the Store and the cost lease."""
    if not isinstance(owner, JobStore) or owner._target_format != 3:
        raise OntologyFault("state")
    if (
        type(publicProjectId) is not str
        or len(publicProjectId) != 36
        or not uuid_ref(publicProjectId)
    ):
        raise OntologyFault("invalid-input")
    if type(readerLimits) is not ReadLimits or type(costSession) is not CostSession:
        raise OntologyFault("invalid-input")
    cost = costSession
    if cost._owner() is not owner or cost._busy:
        raise OntologyFault("state")
    cost.spend(128, "read-entry")
    try:
        if owner._db.in_transaction:
            raise OntologyFault("state")
    except sqlite3.Error as error:
        raise _sql_error(error) from None
    _bound(cost._reads < 16)
    cost._reads += 1
    control = _Control(cost)
    arena = _Arena(cost)
    gate = _RowCacheGate(owner._db, arena, readerLimits)
    view = _SourceView(gate)
    first, material, began = None, None, False
    cost._busy = True
    try:
        control.execute(owner._db, "BEGIN")
        began = True
        header = gate._metadata("PRAGMA user_version")[0]
        if type(header) is not int or header != 3:
            raise OntologyFault("state")
        gate.encoding = gate._metadata("PRAGMA encoding")[0].upper()
        if gate.encoding not in {"UTF-8", "UTF-16LE", "UTF-16BE"}:
            raise OntologyFault("unsupported-source")
        if gate.encoding != "UTF-8":
            gate.utf16_features()
        gate.guard = True
        from types import SimpleNamespace

        ProjectHostReader._preflight(SimpleNamespace(_store=view, _limits=readerLimits))
        gate.guard = False
        value = _read_material(view, publicProjectId)
        cost.spend(8 * (gate.evidence + 64), "return-size-scan")
        size, nodes = _size(value, MAX_RETAINED)
        cost.sort(size, nodes, "return-sort")
        output_hold = cost.copy(size, 3, "owned-return")
        try:
            material = SourceMaterial(value, output_hold)
        except BaseException:
            output_hold.release()
            raise
        del value, output_hold
    except OntologyFault as error:
        first = error
    except HostReadFault as error:
        first = OntologyFault("resource-limit" if error.reason == "limit" else "incomplete-source")
    except job_store.JobFault as error:
        first = OntologyFault(
            "identity-conflict" if error.code == "IDENTITY_CONFLICT" else "incomplete-source"
        )
    except sqlite3.Error as error:
        first = _sql_error(error)
    except (
        ValueError,
        KeyError,
        TypeError,
        AttributeError,
        IndexError,
        OverflowError,
        RecursionError,
    ):
        first = OntologyFault("incomplete-source")
    except BaseException as error:
        first = error
    finally:
        if began:
            try:
                control.execute(owner._db, "ROLLBACK")
            except BaseException as error:
                if first is None:
                    first = error
                first.cleanup_failed = True
        control.close()
        cost._busy = False
    if first is not None:
        if material is not None:
            material.close()
        # Tracebacks/receipts retaining this error retain its paid arena. Do not
        # report reserved=0 merely because control returned to the caller.
        first._ontology_retention = arena
        raise first from None
    gate.json.cache.clear()
    gate.columns.clear()
    gate.types.clear()
    del view, gate
    arena.clear()
    return material
