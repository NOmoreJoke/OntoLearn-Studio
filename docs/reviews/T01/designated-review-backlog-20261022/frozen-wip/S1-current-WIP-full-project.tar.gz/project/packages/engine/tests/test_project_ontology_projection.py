"""S1 actual Store3 source/retention proofs; no T02, metadata writer or host grant."""

import gc
import gzip
import hashlib
import os
import weakref
from pathlib import Path
import json
import math
import sqlite3
from contextlib import contextmanager
from dataclasses import replace

import pytest
from ontolearn_engine.job_store import JobStore
from ontolearn_engine.project import ontology_projection as ontology
from ontolearn_engine.project.ontology_projection import (
    CostSession,
    OntologyFault,
    read_ontology_source,
)
from ontolearn_engine.project.project_host import ReadLimits
from ontolearn_engine.storage import digest
from test_job_store import CONTRACT, uid
from test_storage import fact, mapped

RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
RDFS = "http://www.w3.org/2000/01/rdf-schema#"
OWL = "http://www.w3.org/2002/07/owl#"
INTERNAL = "private-engine-project"


@pytest.fixture(autouse=True)
def archive_cost_ledgers(request, tmp_path, monkeypatch):
    """Real per-run audit, including holds after the last success or failure."""
    root = Path(os.environ.get("T01_S1_LEDGER_DIR", str(tmp_path / "audit-ledgers")))
    root.mkdir(parents=True, exist_ok=True)
    node = hashlib.sha256(request.node.nodeid.encode()).hexdigest()
    streams, sessions = {}, {}

    def audit(session, event, **facts):
        key = id(session)
        if key not in streams:
            index = len(streams)
            path = root / (node + "." + str(index) + ".jsonl.gz")
            streams[key] = (path, gzip.open(path, "xt"))
            sessions[key] = weakref.ref(session)
        streams[key][1].write(json.dumps({
            "event": event, "facts": facts, "work": session.work,
            "queries": session.queries, "retained": session.retained,
            "nativeCacheRetained": session._book.native_retained,
            "lockedWork": session._locked_work,
        }, ensure_ascii=True) + "\n")

    monkeypatch.setattr(CostSession, "_audit", audit)
    yield
    entries = []
    for key, (path, stream) in streams.items():
        stream.close()
        session = sessions[key]()
        entries.append({"path": path.name, "bytes": path.stat().st_size,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "sessionAlive": session is not None,
                        "lastLiveCounters": None if session is None else {
                            "work": session.work, "retained": session.retained,
                            "nativeCacheRetained": session._book.native_retained,
                            "queries": session.queries, "locked": session._locked_work}})
    (root / (node + ".manifest.json")).write_text(json.dumps({
        "test": request.node.nodeid, "ledgers": entries,
    }, indent=2))


def triple(predicate, obj, subject="urn:C"):
    return {"subject": subject, "predicate": predicate, "object": obj}


def class_triples():
    return [
        triple(RDF + "type", "<" + OWL + "Class>"),
        triple(RDFS + "label", '"中文😀"@zh'),
        triple(RDFS + "label", '"Class"@en'),
    ]


@contextmanager
def opened(tmp_path, monkeypatch, encoding="UTF-8", connection=sqlite3.Connection):
    connect = sqlite3.connect

    def create(*args, **kwargs):
        kwargs["factory"] = connection
        db = connect(*args, **kwargs)
        db.execute(f"PRAGMA encoding='{encoding}'")
        return db

    with monkeypatch.context() as patch:
        patch.setattr(sqlite3, "connect", create)
        store = JobStore(tmp_path / "ontology.sqlite", contract=CONTRACT, target_format=3)
    store.create_project(INTERNAL)
    try:
        yield store
    finally:
        store.close()


def define(store, triples, **extra):
    return store.commit(
        INTERNAL,
        store.revision(INTERNAL),
        uid(),
        "source-fixture",
        definitions=[{"layer": "ontology", "id": "schema", "value": {"triples": triples, **extra}}],
    )


def read(store, session=None, limits=None):
    return read_ontology_source(
        store,
        store.public_project(INTERNAL),
        readerLimits=limits or ReadLimits(),
        costSession=session or CostSession(store),
    )


def dump(store):
    return "\n".join(store._db.iterdump())


@pytest.mark.parametrize("encoding", ["UTF-8", "UTF-16le", "UTF-16be"])
@pytest.mark.parametrize("populated", [False, True])
def test_real_three_encodings_exact_snapshot_and_zero_writes(
    tmp_path, monkeypatch, encoding, populated
):
    with opened(tmp_path, monkeypatch, encoding) as store:
        if populated:
            define(store, class_triples())
        public = store.public_project(INTERNAL)
        before, changes, trace = dump(store), store._db.total_changes, []
        rejected = []

        def authorizer(action, first, second, _database, _trigger):
            if action in {sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE} or (
                action == sqlite3.SQLITE_PRAGMA and first == "user_version" and second is not None
            ):
                rejected.append((action, first, second))
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK

        store._db.set_authorizer(authorizer)
        store._db.set_trace_callback(trace.append)
        session = CostSession(store)
        material = read_ontology_source(
            store, public, readerLimits=ReadLimits(), costSession=session
        )
        function_trace = trace.copy()
        with material as result:
            source = result.source
            assert set(source) == {"project", "projectRevision", "dependencyVector", "state"}
            assert source["project"] == INTERNAL
            assert result.value["projectIdentity"]["publicProjectId"] != INTERNAL
            assert source["projectRevision"] == int(populated)
            assert source["state"] == store.state(INTERNAL)
            assert source["dependencyVector"] == store.vector(INTERNAL)
            assert digest(source) == result.source_ref
            assert store.load_snapshot(result.source_ref) == source
            assert result.value["metadata"]["status"] == "metadata-not-recorded"
            assert len(result.value["statementSources"]) == (3 if populated else 0)
        store._db.set_trace_callback(None)
        store._db.set_authorizer(None)
        assert not rejected and dump(store) == before and store._db.total_changes == changes
        assert function_trace[0] == "BEGIN" and function_trace[-1] == "ROLLBACK"
        assert not store._db.in_transaction and not session._busy


def test_ordinary_ontology_material_is_lossless_without_fabricated_metadata(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        triples = class_triples() + [class_triples()[1]]
        define(store, triples)
        store.commit(
            INTERNAL, 1, uid(), "manual", manual=[fact("urn:C", '"中文😀"@zh', RDFS + "label")]
        )
        with read(store) as result:
            value = result.value
            assert len(value["statementSources"]) == 5
            assert len(value["statements"]) == 3
            label = next(s for s in value["statements"] if s["object"] == '"中文😀"@zh')
            assert len(label["supportIndices"]) == 3
            assert [x["carrier"]["tripleIndex"] for x in value["statementSources"][:4]] == [
                0,
                1,
                2,
                3,
            ]
            entity = value["entityInputs"][0]
            assert entity["iri"] == "urn:C" and entity["roles"] == ["class"]
            assert entity["primaryName"]["value"]["text"] == "中文😀"
            assert entity["missingFields"] == ["identifier", "synonyms", "examples"]
            assert (
                "identifier" not in entity and "synonyms" not in entity and "examples" not in entity
            )
            assert value["factInputs"] == []
            assert value["metadata"]["referenceCoverage"] == "explicit-definition-references-only"


@pytest.mark.parametrize("labels", [[('"中文"@zh-cn')], ['"plain"'], ['"一"@zh', '"二"@zh']])
def test_primary_name_has_no_language_or_ambiguous_fallback(tmp_path, monkeypatch, labels):
    with opened(tmp_path, monkeypatch) as store:
        define(store, [class_triples()[0], *[triple(RDFS + "label", v) for v in labels]])
        with read(store) as result:
            entity = result.value["entityInputs"][0]
            assert entity["primaryName"]["status"] == "primary-name-unselected"
            assert [v["term"] for v in entity["rdfLabels"]] == labels


def test_unsupported_role_and_typed_label_material_remain_present(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        define(
            store,
            [
                class_triples()[0],
                triple(RDF + "type", "<" + RDFS + "Class>"),
                triple(RDF + "type", "<" + OWL + "ObjectProperty>"),
                triple(RDFS + "label", '"typed"^^<urn:datatype/custom>'),
            ],
        )
        with read(store) as result:
            entity = result.value["entityInputs"][0]
            assert set(entity["reasons"]) == {
                "multiple-class-declarations",
                "multiple-rdf-roles",
                "typed-or-nonliteral-label",
            }
            assert entity["classTypes"] == ["owl", "rdfs"]
            assert entity["rdfLabels"][0]["datatype"] == "urn:datatype/custom"
            assert entity["constructorStatus"] == "coverage-unavailable"


@pytest.mark.parametrize("collision", [None, {}, {"version": 1, "entities": []}, [1, "raw"]])
def test_legacy_metadata_namespace_never_authenticated(tmp_path, monkeypatch, collision):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples(), entityMetadata=collision)
        with read(store) as result:
            metadata = result.value["metadata"]
            assert metadata["status"] == "coverage-unavailable"
            entry = metadata["scannedDefinitions"][0]
            assert entry["reason"] == "legacy-namespace-collision"
            assert json.loads(entry["rawPayload"])["entityMetadata"] == collision
            assert entry["sourcePath"] == ["state", "definitions", 0, "payload"]
            assert entry["payloadDigest"] == digest(json.loads(entry["rawPayload"]))


def test_original_tombstone_owner_source_row_and_managed_value(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        store.commit(INTERNAL, 0, uid(), "map", mapping=mapped())
        original = store.state(INTERNAL)["facts"][0]
        store.commit(INTERNAL, 1, uid(), "delete", remove=[original["id"]])
        with read(store) as result:
            record = result.value["statementSources"][0]
            assert record["active"] is False and record["object"] is None
            assert record["carrier"] == {"kind": "fact", "recordId": original["id"]}
            assert record["owner"] == "M1" and record["sourceRow"] == original["source_row"]
            assert record["managedValue"] == original["managed_value"]
            assert result.value["statements"] == []
            assert result.source["state"] == store.state(INTERNAL)


def test_existing_transaction_is_not_rolled_back_or_read(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        public = store.public_project(INTERNAL)
        session = CostSession(store)
        store._db.execute("BEGIN")
        trace = []
        store._db.set_trace_callback(trace.append)
        with pytest.raises(OntologyFault, match="state"):
            read_ontology_source(store, public, readerLimits=ReadLimits(), costSession=session)
        assert trace == [] and store._db.in_transaction
        store._db.set_trace_callback(None)
        store._db.rollback()


@pytest.mark.parametrize("header", [0, 2, 4])
def test_actual_header_checked_on_every_new_read(tmp_path, monkeypatch, header):
    with opened(tmp_path, monkeypatch) as store:
        session = CostSession(store)
        store._db.execute(f"PRAGMA user_version={header}")
        before = dump(store)
        with pytest.raises(OntologyFault, match="state"):
            read(store, session)
        assert dump(store) == before and not store._db.in_transaction


@pytest.mark.parametrize("kind", ["source", "container", "text", "key"])
def test_borrowed_material_keeps_actual_retention_after_close(tmp_path, monkeypatch, kind):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples())
        session = CostSession(store)
        result = read(store, session)
        borrowed = {
            "source": result.source,
            "container": result.value["entityInputs"],
            "text": result.source_ref,
            "key": next(iter(result.value)),
        }[kind]
        paid = session.retained
        assert paid > 0
        result.close()
        session.close()
        gc.collect()
        assert session.retained == paid
        del result, borrowed
        gc.collect()
        assert session.retained == 0


def test_output_normal_mutation_refused(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        with read(store) as result:
            with pytest.raises(TypeError):
                result.source["projectRevision"] = 99
            with pytest.raises(TypeError):
                result.source["state"]["facts"].append({})


@pytest.mark.parametrize(
    "field,bad",
    [
        ("work", True),
        ("work", ontology.MAX_WORK + 1),
        ("retained", 0),
        ("queries", ontology.MAX_QUERIES + 1),
        ("ttl", 61),
    ],
)
def test_limits_cannot_be_loosened(tmp_path, monkeypatch, field, bad):
    with opened(tmp_path, monkeypatch) as store:
        with pytest.raises(OntologyFault, match="invalid-input"):
            CostSession(store, **{field: bad})


def test_owner_sessions_are_capped_and_closed_holds_are_still_aggregate(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        sessions = [CostSession(store) for _ in range(4)]
        with pytest.raises(OntologyFault, match="resource-limit"):
            CostSession(store)
        hold = sessions[0].hold(ontology.MAX_RETAINED - 1, "fixture")
        sessions[0].close()
        new = CostSession(store)
        with pytest.raises(OntologyFault, match="resource-limit"):
            new.hold(2, "over-aggregate")
        one = new.hold(1, "exact-aggregate")
        assert new._book.retained == ontology.MAX_RETAINED
        hold.release()
        one.release()


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf, True, 10**1000])
def test_clock_invalid_is_finite_state(tmp_path, monkeypatch, bad):
    with opened(tmp_path, monkeypatch) as store:
        with pytest.raises(OntologyFault, match="state"):
            CostSession(store, clock=lambda: bad)


def test_clock_expiry_and_rollback_do_not_reset_work(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        now = [2.0]
        session = CostSession(store, clock=lambda: now[0], ttl=1)
        session.spend(10, "before")
        now[0] = 1.0
        with pytest.raises(OntologyFault, match="state"):
            session.spend(1, "rollback")
        now[0] = 3.0
        with pytest.raises(OntologyFault, match="resource-limit"):
            read(store, session)
        assert session.work == 10 and not store._db.in_transaction


def test_full_typed_row_evidence_fee_has_independent_json_oracle(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples())
        ledger = []
        session = CostSession(store)
        def audit(event, **entry):
            ledger.append((event, entry))
            CostSession._audit(session, event, **entry)
        monkeypatch.setattr(session, "_audit", audit)
        result = read(store, session)
        fees = [entry for event, entry in ledger if event == "evidence-row"]
        assert fees and len({(f["table"], f["rowid"]) for f in fees}) == len(fees)
        for row in fees:
            value = dict(
                store._db.execute(
                    'SELECT * FROM "' + row["table"] + '" WHERE rowid=?', (row["rowid"],)
                ).fetchone()
            )
            expected = len(
                json.dumps(
                    value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                ).encode()
            )
            assert row["bytes"] == expected
        assert sum(e["amount"] for event, e in ledger if event == "work") + 512 == session.work
        result.close()


def test_resource_failure_keeps_spent_work_and_held_error_until_released(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        session = CostSession(store, work=100000)
        try:
            read(store, session)
        except OntologyFault as error:
            assert error.reason == "resource-limit"
            paid = session.work
            assert paid > 0 and session.retained > 0
            assert not store._db.in_transaction
            retained_error = error
        else:
            pytest.fail("fixture must hit real metered read")
        with pytest.raises(OntologyFault, match="resource-limit"):
            read(store, session)
        assert session.work >= paid
        del retained_error
        gc.collect()
        assert session.retained == 0


def test_tight_read_inventory_limit_refuses_without_database_change(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        before = dump(store)
        with pytest.raises(OntologyFault, match="resource-limit"):
            read(store, limits=replace(ReadLimits(), validation_rows=1))
        assert dump(store) == before and not store._db.in_transaction


def scalar_gate(store, payload):
    """Typed-row fee mechanism, deliberately not a valid Store snapshot carrier."""
    store._db.execute("INSERT INTO snapshots VALUES('fee-scalar',?)", (payload,))
    rowid = store._db.execute("SELECT rowid FROM snapshots WHERE id='fee-scalar'").fetchone()[0]
    session = CostSession(store)
    arena = ontology._Arena(session)
    gate = ontology._RowCacheGate(store._db, arena, ReadLimits())
    gate.encoding = store._db.execute("PRAGMA encoding").fetchone()[0].upper()
    if gate.encoding != "UTF-8":
        gate.utf16_features()
    return gate, rowid


@pytest.mark.parametrize("encoding", ["UTF-8", "UTF-16le", "UTF-16be"])
@pytest.mark.parametrize(
    "value",
    [
        "",
        "中😀\U00010000\U0010ffff",
        'a"\\\b\f\n\r\t\x01\x1f',
        "a" * 11,
        "a" * 12,
        "a" * 255,
        "a" * 256,
    ],
)
def test_scalar_sql_exact_typed_row_oracle_and_duplicate_fee_rule(
    tmp_path, monkeypatch, encoding, value
):
    with opened(tmp_path, monkeypatch, encoding) as store:
        gate, rowid = scalar_gate(store, value)
        before = dump(store)
        expected = len(
            json.dumps(
                {"id": "fee-scalar", "payload": value},
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode()
        )
        assert gate._fee("snapshots", rowid) == expected
        work, queries = gate.session.work, gate.session.queries
        assert gate._fee("snapshots", rowid) == expected
        assert (gate.session.work, gate.session.queries) == (work, queries)
        # A fresh SQL body read is charged even though evidence is already known.
        result = gate._project_rows("snapshots", gate._lookup("snapshots", (("id", "fee-scalar"),)), ("id",)).fetchone()
        assert (
            result[0] == "fee-scalar"
            and gate.session.work > work
            and gate.session.queries > queries
        )
        assert dump(store) == before
        gate.arena.clear()


@pytest.mark.parametrize(
    "encoding,raw",
    [
        ("UTF-16le", "00D8"),
        ("UTF-16le", "00DC"),
        ("UTF-16le", "00D84100"),
        ("UTF-16be", "D800"),
        ("UTF-16be", "DC00"),
        ("UTF-16be", "D8000041"),
    ],
)
def test_native_surrogate_corruption_rejected_by_prepaid_strict_native_decode(tmp_path, monkeypatch, encoding, raw):
    with opened(tmp_path, monkeypatch, encoding) as store:
        store._db.execute("INSERT INTO snapshots VALUES('bad-native',CAST(x'" + raw + "' AS TEXT))")
        rowid = store._db.execute("SELECT rowid FROM snapshots WHERE id='bad-native'").fetchone()[0]
        session = CostSession(store)
        gate = ontology._RowCacheGate(store._db, ontology._Arena(session), ReadLimits())
        gate.encoding = encoding.upper()
        gate.utf16_features()
        trace = []
        store._db.set_trace_callback(trace.append)
        with pytest.raises(OntologyFault, match="incomplete-source"):
            gate._fee("snapshots", rowid)
        assert not any(sql == f'SELECT * FROM "snapshots" WHERE rowid={rowid}' for sql in trace)
        store._db.set_trace_callback(None)
        gate.arena.clear()


@pytest.mark.parametrize("encoding", ["UTF-8", "UTF-16le", "UTF-16be"])
def test_nul_text_rejected_by_complete_row_validation(tmp_path, monkeypatch, encoding):
    with opened(tmp_path, monkeypatch, encoding) as store:
        gate, rowid = scalar_gate(store, "null\x00text")
        trace = []
        store._db.set_trace_callback(trace.append)
        with pytest.raises(OntologyFault, match="incomplete-source"):
            gate._fee("snapshots", rowid)
        assert not any(
            sql.startswith("WITH t(n,ok)") and f'FROM "snapshots" WHERE rowid={rowid}' in sql
            for sql in trace
        )
        store._db.set_trace_callback(None)
        gate.arena.clear()


@pytest.mark.parametrize("encoding", ["UTF-16le", "UTF-16be"])
def test_uninspected_sqlite_source_id_refused_with_rollback(tmp_path, monkeypatch, encoding):
    with opened(tmp_path, monkeypatch, encoding) as store:
        before = dump(store)
        store._db.create_function("sqlite_source_id", 0, lambda: "different-source")
        with pytest.raises(OntologyFault, match="unsupported-source"):
            read(store)
        assert dump(store) == before and not store._db.in_transaction


@pytest.mark.parametrize("encoding", ["UTF-16le", "UTF-16be"])
def test_missing_octet_length_feature_refused_finitely(tmp_path, monkeypatch, encoding):
    with opened(tmp_path, monkeypatch, encoding) as store:
        store._db.create_function("octet_length", 1, None)
        with pytest.raises(OntologyFault, match="unsupported-source"):
            read(store)
        assert not store._db.in_transaction


@pytest.mark.parametrize("encoding", ["UTF-8", "UTF-16le"])
@pytest.mark.parametrize("dimension", ["work", "retained", "queries"])
def test_real_nonempty_admission_boundaries_plus_minus_one(
    tmp_path, monkeypatch, encoding, dimension
):
    with opened(tmp_path, monkeypatch, encoding) as store:
        define(store, class_triples())
        baseline, events = CostSession(store), []

        def audit(event, **entry):
            CostSession._audit(baseline, event, **entry)
            events.append(
                (
                    event,
                    entry,
                    baseline.work + baseline._locked_work,
                    baseline.queries + baseline._locked_queries,
                )
            )

        monkeypatch.setattr(baseline, "_audit", audit)
        result = read(store, baseline)
        result.close()
        del result
        gc.collect()
        limit = (
            max(item[2] for item in events)
            if dimension == "work"
            else max(item[3] for item in events)
            if dimension == "queries"
            else max(entry["total"] for event, entry, *_ in events if event == "retain")
        )
        assert limit > 1
        baseline.close()
        for delta in (-1, 0, 1):
            session = CostSession(store, **{dimension: limit + delta})
            before = dump(store)
            if delta < 0:
                with pytest.raises(OntologyFault, match="resource-limit"):
                    read(store, session)
            else:
                with read(store, session) as material:
                    assert len(material.value["statementSources"]) == 3
            assert not store._db.in_transaction and dump(store) == before
            session.close()
            gc.collect()


class DriverCancel(BaseException):
    pass


class FailureConnection(sqlite3.Connection):
    """Explicit driver seam. These are not OS disk or process failure claims."""

    fault = None
    close_fault = None
    rollback_fault = None
    predicate = None

    def execute(self, sql, parameters=()):
        if sql == "ROLLBACK" and self.rollback_fault is not None:
            raise self.rollback_fault
        if self.predicate is not None and self.predicate(sql):
            if self.fault is not None:
                raise self.fault
            native = super().execute(sql, parameters)
            return FailureCursor(native, self.close_fault)
        return super().execute(sql, parameters)


class FailureCursor:
    def __init__(self, cursor, close_fault):
        self.cursor, self.close_fault = cursor, close_fault

    def fetchone(self):
        return self.cursor.fetchone()

    def fetchall(self):
        return self.cursor.fetchall()

    def close(self):
        if self.close_fault is not None:
            raise self.close_fault
        self.cursor.close()


@pytest.mark.parametrize(
    "code,reason",
    [
        (sqlite3.SQLITE_BUSY, "storage-busy"),
        (sqlite3.SQLITE_LOCKED, "storage-busy"),
        (sqlite3.SQLITE_IOERR, "storage-failure"),
    ],
)
def test_original_storage_error_not_hidden_by_history_catches(tmp_path, monkeypatch, code, reason):
    with opened(tmp_path, monkeypatch, connection=FailureConnection) as store:
        define(store, class_triples())
        error = sqlite3.OperationalError("driver seam")
        error.sqlite_errorcode = code
        store._db.fault = error
        store._db.predicate = lambda sql: sql.startswith("SELECT * FROM app_checkpoints")
        before = dump(store)
        with pytest.raises(OntologyFault, match=reason):
            read(store)
        assert dump(store) == before and not store._db.in_transaction


def test_cancel_identity_survives_failed_owned_rollback(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch, connection=FailureConnection) as store:
        cancellation = DriverCancel("cancel")
        store._db.fault = cancellation
        store._db.predicate = lambda sql: sql == "PRAGMA user_version"
        store._db.rollback_fault = sqlite3.OperationalError("rollback seam")
        session = CostSession(store)
        with pytest.raises(DriverCancel) as raised:
            read(store, session)
        assert raised.value is cancellation and cancellation.cleanup_failed
        assert store._db.in_transaction and not session._busy
        store._db.rollback_fault = None
        store._db.rollback()


def test_utf16_cursor_close_failure_does_not_claim_sql_scratch_released(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch, "UTF-16le", FailureConnection) as store:
        session = CostSession(store)
        error = sqlite3.OperationalError("cursor close seam")
        store._db.close_fault = error
        store._db.predicate = lambda sql: sql.startswith("SELECT rowid,") and "CASE WHEN" in sql
        with pytest.raises(OntologyFault, match="storage-failure") as caught:
            read(store, session)
        assert caught.value.cleanup_failed and session.retained >= 8192
        assert not store._db.in_transaction


def test_opaque_user_record_shape_is_not_reinterpreted_as_json_carrier(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        payload = {"userData": {"layer": "unrecognized", "id": "business", "payload": "not JSON"}}
        store.commit(
            INTERNAL,
            0,
            uid(),
            "opaque",
            definitions=[{"layer": "rule", "id": "opaque", "value": payload}],
        )
        with read(store) as result:
            entry = result.value["metadata"]["scannedDefinitions"][0]
            assert entry["status"] == "coverage-unavailable" and entry["reason"] == "opaque-payload"
            assert json.loads(entry["rawPayload"]) == payload


def test_actual_read_preserves_caller_authorizer_and_uses_only_owner_connection(
    tmp_path, monkeypatch
):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples())
        public = store.public_project(INTERNAL)
        calls = []

        def authorizer(action, first, second, _database, _trigger):
            calls.append((action, first, second))
            if action in {sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_INSERT, sqlite3.SQLITE_DELETE}:
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK

        store._db.set_authorizer(authorizer)

        def no_new_connection(*_args, **_kwargs):
            raise AssertionError("S1 must not open another connection")

        monkeypatch.setattr(sqlite3, "connect", no_new_connection)
        with read_ontology_source(
            store, public, readerLimits=ReadLimits(), costSession=CostSession(store)
        ):
            pass
        with pytest.raises(sqlite3.DatabaseError):
            store._db.execute("UPDATE projects SET revision=revision WHERE id=?", (INTERNAL,))
        assert any(a == sqlite3.SQLITE_READ and name == "app_checkpoints" for a, name, _ in calls)
        store._db.set_authorizer(None)


def test_application_draft_payload_is_prepaid_only_at_real_checkpoint_position(
    tmp_path, monkeypatch
):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples())
        opaque = {"userData": {"layer": "x", "id": "y", "payload": "not JSON"}}
        store.apply_application(
            store.public_project(INTERNAL),
            uid(),
            {
                "type": "draft.save",
                "editor": "q",
                "expectedGeneration": 0,
                "boundDomainRevision": 1,
                "content": opaque,
            },
            actor=uid(),
            permission="write",
        )
        with read(store) as result:
            assert result.source["projectRevision"] == 1
            assert result.value["metadata"]["status"] == "metadata-not-recorded"
            assert result.source_ref == digest(result.source)


def test_real_retirement_control_outside_original_four_key_source(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        define(store, class_triples())
        store.commit(
            INTERNAL, 1, uid(), "retire", remove_definitions=[{"layer": "ontology", "id": "schema"}]
        )
        with read(store) as result:
            assert result.value["retirementControl"] == [["ontology", "schema"]]
            assert set(result.source) == {"project", "projectRevision", "dependencyVector", "state"}
            assert result.source["state"]["definitions"] == []
            assert result.value["entityInputs"] == []


def test_references_keep_exact_carriers_order_and_duplicates(tmp_path, monkeypatch):
    with opened(tmp_path, monkeypatch) as store:
        store.commit(
            INTERNAL,
            0,
            uid(),
            "references",
            definitions=[
                {"layer": "ontology", "id": "schema", "value": {"triples": class_triples()}},
                {
                    "layer": "rule",
                    "id": "dependent",
                    "value": {
                        "references": [
                            {"layer": "ontology", "id": "schema"},
                            {"layer": "ontology", "id": "schema"},
                        ]
                    },
                },
            ],
        )
        with read(store) as result:
            refs = result.value["references"]
            assert [r["referenceIndex"] for r in refs] == [0, 1]
            assert all(r["carrier"]["definitionId"] == "dependent" for r in refs)
            assert all((r["layer"], r["id"]) == ("ontology", "schema") for r in refs)


@pytest.mark.parametrize(
    "limit", [ontology.MAX_TERMS - 1, ontology.MAX_TERMS, ontology.MAX_TERMS + 1]
)
def test_term_count_exact_admission_limit_without_running_old_parser(tmp_path, monkeypatch, limit):
    with opened(tmp_path, monkeypatch) as store:
        session = CostSession(store)
        if limit > ontology.MAX_TERMS:
            with pytest.raises(OntologyFault, match="resource-limit"):
                session.term(1, limit)
            assert session.terms == 0 and session.work == 0
        else:
            session.term(1, limit)
            assert session.terms == limit and session.term_bytes == 1
            if limit == ontology.MAX_TERMS:
                with pytest.raises(OntologyFault, match="resource-limit"):
                    session.term(1)


@pytest.mark.parametrize(
    "size", [ontology.MAX_TERM_BYTES - 1, ontology.MAX_TERM_BYTES, ontology.MAX_TERM_BYTES + 1]
)
def test_term_bytes_exact_admission_limit(tmp_path, monkeypatch, size):
    with opened(tmp_path, monkeypatch) as store:
        session = CostSession(store)
        if size > ontology.MAX_TERM_BYTES:
            with pytest.raises(OntologyFault, match="resource-limit"):
                session.term(size)
        else:
            session.term(size)
            assert session.term_bytes == size


@pytest.mark.parametrize("value,expected", [("a" * 14, 16), ("a" * 15, 17), ("a" * 16, 18)])
def test_bounded_canonical_scalar_exact_size_without_serializing(value, expected):
    assert ontology._size(value, expected)[0] == expected
    with pytest.raises(OntologyFault, match="resource-limit"):
        ontology._size(value, expected - 1)


@pytest.mark.parametrize("bad", ['"\\ud800"', '"\\udc00"', '"\\u0000"', '"\\ud800\\u0041"'])
def test_json_escaped_invalid_scalars_rejected_before_jsonloads(tmp_path, monkeypatch, bad):
    with opened(tmp_path, monkeypatch) as store:
        parser = ontology._Json(ontology._Arena(CostSession(store)))

        def forbidden(*_args, **_kwargs):
            raise AssertionError("decoder reached invalid scalar")

        monkeypatch.setattr(ontology.json, "loads", forbidden)
        with pytest.raises(OntologyFault, match="incomplete-source"):
            parser.read(bad)


@pytest.mark.parametrize("encoding", ["UTF-8", "UTF-16le", "UTF-16be"])
def test_fixed_cache_query_semantics_against_original_sql(tmp_path, monkeypatch, encoding):
    """Only a SQL projection oracle: this seeded cache never certifies a source."""
    with opened(tmp_path, monkeypatch, encoding) as store:
        public = store.public_project(INTERNAL)
        define(store, class_triples())
        store.prepare_plan(public, 1, {}, actor=uid(), permission="write")
        # Additional SQL-only rows exercise collation/NULL; they deliberately
        # do not form a certified historical snapshot and are never exported.
        for key in [None, "", "a", "A", "中", "é", "e\u0301", "\ue000", "\U00010000", "😀"]:
            store._db.execute("INSERT INTO versions VALUES(?,?,?)", (INTERNAL, key, 2))
        store.create_project("oracle-other")
        owners = [None, "", "a", "中", "é", "e\u0301", "\ue000", "\U00010000", "😀"]
        for index, owner in enumerate(owners):
            row = fact("urn:oracle/" + str(index))
            store._db.execute("INSERT INTO facts VALUES(?,?,?,?,?,?,?,?)", (
                INTERNAL, row["id"], row["subject"], row["predicate"], row["object"],
                owner, "row" if owner is not None else None,
                row["object"] if owner is not None else None,
            ))
            store._db.execute("INSERT INTO mapping_state VALUES(?,?,?)", (INTERNAL, owner, 1))
        store._db.execute("INSERT INTO mapping_state VALUES(?,?,?)", ("oracle-other", "other-owner", 1))
        store._db.execute("INSERT INTO commits VALUES(?,?,?,?,?,?)", (INTERNAL, "orphan-no-right", None, 2, None, "{}"))
        gate = ontology._RowCacheGate(store._db, ontology._Arena(CostSession(store)), ReadLimits())
        gate.encoding = encoding.upper()
        for table in sorted(ontology._TABLE_NAMES):
            info = store._db.execute('PRAGMA table_info("' + table + '")').fetchall()
            gate.columns[table] = tuple(row[1] for row in info)
            gate.types[table] = {
                row[1]: ({"integer"} if row[2].upper() in {"INTEGER", "INT"} else {"text"})
                | (set() if row[3] else {"null"}) for row in info
            }
            native = store._db.execute('SELECT rowid,* FROM "' + table + '" ORDER BY rowid').fetchall()
            records = [ontology._CacheRow(zip(gate.columns[table], tuple(row)[1:])) for row in native]
            gate.row_cache[table], gate.row_ids[table] = records, [row[0] for row in native]
            for rid, row in zip(gate.row_ids[table], records):
                size = len(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())
                gate.fees[(table, rid)] = gate.record_fees[id(row)] = size
        checked = []
        for sql, (table, _projection, conditions, _order) in ontology._CACHE_SELECTS.items():
            rows = gate.row_cache[table]
            fields = [c for c in conditions if isinstance(c, str)]
            params = tuple(rows[0][field] if rows else (1 if field == "singleton" else "absent") for field in fields)
            for supplied in (params, tuple(None for _ in params)):
                original = store._db.execute(sql, supplied).fetchall()
                projected = gate.execute(sql, supplied).fetchall()
                assert [tuple(row) for row in projected] == [tuple(row) for row in original], (encoding, sql, supplied)
                assert [list(row.keys()) for row in projected] == [list(row.keys()) for row in original], (encoding, sql)
                for actual, expected in zip(projected, original):
                    assert dict(actual) == dict(expected)
                    assert actual[:] == tuple(expected)
                checked.append(sql)
        union = "SELECT owner FROM mapping_state WHERE project=? UNION SELECT owner FROM facts WHERE project=? AND owner IS NOT NULL"
        join = "SELECT c.*,e.before_snapshot,e.after_snapshot FROM commits c LEFT JOIN commit_evidence e ON e.project=c.project AND e.operation=c.operation WHERE c.project=? AND c.operation=?"
        operation = store._db.execute("SELECT operation FROM commits WHERE project=?", (INTERNAL,)).fetchone()[0]
        for sql, params in [(union, (INTERNAL, INTERNAL)), (union, (None, None)), (union, ("oracle-other", INTERNAL)), (join, (INTERNAL, operation)), (join, (INTERNAL, "orphan-no-right")), (join, (INTERNAL, "missing"))]:
            original = store._db.execute(sql, params).fetchall()
            projected = gate.execute(sql, params).fetchall()
            assert [tuple(row) for row in projected] == [tuple(row) for row in original]
            assert [list(row.keys()) for row in projected] == [list(row.keys()) for row in original]
        assert set(checked) == set(ontology._CACHE_SELECTS)
        gate.arena.clear()
