# T01 创建与只读 resolution 合同：总控独立静态复核

2026-10-21。结论：固定docs/process `379916267e5c36eebedb44d35a6636b9915ccd70` 的39602B修订合同已在设计层关闭原两P2，本次没有发现必须先修改合同的新实质阻断。现有表形状可承载唯一创建claim/receipt/genesis及严格新namespace；原claim/完整Job context的只读恢复方向成立。但真正create/resolution服务所需的当前权限与原dispatch物理绑定仍不存在，不能据本文启用生产服务、返回resolved关闭原意图unknown、签发位置/首IO能力或完成父功能。

可以另行精确批准内部Store事务/namespace历史验证子阶段，真实I06缺失不应泛化为所有内部逻辑都不能写。建议及其严格边界见末节；本报告不自动授权开工、不修改已冻结合同或现读取服务。

本审仅Git、文件读取、stdlib JSON/ZIP/hash和集合/整数/JSON编码算式。没有import或执行产品、测试、probe、构建、数据库、native、GUI或凭据，没有对外发消息。唯一写入本报告；未改原读取报告、owner证据、产品或共享state/Goal。原件中的运行/文档检查由作者及独审执行，不冒称本审重跑。

## 1. 固定Git、六docs与原件绑定

实际树 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-project-host-read-services`；当前本次固定docs ref379916，parent `a816c2d018772ce8b172101d9debec787ffa434a`。以实际Git核parent→child恰6份docs新增，没有产品/测试/配置/依赖/build变化；原base5f→a816的56条路径逐blob与379916比较全部不变。未把纯docs追加当产品候选漂移或重测理由。

| 本次固定件 | bytes | SHA256 |
| --- | ---: | --- |
| project-create-and-resolution-contract.md | 39602 | ff725f2c0ee40cbdf61c9c4d27dfea1be3ccd2068df4399878b037976de4a5f3 |
| creation-resolution-independent-review.md | 14753 | 33b74eabb6bdc7c2f129214fd1bbf1b6a5177fc8cd9ab0b782c36371c8b25930 |
| contract-process-and-evidence-clarification.md | 4106 | 834811a1c0b7f53d4bc8de899d73056ad33016a8c9eb091639934f570754f2c8 |
| contract-source-manifest.json | 1872 | bf079c98c411437b658595d2fbcb95f7fc08a63a8f254ecd824ca06487780bc2 |
| contract-original-evidence.zip | 378856 | 3a76523c3b8612a29db308f11635e58184318b6b6f0b2e8c4f3d1d6e16a462bb |
| contract-original-evidence-index.json | 74322 | f57e31a5bf2278b1dca2f6d0a37810579166e12312a305c02c1ce82507ddd2f9 |

manifest所列5件全部当前=379916 Git=声明bytes/SHA，第六manifest由固定Git/实际delta外部绑定。完整主合同§1–10分段全文读回；批量输出的§8路径曾被工具截断，已另读取精确完整§8。最终14753独审和4106澄清全文读，未以作者摘要代原报告。

ZIP9唯一安全相对成员，无重复/绝对/..路径，全部逐bytes/SHA与index相符。三tool-records分别primary32 pairs/66原record、contract-author24/48、contract-independent-review63/126，共119 pairs/240原record（primary含2 standalone通知）。逐原session line/offset/bytes/SHA核同，并核拼接原行恰等归档jsonl，没有伪造配对或收推理记录。

初稿30208B/`d2d469acdc401f01fec3269647fcdeefb66dc0ca2ddfbf0717f663508f410675`是实际完整文本：归档原件逐字存在于原独审230912 shell输出中，非按摘要回写。初审10182B/`402c0010938b41692d981d2630eac5aa76a3901259a94e1f77118233e3238724`全文也已读；从恢复收据指定原rollout第2526行、call_160f1b9b6ac44940a620ea043cde9e35、contentIndex1、chunk4b912f的output UTF8 offset152精确取10182字节，实算SHA及归档原件全等。恢复的是原始报告字节，不是凭后来的最终14753报告删段重构。

本审只读检查脚本曾错误假设index含recordCount而KeyError，另一次补manifest自身Git绑定时误传父目录导致git退出128；均按实际records列表/明确Git树修正并完成验证。该定位错误未运行或修改任何产品，也未冒称首次审查脚本全部成功。

## 2. 两P2确实闭合于合同，而非已运行实现

| 原问题 | 实际修订与本审判断 |
| --- | --- |
| P2-CR-01 原dispatch物理库归因不足 | §2/3/5/6/9把当前scope、原host/Session来源、原dispatch Store/物理库/instance/generation三条件分开；复制库A→B时相同migration_id、SQL claim/request/origin/receipt不能代原物理事实。所有resolved共有原binding可重新证明前提；丢失、伪造或对应不明为unknown/physical-binding-unavailable。I06供方未交，不造factory/main持久意图账本。设计缺口关闭，真实能力/跨Session证明仍未交。 |
| P2-CR-02 创建预算与现reader不相容 | §3/4/7/9保name原字节guard为初筛，任何写前核完整metadata、目录行、全部合法editor的初始workspace最坏编码及加入项目后的全库row/byte/work/snapshot/page/reserve界；固定page_size无自适应，须核所有合法分组或证明上界。写后逐值与候选核同，不改reader/截名/抬预算。设计缺口关闭，实际预算/事务仍待实施。 |

本审独立以相同stdlib canonical JSON参数重算：4096个ASCII x作名称时完整initialMetadata确为4178B，超过已冻结ReadLimits.metadata_bytes4096。转义扩张亦必须按完整canonical UTF8编码计，不能用固定“减82字节”当任意名称上界。原错项没有被洗成初稿已通过；初审与修后全文/关闭结论分别保留。

初稿→修稿actual文本diff全部读回：修改集中于两P2及相关私有签名/unknown枚举、fresh只读事务、旧apply跨namespace提醒和逐项处置，没有暗改原读取产品/表DDL或引入另一writer。

## 3. 创建事务与既有schema的具体可行边界

必要产品依据仍是固定5de/a816同字节的storage.py、job_store.py、project/{format3,applications,domain_changesets}.py；本轮重读实际create_project/Store.commit/application分支、JOB3_CLAIMS/_validate_job3、apply_application重试、_accepted_job/format3严格JSON与历史验证关键代码。根7435授权及此前48/50源码核同依据继续适用，未将docs作者5f工作目录当新48组合。

现有Store.create_project在同交易建projects revision0并seed Store3 genesis；JobStore.create_project同交易补public映射。JOB3_CLAIMS实际允许kind=application、job NULL、context非NULL且project FK指public_projects；app_operations允许application、app_receipts JSON有项目FK。因此新context/plan/receipt版本可使用现表，不需要新表、kind值或重写旧行。应用层行为扩展仍是新语义，schema形状可承载不等于旧程序兼容。

合同的唯一mutation路径是Store.commit(...,creation=intent)互斥新分支：先global operation查claim/孤儿证据再engine分配UUID；project公开/内部均同新UUID，碰撞拒绝不INSERT OR IGNORE。完整origin/request/requestHash/预算及候选证据先验；同一个外层BEGIN IMMEDIATE内由Store建真实空domain/app genesis、公开映射，随后唯一claim、创建seq1 effect和唯一receipt/head；COMMIT后才返回。requestHash不混新UUID，context/plan/snapshot/checkpoint各hash域独立核。

genesis保既有name=null、metadataVersion0/sequence0和created origin；创建专属步骤才推进metadataVersion1/sequence1、名称原值，domainRevision0不变且无Job/领域marker。真实beforeCheckpoint必须是immutable app_origins.checkpoint，不能先在Store外落库来凑proof，也不能把早已存在的空项目认成此次创建。后续metadata/领域前进不使原receipt重算或失效；同原请求幂等核原证据，不要求当前仍空或名称仍同。

新namespace必须与旧applicationContextVersion1严格互斥、精确字段/版本/类型，持久canonical字符串保持现有格式3_json的canonical等值要求；不能宽松tag fallback或让bool版本混成int。现_validate_job3 application分支直接调用旧claim_context、format3._history亦仅认旧application plan，因此确需job_store与format3精确分派到唯一新validator。旧context/指纹/Job哈希不改、新旧tag互带拒绝，旧3遇新tag安全拒绝，默认2仍不启3。语义reader/writer版本及能力绑定需后续同候选实证，不能只看schema_hash未变宣称双向兼容。

旧apply_application原claim重试入口当前在kind/project相同时立即调用旧claim_context。新创建namespace若进入该处必须先identity-conflict，反向create遇旧Job/application claim同样不接管；该修改在既定job_store.py足够，不需改applications.py。新branch不可夹带manual/definitions/mapping/compensate/application等旧分支；旧默认canonical/plan hash字节和行为保持回归。

实现时要避免新creation validator为了核序号1再递归调用完整format3._history、而_history又回调该validator造成循环；共享validator核它已收到的真实origin/before/after证据，完整链遍历仍由唯一history路径负责。这是正常实施切点，非当前已发现的代码bug或要求新文件。

## 4. resolution的信息充分性与仍未交的物理权威

合同正确优先复用operation_claims和完整Job context，不另建main/localStorage/JSON/SQLite意图账本。唯一operation主键跨同库项目/Job/application，projectId+op不是可复用复合namespace；跨物理库相同UUID亦不证同操作。

queued/running/cancelling可有claim/Job context而无marker，null marker不推出未受理。已知op未知jobId从唯一claim完整发现，不能只查最近16条或带marker者。随后以真实claim project/kind/job/fingerprint、jobs行、完整原expectedRequest/issuedImplementation/issuedLimits逐值及既有_accepted_job校原snapshot/参数/prepared/确认。旧普通Job无host/Session来源时origin-not-recorded，不能借当前会话补历史；ChangeSet原origin须实际immutable prepared envelope和确认回执交叉核，不按当前base重建已受理计划。

当前库/项目许可必须先于内容返回，原来源不是现在权限；未知项目创建恢复需要窄库catalog+creation-receipt-read，不靠猜operation授权。当前许可不足直接权限失败，明显异请求身份冲突；缺claim/上下文/Job/proof时unknown不补写，Store本已坏到不能打开也不假称可resolution。无原dispatch绑定或复制库对应不明时所有resolved分支禁止；允许在当前B许可下展示B真实历史，是另一项普通只读事实，不关闭原A意图unknown。

跨Session是否能够重新证明原物理对应，现未有I06可消费实件。random migration_id/libraryEvidenceRef、当前Store实例、当前path、模型状态、caller同形对象/scope布尔、复制来的request/origin/receipt都不填该缺口。持有过原binding的可信调用链也必须有实际捕获/寿命/撤销和跨实例对应验证，不能由SQL现场mint。无证明宁保持unknown，不能换op/自动create/job.create重派、恢复旧grant或切换新generation当前项目。

resolution必须fresh只读事务并拒调用者未知活动writer事务，不调用create/commit/reconcile/snapshot/public_project/worker/迁移。SQL先按所有将读唯一行计完整证据字节，再有界展开所有必要引用和链，不能先无界_history/accepted_job物化再计返回。selector≤262144、证据caller显式正safeint≤67108864、返回≤131072和真实page/frame剩余最小值；重复引用可去重复计但遍历/字段/缓存不能免费或漏掉。具体实现的引用发现/费用/原子失败待代码验证，64MiB不是启动全库内存或CPU保证。

## 5. 完整写前预算与失败语义

创建初筛name1–4096 UTF8B、request≤16384、context+plan≤65536、receipt≤16384、成功返回≤32768，精确键/合法Unicode scalar/无surrogate、NUL、NaN或非safeinteger。先界后深复制/持久化，名称原字符不trim/NFC/casefold，同名不合并；默认空白metadata沿现created/guided，不扩模板/示例能力。

实际ReadLimits为可信host选择且只能收紧，不让renderer放大或复制第二套可漂移政策。完整metadata/目录行与missing-draft初始workspace（所有合法editor最坏JSON转义）写前核；已有所有行+候选全部真实genesis/public/claim/context/checkpoint/operation/receipt行按reader相同SQL字节口径核rows/bytes/work，完整新目录snapshot及1..page_items每组page size/offset编码或已证保守上界核page_bytes，93B cursor/36B snapshotId/标点/字段名一并计。

候选genesis及其hash在首次INSERT前可作为预算模型计算，不能假称已是持久证明；实际Store写后逐原数据/真实hash/receipt核候选相等，不等回滚。不能调用会拒活动writer事务的ProjectHostReader.catalog_start/workspace作事务内预检，不能另开连接或补snapshot。现reader约束/旧56路径不需修改；快照槽位/剩余runtime留存/TTL仍可资源失败，持久相容不承诺任何占用状态都能读。

取消/超时只影响尚未dispatch或等待；同步commit中不承诺新取消抢占，COMMIT后失响应/flush失败不删成功项目，COMMIT前真实退出全组回滚。unknown后只读对账，失败/取消Job不自动重跑。所有错误有限reason/参数，不把路径/原异常/名称/context泄回；当前合同未注册新公共code或fault环境。真实退出/故障用例与合成注入各自据实。

## 6. source退出澄清准确且不改变读取阶段

4106B过程文档与本审此前已读raw一致：60f3c4 shell先npm verify:sources重定向，后独立Python核48/hash；未fail-fast/未独捕npm inner exit，不能把最后Python/整shell0冒填为npm0。原111B log确实成功尾打印核12；此前本审另用stdlib独立逐12当前hash全同，源完整性有事实，npm子exit没有独立元数据则如实缺失。

新文档没有覆盖a816 validation/旧独审/raw，没有重跑无变化产品。check04最后命令与session5551/70ca9d实际exit0独立成立，1125TS/2841Python+44既有skip不因source元数据澄清改变。contract index clarification也明确independentNpmVerifySourcesExitCaptured=false，没有倒填。

## 7. 内部事务阶段可先行，但正式服务必须保留前置

§8末段“审批前必须确认I06真实库用途能力……”应作为**正式create_project_request/resolve_operation与host消费**的前置；不能据此认为所有内部Store事务/validator都必须等native完成。原用户AGENTS允许独立纯模块和真实库机制先行，正式接线保强依赖。此拆分保持本合同的创建持久语义与物理权威要求，不需要修改ff725原件或降低两个P2。

root若选择先推进，建议另发一份准确的新阶段授权/范围说明，明确仅内部事务机制，使用owner§8已有集合的子集：

| 既定路径 | 可先实施的内部职责 | 此阶段排除 |
| --- | --- | --- |
| 新project/project_lifecycle.py | request/intent/context/plan/receipt严格唯一validator、写前完整预算模型、Store委托效果及真实持久证据读核 | 不实现可生产接受的scope/dispatch工厂、不签任何物理binding；不把内部receipt包装成resolved关闭unknown。 |
| storage.py | Store.commit互斥creation分支与唯一真实交易；genesis/public/唯一claim/seq1/receipt全组原子性 | 不开放文件路径/新连接/迁移/默认生产3或另writer。 |
| job_store.py | 精确新namespace的Job-ready验证分派及旧apply跨namespaceidentity-conflict | 正式受信创建薄适配、当前scope/原dispatch校验消费和完整resolution服务后置；不造成功ready/权限。 |
| project/format3.py | created origin→create seq1→后续完整链/receipt效果校验，旧origin/application不变 | 不改DDL/schemahash、不放松旧validator或伪称旧3兼容新语义。 |
| 新test_project_create_contract.py | 真实临时JobStore3、完整dump、逐持久边界rollback/commit/真实退出、namespace/旧兼容/读写预算相容机制测试 | test origin/intent只证事务，不证真实host/人类/FS许可；可暂不创建完整test_project_operation_resolution.py。 |

此为owner已列四产品+两测试中的**四产品+一测试子集建议**，没有自行扩大路径；是否采用、实际新树/基线/只读继承、原共享文件唯一窗口、旧验证器对照资产与执行范围仍由root精确批准。本报告不直接让作者改代码。新逻辑不应以测试scope布尔、同形capability、fake厂或“调用者自报受信”来让正式服务可用，也无需创建一个返回假成功的stub facade。

内部代码消费已经开好的、实际Store3+Job3结构可验证连接，不能仅target_format3就假设operation_claims/public_projects存在；纯Store3而非JobStore3必须明确拒本新增分支，真实schema/foreign keys/ready验证需在机制测试覆盖。此处证明已打开连接内的SQL事务正确性，不能倒称这次打开本身已获位置授权。engine UUID分配/原claim优先是内部mechanism事实，原trusted_origin测试值只是持久数据输入，不是其来源已获真人/会话认证。

正式create/resolution实现与使用继续等实际I06库用途/生命周期、当前scope和原dispatch物理绑定捕获/撤销/重新对应、原host/Session/generation及真实人类动作前置；它们没有时不接公开路径、不能resolved或自动重派。后续可独立补test_project_operation_resolution.py及真实权限消费，仍按本同一合同、根精确授权和实际owner实件。若实施实际证明四路径不足或持久形状需变，保反例再报root，不加表/新ledger绕过。

本次没有必须先修改主合同才能批准上述受限内部事务子阶段的实质设计阻断；新授权中明确“§8前置只在正式服务阶段满足”即可避免审计时误读，不必把native缺失泛化为全体内部工作停滞。此为可实施阶段划分建议，不是全create/resolution已经授权或已通过。

原完整FR-001–006/804、四入口/模板示例/T09、真实位置/主进程/公开DTO、目标OS/native、父44/57P0、指定GLM-5.3最高与M3.1-Flash xhigh双方同版新审、CI/正常develop合并/远端核验全部保留。本轮无push/PR/merge/Goal变化，不把文档静态通过或内部事务机制当完整产品验收。
