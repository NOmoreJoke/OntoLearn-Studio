from pathlib import Path
from hashlib import sha256
import json
import subprocess
import zipfile

root = Path.cwd()
out = root / 'docs/reviews/T01/project-create-core-C1'
control = Path('/Users/kyle/Documents/工作/知爻/本体/iteration-control/2026-10-21-weekly-release')
base = '5f910b52c69d86a1076b2032e5d3c63e715947f3'
adoption = 'ba2c6c293f9fd9e1742c9ab352dae5e3c951f6a4'
fixed = json.loads((control/'T01-project-create-core-fixed-foundation-inputs.json').read_text())
fingerprint = lambda b: {'bytes': len(b), 'sha256': sha256(b).hexdigest()}
new = ['packages/engine/src/ontolearn_engine/project/project_lifecycle.py',
       'packages/engine/tests/test_project_create_contract.py']
product_paths = sorted([x['path'] for x in fixed['initialExactAdoption']] + new)
assert len(product_paths) == len(set(product_paths)) == 52
foundation = []
for item in fixed['initialExactAdoption']:
    path = item['path']
    original = subprocess.check_output(['git', 'show', item['ref']+':'+path])
    adopted = subprocess.check_output(['git', 'show', adoption+':'+path])
    current = (root/path).read_bytes()
    assert adopted == original and fingerprint(original) == {'bytes': item['bytes'], 'sha256': item['sha256']}
    if item['futureRole'] == 'readonly':
        assert current == original
    foundation.append({'path': path, 'futureRole': item['futureRole'],
                       'sourceRef': item['ref'], 'adoption': fingerprint(adopted),
                       'current': fingerprint(current), 'unchangedFromAdoption': current == adopted})
assert sum(x['futureRole'] == 'readonly' for x in foundation) == 47
assert subprocess.check_output(['git', 'rev-parse', adoption+'^'], text=True).strip() == base
assert sorted(subprocess.check_output(['git', 'diff', '--name-only', base, adoption], text=True).splitlines()) == sorted(x['path'] for x in foundation)
protected = fingerprint((root/'AGENTS.md').read_bytes())
assert protected == {'bytes': 15852, 'sha256': '78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759'}

entries = {}
transcripts = []
session_root = Path('/Users/kyle/.codex/sessions/2026/10/21')
sources = {
 'primary': session_root/'rollout-2026-10-21T07-51-20-01a15bba-0884-7401-b24f-f50c1fcf60aa.jsonl',
 'independent-transactions': session_root/'rollout-2026-10-21T16-53-41-01a15daa-8f89-7971-b5bc-e9fed0a6cc67.jsonl',
 'independent-budget': session_root/'rollout-2026-10-21T16-54-05-01a15daa-ef8c-7563-a2bf-10f6e91fa5be.jsonl',
}
cutoff = '2026-10-21T08:48:00.000Z'
for label, path in sources.items():
    prefix = path.read_bytes()
    calls, outputs, standalone = {}, {}, []
    offset = 0
    for line_number, raw in enumerate(prefix.splitlines(keepends=True), 1):
        item = json.loads(raw)
        payload = item.get('payload', {})
        kind = payload.get('type')
        if item.get('type') == 'response_item' and item.get('timestamp', '') >= cutoff:
            record = {'line': line_number, 'offset': offset, **fingerprint(raw),
                      'type': kind, 'timestamp': item['timestamp'], 'raw': raw}
            if kind in ('function_call', 'custom_tool_call'):
                calls[payload['call_id']] = record
            elif kind in ('function_call_output', 'custom_tool_call_output'):
                if 'call_id' in payload:
                    outputs.setdefault(payload['call_id'], []).append(record)
                else:
                    standalone.append(record)
        offset += len(raw)
    selected, pairs = list(standalone), []
    for call_id, call in calls.items():
        if call_id not in outputs:
            continue
        selected.extend([call, *outputs[call_id]])
        pairs.append({'callId': call_id, 'callLine': call['line'],
                      'outputLines': [r['line'] for r in outputs[call_id]]})
    selected.sort(key=lambda r: r['line'])
    member = 'tool-records/'+label+'.jsonl'
    entries[member] = b''.join(r['raw'] for r in selected)
    transcripts.append({'source': str(path), 'capturedPrefix': fingerprint(prefix),
                        'cutoffUtc': cutoff, 'member': member, 'pairCount': len(pairs),
                        'recordCount': len(selected), 'pairs': pairs,
                        'standaloneOutputLines': [r['line'] for r in standalone],
                        'unfinishedCallIdsExcluded': [c for c in calls if c not in outputs],
                        'records': [{k: v for k, v in r.items() if k != 'raw'} for r in selected]})
for path in sorted(Path('/tmp').glob('t01-create-core-*.log')):
    entries['logs/'+path.name] = path.read_bytes()
for name in ['T01-project-create-core-C1-implementation-authorization.md',
             'T01-project-create-core-fixed-foundation-inputs.json',
             'T01-controller-project-create-resolution-contract-review.md',
             'developer-common-instructions.md']:
    entries['inputs/'+name] = (control/name).read_bytes()
entries['inputs/AGENTS-protected.md'] = (root/'AGENTS.md').read_bytes()
contract = root.parent/'T01-project-host-read-services/docs/iterations/T01/project-create-and-resolution-contract.md'
assert fingerprint(contract.read_bytes()) == {'bytes': 39602, 'sha256': 'ff725f2c0ee40cbdf61c9c4d27dfea1be3ccd2068df4399878b037976de4a5f3'}
entries['inputs/project-create-and-resolution-contract-frozen.md'] = contract.read_bytes()
entries['inputs/adoption-receipt.json'] = Path('/tmp/t01-create-core-adoption-01.json').read_bytes()
entries['tooling/build-evidence.py'] = Path(__file__).read_bytes()
archive = out/'original-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        info = zipfile.ZipInfo(name, date_time=(2026,10,21,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(entries) and z.testzip() is None
    for name, data in entries.items():
        assert z.read(name) == data
index = {
 'scope': 'C1 internal creation only; original complete tool call/output pairs and separately labeled async outputs. No reasoning/messages/DB/runtime artifacts. First pre-dispatch 8120B authorization observation is retained but superseded by actual 8323B formal dispatch; not authority. No formal service, physical scope/binding, designated external double review, desktop/native, CI or release proof.',
 'archive': {'path': archive.name, **fingerprint(archive.read_bytes())},
 'members': [{'path': n, **fingerprint(b)} for n,b in sorted(entries.items())],
 'transcripts': transcripts,
 'finalChecks': [
  {'command': '.venv/bin/pytest packages/engine/tests/test_project_create_contract.py -q', 'startChunk': 'b50a2c', 'session': 98989, 'terminalChunk': '53abda', 'exitCode': 0, 'passed': 128, 'log': 'logs/t01-create-core-target-pytest-06.log'},
  {'command': 'UV_CACHE_DIR=/tmp/t01-create-core-runtime-cache/uv npm run check', 'startChunk': '79a7dd', 'session': 96986, 'terminalChunk': '3b62e4', 'exitCode': 0, 'typescriptPassed': 1125, 'pythonPassed': 2969, 'existingPythonSkipped': 44, 'log': 'logs/t01-create-core-check-01.log'},
  {'command': 'npm run verify:sources', 'terminalChunk': '7c9c20', 'exitCode': 0, 'log': 'logs/t01-create-core-verify-sources-01.log'}],
 'firstFailures': ['target01 metadata threshold fixture and old-reader package missing static resource', 'target05 domain receipt fixture wrong field key', 'ruff unused imports and long lines; complete original logs retained'],
 'independentCounterexamples': {'beforeFixChunk': '4f7fc8', 'afterFixChunk': 'a29141', 'status': 'P2-C1-01 closed by independent real SQLite replay; bounded internal mechanism only'},
}
index_path = out/'original-evidence-index.json'
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n')
docs = [root/'docs/iterations/T01/project-create-core-C1.md',
        out/'validation.md', out/'independent-review.md', out/'budget-model-review.md',
        archive, index_path]
manifest = {
 'base': base, 'adoption': adoption, 'branch': 'feature/weekly-t01-project-create-core',
 'sourceRef': fixed['sourceRef'], 'productTestPaths': 52,
 'productsAndTests': [{'path': p, **fingerprint((root/p).read_bytes())} for p in product_paths],
 'initialExactAdoption': foundation, 'currentReadonlyExact': 47, 'protectedUnstagedAGENTS': protected,
 'docsAndEvidenceExcludingThisManifest': [{'path': str(p.relative_to(root)), **fingerprint(p.read_bytes())} for p in docs],
 'notes': 'Manifest hashes current frozen bytes, not a future commit. Final Git identity and safety source ZIP verified separately after explicit staging/commit. No self hash or fabricated tool pair.'
}
manifest_path = out/'source-manifest.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'rawArchive': index['archive'], 'members': len(entries),
                  'completePairs': sum(x['pairCount'] for x in transcripts),
                  'records': sum(x['recordCount'] for x in transcripts),
                  'index': fingerprint(index_path.read_bytes()),
                  'manifest': fingerprint(manifest_path.read_bytes()),
                  'productsAndTests': 52, 'readonlyExact': 47}, ensure_ascii=False, indent=2))
