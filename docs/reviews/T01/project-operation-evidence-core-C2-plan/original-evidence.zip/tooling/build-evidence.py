from pathlib import Path
from hashlib import sha256
import json
import zipfile

root = Path.cwd()
out = root/'docs/reviews/T01/project-operation-evidence-core-C2-plan'
control = Path('/Users/kyle/Documents/工作/知爻/本体/iteration-control/2026-10-21-weekly-release')
fp = lambda b: {'bytes': len(b), 'sha256': sha256(b).hexdigest()}
session_root = Path('/Users/kyle/.codex/sessions/2026/10/21')
sources = {
 'primary': session_root/'rollout-2026-10-21T07-51-20-01a15bba-0884-7401-b24f-f50c1fcf60aa.jsonl',
 'independent-core': session_root/'rollout-2026-10-21T16-53-41-01a15daa-8f89-7971-b5bc-e9fed0a6cc67.jsonl',
 'independent-budget': session_root/'rollout-2026-10-21T16-54-05-01a15daa-ef8c-7563-a2bf-10f6e91fa5be.jsonl',
}
entries, transcripts = {}, []
cutoff = '2026-10-21T09:52:20.000Z'
for label, path in sources.items():
    prefix = path.read_bytes()
    calls, outputs, standalone = {}, {}, []
    offset = 0
    for number, raw in enumerate(prefix.splitlines(keepends=True), 1):
        item = json.loads(raw)
        p = item.get('payload', {})
        kind = p.get('type')
        if item.get('type') == 'response_item' and item.get('timestamp', '') >= cutoff:
            info = {'line': number, 'offset': offset, **fp(raw),
                    'type': kind, 'timestamp': item['timestamp'], 'raw': raw}
            if kind in ('custom_tool_call', 'function_call'):
                calls[p['call_id']] = info
            elif kind in ('custom_tool_call_output', 'function_call_output'):
                if 'call_id' in p:
                    outputs.setdefault(p['call_id'], []).append(info)
                else:
                    standalone.append(info)
        offset += len(raw)
    selected, pairs = list(standalone), []
    for call_id, call in calls.items():
        if call_id in outputs:
            selected.extend([call, *outputs[call_id]])
            pairs.append({'callId': call_id, 'callLine': call['line'],
                          'outputLines': [x['line'] for x in outputs[call_id]]})
    selected.sort(key=lambda x: x['line'])
    member = 'tool-records/'+label+'.jsonl'
    entries[member] = b''.join(x['raw'] for x in selected)
    transcripts.append({'source': str(path), 'capturedPrefix': fp(prefix),
                        'cutoffUtc': cutoff, 'member': member, 'pairs': pairs,
                        'pairCount': len(pairs), 'recordCount': len(selected),
                        'standaloneOutputLines': [x['line'] for x in standalone],
                        'unfinishedCallsExcluded': [c for c in calls if c not in outputs],
                        'records': [{k:v for k,v in x.items() if k != 'raw'} for x in selected]})
for name in ['T01-operation-evidence-C2-plan-preparation.md',
             'T01-project-create-core-C1-root-closure.md',
             'T01-controller-project-create-core-C1-readback.md',
             'developer-common-instructions.md']:
    entries['inputs/'+name] = (control/name).read_bytes()
entries['inputs/AGENTS-protected.md'] = (root/'AGENTS.md').read_bytes()
contract = root.parent/'T01-project-host-read-services/docs/iterations/T01/project-create-and-resolution-contract.md'
assert fp(contract.read_bytes()) == {'bytes': 39602, 'sha256': 'ff725f2c0ee40cbdf61c9c4d27dfea1be3ccd2068df4399878b037976de4a5f3'}
entries['inputs/contract-frozen-ff725.md'] = contract.read_bytes()
entries['inputs/fixed-foundation-inputs.json'] = (out/'fixed-foundation-inputs.json').read_bytes()
for path in sorted(Path('/tmp').glob('t01-operation-evidence-C2-plan-format-*.log')):
    entries['logs/'+path.name] = path.read_bytes()
entries['tooling/build-evidence.py'] = Path(__file__).read_bytes()
archive = out/'original-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        info = zipfile.ZipInfo(name, date_time=(2026,10,21,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(entries)
    for name, data in entries.items():
        assert z.read(name) == data
index = {'scope': 'C2 documentation preparation only. Complete original paired tool records and separately labeled async outputs; no reasoning/messages/DB. Primary records also include parallel separately authorized dispatch-plan discussion; those are not C2 adopted product or validation evidence. No product/test/runtime execution or code authorization is implied. Snapshot is a captured prefix; later archive verification/staging/Git actions cannot already be included.',
         'archive': {'path': archive.name, **fp(archive.read_bytes())},
         'members': [{'path': n, **fp(b)} for n,b in sorted(entries.items())],
         'transcripts': transcripts,
         'finalPlan': {'path': 'docs/iterations/T01/project-operation-evidence-core-C2-plan.md',
                       **fp((root/'docs/iterations/T01/project-operation-evidence-core-C2-plan.md').read_bytes())},
         'formatChecks': [{'terminalChunk': 'c14d42', 'exit': 0,
                           'log': 'logs/t01-operation-evidence-C2-plan-format-01.log'},
                          {'terminalChunk': '423cc7', 'exit': 0,
                           'log': 'logs/t01-operation-evidence-C2-plan-format-02.log'}],
         'staticChecks': {'terminalChunk': '2a9ec2', 'exit': 0, 'foundationReadonly': 52,
                          'C1OriginalUnchanged': 59, 'pythonASTParsed': 32,
                          'plannedTreeAndProductsAbsent': True},
         'runtimeTests': 'Not authorized and not run; plan matrices are future acceptance only.'}
index_path = out/'original-evidence-index.json'
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n')
paths = [root/'docs/iterations/T01/project-operation-evidence-core-C2-plan.md',
         out/'fixed-foundation-inputs.json', out/'budget-investigation.md',
         out/'independent-plan-review.md', out/'review-dispositions.md',
         out/'checks.json', archive, index_path]
manifest = {'kind': 'C2-plan-docs-only-source-manifest',
            'processParent': 'a33cc80e82475e54d74b4e48c1fd32f32979983a',
            'frozenProductRef': '423b7e4c799f188cf2ce6e8e7121893ce85624cd',
            'pathsExcludingThisManifest': [{'path': str(p.relative_to(root)), **fp(p.read_bytes())} for p in paths],
            'plannedFoundationPaths': 52, 'plannedAllReadonly': True,
            'actualProductOrTestChanges': [],
            'notes': 'Self hash bound by final Git/source ZIP. Only these eight docs plus this manifest belong to C2 plan. C1 original59/closure and parallel dispatch docs are excluded and remain unchanged.'}
manifest_path = out/'source-manifest.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'archive': index['archive'], 'members': len(entries),
                  'pairs': sum(x['pairCount'] for x in transcripts),
                  'records': sum(x['recordCount'] for x in transcripts),
                  'index': fp(index_path.read_bytes()),
                  'manifest': fp(manifest_path.read_bytes()), 'docsTotal': 9}, ensure_ascii=False, indent=2))
