# T01 C1 内部创建核心：控制侧固定读回

结论：对固定提交 `423b7e4c799f188cf2ce6e8e7121893ce85624cd`，本次独立静态审读、Git/归档核验及原始运行证据读回在获准 C1 内部机制范围内通过，未发现新增未解决实质问题。P2-C1-01 的修前真实反例、修后独立拒绝和正常历史/幂等反例已与最终源码绑定。此结论只供根决定内部 C1 接收；不替代指定双模型、CI、正常 develop 集成、完整 Host、I06 原物理 dispatch 能力或父功能验收。

本审仅写本文件；没有改产品、测试、owner 报告/原件、旧控制报告或共享 state，没有 import/执行产品、运行测试/构建/DB、启动 GUI/native/Keychain、调用模型或操作 Git index/branch/commit。运行核验归属实际 owner/独立事务审查人，本审只读其原始记录并独立验证归档出处、Git、文件、AST、JSON 和 SHA。

## 1. 授权与固定范围

新树 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-project-create-core`，分支 `feature/weekly-t01-project-create-core`。实际 Git 父链：

- 批准 base：`5f910b52c69d86a1076b2032e5d3c63e715947f3`。
- 独立精确采纳：`ba2c6c293f9fd9e1742c9ab352dae5e3c951f6a4`，parent 恰 base；delta 恰固定清单 50 路径。
- C1 产品提交：`423b7e4c799f188cf2ce6e8e7121893ce85624cd`，parent 恰 ba2c。相对 ba2c 为五项产品/测试及七项 docs/evidence 共 12 路径；相对 base 为完整 52 产品/测试、7 docs/evidence，共 59 路径，全部实际 Git mode100644。

规则与授权身份已核：

| 输入 | bytes | SHA256 |
| --- | ---: | --- |
| 本树受保护 AGENTS.md | 15852 | 78df28251883651ea8a068a8a21daed6d6dc0f50348894d59a808b969a97a759 |
| 共同指令（原件包内与此前已读身份相同） | 17891 | e437121a08053544c2a09151ac5183baf15b5fa67a3a604891aaa9e77ba971b0 |
| 根 C1 实施授权 | 8323 | 93528eb38395856af86a76edf9c26822ef406f8a32315282086a509db235d8b5 |
| 根固定 foundation 清单 | 14299 | c87fd0a1aca68c9a82ceb8aa142a5d8b6ab974d5e29d17588bd1909d64aa9726 |
| 固定创建/resolution 合同 | 39602 | ff725f2c0ee40cbdf61c9c4d27dfea1be3ccd2068df4399878b037976de4a5f3 |
| 根前一合同独立复核 | 18372 | 517b29bf74765bdca633b2bbc128cd036b7517aae8a7cb47edf900ae3e2e3bad |

授权与固定清单已实读。按根原清单逐项核 50 个 adoption Git blob = a816 原 Git blob、bytes/SHA 一致；47 项 futureRole readonly 的当前文件与 adoption/a816 仍逐字节相同。52 集合严格等于上述 50 项加新 lifecycle module 和新 create test，并非只核五个 writer。未 whole-commit 采用 a816 或复制他树环境。当前 status 仅 ` M AGENTS.md`，无 staged/untracked 产品项；保护字节未纳入 C1 提交。

## 2. 最终源码、文档与归档身份

新模块及新测试全文、三项继承 writer 相对 ba2c 的完整 diff 已审读；另定点实读既有 transaction、Job3/format3 history 与 frozen reader 计费切点。初始静态读回时尚在 ba2c HEAD 的五文件字节，与最终 423b7e4 固定 Git blob 完全相同，未把后续冻结前身份当成最终通过。所有清单中的 Python 文件仅经 stdlib AST parse，没有 import 或执行。

| 五个 writer（前四项相对 packages/engine/src/ontolearn_engine） | bytes | SHA256 |
| --- | ---: | --- |
| project/project_lifecycle.py | 20932 | a43365c1615082a0229de0d8e48569227fa930a7c3a7f869360975d72f30d104 |
| storage.py | 76042 | fbef0d0ace0a01b9ced5eaecaf83aeb9306258c0cbfa5fd98a6d79e46bc5a39a |
| job_store.py | 87227 | 8896c3e30007e1dec04eaf47ae5bb5c33a1e9b3a1d016cb9165f99d8b4deeacc |
| project/format3.py | 32169 | 505d0beb124534b2ab2e6c1716df53ef7b8108bedb57f5300fcb79a68e955782 |
| packages/engine/tests/test_project_create_contract.py | 27843 | de02dcf022da0784e2d5d31dc0d29f8b2ca5cf0691cd2ca19835cd136c91020a |

下列 docs/evidence 均已核当前文件 = 固定 Git，并与 source-manifest 所列身份核同；main/validation/两独审全文已读。manifest 本身无自 hash，固定 Git 及完整 source ZIP/独立 final-git 收据补足绑定。

| 文件 | bytes | SHA256 |
| --- | ---: | --- |
| docs/iterations/T01/project-create-core-C1.md | 10867 | 13bcacbd9e3031effe8827856215183a2def15ef2209df175b44a2985a8b6305 |
| validation.md | 6172 | bacda2169eb2e093a3ace863c20c1ab0d1a00e788bd605a5ff44d6801186f9ab |
| independent-review.md | 14125 | c408b280e5377d3645b039f4637947e4559fecfebc39afe9f09b87f68fba00e8 |
| budget-model-review.md | 24151 | ead73bb04c974f91c908e6eeda2ab4ffc99264b02ebc05a469cbc3c18f5f4614 |
| original-evidence.zip | 803376 | 66028ff6035c0ac5e010eb2337bd05fc9a6e1adc5fb5798ff2291dae3e9c3a18 |
| original-evidence-index.json | 239692 | 7f6fcb5684448580ebed3e3362b3daba28ba3036acb644d44327f5380aa00a58 |
| source-manifest.json | 35652 | 6f7fa50afb84e54236d0db55104a5f72be6ee4bb8939e5546d3163a58d21f1cf |

除首项外，该表相对 `docs/reviews/T01/project-create-core-C1/`。额外安全包 `/tmp/t01-project-create-core-C1-source.zip` 为1193438B / `6242692e9317dfe26fb26a4f802c21d5a85f9f65f1043e16118de0fbeb6b7168`，59成员逐项核同 Git/bytes/SHA；`/tmp/t01-project-create-core-C1-final-git.json` 为14049B / `cd0a477b60f68ffb66fd50b72d2fad741410fe2f357bab288838c2ff593ec77c`，父链、59路径、mode、source包及实际当前状态均独立核同，不仅信收据布尔值。

## 3. 内部事务与 namespace 的实际审读

`Store.commit` 只有 creation 非 None 才委托新模块，所有旧 edit/application/compensation 参数（包括显式空列表）互斥；省略 creation 的旧分支/hash 与默认格式不改。内部入口要求真实 JobStore、target3、没有未知 caller 活动事务，以及 project/base/job 均 None；实际 PRAGMA user_version3、frozen reader 硬 guard、完整 format3 与 Job3 schema/catalog/FK/claim 验证都在同连接首 INSERT 前完成。纯 Store3 不会隐式构造 Job3，缺表/错误 header 不进行修复。

同一外层 `_transaction` 的 BEGIN IMMEDIATE/COMMIT 包围所有效果。原 `_transaction` 的 savepoint 行为没有更改；新入口提前拒绝 caller transaction，不误将 RELEASE 当持久成功。返回值在 context manager COMMIT 后才离开函数；before_commit 异常回滚，after_commit 交付异常保留已成功事实，后续相同原请求读回原回执。

创建意图是专属内部 `projectCreateCoreVersion1`，不冒充完整受信宿主 intent。request/origin 精确普通 dict、字段集有限，bool 版本拒绝；三个 UUID 标量在解析前均界36字符；operation 与 request.operationId 精确核同。name 保原序列且先界字符/UTF8，再核完整编码；不 trim/NFC/casefold 或截断。origin host/session UUID 与 permission 只是持久输入，不认证真人、物理库、当前 scope 或原 dispatch。

全库原 claim 先于项目 UUID 分配和新预算：相同创建 namespace 必须原 request/origin 精确相同，且原 context、完整真实 history、receipt 核同；返回原 result，不要求仍叫原名或领域仍空。新收紧 readerLimits 不改原请求身份。旧 application/job 或孤儿 operation 证据不被接管；旧 apply_application 反向遇创建 claim 先 identity-conflict。UUID 只在无原 claim 后由 engine 分配；内部/public 同真实新UUID，已有 project/public/internal/snapshot/checkpoint 冲突均拒绝。

唯一新效果为10条末态持久行：projects1、snapshots1、app_projects1、app_checkpoints2、app_origins1、public_projects1、operation_claims1、app_operations1、app_receipts1。中间 metadata/head UPDATE 不重复计末态行。strict seed/checkpoint 使用普通 INSERT、真实领域 state/snapshot 和真实 genesis；不改变旧默认 INSERT OR IGNORE 路径。真实 genesis 经现有 project_checkpoint/history 读回，与预算候选核同后才重建实际 plan/context/receipt；不以预测 hash 充当存在证明。逐typed row与全库SQL aggregate、完整format3/Job3最终核同，否则整笔回滚。

创建 namespace 只接受精确 context 键集和版本、空白 domain revision0、created origin、seq1/metadata1 的真实 genesis→after 效果、无 domain marker。claim requestHash/contextHash/planHash、完整 origin/request、public mapping、app_origins、真实 seq1 application op 与真实 receipt 均核同。`_history` 使用当前遍历已经持有的 before/after/origin；新 validator 不回调 history 或 Job-ready，未引入递归证明。其余旧 application 仍走原 strict validator；混 tag/未知 tag 不获宽松 fallback。Job3 对创建又核完整 history 返回的实际 receipt，不只认可自洽 claim。

三项既有修改中没有新 DDL/table/kind/hash/default3，没有公开 wire/main/IPC/FS 或 create/resolution 注册；47 readonly 原码未改变。旧 a816 reader 拒绝新 namespace 是显式兼容边界，不能声称旧新双向通用；测试从固定 Git 取三旧模块及原 invalidation 资源构建私有对照包，使用本树环境，未借他树 runtime。

## 4. 完整预算的实际边界

预算在第一次 INSERT 前，而非先试写再 rollback 计费。已有库先按 frozen reader 硬 guard 界 schema/表/列/全行/字节/work；新阶段再只读消费同版真实 ReadLimits，不复制放宽 policy。当前全库每表每列 CAST BLOB 聚合与候选每 typed scalar 的同连接 `length(CAST(? AS BLOB))` 口径相同，不假定 Python UTF8 长度等于任意 SQLite 编码。

新增10行的最终总 R/B 预扣后，work 用新增后的 `B × (1 + app_operations总行数 + snapshots总行数)`；不是只乘新项目或写前旧 O/S。request≤16384B、context+plan≤65536、receipt≤16384、result≤32768。后两份 checkpoint、public/claim/context/receipt 等真实整行均收费，写后所有列值和全库 aggregate 再精确核预测。

完整目录包含所有旧项目、原metadata及新项目：全部内部ID和完整metadata、每目录行先核，按 publicUUID BINARY 顺序排列；新UUID必须能放入identity_bytes。snapshot 依冻结reader的 `sum(rowBytes)+2+count`，不是用少1字节的真实数组长度替换；reserve 为 `768 + count*(catalog_row_bytes+64)`。逐 page_size1..page_items 的每个实际可达 offset 核完整页，含36字节 snapshotId、93字节非末 cursor、末页null、total/offset/标点/转义。size3和size1都能放入但size2末页不能放入的反例，已进入新测试。不能只测最大页或单行。

初始 workspace 缺draft，完整metadata/refs/版本字段收费；全部合法 editor 用 U+0001 重复 identity_bytes 覆盖可达6倍JSON转义。name4096个ASCII→完整metadata4178B写前拒绝；4014个ASCII→4096B可通过，引号扩张按完整编码拒绝。预算不足不截名/页，不补造 draft bound/generation。

这只是有限消费相容门：reader 当前已有快照占用、TTL/槽位运行资源仍可能有限失败；创建没有承诺预订所有未来 reader 内存或永久可读。测试中一项原子行费用核对使用实现 helper，单独不足以独立证明计费；另11字段±1测试从真实已提交 reference DB 的独立全表SQL、实际reader全部页及最坏editor取得阈值，再在另一目标 DB 拒绝/接受，补足独立边界证据。两独审中的独立纯数学反例与实际代码/测试方向一致，不把静态算式写成亲跑数据库。

## 5. P2-C1-01：原件反例与关闭

本审直接从校验出处的 tool-records 读取实际 call 与 output，没有用独审结论摘要替代。修前 `4f7fc8` exit0：真实旧空项目 + 合法 domain commit，再只插入自洽创建 namespace claim。原 Job-ready 与 format3 都 accepted；actualReceiptKind=domain、metadata0/domainRevision1、预测创建 afterCheckpoint 不存在；重开 actual3 仍 accepted，完整 dump 不变。修前 module20246/a998…、job_store87041/aaa926…、test25875/78de…，没有把该反例错误绑定到最终已修源码。

修后 `a29141` exit0 的实际命令重建同类真实临时 SQLite，并在受控 authorizer 下读取：creation_context→CreationFault:structure，Job-ready→Format3Fault:Invalid project structure，真实重开同样拒绝，writeAttempts=[]、完整logicalDump不变；源码前后五 SHA 与本报告最终候选一致。同时另一真实库通过新 Store.commit 创建，再正常 metadata/domain 推进，原 request 重试与真实重开后重试均返回原回执；workspace 为sequence3/metadataVersion2/domainRevision1。修复不是强迫项目永远保持空白。

静态修复对应 creation_context 的真实 origin/seq1 application op/receipt 三 immutable tuple 逐值核同，以及 Job3 receipt_for 返回值与创建 receipt 核同；新增回归要求真实旧 domain receipt、没有创建 afterCheckpoint 的伪 claim 被直接验证/Job-ready/重开拒绝且dump不变。P2在限定损坏证据验证范围内关闭。普通format3纯领域链单独不承担Job3全局claim证明，本审不把其接受原合法domain链误报为修复失败，也不把此修复当成物理授权认证。

## 6. 原始运行记录、失败和归档出处

原件ZIP29成员无重复名，member set 与 index 精确相同，各 bytes/SHA 全部核同。三份原工具记录逐实际源 rollout capturedPrefix SHA、byte offset/长度、原行号、行SHA、call_id/配对 output核验，ZIP成员恰原始行字节拼接：primary58pair/118records，事务独审124/253，预算独审135/275，合317pair/646records；12条standalone异步输出另标。记录中包含 fork 继承的较早工具，317是归档配对计数，不是317次相互独立的C1验收；没有把未完成call伪配。

最终运行原件全文已读并 hash：

| 实际命令与日志 | bytes / SHA256 | 真正终态及结果 |
| --- | --- | --- |
| `.venv/bin/pytest packages/engine/tests/test_project_create_contract.py -q`；target-pytest-06.log | 180 / f3e954e07c05a2ae600a53f52a9c1334a4579c5ec29cd01bdc435f1ad37d4298 | start b50a2c、session98989、terminal53abda exit0；128 passed 4.81s |
| `UV_CACHE_DIR=/tmp/t01-create-core-runtime-cache/uv npm run check`；check-01.log | 8667 / 897bd1596e9f61a55baa2a07531208c9adce8a488f22644bbd723f474a1bc2a7 | start79a7dd、session96986、terminal3b62e4 exit0；lint/format/typecheck/build完成、22 TS文件1125 tests、Python2969 passed/44既有skip |
| `npm run verify:sources`；verify-sources-01.log | 111 / 1439dca3a0fd2dbc3702b336e9accceedc93893d0d65264c69da1aa175c45536 | 独立exec_command末命令7c9c20 exit0；12归档源核对 |

表中日志相对ZIP `logs/t01-create-core-`，exit来自实际工具终态而非日志正文。sourceverify虽处在一次外层exec中的多个独立调用，自己的 exec_command 只有 npm 末命令；没有用后续Python exit0遮蔽npm。本审还用stdlib独立按 docs/source-manifest.json 逐12个实际源原件重新核SHA，全部一致，不重新执行verify:sources，也不把12归档源等同47/50接收清单。

新测试全文实际包含19个phase的异常rollback/after_commit保持事实、19个真实子进程os._exit(77)/重开、9类SQL INSERT拒绝与全dump核同、10类零INSERT预算拒绝、11字段±1/所有页/editor/metadata反例、namespace冲突/损坏/重试/旧reader/实际header/纯Store3或缺Job3/未知caller事务拒绝。真实专项128和fullcheck2969是运行它们的原证据；本审没有亲自重跑，44skip未算作通过。此证据证明的是本树临时库与真实退出恢复，不是已交真实位置IO或宿主真人验收。

保留且实读首失败：target01为2failed/81passed（metadata阈值100大于合法metadata、旧reader临时包漏invalidation资源），target05为1failed/127passed（fixture错读domainRevision，实际字段domainAfterRevision），ruff01为未用re及长行3errors；最终测试对照包补原资源且实际要求Invalid project structure，未把早先导入失败当旧reader安全拒新语义。原失败未删除；target02等中间日志也在29成员中，不用中间126/127通过代替final128。

时态另核：ZIP产生后的原rollout尾部真实记录为 b84967 归档完成；c55695 的 python3 归档校验因旧解释器不接受 zip(strict=...) exit1；随后 `.venv/bin/python` 校验/stage 的0580be exit0、3be54c提交exit0、076351固定Git/source安全包exit0。本审直接读取尾部真实原件，并另对最终Git/ZIP重核；这些后续事件未包含在先前冻结ZIP，不能反称原ZIP已收录它们。该失败是归档验证脚本解释器兼容失败，不是被省略的产品check失败或重跑产品成功。

## 7. 接收结论与不放行项

C1在已授权五writer及完整52继承范围内实现真实内部Store事务、严格创建namespace/history与完整预算，并有最终固定候选、独立修前/后反例、真实临时SQLite/退出恢复及完整检查证据。原件/来源/保护路径与Git安全包一致，本审无新增待修事项，可由根按内部子阶段接收。

该内部机制不提供或认证正式 create_project_request/resolve_operation、真实I06 producer、原物理库/dispatch、current_scope、位置首IO、公开host/main/IPC/FS、默认格式3启用。app_format.migration_id派生libraryEvidenceRef是逻辑材料，复制库可相同；随机UUID、origin字符串、caller结构和fixture都不能补缺失真实物理身份。没有新增factory/第二主账本或unknown/null自动重派。

原同版GLM-5.3最高与MiniMax M3.1-Flash/xhigh指定双审、桌面native/双OS真人、CI/正常develop合并、FR-001–006/804、44/57P0及父Goal门仍未在本审关闭。静态build成功不代表Electron运行；两个内部独立agent报告不代替指定模型外审。本文件不变更父state或授权范围。

## 8. 可独立继续的只读证据核心：建议，不是实施授权

根可先关闭上述固定内部 C1 收件，随后独立调度“真实持久证据的只读核验核心”；不必因 native/物理 binding 尚未交齐而停下所有内部逻辑。此拆分不改39602B合同§6–7语义：核心只能核数据库内已发生的真实事实及其充分性，不能输出正式 resolved-create/resolved-job 来关闭原意图 unknown，也不能 mint 权限/库绑定/当前scope。后者仍是正式服务的共同前置。

基于实际源码，现有可复用只读切点为：C1 `project_lifecycle.creation_context`、`format3.receipt_for/_history`；Job 的 `_accepted_job` 连同 `get_job`、`blob`、`_job_prepared_plan`/ChangeSet accepted_plan 引用链。`_accepted_job`会核完整 context fingerprint、原 project/capability/input/confirmation/implementation/limits、真实 snapshot/参数/runConfig events/prepared，并回真实严格DTO；它本身不替新核心完成原 dispatch 来源归因、terminal receipt/marker互证或将读全部引用的预算。因此不能只调用它一次、只比DTO/hash或JOIN就声称合同完成。

建议 owner 先提精确两新增产品/测试路径供根冻结：`packages/engine/src/ontolearn_engine/project/operation_evidence.py` 和 `packages/engine/tests/test_project_operation_evidence.py`，另独立过程docs；本建议不在当前授权内创建它们、不转移47项维护权，也不默认允许改任何既有路径。C1五文件及完整基础输入可先只读采用固定423b7e4身份。若确需既有切点调整，应另给根具体路径、原因和最小diff后授权，不以建议自行扩大施工。

内部阶段必须先固定并实证的最小内容：

- 同一全新只读事务，拒绝未知caller活动事务；SQLite authorizer拒全部写/DDL/写PRAGMA仍运行，前后全库dump核同；无create/commit/reconcile_jobs/snapshot/public_project、无路径/worker/迁移/新账本。
- 通过全库唯一operation claim发现真实Job，不限最近16条或有marker者；完整原业务请求、issuedImplementation/issuedLimits与原context逐值核同，已知jobId冲突明确失败。创建按C1完整真实origin/seq1效果/receipt/历史核同；后续历史推进仍能只读恢复原事实。
- 普通旧Job没有原host/session不能补造，保留origin-not-recorded；正式ChangeSet由原immutable prepared envelope+确认原回执交叉核原来源，不从当前Session补。queued/running/cancelling表示已受理、terminal失败/取消可无marker、成功marker/receipt互证，均不自动重派或继续worker。
- 在解析/复制整行和引用正文之前，有限selector先界形状/标量/编码；caller显式maxEvidenceBytes为有限正safe integer且≤67108864，不设无限默认。按唯一实际行先做SQL有界计费，覆盖完整context、DTO、参数/snapshot、prepared/confirmation及必要checkpoint/history链；去重计费但不漏引用，资源不足整体失败不截断。resolution合同的口径是canonical UTF8证据预算，不可未经证明机械复用C1依SQLite数据库编码CAST BLOB的整库计费；具体计价及读取次序须由owner提出并测试。
- 新核心只产生内部证据核验事实/有限失败，有限输出与临时留存均有界；不定义自己的正式resolved或scope/physical factory。正式selector≤min(262144,真实profile frame)、返回≤min(131072,真实page/frame扣实际envelope)的适配须由真实供方提供数值/版本，不能在内部fixture中假装已有host profile。

正式公开 resolution 接线仍待真实接口：I06原dispatch物理库绑定的可重证明能力（复制A→B不能通用）、当前实际库/项目read与创建回执恢复的catalog+creation-receipt-read窄能力、原请求/issued版本/limits/来源的可信持有与当前profile frame/page/envelope预算。缺绑定时仍是physical-binding-unavailable；unknown/null证据绝不变成notAccepted或自动重放，权限不足先于内容返回。内部module/tests的可信Store fixture只证事实核验、预算与零写，不替这些真实供方。根应另行冻结这批内部核心的路径、输入、结果边界和测试授权；本报告建议不是新产品任务或放行。
