from pathlib import Path, PurePosixPath
from hashlib import sha256
import json
import zipfile

root = Path.cwd()
out = root / 'docs/reviews/T01/dispatch-and-permanent-drain-plan'
session_root = Path('/Users/kyle/.codex/sessions/2026/10/21')
finger = lambda b: {'bytes': len(b), 'sha256': sha256(b).hexdigest()}
sources = []
for path in session_root.glob('*.jsonl'):
    with path.open('rb') as stream:
        first = json.loads(stream.readline())
    meta = first.get('payload', {})
    if meta.get('agent_path') in ('/root/dispatch_plan_author', '/root/dispatch_plan_review'):
        sources.append({'path': path, 'label': meta['agent_path'].rsplit('/', 1)[-1],
                        'cutoff': first['timestamp'], 'minimumOrdinal': meta['subagent_history_start_ordinal'], 'selection': 'actual tool calls with ordinal at or above session_meta subagent_history_start_ordinal; inherited fork tools excluded despite rewritten timestamps'})
assert len(sources) == 2
sources.append({'path': session_root/'rollout-2026-10-21T07-51-20-01a15bba-0884-7401-b24f-f50c1fcf60aa.jsonl',
                'label': 'primary-authority-read', 'cutoff': '2026-10-21T11:45:23.781Z',
                'onlyCallId': 'call_e05c969685dc48dba6ede66041ffb932',
                'selection': 'exact primary ea2b08 actual 5480B authorization read call/output only; no parallel C2 product execution selected'})
entries, transcripts = {}, []
for spec in sources:
    path = spec['path']
    cap = path.stat().st_size
    prefix_hash = sha256()
    calls, outputs, standalone = {}, {}, []
    offset = 0
    ignored_tail = 0
    with path.open('rb') as stream:
        line_number = 0
        while offset < cap:
            raw = stream.readline(cap-offset)
            if not raw:
                break
            line_number += 1
            prefix_hash.update(raw)
            if not raw.endswith(b'\n'):
                ignored_tail = len(raw)
                offset += len(raw)
                break
            item = json.loads(raw)
            payload = item.get('payload', {})
            kind = payload.get('type')
            call_id = payload.get('call_id')
            if item.get('type') == 'response_item' and item.get('timestamp', '') >= spec['cutoff'] and item.get('ordinal', -1) >= spec.get('minimumOrdinal', -1):
                record = {'line': line_number, 'offset': offset, **finger(raw),
                          'timestamp': item['timestamp'], 'ordinal': item.get('ordinal'), 'type': kind, 'raw': raw}
                wanted = not spec.get('onlyCallId') or call_id == spec['onlyCallId']
                if kind in ('custom_tool_call', 'function_call') and wanted:
                    calls[call_id] = record
                elif kind in ('custom_tool_call_output', 'function_call_output') and wanted:
                    if call_id:
                        outputs.setdefault(call_id, []).append(record)
                    elif not spec.get('onlyCallId'):
                        standalone.append(record)
            offset += len(raw)
    assert offset == cap
    selected, pairs = list(standalone), []
    for call_id, call in calls.items():
        if not outputs.get(call_id):
            continue
        selected.extend([call, *outputs[call_id]])
        pairs.append({'callId': call_id, 'callLine': call['line'],
                      'outputLines': [r['line'] for r in outputs[call_id]]})
    selected.sort(key=lambda r: r['line'])
    member = 'tool-records/'+spec['label']+'.jsonl'
    entries[member] = b''.join(r['raw'] for r in selected)
    transcripts.append({'source': str(path), 'member': member, 'selection': spec['selection'],
                        'cutoffUtc': spec['cutoff'], 'minimumOrdinal': spec.get('minimumOrdinal'), 'capturedPrefixBytes': cap,
                        'capturedPrefixSHA256': prefix_hash.hexdigest(),
                        'ignoredIncompleteTailBytes': ignored_tail,
                        'pairCount': len(pairs), 'recordCount': len(selected), 'pairs': pairs,
                        'standaloneOutputLines': [r['line'] for r in standalone],
                        'unfinishedCallIdsExcluded': [c for c in calls if c not in outputs],
                        'records': [{k:v for k,v in r.items() if k != 'raw'} for r in selected]})
    if spec.get('onlyCallId'):
        assert len(pairs) == 1 and len(selected) == 2

inputs = json.loads((out/'investigation-inputs.json').read_text())['inputs']
input_sources = []
for position, item in enumerate(inputs, 1):
    path = Path(item['path'])
    current = path.read_bytes()
    data = current[:item['bytes']]
    assert finger(data) == {'bytes': item['bytes'], 'sha256': item['sha256']}
    name = f'inputs/{position:02d}-'+path.name
    entries[name] = data
    input_sources.append({'member': name, 'source': str(path),
                          'selection': 'entire original file' if data == current else 'original fixed prefix with exact recorded bytes/SHA; later append not substituted',
                          **finger(data)})
for name in ['fixed-foundation-inputs.json', 'investigation-inputs.json', 'checks.json',
             'review-input-r1.json', 'plan-r1-before-revision.md', 'independent-review-r1-before-r2.md',
             'disposition-r2.md', 'checks-r2.json', 'review-input-r2.json', 'independent-plan-review.md']:
    entries['phase-originals/'+name] = (out/name).read_bytes()
entries['phase-originals/dispatch-and-permanent-drain-plan.md'] = (root/'docs/iterations/T01/dispatch-and-permanent-drain-plan.md').read_bytes()
entries['tooling/build-original-evidence.py'] = Path(__file__).read_bytes()
archive = out/'original-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, date_time=(2026,10,21,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(entries)
    for name, data in entries.items():
        assert z.read(name) == data
index = {
 'scope': 'Dispatch/permanent-child-drain document preparation and static independent review only. No product/DB/test/new-child/network/model/GUI/native execution proof. Parallel C2 product operations are not selected as dispatch evidence.',
 'selectionBoundary': 'Exact original complete call/output pairs from actual author/reviewer sessions, excluding inherited fork tools; one primary ea2b08 actual authorization-read pair. No reasoning or conversation records. Standalone async outputs separately labeled. Current unfinished archive call excluded; later formatting/static/staging/commit events are outside this captured ZIP and must be cited separately.',
 'firstFailuresRetained': 'Initial combined rule output truncation and subsequent complete common read; atomic apply_patch context rejections; source-read final rg no match exit1; r2 JSON formatting first fail 35404 followed by d6f43c/fbf648 correction. Failures are original tools, not reconstructed output or product test claims.',
 'nonfinalSelectionCorrection': {'reason': 'Fork records have rewritten timestamps; initial timestamp-only selection included inherited tools. Final selection enforces actual session_meta ordinal boundary. Initial nonfinal files preserved outside repository in /tmp, not included as dispatch evidence.', 'initialNonfinalArchiveSHA256': '17507b77ee71532f63c2e86c2a0a8650ca9ac98c4f2948b32368944e4b0af2e1', 'initialNonfinalIndexSHA256': '76c349b8657e3fc6f772c07cbaa06079018ce2ad67f71202f9f97cf7567c1d47'},
 'archive': {'path': archive.name, **finger(archive.read_bytes())},
 'members': [{'path': name, **finger(data)} for name,data in sorted(entries.items())],
 'inputSources': input_sources,
 'transcripts': transcripts,
 'planCandidate': {'path':'docs/iterations/T01/dispatch-and-permanent-drain-plan.md', **finger(entries['phase-originals/dispatch-and-permanent-drain-plan.md'])},
 'independentReview': {'path':'independent-plan-review.md', **finger(entries['phase-originals/independent-plan-review.md']), 'result':'r2 static design passed; does not grant implementation'},
}
p = out/'original-evidence-index.json'
p.write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'archive': index['archive'], 'indexInitial': finger(p.read_bytes()),
                  'members': len(entries), 'sources': [{'member': t['member'], 'pairs':t['pairCount'], 'records':t['recordCount'], 'standalone':len(t['standaloneOutputLines']), 'unfinishedExcluded': t['unfinishedCallIdsExcluded']} for t in transcripts]}, ensure_ascii=False, indent=2))
