from pathlib import Path
import subprocess, tempfile, os, time, json, hashlib
root=Path('/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-dispatch-permanent-drain')
owned=Path(tempfile.mkdtemp(prefix='t01-dispatch-permanent-drain-pid-evidence-',dir='/tmp'))
argv=['/usr/local/bin/node',str(root/'node_modules/vitest/vitest.mjs'),'run','tests/unit/t01-dispatch-permanent-drain.test.ts']
log=Path('/tmp/t01-dispatch-permanent-drain-focused-pids-01.log')
records={};pids={}
def proc(pid):
 r=subprocess.run(['ps','-ww','-p',str(pid),'-o','pid=,ppid=,lstart=,args='],text=True,capture_output=True)
 return {'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
with log.open('wb') as stdout:
 env=dict(os.environ,TMPDIR=str(owned))
 child=subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=subprocess.STDOUT)
 controller={'pid':child.pid,'argv':argv,'process':proc(child.pid)}
 while True:
  for file in owned.glob('t01-dispatch-drain-*/events.jsonl'):
   try:b=file.read_bytes()
   except FileNotFoundError:continue
   b=b[:b.rfind(b'\n')+1]
   if not b:continue
   key=str(file)
   if key not in records or len(b)>len(records[key]):records[key]=b
   try:events=[json.loads(s) for s in b.splitlines()]
   except (json.JSONDecodeError,UnicodeDecodeError):continue
   for event in events:
    pid=event.get('spawn')
    if isinstance(pid,int) and pid not in pids:pids[pid]=proc(pid)
  if child.poll() is not None:break
  time.sleep(.001)
 status=child.wait()
source=[]
for rel in ['apps/desktop/src/main/engine.ts','apps/desktop/src/main/engine-lifecycle.ts','tests/unit/t01-dispatch-permanent-drain.test.ts']:
 b=(root/rel).read_bytes();g=subprocess.check_output(['git','show','04ed06afca87ef8d21a71c68371bc19a849d98f8:'+rel]);assert b==g
 source.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'currentEqualsProduct':True})
result={'product':'04ed06afca87ef8d21a71c68371bc19a849d98f8','cwd':str(root),'ownedTMPDIR':str(owned),'controller':controller,'sourceInputs':source,'exitCode':status,'log':str(log),'actualProcesses':[{'pid':pid,**value} for pid,value in pids.items()],'fixtureMarkers':[{'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'utf8':b.decode()} for path,b in records.items()],'limits':'Read-only capture of own unique TMPDIR while unchanged tests execute. Fake write/close cases remain logic-only. No product mutation, GUI, model, native or database-release claim.'}
out=Path('/tmp/t01-dispatch-permanent-drain-pid-evidence-01.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exitCode':status,'actualProcesses':len(pids),'capturedCompleteLineMarkers':len(records),'evidence':str(out),'log':str(log)},ensure_ascii=False))
raise SystemExit(status)
