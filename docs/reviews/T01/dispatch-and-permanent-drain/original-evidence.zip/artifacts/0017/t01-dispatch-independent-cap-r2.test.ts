import { it, expect } from 'vitest'
import { EngineSupervisor } from '/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-dispatch-permanent-drain/apps/desktop/src/main/engine.ts'
import { DispatchAccounting } from '/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-dispatch-permanent-drain/apps/desktop/src/main/engine-lifecycle.ts'
import { v2Registry } from '@ontolearn/contracts/v2'
import { randomUUID, createHash } from 'node:crypto'
import { readFileSync, mkdtempSync, appendFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const pause=(ms:number)=>new Promise(r=>setTimeout(r,ms))
it('cross-session ping + completion + 128 business + new hello must not exceed 130', async()=>{
 const root='/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-dispatch-permanent-drain', dir=mkdtempSync(join(tmpdir(),'t01-independent-cap-')), marker=join(dir,'wire.jsonl')
 const fixtures=JSON.parse(readFileSync(join(root,'packages/contracts/v2/fixtures.json'),'utf8')).cases
 const request=structuredClone(fixtures.find((x:any)=>x.valid&&x.name==='request job.create').value.params)
 request.operationId=randomUUID()
 const jobTemplate=fixtures.find((x:any)=>x.valid&&x.name==='response job.create').value.result
 const limits={startupMs:1000,handshakeMs:1000,requestMs:1000,totalMs:10000,heartbeatMs:1000,cancelGraceMs:1000,maxFrameBytes:262144,maxQueuedJobs:32,maxConcurrentJobs:2,maxPageItems:100,maxPageBytes:131072,maxWorkerMemoryBytes:536870912}
 const registryPath=join(root,'packages/contracts/v2/registry.json'), hash=createHash('sha256').update(readFileSync(registryPath)).digest('hex')
 const script=String.raw`const fs=require('node:fs'),{randomUUID}=require('node:crypto'),{createInterface}=require('node:readline');const [marker,hash,limits,caps,template]=process.argv.slice(1),session=randomUUID();const seq=fs.existsSync(marker)?fs.readFileSync(marker,'utf8').split('"spawn"').length:1;fs.appendFileSync(marker,JSON.stringify({spawn:process.pid,seq})+'\n');process.on('SIGTERM',()=>{});const reply=(q,result)=>process.stdout.write(JSON.stringify({kind:'response',protocolVersion:q.method==='hello'?2:3,engineSessionId:session,id:q.id,method:q.method,ok:true,result})+'\n');createInterface({input:process.stdin}).on('line',s=>{const q=JSON.parse(s);fs.appendFileSync(marker,JSON.stringify({method:q.method,pid:process.pid})+'\n');if(q.method==='hello'){const run=()=>reply(q,{selectedVersion:3,engineVersion:'0.1.0',engineSessionId:session,capabilities:JSON.parse(caps),limits:JSON.parse(limits),registryHash:hash});if(seq>1)setTimeout(run,400);else run()}else if(q.method==='job.create'){reply(q,{...JSON.parse(template),jobId:randomUUID(),projectId:q.params.projectId,operationId:q.params.operationId,capability:q.params.capability,input:q.params.input,inputSnapshotId:q.params.input.inputSnapshotId,scope:q.params.input.scope,parametersHash:q.params.input.parametersHash,confirmationRef:q.params.confirmationRef})}else if(q.method==='health')reply(q,{status:'ok',engineVersion:'0.1.0'});});`
 const tickets:any[]=[]; const original=DispatchAccounting.prototype.reserve
 DispatchAccounting.prototype.reserve=function(...args:any[]){const t=Reflect.apply(original,this,args);tickets.push(t);return t}
 let reservation:any, callback:any, job:any, session:any
 const terminal=new WeakMap<object,any>()
 const producer={incarnation:{},reserveOperation(f:any){reservation=f;return {}},cancelReservation(){},bindOperation(){return {}},bindAcceptedJob(_o:any,r:any){job=r.result},observe(_o:any,cb:any){callback=cb;return {closeObservation(){return new Promise(()=>{})}}},projectTerminal(i:any){return terminal.get(i)},projectObservationCleanup(){throw Error('unknown')}}
 const source={execution:producer,installInvalidationSink(){},checkBeforeSpawnSync(){},recordValidatedSession(f:any){session=f},checkAndConsumeDispatchSync(){},recordSessionTerminal(){}}
 const engine=new EngineSupervisor({packaged:false,appPath:join(root,'apps/desktop'),resourcesPath:''},{profile:'business3',registryPath,requestMs:25,handshakeMs:1000,startupMs:1500,heartbeatMs:1000,command:{command:process.execPath,args:['-e',script,marker,hash,JSON.stringify(limits),JSON.stringify(v2Registry.foundationProfiles.business3.methods),JSON.stringify(jobTemplate)]}})
 try {
  engine.attachDispatchSource(source)
  const op=engine.requestWithDispatch({},'job.create',request); await op.logicalOutcome
  const completion=reservation.completionPort.request(reservation.privateTicket,'job.get',{projectId:job.projectId,jobId:job.jobId},{})
  void completion.catch(()=>{})
  await pause(40)
  const proof={};terminal.set(proof,{operationId:job.operationId,projectId:job.projectId,jobId:job.jobId,state:'succeeded'});callback(proof);await op.operationExecution
  for(let i=0;i<200&&engine.engineSessionId;i++)await pause(10)
  expect(engine.engineSessionId).toBeUndefined()
  const requests=Array.from({length:128},()=>engine.health()); requests.forEach(p=>void p.catch(()=>{}))
  for(let i=0;i<100&&!tickets.some(t=>t.pool==='hello'&&t.bytes>0);i++)await pause(5)
  await pause(90)
  const active=tickets.filter(t=>t.bytes>0), pools=Object.fromEntries(['business','completion','ping','hello'].map(p=>[p,active.filter(t=>t.pool===p).length]))
  const evidence={pools,total:active.length,pidsAndWire:readFileSync(marker,'utf8'),directory:dir}
  writeFileSync('/tmp/t01-dispatch-independent-cap-r2-evidence.json',JSON.stringify(evidence,null,2)+'\n')
  console.log(JSON.stringify(evidence))
  expect(active.length).toBeLessThanOrEqual(130)
 } finally {await engine.stopAndDrain().transportOwnershipLifetime;DispatchAccounting.prototype.reserve=original}
},7000)
