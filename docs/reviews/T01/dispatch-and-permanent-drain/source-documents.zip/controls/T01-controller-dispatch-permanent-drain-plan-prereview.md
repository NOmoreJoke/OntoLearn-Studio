# T01 dispatch／永久 child 排空 r2：控制侧预审

结论：本次实读的46175B / `fc341d0c24ffb91ac170a0f393616e22551a8e22a53b35ac373346012e97b368` r2方案，暂无新增阻断设计问题，根可依据明确三writer及有限guard作内部机制的精确实施决定。r1的scope-only撤销P2和producer/退避deferred意见已具体处置；128满槽观察通道是有真实供方前提的有限方案，不是已交付生产闭环。本文不授权代码或真实scope/位置/后台producer，也不把文档、mock或静态原件当运行通过。

本预审启动时dispatch全套尚未提交，实际HEAD为0a03539；根随后捕获同稿17docs，本审核同；末次只读看见owner提交506e157，又按根要求补固定Git增量。主稿与本次实际所读输入全程未漂移；这不是把启动时的WIP倒写为已固定Git。末节给出已核父链/17件原字节绑定，仍待根正式收件。

本审唯一写本文件。没有改产品、测试、owner文档、C1/C2或shared state/Goal，没有执行或import产品、SQLite/DB/探针、测试、构建、真实或模拟child实验、native/GUI/Keychain、网络或模型，没有stage/commit/checkout或新建产品树。只进行文件/Git/hash/AST/JSON/ZIP与静态源码审读。ontology供应提案不在本候选，未作为本dispatch已批准依赖。

## 1. 实际输入与预审身份

根准备授权5480B / SHA256 `c74eb72aa29fb6dce5e77cd48c22df69c2845e99b1c9be41074844fb1f016caa`全文实读；AGENTS15852B/78df、common17891B/e437沿此前已读身份并核原件来源。主稿242行全文、独审r1的9173B全文及r2追加后16878B全文、作者处置3716B、r1/r2 checks/inputs、foundation/investigation来源、final检查及manifest均已读/解析。独审首9173B与r1快照逐字前缀一致，没有倒改首审；§5取代开头历史待修状态必须连读。

根只读捕获包为 `T01-dispatch-plan-r2-captured-docs.zip`，582621B / `1629498a9a02055a19072416e226713f3fbf7bfcfd793c9992b06b87f554193b`；捕获清单 `T01-dispatch-plan-r2-captured-docs.json` 为4134B / `9c44134e3041d9a86061f7074a2afa82bb4d97c0c15932c3c8400a831ee3880d`。两者位于本控制目录。17成员set、唯一名、每件bytes/SHA及current逐字核同；主稿及最早14项输入未变，后增加final-static-checks/source-documents/source-manifest是归档增量，不是主设计漂移。

| 本次实际候选文件 | bytes | SHA256 |
| --- | ---: | --- |
| dispatch-and-permanent-drain-plan.md | 46175 | fc341d0c24ffb91ac170a0f393616e22551a8e22a53b35ac373346012e97b368 |
| checks-r2.json | 2675 | 4869cd66ae0f757115131aecb15491d0e2bcfcbd1d4f0f326dda1e480a7d0840 |
| checks.json | 1236 | 224e2f1097346963f3a3212838614a2b8f6082caf01b112eda22a08081b59587 |
| disposition-r2.md | 3716 | 2e6520dbf8ac28eeaa4e71750865f8fce0d84ac9ec68bcae6236d2adfe41c920 |
| final-static-checks.json | 7426 | 98e472424261914226dd3cec3657943c3fa20b602d51b69c5c457fd0def5b7f5 |
| fixed-foundation-inputs.json | 15031 | acd98954a826450dc016169a49508ed6bb1d2b758ba2683b6a5c4ecb1b77e940 |
| independent-plan-review.md | 16878 | a9244b2ef43731448451f58583c4d077f7c4f2afb1129d15e308e473f470fd5e |
| independent-review-r1-before-r2.md | 9173 | a6bce6c54fb66b812b2971a539775de18c216cd72843eebcdfbfe7becec12a26 |
| investigation-inputs.json | 6679 | a30a128fdb04ed8a1f764023aac541a8427e277a8fdd6d5e4b14afc9a265d7d4 |
| original-evidence-index.json | 61926 | 78684fafc0c76da3b3e6ef8092f2ede93b92e66163363d8226cc4f532043ec4e |
| original-evidence.zip | 436890 | b5c02a90eb877fd6f10649cb175a83a169a20b42479cf8a8c2200726e7804970 |
| plan-r1-before-revision.md | 35460 | 7b1fc29a0314787a5c13e14da903b2c2c8f12394a4e88db73f2989cb4b15151c |
| review-input-r1.json | 1371 | 714e7f7178f19fe1d85d90859ac655571075c42e3104387507c8db191925c1a7 |
| review-input-r2.json | 2596 | cd6601717ac4e1863bb953bd3ecd1ba71f41755c4a5ec9aecf5d1555c449afd1 |
| source-documents.zip | 64769 | ef2a2d1316331046d5aba8055a51d945b4be8bbf288fc56314b8bb2711c87307 |
| source-investigation.md | 4864 | e72a66f2bff50c63aa4123b7a64c5a4eca79a1c7961f2638f97c3de5ba4e9e9a |
| source-manifest.json | 4175 | 1461b9ef75b05b286f925edadff40de46adb8169a6c9cc66bf7dcb26c244faa0 |

主稿相对 `docs/iterations/T01/`，其余相对 `docs/reviews/T01/dispatch-and-permanent-drain-plan/`。这17项是实际完整读回集合，manifest的16输入及其self也与根捕获绑定；source-documents.zip的12成员逐同真实源文档，不仅信checks布尔值。

拟foundation15031B/acd989完整52项逐原423b Git=current/bytes/SHA核同，engine为唯一继承未来writer，其余51readonly；Python项只AST parse。末次另核C1原59件current=423b Git=当前Git，C2固定0a03539的9docs current/Git不变。拟dispatch新树不存在，新helper/test未创建。本报告并非C2代码审查或复测。

## 2. 真实切点与可施工性

固定engine.ts26260B / `6d55774068ca27a49958daeea9f4b1fa15614c95563ca28b8a768265ecd4365e`全文实读并核423b Git。另实际读jsonl.ts4924B/8426…全文，main/index6928B/8578…的装配/health/退出/IPC、TaskService35857B/4a14…的真实request/故障投影/订阅切点、Coordinator41168B/6e057…的request/dispatch/tick、stop与serve finally，及原registry方法表。I06固定ffb B方案的§4.1/6/8仅作供方合同，Node官方类型声明只离线读注释，不当实测或额外采用依赖。

真实engine目前#operation先排微任务，request/health内await #ensure，#send才核pending/整帧并stdin.write；#finish先stop parser、reject/清pending、移除当前session，再kill/升级timer，没有永久owned集合。#start退避Promise仅由timer结算，#starting依finally清。现5次/分钟不能限制跨分钟未关闭旧child。故增加transport有限owned账与最后同步写前门有真实切点，不能把旧实现说成已有永久排空。

Coordinator的request是同步dispatch，serve先emit(request(value))后才await tick；普通严格原response能证对应foreground handler已经返回。job.create先持久受理返回queued，后台tasks/worker随后运行；job.cancel回复也不结原Job。Store关闭、worker/task停止、阻塞OS读thread及cleanup_failures均有独立生命期，child/pipe结束不代表全部已释放。真实main before-quit当前仅dispose/stop:void；本三writer不会悄然把它接成生产drain屏障，正式consumer仍后置。

最小申请范围可维持：从5f910b52新树 `.worktrees/T01-dispatch-permanent-drain` / branch `feature/weekly-t01-dispatch-permanent-drain`，逐52项接收423b独立adoption；旧writer仅 `apps/desktop/src/main/engine.ts`，新增 `apps/desktop/src/main/engine-lifecycle.ts` 和 `tests/unit/t01-dispatch-permanent-drain.test.ts`，完整相对base产品/test54项。其余51、旧测试、main/TaskService、Store/worker/canonical/native/build不改。真正发现额外切点先给精确diff申请，不能复制validator或以fixture填producer。

## 3. scope-only同步撤销与真实write临界段

r1 P2-DP-01成立：source在同步核验中外调撤scope，但stopped/current/owned三量不变，单靠“无await”仍可能写帧。r2§5.4/§12.1已给具体否定fence：同actualSource私有单调epoch，真实issuer在所有scope/lease/cohort撤销前同步推进T01失效sink，再改registry、最后才通知/异步；sink不能授scope、caller不能填epoch，耗尽永久封闭。新scope不复活旧epoch单次dispatch。

T01捕获私有E；source最后check/consume/return只碰私有登记和自有不可变事实，不外调、不通知、不运行getter/thenable/Promise/再入；返回后T01直接读本地source附着/epoch=E/未封闭及原stopped/current/child代际，再紧邻真实stdin.write。此间不得再hash/序列化caller对象、诊断或外部listener。原request/encoded帧一次冻结，不能检查A后发送B。先标write-attempted再write；抛错、false、callback失败、超时/断线仍可能已发送，不重写同帧。consume后本地fence拒绝不重用旧permit。

这些设计消除首轮同步再入不可见撤权缺口；真实source全部撤销路径是否正确、最后尾段是否实无外调，仍须独立审查实际issuer及真实write0反例。epoch是本地否定fence，不是scope/OS authority factory；跨进程、文件替换/撤权与首IO仍需native真实机制。business3在hello前已开/迁移Store，guard不能倒授权该首IO；缺I06/native生产候选不得spawn。hello/ping/health各自受原真实profile/frame/期限，只证控制handler，不能夹带业务或库ready授权。

attached Supervisor上的裸request也必须共门、缺originalDispatch即拒。旧内部raw fixture仍能运行不是生产旁路许可；直到main/TaskService/模型真实消费者全封闭前不能发布生产能力。旧FailureOrigin/原Promise品牌与TaskService.projectFailure引用关系应保持，logicalOutcome不能因额外async包装失去原操作投影。

## 4. 永久owned、退避与stdio

cap2是新增工程政策：先占owned reservation再spawn，覆盖reserved/starting/current/retiring/unknown；逻辑session被移除不删entry。所有旧/当前/已进入spawn的child均在同一Supervisor永久持有集合里，旧child不真实close则拒第三个spawn，不能用每分钟速率或遗忘unknown腾槽。

永久stop线性点先stopped/generation失效，再撤所有session派发、取消尚未spawn退避、遍历全部owned请求收尾；late continuation在spawn前重核epoch/预留。r2对delay deferred的处置准确：clear自有timer同时reject自有deferred，让await/finally实际走完，只清本attempt；spawnEntered=false且无child才never-created，已进spawn仍等真实终态。只clear timer、没返回对象或Promise fulfilled不充无资源证明。

每child独立观察spawn/error/exit/close及每条自有stdin/stdout/stderr的真实close/可核closed；end/finish/destroyed不等于close，失败spawn缺stream须与实际null/undefined及close事实核同。不以child close概括全部pipe。reader停止/data listener解绑或惰性丢弃、所有自有startup/heartbeat/kill timer清理也属于结账。只请求本对象持有child，不通用按PID/进程组kill；已exit/close不再kill，升级最多一次，失败保unknown、不定时反复杀。官方本地声明确实说明killed不表示进程终止、PID复用风险和stream.closed语义；它不是本机真实OS事件证据。

stopAndDrain重复返回同一永久操作；观察最多8个、每wait≤60000ms，observer timeout只返回pending/unknown，不结束实际寿命。短session重连不结束Supervisor永久ownership；永久结束仅证其自有child/pipe/计时/预留，不能签Store/worker/VFS/SQLite锁/LocationLease或外部后代全释放。

## 5. completion可用性与有限身份

普通同步严格response释放foreground，迟到response须按同child/session保留的原request精确关联，仅结底层foreground、不重resolve逻辑Promise；未知id/错frame沿原异常政策。job.create queued仅把原ticket从foreground转后台，错误response亦不能未经claim对账就认未受理。相同operation不造第二ticket/Job，no marker不改operation重派。

r2 ExecutionEvidenceProducer的bindOperation/bindAcceptedJob/observe/projectTerminal/closeObservation已给出具体待供签名：真实issuer incarnation、实际Supervisor/child/privateTicket/originalDispatch、原完整request/hash/origin和真正已知implementation/limits、实际claim/context/Job/receipt/round核同；原版本未知不从新Session补。terminal Job事实只结本业务ticket，不结worker、Store或native。任意Promise、布尔或字段相同新DTO不能登记完成。

128业务ticket满时，独立completion lane不再消耗业务ticket池：最多1前台RPC、独立≤262144B帧池及一个scheduler，只允许已注册producer针对现ticket的job.get/subscribe/unsubscribe，仍走实际profile/maxFrame/current scope及相同fence，不借health/ping或renderer优先级。通知预留必须与TaskService共享server真实128订阅，不能假定额外128；无余量可串行job.get。poll timeout保持该实际在途槽unknown、停止新poll，严格迟到response或真实owner终态才结，不能每超时再开并行查询。故在已知Job绑定且真实producer可取完整证据时，新增lane确能解除“业务128满所以连观察都发不出”的结构性自锁，同时没有scope/frame特权旁路。

但lane本身不是完整producer：全部job.create失响应且jobId未知时，job.get不能发现原Job；现operation.get仅返回marker或null，也不能发现queued无marker受理。原operation→唯一claim/jobId的完整发现、原物理dispatch重证明和terminal证明必须由实际Coordinator/Store/C2后续正式供方提供。r2已经保留该未供前提；没有producer/原绑定时生产job派发须unsupported/unknown，不能用通知DTO或C2局部facts签足量完成。三writer内部可验证通道机制及缺供方拒绝，不能把“满槽真实生产闭环”写为已交付。

每ticket一个observation/watch、全局最多128、一个通知分派listener；terminal后清业务frame也不能让未清watch免费。cleanup-unknown继续占观察容量，须与新active watch共计上界；接纳新job前预留producer/watch真实容量，不能先write再发现无观察位。terminal待清identity≤4096B/件、128合≤524288B是实际留存约束，不能只数外壳：producer registry、WeakMap值、listener闭包都不得暗留原完整request；清理失败保必要identity及真实清理来源。T01不能靠删map或close()返回假释放远端订阅。此为实际实现与producer审查的必要条件，未新增通用存储账本或cleanup万能resolver。

## 6. 应明确执行的验收条件与旧测试风险

以下是现既定有限/真实生命周期要求的具体落点，不是新增产品授权或凭未提交状态制造P2：

1. **接纳在异步等待前界定。** 当前#operation先排Promise微任务、request再await #ensure，#send才计数；新受保护入口须在排该微任务/await #ensure之前同步预留数量、原帧留存字节及必要producer/watch容量。否则启动/退避/owned满时，任意多请求可等待同一#starting并闭包持有caller params/dispatch，而#send的128/8MiB还未见到它们。只在#send加guard不够。可在现三writer内按§5“入口先界”/§7“留存前先界”实现；拒绝不得spawn/write/强留超额输入，never-written取消须释放自己的预留。专项应在hello未返回或退避时突发129+请求、含大帧，核等待者也在统一数量/字节界内，stop后这些deferred真正settle。
2. scope-only revoke或核验准备段再入导致准入失效的反例均write0；另核最后consume尾段禁止外调。consume后本地拒绝旧permit不能换帧重发。完整原request/hash、scope/actualchild/会话/代际逐项错配，不靠caller bool。
3. cap2下旧child迟close及三pipe分离、failed spawn/空stream、stop与spawn/晚continuation、退避deferred、观测超时、已timeout但底层仍在，优先真实自有Node child/stdio实证。真实终态listener不能为绿测解绑太早，不能以“没有await者”GC unknown。
4. 满128后台ticket、server订阅已由其他owner占用、completion单通道慢/超时、cleanup-unknown watch槽及原jobId未知分别验；完整producer未到的项目如实待供，不用mock authority/queued回复解业务槽。真实terminal事实不得结worker/Store寿命。
5. 旧fake风险已静态查到：t01-startup-supervisor.test.ts138起有EventEmitter child和三PassThrough，kill只microtask emit child.close，stdout.end并没有close全部pipe。该旧用例只断言startup logicalOutcome/first cause/write0，不断言drain或继续在同Supervisor创建三child；不能据此称“新cap2已导致旧测试失败”。实现须让逻辑失败正常结算而真实drain仍unknown。其余supervisor/connection-state测试相关段多用真实Node child，尚未跑新代码，事件时序兼容性仍是风险。若未来旧mock触发新guard/未close，应先给真实失败与精确申请；当前不授权改旧测试、放松pipe终态或将fake.close当真实OS证据。

原frame8MiB是编码留存界，不等于全部Zod/stringify临时分配、Promise等待队列或RSS已证明有界；测试必须核前述真正入口。原callback/diagnostic在write临界段之外；source通知失败不逆转已固定首因/准入。

## 7. 与C2在同功能内部并行的判断

从实际writer和冻结输入看，可以由原T01同功能内部独立作者在各自5f树并行推进：C2只新Python operation_evidence.py及其test；本线旧engine.ts+新engine-lifecycle.ts及TS test，集合无交集。各自从423b精确52项只读采用；C2不消费未交dispatch helper，dispatch不把未正式接线的C2当生产completion/physical authority，没有当前源码级相互导入或必须等待对方改共享文件的接口依赖。

各自独立venv/node_modules、cache、临时SQLite/Node fixture、日志与专属docs/原件，禁止跨树写对方输入或共改state/旧tests。完整npm check与真实自有child会有并发负载，但只要使用本树环境、唯一临时路径/端点/进程身份且不宽泛kill，没有已识别的共享数据/固定测试进程冲突；不能将负载时长当性能结论。Coordinator/source生产接口后置的共享依赖不是现三writer窗口可以顺手消费或修改的权限。

根此前C2独占窗口是调度约束，本报告不擅改它，也不因该文字就否定同功能分树的独立子任务。根若另冻结并行窗口，可据此分工；最终组合产品/test预计52+4新=56项，须另固定组合Git/bytes/SHA并做对应整合检查、独审/指定同版双审等门，不能拿各自54项Pass代组合56。正文没有授并行代码写权。

## 8. 原始证据与预审后固定Git增量

原件ZIP436890B/b5c02…的30成员及每件bytes/SHA已核；两作者/独审真实session以实际subagent_history_start_ordinal边界排除继承工具，另精确保原主授权read pair。本审逐实际rollout prefix SHA、offset/长度/原行号/ordinal/行SHA、call_id-output配对验证：作者37pair/74records、独审25/50、原主授权1/2，合63pair/126原记录。raw成员恰原字节拼接；不是按fork重写timestamp猜是否独立，也不是63次产品验收。r1/r2格式及JSON初fail/修正、atomic patch拒写和读源rg尾无匹配exit1等在原件时态保留，不冒称产品失败或运行通过。post-capture归档/格式/stage/commit事件不反称已在该ZIP。

本报告启动时为未提交预审，无“缺Git所以P2”的处理。根17docs捕获后，末次实际新见 `506e15744e47fd36f43bdbd645f6e65526cf0bf4`，parent精确 `0a03539a44c43fafb2f890953bbb59a77ea33a05`，delta set精确上述17docs；current=506 Git=root捕获17件逐字节核同。C1原59及C2九docs current/各自固定Git/506 Git均相同，foundation52及AGENTS保护字节无漂移；status仅AGENTS既有dirty及独立ontology未跟踪文件。没有产品、C1、C2变更混入此提交。

因此可把506作为**预审后同稿固定Git绑定增量**供根收件，不重做相同方案全审；它不倒写预审启动已提交，不代根确认owner最终handoff。若后续正式source/ref/manifest/原件仍一致，只需身份/来源或新增过程原件增量校验；若主设计字节改变须另审，不跨版本借本结论。

本轮只认为内部transport机制方案有具体可实施边界，无新增未解决阻断；真正I06/native scope/lease/原物理dispatch、完整Coordinator/Store/worker producer与清理、生产main/TaskService/model全接线、真实首IO、双OS/真人、GLM-5.3最高和M3.1-Flash/xhigh同版新外审、CI/正常develop合并及父57P0/完整Goal均未由本审放行。根可按上述三writer/52采用/51readonly、全部有限policy及具体验收条件作独立决定。
