# T01 dispatch 与永久 child 排空：精确实施窗口

2026-10-21。根已全文读主46175B/SHAfc341d0c24ffb91ac170a0f393616e22551a8e22a53b35ac373346012e97b368、16878B独审全历史/最终r2、3716B处置与checks；控制预审20090B/SHA4f77f1f779f0e71cd66c34a868384f043ce4f04397f27897ced4754a328c2161已全文读回。主稿不漂移，后固定506e15744e47fd36f43bdbd645f6e65526cf0bf4，parent0a03539，17docs逐current/Git/根捕获同字节；C1原59/C2九不变，原30成员63pair126行出处已独立核。方案范围无新增阻断，不是产品/真实scope或后台producer已验收。

本件批准原T01同一功能内部的三writer实现及真实transport机制验证。为减少独立部分空等，明确更新此前C2授权最后一段“产品写窗独占”的调度约束：C2与本线可由同一原T01中的不同作者，在各自独立5f树并行实施。实际writer无交集，不共享环境/cache/temp/fixture进程/日志，不写对方树。不是另建功能聊天或把本工作交根开发；C2原两writer、52只读和全部验收仍完整有效。ontology供应仍仅docs，任何其他共享路径不因此获得并行写权。

## 树、固定采用与唯一writer

从批准5f910b52c69d86a1076b2032e5d3c63e715947f3新建 .worktrees/T01-dispatch-permanent-drain，branch feature/weekly-t01-dispatch-permanent-drain。既有C1/C2/dispatch方案/ontology文档原字节冻结；不切原树分支、不stage AGENTS、common、原64保护文件/原型或来源不明改动。

根已实际逐52原Git/current/bytes/SHA核同。仅按控制同目录 T01-dispatch-permanent-drain-fixed-foundation-inputs.json 原字节15031B/SHAacd98954a826450dc016169a49508ed6bb1d2b758ba2683b6a5c4ecb1b77e940，从423b7e4c799f188cf2ce6e8e7121893ce85624cd逐项精确采用，单独adoption提交及回执；不whole-commit、不复制旧docs或他树venv/node_modules。52中engine之外51项继续只读，所有维护权不转移。

只准三产品/test writer：

- apps/desktop/src/main/engine.ts（唯一继承writer，起点26260B/6d55774068ca27a49958daeea9f4b1fa15614c95563ca28b8a768265ecd4365e）
- apps/desktop/src/main/engine-lifecycle.ts（新增）
- tests/unit/t01-dispatch-permanent-drain.test.ts（新增）

专属新过程仅 docs/iterations/T01/dispatch-and-permanent-drain.md 与 docs/reviews/T01/dispatch-and-permanent-drain/。完整相对5f为54产品/test+全部新docs，不仅三writer。旧tests、main/index、task-service、jsonl、canonical/registry、Coordinator/Store/worker、I05 runtime、I06/native、依赖/锁/build/CI只读。真闭包不足或旧测试确需适配时，先给实际失败/源码切点/最小diff另申，不能擅改旧测试、复制validator、加helper路径或放松真实终态求绿。

## 私有合同与同步写前门

按固定主稿§3–5/12实现attachDispatchSource、requestWithDispatch的logicalOutcome/dispatchObservation/operationExecution、stopAndDrain同一永久操作及有限observe。保持原FailureOrigin/原Promise来源投影和stop():void请求停止兼容，不以多层async包装断原TaskService故障来源。原同步response只证其foreground handler返回；queued与取消回复不结派生后台Job。

source只能可信装配附着一次，真实issuer持有原request/operation、实际Supervisor/child/host/session/generation/cohort/current scope/lease/物理来源。T01本地epoch/sink只有否定失效能力，不mint scope/permit，不从UUID/hash/DTO字段或caller布尔造权限。真实source/issuer尚未交付，生产入口缺供方须write0/unsupported；fixture只证机制，不把品牌/无条件callback当正式来源。attached对象全部业务路径包括裸request共门，裸调用缺原dispatch即拒，最终生产旁路封闭需所有真实消费者另行接线。

严格原完整输入/编码帧/原request同一份冻结，按schema、标量/深度/节点和wire界在复制/编码前有限检查。最后check/consume到return只触供方自有不可变事实/私有登记，无外调/getter/thenable/Promise/再入；issuer所有scope/lease/cohort撤销先同步推进本T01 fence，再改registry，最后才通知。T01返回后直接核私有source同一附着/epoch=捕获E/未封闭、stopped/current/owned/session/代际，紧邻真实stdin.write，无额外hash/编码/diagnostic外调。write前标attempted；抛错/false/callback失败/超时不断言未发送，不重复同frame；consume后本地拒绝不补permit或换帧重发。控制hello/health/ping不夹业务权限。

额外明确既定“留存前先界”的入口位置：在#operation排Promise微任务、await #ensure/握手/退避之前，同步预留数量、原帧留存bytes与必需producer/watch容量。不能只在#send检查128/8MiB，使等待同一starting的闭包无限持有params/dispatch。拒绝不spawn/write/强留超额输入；never-written取消只退自己的预留，实际已发送不清底层事实。对旧caller序列化/registry先read后界的既有风险准确列出，不假称所有旧内存分配已解决。

## 永久所有权、真实清理与有限政策

批准固定主稿§7明确内部工程guard：owned child加spawn reservation最多2（当前/starting一+退役一），先占后spawn；starting最多1；跨所有session未结业务≤实际maxPending且≤128；原encoded frame累计≤8388608B、单帧≤真实maxFrameBytes且≤262144；logical普通≤128、heartbeat≤1、completion≤1，总≤130。两listener集合各≤64；drain observer最多8，wait正safe integer≤60000；permanent drain操作唯一；现5starts/60000ms、退避100..2000ms、原可信各期限保持。它们是拒绝政策，不是Q5用户容量或CPU/RSS/性能保证。

全owned集合覆盖reserved/starting/current/retiring/unknown；#finish逻辑terminal/移除session不删真实entry。child close与各实际存在三pipe close/可核closed分别记录；end/finish/destroyed、kill返回、exitCode、超时、Promise fulfilled、pending0都不足。失败spawn缺stream按真实null/失败/close核同；不能证明未创建资源就unknown。只收尾本对象自有child引用，不通用PID/进程组kill；退出后不再kill，原1000ms升级最多一次，失败不周期重杀或TTL清槽。

永久stop先同步撤新接纳/推进generation，取消未spawn退避并clear timer+同步reject自有deferred，使await/finally实际settle；spawnEntered=false且无child才never-created，已进spawn继续真实owned排空，late continuation再核本attempt/epoch。reader/listener/timer/starting reservation一并真实结束才结transport寿命。repeat stopAndDrain同一操作、observer timeout仅pending/unknown；短重连不结永久寿命，新Supervisor同UUID不复用旧来源。

该寿命只证本Supervisor自有child/pipe/计时/预留，不签Store连接/事务/worker/后代/VFS/SQLite锁/LocationLease或整个cohort释放。hello之前已有生产位置首IO，写前门不倒授权；没有真实I06/native准入不启动生产候选，内部自有临时fixture单独准确标明。

## completion有限通道与未交真实供方

按§12.2/12.3实现私有producer binding/observation/terminal投影接口的有限消费机制，所有绑定核实际issuer incarnation、原ticket/dispatch/request/Job/已知版本/limits/origin，未知原implementation不能拿新Session补。普通严格匹配response释放foreground，迟到response按原child/session/帧关联只结底层、不重新resolve已结逻辑Promise；job.create queued只转后台ticket。相同原operation不造第二ticket/Job；缺marker/null不等于未受理，不自动改operation重派。

每ticket observation/watch最多1、全Supervisor128、通知仅一个有限分派listener；接纳前预留真实producer/watch容量，active与terminal-cleanup-unknown共计。已terminal可结业务ticket，但原观察只有真实注销成功或对应notification owner真实终态后才回收。terminal待清identity≤4096B/件、总≤524288B，不能通过WeakMap值/监听闭包暗留整原frame。各owner实际留存计账，删map/close返回不是释放证据。

批准独立completion foreground最多1、独立帧池≤262144B、scheduler timer最多1，只供真实注册producer为现ticket发job.get/subscribe/unsubscribe，仍守原profile/schema/frame/current scope/同步fence。不接renderer优先级、任意method/job.create/cancel或假health；server128订阅需与真实TaskService共享，不假定新增128，没余量可串行get。poll超时保实际inflight unknown并暂停新poll，不每轮重开并行查询。

满业务128的已知Job观察机制必须可取得真实对应terminal而只解对应ticket。jobId未知的queued失响应当前operation.get只marker/null，完整唯一claim发现/原物理重证明/真实terminal producer仍后置，不能用C2局部facts、同形通知或fixture签生产闭环。本三writer不改Coordinator/协议/TaskService，也不把最终生产目标改为永久unknown；需要的准确producer另由唯一owner提出并完成真实接线。

## 实际验证、审查与交付

在本新树独立环境/cache中，允许本专项与相关supervisor/startup/connection/task-service回归、真实自有Node child/三stdio/受控临时文件fixture、必要本树原Python临时Coordinator机制验证，以及正常npm run check和独立npm run verify:sources。依赖沿既有锁，不升级/改锁/借他树环境。用本树唯一临时路径/endpoint/进程身份，所有收尾只针对本测试实际所有者；不GUI/Electron/e2e/native/Keychain/用户目录/网络业务/模型/付费/打包。与C2并行测试不得共用临时DB/脚本/日志或宽泛kill。

完整执行固定§10及控制预审§6：scope-only/同步再入write0、完整字段错配、write抛错/false/late响应、真实child延迟close/后代延持stdio、exit与pipe分离、cap2第三spawn0、退避stop使deferred/finally实际settle、空stream/failed spawn、同operation去重、unknown不清槽；hello未返回/退避时突发129+请求和大帧，等待者也在统一数量/bytes界且stop后真实settle；各工程界±1。满128/订阅被其他owner占用/单completion慢与超时/cleanup-unknown watch容量、未知JobId分开核。真producer未到项目明确待供，不把mock authority或queued回复当通过，terminal Job不结Store/worker寿命。

旧PassThrough fake只emit child.close未close三pipe的测试仅断言logical/first cause，须保持逻辑可结而drain仍unknown；不擅改它、不虚认fake证明OS close，不预称已有测试失败。任何真实回归失败保完整首fail/源码/候选再申请必要最小变更。

原命令每次独立终态exit/timeout、完整stdout/stderr/argv、真实进程与source指纹保全；不借后续shell成功覆盖失败。固定54完整候选/全部过程docs，独立agent审实际源码/预算/生命周期并按真实反例修复复审，受审实现冻结；交base/adoption/product/process ref、逐current/Git/hash的全差异manifest、原件来源索引/完整正常check/source终态及未验边界，不无变化重测旧C1/C2。

后续若组合C2与本线，预计52基础+4新增=56产品/test，需另精确冻结组合SHA/闭包、完整对应检查/审查；各自54通过不能代组合56。T01真实scope/原dispatch/native首IO、Store/worker/完整producer、全main/TaskService/model装配、双目标OS/真人、指定GLM-5.3最高与M3.1-Flash xhigh同版独审、CI、push/PR/正常develop合并及父57P0/C–G/PRD10–12仍未关闭。不重建Goal，不授推送/合并，不以内部技术阶段代完整功能。
