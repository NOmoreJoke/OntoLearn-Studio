# T01 dispatch／永久排空：固定源码独立预审

2026-10-22。结论：**原固定产品04ed06a仍有一项需要关闭的未发送producer reservation清理缺口，不能出具最终Pass。**本审从实际源码给出同步再入反例，根已实际复核并授权原作者在原三writer修复、专项验证、新固定候选及独立复审；当前WIP正属该授权，不是未知夹带。第二项仅为运行证据措辞：29次ps成功中只有28份完整argv。完整原tool call/result/cwd/真实exit归档和修复候选/最终独审尚待收件。本报告固定审04ed产品与4f270f过程，绝不把正修改的current字节或旧check当新版通过。

已全文读engine.ts1267行、engine-lifecycle.ts522行、新专项1029行、实现主说明14728B，以及授权和固定506方案必要规范；只文件/Git/JSON/hash/静态源审，不运行产品、Node、测试、child、DB/探针、build、GUI/native或网络。本审唯一写本报告，不改产品、owner原件、旧控制报告、共享state或Goal，不替指定双模型、父验收或发布。

## 固定身份与允许范围

树 `/Users/kyle/Documents/工作/知爻/本体/.worktrees/T01-dispatch-permanent-drain`，branch `feature/weekly-t01-dispatch-permanent-drain`。真实Git链为：

- base `5f910b52c69d86a1076b2032e5d3c63e715947f3`。
- adoption `e79d9d4f2e2fbdfe29217be5e4cc03f8bcce82e1`，从423b逐52原件采用。
- product `04ed06afca87ef8d21a71c68371bc19a849d98f8`，parent正是上述adoption；该提交恰三writer。
- process `5aa8e9e984e2325b8ea6a381b3d0845fb7ab5893` parent04ed，再 `4f270f0f5c648b730d4bdf13009f26da72909080` parent5aa8；product→4f恰8件专属docs，没有产品变更。

实施授权11686B/SHA256 `4ea8dede0ad911a0715f907ce8216364847f9f18324c9309b88d3542b0c93a2e`全文读；固定506主46175B/`fc341d0c24ffb91ac170a0f393616e22551a8e22a53b35ac373346012e97b368`从Git实核，并补读§12，不重做整方案审查。52输入清单15031B/acd98954…、AGENTS15852B/78df2825…及common17891B/e437121a…是固定适用原件。唯一产品writer为原engine.ts、新engine-lifecycle.ts、新tests/unit/t01-dispatch-permanent-drain.test.ts；原51项及旧测试、TaskService/main/index、canonical/registry、Store/Coordinator/worker、锁/配置/build/CI全部readonly。

| 固定产品文件 | bytes / SHA256 |
| --- | --- |
| apps/desktop/src/main/engine.ts | 45410 / 1a0613bab6c88ccc194d01e58cba651f04757962115fafaa9e30e919d7b63946 |
| apps/desktop/src/main/engine-lifecycle.ts | 18536 / e3f33a55938c89c344c203253522140326052e6cdddedbad7ca0dcd1fe12f31b |
| tests/unit/t01-dispatch-permanent-drain.test.ts | 43765 / 66be70925677ab34e4d6aac82edc49ee34c878f067c226aa0e4cadf025f9692a |

实际candidate-manifest26507B/12b16217…的54项全部逐04ed Git bytes/SHA核同，集合恰base→product完整54产品/test；其中51项也逐current/adoption/423b Git核同，adoption52全部逐来源Git核同。两新文件在adoption不属于原52。不能只报三writer当完整候选，也不whole-commit采用423b。

本审开始全文读时三个current writer与上述固定hash相同。后续逐件核验捕获真实WIP漂移，首见engine45807B/a47b18a4…、lifecycle18632B/b5bfe47e…；根明确这是收到本反例后发出的原窗口修复。再捕获current engine46221B/8948ef7f9b2a581e712da259e7ad6d9188840c1e71d01c67dcfa6896ed15d900、lifecycle18826B/35665d40f436032cf4b68a54061ccb65508a1d8b54430d810837013d05b8ebe4、test54958B/452ea8b8e2d751536ac89925569184c6b479db760b9591a7a7a473a69cb77d89。它们只是当时快照，仍可能变化，未当本报告受审候选或复审通过。

此时HEAD仍4f270f，status为受保护AGENTS、三writer修改及未跟踪独审文件。独审文件实际14062B/eec339c0…存在不等于其固定/任务完成/当前修复已通过，本审未据该WIP文件替原独审者判结论。逐current==旧manifest断言曾因这些真实漂移失败，随后明确改用04ed Git绑定并把51readonly另核；这是本审静态身份检查失败，不是产品运行失败或隐藏成全current相同。

## P2-T01-DSP-C01：同步stop发生在producer预留返回前，已知reservation永不取消

位置为固定engine.ts:382–406与engine-lifecycle.ts:464–475，前者在 `ticket.producerReserveEntered=true` 后外调 `producer.reserveOperation(...)`，返回值才赋给ticket.producerReservation；后者先把cancelAttempted设true并release业务票，只有此刻已有reservation才实际调用cancelReservation。

具体无异步间隙反例：

1. requestWithDispatch为合法job.create同步取得业务/bytes/watch票，进入真实producer.reserveOperation。
2. 该预留回调在返回前触发owner决定永久停止，并同步engine.stop()。stopUnwritten→cancelUnwritten看到attempted=false、reservation尚未赋值，设置cancelAttempted=true、清业务留存；因producerReserveEntered=true，保watch未知。没有实际cancelReservation调用。
3. 同一个reserveOperation正常返回它实际新预留的reservation。engine把它赋到已取消的ticket，未复核停止/已取消状态，返回ticket。
4. #request微任务在#ensure看到stopped后拒绝，再调cancelUnwritten因cancelAttempted=true立即return。之后没有任何路径尝试取消现已知的真实reservation；该ticket没有child owner，故ownerEnded也无法清它。

影响是never-written本地票已归还，但已知producer预留与watch只能永久遗留，未兑现真实取消/清理。没有write或child，因此这不是重复发送/越权字节反例，也不能拿transport-ended当该producer容量已取消。reserve回调不处于最终checkAndConsume的禁止再入段，当前私有接口并未给它同等不可再入前提；不能把此输入归为不合法issuer来绕过消费者清理。

最小修复应区分“已请求取消”与“对已知reservation已尝试一次取消”。reserveOperation正常返回后必须复核stop/票仍有效，若期间已取消，针对该同一返回reservation进行一次真实取消；失败/抛错仍保cleanup-unknown，不无限重试或假释放。也应覆盖预留过程抛错/只部分创建、重复stop、真实取消回调同步再入等相邻边界，防把状态分离改成重复cancel或留无限对象。现原42专项没有这条“reserve内stop再正常返回”的反例。

根已实际读两个函数确认并于00:51前明确授原作者原三writer修复、专项、新固定candidate/独立复审；因此本项**已采纳、修复中，未关闭**。本审未执行复现，不以静态改稿/旧1167测试结果作修复验证。新固定ref到后定点核该delta及必要新check/source/独审/原件，不重跑或重做无变化全方案。

## 同步准入、撤权及原始错误来源

固定#prepare确在#operation Promise微任务与await #ensure之前执行。它先ownJson拥有冻结{method,params}，严格同版schema核验，预留真实frame编码长度+192的保守envelope额度、业务数量及job.create watch/producer容量。等待hello/退避者也已计数；129或8MiB越界不会先spawn/强留超额输入。stop取消尚未attempted的本地票，已write-attempted不退回成not-written。上述P2说明预留的同步外调边界仍须补清理，不能据一般顺序正确推定全部异常原子。

ownJson拒getter、循环、非JSON/非法surrogate、非有限或超safe范围数字，界深度32/节点262144/UTF8转义字节262144。它会先建立own-property names列表，registry也仍先read后界；主说明诚实承认没有证明所有临时分配/RSS已界住。这里只证新增留存池/单请求工程拒绝政策，不声称任意巨大caller对象的全进程内存预界或性能提升。

实际完整request在hello后以同一owned params构造、严格schema、编码LF/hash一次，核实际encoded≤原预留及协商maxFrameBytes。source facts绑定实际Supervisor/child owner、generation、host/session、profile/registry/engineVersion/limits、privateTicket与两阶段原request/hash/frame bytes。producer绑定与observer注册、write方法读取/bind、所有编码/hash/pending/timer在最终consume之前完成。

source的scope/lease/cohort撤销须先同步sink推进本地epoch，再改私有登记再通知；sink只否定、溢出封闭，不mint权限。最终check捕获实际source epoch，供方正常返回必须undefined；其最后check→consume→return不得外调/getter/thenable/Promise或再入。返回后只读T01私有current/stopped/source同附着/epoch未变/未封闭，标attempted紧邻预绑定write；source-only revoke、同步stop或再入普通入口不能越过该fence。供方真实撤权路径尚不存在，fixture WeakMap不能证明生产兑现。

write返回false只是背压，throw/callback error/timeout都保attempted，不replay同frame或新operation。逻辑超时保原frame/session/child绑定，严格原迟到回包可结对应foreground，但不再次resolve旧logicalOutcome；未知strict3回包仍终止。原FailureOrigin和#operation Promise身份保留，TaskService.call实际把原engine.request返回Promise交projectFailure；没有另包Promise冒充原来源。旧内部无source的已知同完整params重复job.create改只读job.get，不再造第二create；附着source的重复未结operation则拒绝。

本机制不能授真实首IO：attach前启动/generation或业务接纳均拒事后附着；失败附着封闭不回落裸业务。attached业务缺原dispatch拒绝，attached job.create缺真实producer在spawn前拒绝。裸旧内部回归仍可工作不等于正式production入口已封闭；真实main/TaskService仍未改接线。checkBeforeSpawnSync的实际位置/lease能力必须真实owner交付，hello以后写前门不倒授权已发生的生产首IO。

## 三种寿命、owned集合及永久排空

logicalOutcome仅原API Promise；普通严格response仅签foreground-returned。job.create queued/running/cancelling及cancel handler回复不能签后台terminal。producer.projectTerminal须原incarnation/observation/privateTicket验证，T01再将四项有限fact界4096B并核原project/operation/已知jobId/state；字段同形伪对象或错Job不结票。

ChildOwnership在spawn前reserve，current/starting/retired/unknown共2；已进入spawn但抛错无handle仍unknown，只有spawnEntered=false且无child可never-created。#finish停止reader、reject原pending、clear startup/heartbeat并退役owner，不删除真实child entry。OwnedChild等待starting finally、kill timer真实结束、child.close及全部实际存在三pipe.closed，再移除terminal listeners/release；exit/end/destroyed/kill返回或超时都不够。null-stream仍需实际child close，failed OS spawn也沿真实error/close。只对自有ChildProcess引用TERM一次、1000ms后最多KILL一次，已exit/close不继续kill，不泛PID/进程组杀。

stop同步stopped/generation/source封闭，clear退避timer并reject自有delay deferred，await/finally才真实settle；晚continuation再核stopped。stopAndDrain重复同一永久操作，observe最多8/正safe wait≤60000，超时只pending不取消资源收口。正常2旧/当前child与继承pipe延迟均有限留存，不TTL清槽。旧只emit child.close而未关三PassThrough的测试仅证logical/first cause，本候选新增逻辑测试明确drain仍pending，不能称其已证明OS close或擅改旧测试求绿。

transport-ended只证本Supervisor的自有child/pipe/listener/timer/starting，不能签Store连接/事务、worker、后代、SQLite锁/SHM、VFS/LocationLease或全cohort。即使原child三pipe已关，后台Job仍unknown；供方后来出具真实原terminal可以独立结业务，不能倒推其它owner寿命。

## producer/watch、满额completion与未交供方

同步先占watch128与真实producer reservation，绑定同一originalRequest/privateTicket/dispatch，hello后同reservation绑定Session，再至多一个观察。terminal释放业务/frame后，closeObservation只是请求；必须原producer认证真实注销来源才解watch，未验证返回/Promise fulfilled/抛错保terminal-cleanup-unknown。对应实际notification owner的child+pipe终态能结该连接watch，但不结后台业务。消费者清掉自己的request/frame；真实producer WeakMap/闭包也必须实际保有限身份，不可暗留完整frame。真实producer尚未交付，这部分跨owner留存/dispatcher只有合同，无生产容量证明。

CompletionPort仅已登记producer的原ticket/已知project/job发get/subscribe/unsubscribe，仍同schema/frame/current scope/最终fence。独立foreground1/262144B不受普通业务满128阻塞，超时保真实inflight不再开第二poll；同ticket订阅最多1，unsubscribe核原subscriptionId。实际server订阅与TaskService共享，QUEUE_FULL后可串行get，不假设另加128。消费端无poll timer（0≤1），未来真实producer调度仍须有限。两public listener集合各64，producer生产分派必须共用一个listener，不能每Job另占公共listener。

满128专项的真实Node child确实接收独立job.get并返回queued，随后由fixture producer发terminal模拟释放一个ticket再接纳第129；**它证明通道机制可用，不证明真实Coordinator terminal闭环已交。**没有真实producer不得因queued、marker/null或同形通知释放后台票。固定JobStore.operation_get:1210确只返回marker/null，无法发现queued失响应的未知jobId；C2局部facts也不补原claim发现/物理重证明。完整producer、unknown JobId发现、原known implementation/limits/origin/receipt/round及跨Session绑定需真实owner另供，不把新Session当前值补成原事实。

总体资源政策业务≤maxPending≤128、普通frame池8MiB、heartbeat1、completion1、两listener集合64、owned2、starts5/60s、退避100–2000ms、期限≤60s。terminal-cleanup watch≤128与每项4096B/总524288B的承诺，还需要真实producer自己的闭包/identity留存证据；本三writer不能凭外部opaque引用保证供方实际内存。本报告既不误判所有opaque source天然不安全，也不把接口存在当该跨owner预算已验。

## 原验证日志与真实PID证据

4f过程8件current文档与其固定Git原件相同；其review-input列出的原三产品以04ed Git核同，当前因获批修复不同。log-index的29份完整combined stdout/stderr与2个runtime artifact全部逐实际/tmp文件length/SHA核同，首失败没有被后shell成功覆盖。主说明14728B/67f7afc5…、candidate-manifest26507B/12b16217…、checks6512B/a5348e4d…、runtime-process1698B/d42f6b52…、source-index2818B/7135057e…、log-index5957B/56461d6b…、review-input3153B/ea2c3e26…，均是原过程身份，不包括新修复/新独审。

已完整读最终check06、source02、focused-pids01及观察器源码，并读首lint/type/旧late诊断/新unsubscribe参数失败。最终check06日志8676B/SHA `5d986475201092184d4b7f9c3db64d5899f223e2a3d4b3f64a05720c046ab59b`确记录23文件/1167TS、真实构建/ruff/type以及2969Py/44skip；source02记录12归档源；原42专项运行日志218B/`ac01ddb5783d680ed4f3899beed32c40558dcc9423bcc9068440932ad64b0a29`记录42通过。这些是04ed旧候选结果，不能沿用给当前三writer修复版。

独立运行观察器2772B/`799b961f0a83628d7b22c7f6ca8ce89fbac333afb2bec9aa4037efd4f3e18758`静态读回；其只扫描本次独立TMPDIR，定向ps本测试marker所报PID，未泛扫/kill进程。原PID JSON395861B/`ebc0babee9c447d709eb8ce9ee09413804e7babfa1a39d070ec1c6a3ff6cbc7a`绑定04ed源码指纹、实际cwd、controller原argv/exitCode0和28个marker完整行前缀；29个spawn PID与29个ps记录集合精确相同，所有marker原prefix bytes/SHA核同。不是所有测试最后marker写入的完整归档，也没有每个child最终OS退出码或三pipe事件全trace。

**P3-T01-DSP-E01：完整argv数量过报。**该原JSON29次ps均exit0，但PID37879输出仅 `37879 37862 Thu Oct 22 00:25:50 2026     (node)`，缺execPath/-e/script/独立marker路径；另28项有完整fixture argv和本次TMPDIR。ps exit0是采集命令成功，不是child运行exit0。准确陈述应为“29个真实marker PID、29次成功定向ps、28份完整argv加1份仅进程名、28个marker文件前缀”。runtime-process/main当前称29完整argv过强，根已收到需保原件并澄清；此为过程措辞，不是新产品失败或要求无变化重跑42测试。

尚未收到完整原ee810f→c60b32 check、0eddb7 source、8c7cef PID观察的tool call/output及source rollout位置/byte-offset/真实cwd/exit来源归档。checks里的tool/session/exit数字是过程转述，日志本身也不含外层进程exit；PID JSON给了controller wait结果但仍不能代全部工具原记录。应在最终交付绑定真实call/result/终态、命令argv、源码固定时点及首fail原件，不能仅据文件存在判全流程闭包。因受托只读，本审不重跑补证，不扫描其它会话冒充来源。

## 收件状态及下一步

原04ed源码和4f文档可审，但P2-T01-DSP-C01修复/专项/新固定ref/原独审复核尚未完成，本审结论保持“预审发现需关闭点，最终收件pending”。WIP独审存在不等同新版Pass。新交付至少补：精确base/adoption/product/process、54累计diff及新三writer/current/Git清单、原反例修前证据或准确静态推导、新专项与必要check/source原终态、独审同候选结论、29/28argv澄清和完整原工具出处。届时只做新delta与身份/raw增量绑定，不重复已关闭整方案或无变化C1/C2。

此前ontology控制报告24648B/SHA `81f642b4da802844b9ca8310bbe0f2da84aed66ac7918f54160663de7a85215a`和dispatch方案预审20090B/`4f77f1f779f0e71cd66c34a868384f043ce4f04397f27897ced4754a328c2161`已重新逐hash核同，未改动。C2仍独立两writer；未来组合52+4新=56须新候选/验证/审查，两个54通过不代组合。所有真实issuer/native首IO/Store-worker/完整producer、正式main/model接线、目标OS真人、指定双模型、CI与push/PR/正常develop/远端仍未由本预审关闭。


---

# 续审追加：7dfa9c8固定修复／009e947过程

2026-10-22。本节只追加，不改上面18251B/930091392ac39857546d9e91856e4328cbace7942d802a847ac7dab6e107137f原前缀。旧04ed的发现、当时WIP和pending均作为历史保留。**新固定三writer定点源码未见新增未解阻断；C01与DI-01修复方向及当前独审实件已核。最终过程收件仍pending，尚缺完整新版原工具call/result与最终Git/归档绑定，不能据作者摘要或本段提前宣告最终Pass。**本次没有运行产品/Node/tests/probe/DB/child/build/网络，只Git/文件/JSON/hash；未重审整方案或改原52/51只读输入，也不改C2/ontology控制报告。

## A. 新固定身份及本次实际差异

实际新链为原4f270f → 修复 `cd506d5bd978a5b0c7e4faaf0e509ee2a48a8ba2` → 新产品 `7dfa9c8008727d469935181fc20beebb5ba4419a` → 过程 `009e947bfb8a769b18defc299fe6018281be483c`，三parent均由实际Git核同。7dfa相对cd506只修新增测试的128帧批量延迟假设，产品代码两件相同。由于修复提交继承4f过程，不能把新product称“parent仍adoption”或省掉继承历史docs。

| 新固定writer | bytes / SHA256 |
| --- | --- |
| apps/desktop/src/main/engine.ts | 46221 / 8948ef7f9b2a581e712da259e7ad6d9188840c1e71d01c67dcfa6896ed15d900 |
| apps/desktop/src/main/engine-lifecycle.ts | 18826 / 35665d40f436032cf4b68a54061ccb65508a1d8b54430d810837013d05b8ebe4 |
| tests/unit/t01-dispatch-permanent-drain.test.ts | 56494 / bb4c23c51cc63383f62263d0617555fba613141928c4f04808065aa4973fecc6 |

04ed→7dfa非docs差异精确这三项，实际全部product diff与新增8case/测试记录器全文读取，旧42case未删除。candidate-manifest-r2 27389B/00eb2598…的54行逐current/newGit/bytes/SHA核同；51readonly再次仅做身份核对，全部等423b，没有重复整源语义审查或产品执行。current三writer均同新fixed，不拿旧04ed或中间WIP指纹充本候选。

过程12个新输入逐current/009e Git核同，review-input-r2 4060B/9e1e4ddb…中第13项是原14062B独审历史前缀：当前完整文件已追加为25535B/SHA `8614f0d463d2fd089ff993250605547881612706a67b0ed30bcdabb969306b5e`，前14062B仍exact eec339c0…。应分别绑定原前缀和新完整报告，不能以其当前长度不同误判改写历史，也不能把untracked新报告说成009e已含。

本审实际全文读原14062B及本次R2追加。新独审末节明确对7dfa定点通过，独立复跑原131反例及另4项边界，非最初“仍进行中”的摘要状态。但末次Git仍009e，完整独审文件尚未跟踪，正式过程/source/raw收口未交；本段只记录实际成稿与指纹，不替其后最终Git收件。

## B. C01：真实reservation返回后的至多一次取消

新实现把cancelRequested与attemptedCancellation原对象身份分开。stopUnwritten在token尚未返回时只记录取消请求、撤业务票，保unknown watch；reserveOperation正常返回真实token后，#prepare再核stopped/cancelRequested/ticket.request，已取消就在进入ensure之前针对该同一token调用cancelUnwritten并拒ENGINE_EXITED。它不再因一个旧布尔把真正取消永久跳过。

cancelUnwritten对已attempted帧仍拒退额；对未发送票可重复表达cancelRequested，但对同一producerReservation在外调之前先记attemptedCancellation。于是cancel回调本身再入stop/原cancelUnwritten时不产生第二次真cancel。成功同步undefined且无已绑定observation才回收该watch、清身份；throw或Promise/thenable样非undefined返回不冒充清理，保相同真实token/attemptedCancellation和watch1，不无限重试。payload已退与producer清理未证是不同事实，transport无child结束不代证后者。

作者三新case覆盖success/throw/async-looking的reserve→同步stop→返回实际fixture token；独审另9437B/c5f4675b…脚本的三个独立case还在cancel内部再stop，并直接重复原账cancelUnwritten，未借作者测试来替这些断言。已全文读实际脚本、230B/cfac79fa…日志4pass和485B/1798ea1e…逐行结果：三类均cancelCalls=1、spawnChecks=0、attempted=false、业务/frame0；success watch0，throw与async-looking watch1且knownIdentity=true。request/reservedRequest/frame清除；bind/observe/validated session/consume都被设为不应到达。只能称消费机制反例闭环，不是实际生产issuer或其内部内存已证。

因此本审原P2-T01-DSP-C01的代码遗漏已具体修正，当前独审亦明确关闭；最终验证收件待下文原工具出处增量绑定。保留原静态修前反例，不捏造一份当时未运行的修前实测。

## C. DI-01：hello/ping同一个control槽，spawn前真实占额

原独审P2-DI-01另有真实131反例：旧ping1与旧completion1仍unknown时，128业务入口和新hello1达到131；旧owner仍存在，不能以逻辑断开清它。原419B/a106b2cd…与486B/3215d204…JSON实际total131，第二份有旧44234/new44258两个真实PID；首fail日志保留，不把旧全仓绿改称原独审通过。

新DispatchAccounting.reserve直接令hello+ping合计≤1，业务≤128/completion≤1，故这三个池组合≤130；并未改批准上限或提前释放旧unknown。#start在退避后、实际spawn前取得同一helloTicket与hostClientId，spawn事件发送原reservedHello，不另造第二control；不足立即规范QUEUE_FULL。owned reservation仍先占，尚未spawn的候选在never-created+starting finally真实退掉；已进入spawn/已发送控制继续等原严格response或实际owner终态，不以失败/新Session/TTL清额。旧#start EngineError原对象保留，局部LifecycleFault安全映射规范QUEUE_FULL，不破FailureOrigin。

原独审5708B脚本只改输出名后的真实JSON415B/584928f6…显示旧PID60117的hello/create/get/ping，末态business0/completion1/ping1/hello0，total2；这表示128新入口在缺control时撤回，不能据末态2否认它们曾达到同步峰值。新独立边界815B/25612959…进一步实记peak130/controlPeak1：旧PID60856未终态时只有一child，等旧owner实际结束才有新60887 hello/health，旧completion.bytes依旧>0。即便transport旧owner结束，也未假签旧completion原handler成功。

作者的新真实跨代测试也检查旧ping/completion不清、129拒绝/第二spawn0、真实旧owner关后才恢复、新hello reservation、128waiter stop和双向control边界。新恢复批量允许原合法TIMEOUT，但仍等严格迟到回包把所有business foreground结清，再要求一次正常health；这纠正新增测试的延迟假设，没有放宽产品requestMs、130/2owned或旧unknown条件，不构成性能声明。

新固定代码保留原owned cap2、永久排空、三pipe和starting finally逻辑，除前置hello reservation/错误安全映射未改其释放条件。本次差异未见用false/null/close超时自签终态，未扩大旧main/TaskService/Store/worker/生产路径。

## D. 实际日志、预算轨迹及新旧PID

新checks-r2 5561B/875f24f9…、disposition4185B/90aa8bc1…、runtime-r2 6367B/b2418404…及实现主16906B/f92afae8…已全文读。log-index-r2 9422B/d45c8b90…列34个/tmp原件和12份正常check预算trace，全部逐当前实际文件bytes/SHA核同。normalCheckTraceOriginals是reservations轨迹，不是tool call/result原件，不能据字段名字宣称已收全工具流。

final check02日志8677B/SHA `3cd3df5901cf527d69a32115c0797e9df694327f7a9b95c368643f2cfc0e0b7d`全文确认1175TS/23文件、2969Py/44既有skip以及lint/format/type/build/ruff；对应checks声明d5fb00/session9376→ede6da exit0。source02 111B/1439dca3…确认12原源，对应e928ed。新版专项230B/d37b6b10…明确8pass/42过滤skip（总50），不是全量时跳过42；全量check另外覆盖50。原cd506 check01或旧04ed check06不沿用来充7dfa验证。

作者复制独审probe的4d52de被声明exit0，已读原230B/a19d48c8…日志和JSON旧PID49066/total2保ping1+completion1；独审自己的两个实际命令声明57fdd6（原probe1pass）与acb720（新4case pass），九个脚本/config/log/evidence实际bytes/SHA与25535报告逐项核同。它们都是真实文件/源码证据，本审没有重跑；完整原call/result及真实exec/write_stdin终态尚待归档绑定，所以没有把报告转述的tool数字独立认证为原工具终态。

新版运行原JSON306559B/SHA `1c633f664cd8750415daf372a6b61d8239f1a949f2c0e33b1481a26623a132c4`实核7dfa三writer指纹、cwd、controller.argv和wait exit0、5个marker PID与5份实际定向ps对应，5份均有完整Node fixture argv及本次独立TMPDIR；3个marker完整行前缀逐hash核同。另6个budgetTraces逐原文件/UTF8/hash核同，所有sample都满足total=business+completion+control、total≤130、control≤1、business≤128、completion≤1；最大130。跨代trace475样本/峰130，永久stop trace144/峰129，旧hello156样本；三个取消case各2样本并明确失败watch1。只证该次实际机制/采样，不把ps exit0当child exit0或所有最后写入完整捕获。

旧原395861B/ebc0 JSON仍不变。新版runtime摘要已明确改为29marker PID/29次ps成功、28完整argv+PID37879仅(node)、28marker文件；主文和独审追加亦澄清。故本审P3-T01-DSP-E01的措辞更正已见，不用新5PID倒补旧29，也不重跑旧42追数字。原4f Git/旧首失败/原独审前缀完整保留。

R2首focused01两fail、focused02批量TIMEOUT、observer01的-t被误当源码路径等均保完整原件，处置承认两种实际失败，没有被后续成功洗掉；最终observer采用本次独立路径的增量marker读取。这里未把数据采样器、控制fixture或成功callback当真实业务authority。

## E. 尚待最终增量收件

目前已核新源码/固定过程输入、原P2反例、当前25535独审明确结论、临时原脚本/日志/JSON和当前资源样本；未见新的代码阻断。**仍待最终归档/Git收件，不出最终Pass**：完整独审25535尚未跟踪，最终raw ZIP/index/source package/delivery与外部Git回执未到；normal check/source/observer、4d52de以及57fdd6/acb720的真实call/result/cwd/exec或session终态与捕获边界仍须原记录绑定。后续若仅交这些身份/raw增量且三writer不变，不再重做无变化源码/方案或测试。

C2控制报告20218B/c61b7608f759a3b8e9926a0d7ed8add9a983035533a8a212a185ae2d7b154ab1与ontology24648B/81f642b4da802844b9ca8310bbe0f2da84aed66ac7918f54160663de7a85215a保持原字节。所有正式issuer/撤权scope/物理首IO、真实terminal producer、未知JobId发现、opaque供方预算、Store/worker/VFS/LocationLease/cohort、生产旁路/模型装配、双OS真人/指定双模型/CI/正常develop及父门仍不由本增量关闭。
