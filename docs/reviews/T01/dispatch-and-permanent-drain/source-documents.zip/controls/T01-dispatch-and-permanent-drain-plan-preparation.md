# T01 dispatch 与永久 child 排空来源：并行精确方案准备

2026-10-21。本件仅在根实际发送原T01后生效，当前只准备方案，不修改产品。与C2只读操作证据方案可并行且互不写同一文件；由同一T01功能聊天按可用独立agent安排，不能为并行打断C2已在做的审查。完整57P0、正式宿主/模型/位置切换与原指定双审门不变。

背景：I06固定ffb B方案§6/§8与实际engine源均指出，RPC reject、pending.size=0、child.kill返回、session结束或stop()返回并非该Supervisor全部旧/当前child和自有资源已实际结束。生产首内容IO/LocationLease仍需native等前置，但写帧前准入与真实永久child持有来源的精确合同可以独立先推进，不必把全部横向供方等到完整native才设计。

仅可新增主说明 docs/iterations/T01/dispatch-and-permanent-drain-plan.md 及证据/独立调查/独审 docs/reviews/T01/dispatch-and-permanent-drain-plan/。C1固定423b59件、a33原收口、C2方案及其证据、AGENTS、全部产品/测试/配置均只读；如本地过程提交只含本件新docs。不得因此新建代码树/改engine.ts/main/task-service/worker/canonical/native/build，后续实施另列精确ref/path/bytes/SHA与writer。

以固定423b7e4c799f188cf2ce6e8e7121893ce85624cd实际engine.ts为唯一T01源码起点（26260B/SHA6d55774068ca27a49958daeea9f4b1fa15614c95563ca28b8a768265ecd4365e），实际追踪#ensure/#start/#send/#finish/stop、generation/session、所有spawn/close/stdio/timer及待spawn状态。旧I06 e2c调用图只作来源，不当已批准canonical/cohort/runtime。根据现有真实代码提出最小T01私有接口，不能只以将来有个safe callback概括。

方案应具体冻结：

1. 写帧前最后一个同步检查点、严格原request/current host/session/generation/实际Supervisor及operation来源，检查成功到stdin.write之间无await/可重入改权空隙；尚未发送与已发出未知结果如何分开。不得从renderer传布尔/UUID或JSON捏造current_scope/physicalbinding。真实I06 scope/lease尚未交付时保拒绝/unsupported，不能以fixture假装生产授权。hello/control/heartbeat与业务写帧分别列真实语义，不破坏既有握手/期限或偷偷把业务call当健康检查。
2. logicalOutcome、每原operation实际执行结算、整个Supervisor永久ownershipLifetime三者分别说明。queued Job受理回复不是Python后台执行完成；pending清零/timeout/abort/response或kill不能替实际底层任务/child/Store终态。若现协议缺operation完成供应，给出最小具体T01/I05供方请求与对应既有Job/claim只读事实，不能加第二Job/意图账本或造中间状态自证。
3. 永久停止先禁止新request/spawn，再覆盖所有曾创建且尚未实际close的child，包括已从#session移除、重连旧child、spawn中/退避中/延迟清理者。每个自有stdin/stdout/stderr与child的真实终态、未决close/error处理和有限资源留存/回收需明确；exit事件、kill返回或一个Promise.fulfilled不当全部释放。不得按时间到自动released或把unknown残留从集合删掉。若某Node事件契约足以证明其自有流结束，说明实际源码/官方原语依据和剩余OS边界。
4. 普通短session断线/同Supervisor重连仍走原恢复，不能因此结束永久ownershipLifetime或误清模型grant。只有永久stopAndDrain及所有自有终态后可结算内部寿命来源；它不认证外部进程、别的连接、SQLite锁/VFS或OS LocationLease释放。Store/worker/native由各实际owner提供完整终态，未交时保unknown；不把child exit码推广成全局DB释放receipt。
5. 与I06四角色、真实仓库/模型引用、同UUID新engine需重建整个ModelService/Application/Source/Projector/Core的实际握手，列准确提议接口/生命周期/错误/owner，不复制未批准Model DTO或要求I06改T01源码。旧ready/hello/permission/readscope和主指针交换由唯一owner维持，禁止第二通用桥/authorityfactory。
6. 工程guard必须从现maxPending/starts/listener/timer与实际在途child推导有限上界及失效策略，给新状态保留/查找/清理/票据的确切预算和先界次序，不能新建无界reaper集合；真实资源未终态时可以拒绝再spawn，不能通过遗忘释放名额。

列实施候选最小新/旧writer与只读采用集合，拟独立5f树/branch和完整diff；按真实现有接口决定是否需一个私有helper/新测试，不能泛授权main目录。适当运行验收应优先真实无GUI自有子进程及完整stdio，覆盖kill请求后实际close延迟、多个旧child/重连/stop与spawn竞态、已timeout但仍实际在途、失败spawn/stream close、停止后拒绝新dispatch、检查失败write0、同UUID新对象不复用旧来源、短断线与永久寿命区别。纯mock只能补状态反例，不替真实Node child终态；临时脚本/受控管道与用户进程隔离，不提前运行计划或宽泛kill。

完整方案经独立agent审查、意见逐项处理、固定docs/ref/manifest交根，再决定精确代码窗口。当前只做源码调查/文档格式/Git/hash，不运行产品/tests/新子进程/native/网络/GUI/模型，不重跑C1、不push/PR/merge，不重开重建原Goal。缺native/原binding不降低正式验收；本方案只使其横向调用链和真实待供接口可实施可审。
