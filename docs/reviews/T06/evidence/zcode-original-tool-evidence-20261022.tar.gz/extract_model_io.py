from pathlib import Path
import json,hashlib,copy,re,collections,datetime
OUT=Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261022_t06_external_review/zcode-model-io-extraction')
SID='session_863fdf5a03a40f74ea7b4b7289b097d1'
SRC=OUT/('model-io-'+SID+'.jsonl')
H=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
(OUT/'tool-record-values').mkdir(exist_ok=True)
rows=[];records=[];off=0
with SRC.open('rb') as f:
 for line_no,line in enumerate(f,1):
  d=json.loads(line);assert d['sessionId']==SID
  rows.append({'line':line_no,'byte_offset':off,'byte_length':len(line),'sha256':H(line),'querySource':d.get('querySource'),'requestId':d.get('requestId'),'startedAt':d.get('startedAt'),'completedAt':d.get('completedAt'),'modelIOReset':bool(d.get('modelIOReset'))})
  records.append(d);off+=len(line)
assert H(SRC.read_bytes())==json.loads((OUT/'raw-source-manifest.json').read_text())['sha256']
(OUT/'source-lines.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
occurrences=[];versions={};by_id={};collection_states={};delta_count=0;tail_count=0;invalid_deltas=[];raw_shapes=collections.Counter()

def tid(v):
 return v.get('id') or v.get('toolCallId') or v.get('tool_call_id') or v.get('tool_use_id') or v.get('toolUseId')
def tname(v):
 return v.get('name') or v.get('toolName') or (v.get('function') or {}).get('name')
def add(kind,value,call_id,name,src,view,ptr):
 if not isinstance(call_id,str) or not call_id:return
 key=H(canonical({'kind':kind,'view':view,'value':value}));version_id=kind+'-'+key
 if version_id not in versions:
  p=OUT/'tool-record-values'/(version_id+'.json')
  obj={'kind':kind,'call_id':call_id,'tool_name':name,'view':view,'raw_value':value}
  p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
  versions[version_id]={'version_id':version_id,'kind':kind,'call_id':call_id,'tool_name':name,'view':view,'raw_value_canonical_sha256':H(canonical(value)),'path':str(p),'file_bytes':p.stat().st_size,'file_sha256':H(p.read_bytes())}
 occ={'version_id':version_id,'kind':kind,'call_id':call_id,'tool_name':name,'source_line':src['line'],'source_byte_offset':src['byte_offset'],'source_byte_length':src['byte_length'],'source_line_sha256':src['sha256'],'json_pointer':ptr,'view':view}
 occurrences.append(occ)
 group=by_id.setdefault(call_id,{'call_id':call_id,'tool_names':set(),'first_source_line':src['line'],'last_source_line':src['line'],'call_versions':set(),'result_versions':set(),'occurrence_count':0})
 if name:group['tool_names'].add(name)
 group['last_source_line']=max(group['last_source_line'],src['line']);group[kind+'_versions'].add(version_id);group['occurrence_count']+=1

def process_messages(a,origin,view,prefix):
 for i,(m,src,raw_i) in enumerate(a):
  if not isinstance(m,dict):continue
  ptr=prefix+'/'+str(raw_i)
  role=m.get('role');content=m.get('content');raw_shapes[(view,str(role),type(content).__name__)]+=1
  if role=='tool':
   if isinstance(content,list):
    for j,p in enumerate(content):
     if isinstance(p,dict) and p.get('type') in ['tool-result','tool_result']:
      add('result',p,tid(p) or tid(m),tname(p) or tname(m),src,view,ptr+'/content/'+str(j))
   else:add('result',m,tid(m),tname(m),src,view,ptr)
  if role=='assistant':
   if isinstance(content,list):
    for j,p in enumerate(content):
     if isinstance(p,dict) and p.get('type') in ['tool-call','tool_call','tool_use']:
      add('call',p,tid(p),tname(p),src,view,ptr+'/content/'+str(j))
   for j,p in enumerate(m.get('tool_calls') or []):
    if isinstance(p,dict):add('call',p,tid(p),tname(p),src,view,ptr+'/tool_calls/'+str(j))

for d,src in zip(records,rows):
 req=d.get('request') or {};response=d.get('response') or {}
 for j,p in enumerate(response.get('toolCalls') or []):
  if isinstance(p,dict):add('call',p,tid(p),tname(p),src,'response.toolCalls','/response/toolCalls/'+str(j))
 for view,key,kind_key,offset_key,container,prefix in [
  ('request.messages','messages','messagesKind','messageOffset',req,'/request/messages'),
  ('request.sdkMessages','sdkMessages','sdkMessagesKind','sdkMessageOffset',req,'/request/sdkMessages'),
  ('request.body.messages','messages','bodyMessagesKind','bodyMessageOffset',req.get('body') if isinstance(req.get('body'),dict) else {},'/request/body/messages')]:
  a=container.get(key);metadata=req;kind=metadata.get(kind_key);offset=metadata.get(offset_key)
  if not isinstance(a,list):continue
  direct=[(m,src,i) for i,m in enumerate(a)];expanded=direct
  if kind=='delta':
   delta_count+=1;prev=collection_states.get(view)
   if prev is not None and isinstance(offset,int) and not isinstance(offset,bool) and offset>=0:expanded=prev[:offset]+direct
   else:invalid_deltas.append({'line':src['line'],'view':view,'offset':offset})
  elif kind=='tail':tail_count+=1
  collection_states[view]=expanded
  process_messages(expanded,src,view,prefix)

# Keep every raw variant, all occurrence references, and exact raw line bytes in source copy.
with (OUT/'tool-record-occurrences.jsonl').open('w') as f:
 for o in occurrences:f.write(json.dumps(o,ensure_ascii=False,separators=(',',':'))+'\n')
(OUT/'tool-record-versions.json').write_text(json.dumps(list(versions.values()),ensure_ascii=False,indent=2)+'\n')
for g in by_id.values():
 for k in ['tool_names','call_versions','result_versions']:g[k]=sorted(g[k])
(OUT/'tool-call-id-index.json').write_text(json.dumps(list(by_id.values()),ensure_ascii=False,indent=2)+'\n')
finals=[(d,s) for d,s in zip(records,rows) if d.get('querySource')=='main_turn' and (d.get('response') or {}).get('finishReason')=='stop' and isinstance((d.get('response') or {}).get('text'),str)]
assert finals;final,final_src=finals[-1];txt=final['response']['text'];p=OUT/'final-assistant-message.txt';p.write_bytes(txt.encode());p.chmod(0o600)
final_info={'path':str(p),'utf8_bytes':len(txt.encode()),'chars':len(txt),'sha256':H(txt.encode()),'source':final_src,'json_pointer':'/response/text','finishReason':'stop','responseToolCalls':len(final['response'].get('toolCalls') or [])};(OUT/'final-assistant-source.json').write_text(json.dumps(final_info,ensure_ascii=False,indent=2)+'\n')

# Examine only decoded tool records for rejection/stdin markers and explicit output-artifact locators.
markers=[];artifact_mentions=[]
for v in versions.values():
 obj=json.loads(Path(v['path']).read_text());val=obj['raw_value'];s=json.dumps(val,ensure_ascii=False)
 matches=[term for term in ['Mimosa','mimosa','permission denied','Permission denied','not allowed','not permitted','拒绝','denied','uv run --frozen python -','python - <<','python3 - <<','output_file','outputFile','Output file','background task','Background task','truncated','Truncated'] if term in s]
 if matches:markers.append({'version_id':v['version_id'],'call_id':v['call_id'],'kind':v['kind'],'tool_name':v['tool_name'],'view':v['view'],'markers':matches,'path':v['path']})
 # Parse JSON-looking strings only for actual artifact keys, no arbitrary paths from code/source text.
 def walk(x,loc=''):
  if isinstance(x,dict):
   for k,y in x.items():
    if isinstance(y,str) and k.lower() in ['output_file','outputfile','outputfilepath','full_output_file','fulloutputpath','full_output_path','stdout_file','stderr_file','log_file']:
     artifact_mentions.append({'call_id':v['call_id'],'version_id':v['version_id'],'field':loc+'/'+k,'value':y})
    walk(y,loc+'/'+k)
  elif isinstance(x,list):
   for j,y in enumerate(x):walk(y,loc+'/'+str(j))
  elif isinstance(x,str) and x[:1] in ['{','[']:
   try:walk(json.loads(x),loc+'/parsed_json')
   except (ValueError,RecursionError):pass
 walk(val)
 for match in re.finditer(r'(?:Output file|output file|Full output|full output)(?: saved to| written to| available (?:at|in))?\s*[:=]\s*[`\"]?([^\n\r`\"<>]+)',s):
  artifact_mentions.append({'call_id':v['call_id'],'version_id':v['version_id'],'field':'explicit_text_output_locator','value':match.group(1)})
(OUT/'tool-marker-index.json').write_text(json.dumps(markers,ensure_ascii=False,indent=2)+'\n');(OUT/'explicit-output-artifact-mentions.json').write_text(json.dumps(artifact_mentions,ensure_ascii=False,indent=2)+'\n')
coverage={'captured_at':datetime.datetime.now().astimezone().isoformat(),'source_records':len(records),'all_exact_target_session':True,'main_turn_records':sum(d.get('querySource')=='main_turn' for d in records),'model_io_reset_seen':any(r['modelIOReset'] for r in rows),'delta_collections_expanded':delta_count,'tail_baselines_seen':tail_count,'invalid_delta_collections':invalid_deltas,'unique_tool_call_ids':len(by_id),'unique_call_ids_with_calls':sum(bool(x['call_versions']) for x in by_id.values()),'unique_call_ids_with_results':sum(bool(x['result_versions']) for x in by_id.values()),'call_ids_without_results':[k for k,v in by_id.items() if not v['result_versions']],'result_ids_without_calls':[k for k,v in by_id.items() if not v['call_versions']],'unique_decoded_tool_record_versions':len(versions),'tool_record_occurrences':len(occurrences),'final_assistant':final_info,'marker_records':len(markers),'explicit_artifact_mentions':len(artifact_mentions),'source_headers_system_prompts_reasoning_not_emitted_in_extracted_records':True,'raw_copy_contains_original_officially_sanitized_record':True,'not_reexecuted':True,'limitations':['Raw source byte copy is exact. Extracted tool value files are JSON reserializations of exact decoded subobjects; original line bytes remain recoverable from byte/length/hash index.','Tool returned truncation markers remain as recorded; full output artifacts are separately assessed; no test or archived command is reexecuted.']}
(OUT/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in coverage.items() if k!='final_assistant'},ensure_ascii=False,indent=2));print('final',final_info['utf8_bytes'],final_info['sha256'])
