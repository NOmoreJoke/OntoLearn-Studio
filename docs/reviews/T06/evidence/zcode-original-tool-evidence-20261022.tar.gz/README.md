# ZCode 自身审查记录保全

仅 session_863fdf5a03a40f74ea7b4b7289b097d1 的官方既存 model-I/O 原件。没有执行原工具命令、测试、被拒脚本、登录、GUI 或新会话。原审查报告没有改写。

原件 63,382,480 B，SHA-256 d46d22c8d7825f3d24eb2b33ddf22438e6d84ca09f14542bd7f27a2ceb24ad3f，保存在本 outputs 私有目录，不纳入本精简归档或 Git。raw-source-manifest.json 保留原来源、mtime 和哈希。原件自带的官方诊断脱敏不等于适合公开分享；没有在提取值中输出 headers、system prompt 或 reasoning。

44 条原 model-I/O（43 main_turn、1 session_title）全部精确匹配本 session，未发现 delta/tail/reset。本提取器保留官方 delta 展开规则；本次实际无需展开。58 个模型工具调用 ID 均有 call/result，372 个解码原值版本、5594 个原行/byte offset/length/SHA/JSON pointer 引用。每个 occurrence 已独立逐指针对原件 JSON 原值核验相等。原值文件是 JSON 重新序列化；其原始 lexical bytes 由源原行索引定位，不把重序列化文件称原始行字节。

执行 support log 的 started/completed 各 54 个 ID；缺少执行事件的四个恰是 Mimosa 拒绝（1 Bash、3 Write）。不是仅两次 Write；各拒绝完整原 call/result 和后继两 stdin 命令/返回均保留。首 stdin 返回 Exit code 1、20 PASS/2 FAIL，随后修正预期探针 ALL PASS。此处只保全实际过程，不替代作者事实补正、独立审查或改变产品结论。

最终 assistant：final-assistant-message.txt，1210 chars / 2138 UTF-8 B，SHA-256 4614773546f7e7d7d7b9045107264f0c126a9ddad022de22d0b864f96afdd309；对应原第43行 response.text，finishReason stop。第44行只是标题。

npm run check 的本 session 显式背景输出原件已另复制：own-output-artifacts/call_9355a20be47d40e59977bbca-stdout.log，7757 B、163行、SHA-256 2e51ddc0264f4a58339f681c60f0e6853be9e32bee1e9f260a2e374ba9e4479b。122tests 命令本身 pipe tail，保存的是完整已记录工具返回，不能声称另有未捕获的 pipe 前 stdout。两 stdin 返回亦完整保留。未检测到工具返回自身截断标记，不把故意 head/tail 的输出当完整底层进程输出。运行时 argv 没有原始记录，不能由源码倒推。

author-own-facts-manifest.json 是可交原作者的自身事实索引；不含其他模型意见，也不预设补正后结论。tool-call-id-index.json 按调用ID分组但保留所有原版本；tool-record-occurrences.jsonl 逐出现位置溯源。bash-commands-and-returns/ 保存精确命令文本和工具返回文本，文本文件不执行。
