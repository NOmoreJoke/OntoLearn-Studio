// ZCode GLM-5.3 独立审查补充只读内存反例（2026-10-22）
// 模式沿用历史 negative-probes：vite 内存构建本树源码，不写源文件、不依赖浏览器。
import assert from 'node:assert/strict'
import path from 'node:path'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'

const root = '/Users/kyle/Documents/工作/知爻/本体/.worktrees/T06-ui-zcode-review-da37709'
const require = createRequire(path.join(root, 'package.json'))
const { build } = await import(pathToFileURL(require.resolve('vite')).href)
const entry = 'virtual:t06-readonly-extra-probes'
const source = ['model', 'controller', 'presentation']
  .map((name) => `export * from ${JSON.stringify(path.join(root, 'apps/desktop/src/renderer/src/behavior', name + '.ts'))};`)
  .join('\n')
const built = await build({
  root,
  configFile: false,
  logLevel: 'silent',
  plugins: [
    {
      name: 'readonly-extra-probes',
      resolveId: (id) => (id.endsWith(entry) ? '\0probes.ts' : undefined),
      load: (id) => (id === '\0probes.ts' ? source : undefined),
    },
  ],
  build: { write: false, minify: false, lib: { entry, formats: ['es'] } },
})
const code = (Array.isArray(built) ? built[0] : built).output.find((x) => x.type === 'chunk' && x.isEntry).code
const m = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'))

const context = { projectId: 'P', inputVersion: 'V1', behaviorVersion: 'B1', scopeId: 'scope-1' }
const catalog = {
  objects: ['T1', 'W-test'],
  classes: ['TestObject', 'Notification'],
  properties: [
    { id: 'P', kind: 'single' },
    { id: 'links', kind: 'multi' },
  ],
  behaviorIds: [],
}
const baseDraft = {
  id: 'B',
  name: '行为',
  description: '说明',
  trigger: 'alarm',
  conditions: [{ kind: 'equals', object: 'T1', property: 'P', value: { kind: 'boolean', value: false } }],
  actions: [{ kind: 'notify', message: '通知' }],
  effect: '效果',
  enabled: true,
  priority: 0,
  version: 1,
}
const ev = (payload) => ({ id: 'E-1', type: 'alarm', payload, changes: [] })

// A. 非对象 JSON 载荷：数组/标量/null/嵌套对象必须被拒绝，不得静默转成空对象或丢值
for (const payload of ['[]', '[1,2]', 'null', '123', '"text"', 'true', '{"x":{"a":1}}', '{"x":[1]}', '{"x":1e400}']) {
  const r = m.parseEvents([ev(payload)])
  assert.equal(r.events.length, 0, `payload ${payload} must not be accepted`)
  assert.equal(r.issues.length, 1, `payload ${payload} must produce one issue`)
  assert.equal(r.issues[0].path, 'events.0')
  console.log(`A reject non-object/malformed payload ok: ${payload}`)
}

// B. 载荷键/值长度边界：>200 键、>2000 值、>100 键被拒；正常边界通过
{
  const longKey = 'k'.repeat(201)
  const r1 = m.parseEvents([ev(`{"${longKey}":"v"}`)])
  assert.equal(r1.events.length, 0)
  const longVal = 'v'.repeat(2001)
  const r2 = m.parseEvents([ev(`{"k":"${longVal}"}`)])
  assert.equal(r2.events.length, 0)
  const manyKeys = JSON.stringify(Object.fromEntries(Array.from({ length: 101 }, (_, i) => [`k${i}`, i])))
  const r3 = m.parseEvents([ev(manyKeys)])
  assert.equal(r3.events.length, 0)
  const okKeys = JSON.stringify(Object.fromEntries(Array.from({ length: 100 }, (_, i) => [`k${i}`, i])))
  const r4 = m.parseEvents([ev(okKeys)])
  assert.equal(r4.issues.length, 0)
  assert.equal(Object.keys(r4.events[0].payload).length, 100)
  console.log('B payload size/count boundaries ok')
}

// C. 事件数量边界：0 与 101 拒绝，100 通过
{
  const mk = (n) => Array.from({ length: n }, (_, i) => ({ id: `E-${i}`, type: 't', payload: '{}', changes: [] }))
  assert.equal(m.parseEvents([]).issues[0].path, 'events')
  assert.equal(m.parseEvents(mk(101)).issues[0].path, 'events')
  const r = m.parseEvents(mk(100))
  assert.equal(r.issues.length, 0)
  assert.equal(r.events.length, 100)
  console.log('C event count boundaries ok')
}

// D. 保留键变体：对象值、转义、prototype/constructor 一律拒绝；近似普通键保留
for (const payload of [
  '{"__proto__":{"x":1}}',
  '{"prototype":[]}',
  '{"constructor":{"a":1}}',
  String.raw`{"\u005f_proto__":"escaped"}`,
  String.raw`{"\u0063onstructor":"escaped-c"}`,
]) {
  const r = m.parseEvents([ev(payload)])
  assert.equal(r.events.length, 0, `reserved variant must be rejected: ${payload}`)
  assert.ok(r.issues[0].message.includes('保留键'))
  console.log(`D reserved-key variant rejected ok: ${payload}`)
}
{
  const keep = { proto_value: 'a', prototypes: 'b', __proto__value: 'c' }
  const r = m.parseEvents([ev(JSON.stringify(keep))])
  assert.deepEqual(r.events[0].payload, keep)
  assert.equal(r.issues.length, 0)
  console.log('D ordinary similar-named fields preserved ok')
}

// E. draft 边界：priority ±1000000 通过、超界拒绝；conditions 51 拒绝；actions 101 拒绝；always 混入额外字段拒绝
{
  assert.equal(m.validateDraft({ ...baseDraft, priority: -1000000 }, catalog).length, 0)
  assert.equal(m.validateDraft({ ...baseDraft, priority: 1000000 }, catalog).length, 0)
  assert.notEqual(m.validateDraft({ ...baseDraft, priority: 1000001 }, catalog).length, 0)
  const manyCond = Array.from({ length: 51 }, () => ({ kind: 'always' }))
  assert.notEqual(m.validateDraft({ ...baseDraft, conditions: manyCond }, catalog).length, 0)
  const manyAct = Array.from({ length: 101 }, () => ({ kind: 'notify', message: 'x' }))
  assert.notEqual(m.validateDraft({ ...baseDraft, actions: manyAct }, catalog).length, 0)
  assert.equal(m.draftSchema.safeParse({ ...baseDraft, conditions: [{ kind: 'always', object: 'T1' }] }).success, false)
  console.log('E draft boundaries ok')
}

// F. resultSchema 补充：stale 无说明拒绝；completed 无 committed 拒绝；超量数组拒绝；unknown 字段拒绝
const baseResult = (patch = {}) => ({
  binding: { ...context, requestId: 'r1' },
  runId: 'R1',
  state: 'candidate',
  committed: false,
  freshness: 'current',
  freshnessDetail: '',
  assertionVersion: 'A1',
  inferenceVersion: 'I1',
  semanticsVersion: 'E1',
  conditions: [],
  actions: [
    { eventId: 'E1', behaviorId: 'B', index: 0, kind: 'notify', state: 'planned', detail: 'd' },
  ],
  diff: { added: [], removed: [] },
  notifications: [{ eventId: 'E1', behaviorId: 'B', message: 'm', state: 'candidate' }],
  error: null,
  ...patch,
})
{
  assert.equal(m.resultSchema.safeParse(baseResult({ freshness: 'stale', freshnessDetail: '' })).success, false)
  assert.equal(m.resultSchema.safeParse(baseResult({ state: 'completed', committed: false })).success, false)
  assert.equal(m.resultSchema.safeParse(baseResult({ extra: 1 })).success, false)
  const manyActions = Array.from({ length: 10001 }, (_, i) => ({
    eventId: 'E1', behaviorId: 'B', index: i, kind: 'notify', state: 'planned', detail: 'd',
  }))
  assert.equal(m.resultSchema.safeParse(baseResult({ actions: manyActions })).success, false)
  assert.equal(m.resultSchema.safeParse(baseResult()).success, true)
  console.log('F resultSchema extra negatives ok')
}

// G. controller：缺 refresh 服务时 refresh 无操作；pending 中 run 不重复提交；接收非对象返回拒绝
{
  const calls = []
  const controller = new m.BehaviorController(context, catalog, baseDraft, {
    runSample: async (req) => {
      calls.push(req)
      return 'not-an-object'
    },
  })
  controller.editEvents([{ id: 'E-1', type: 'alarm', payload: '{}', changes: [] }])
  await controller.run()
  assert.equal(calls.length, 1)
  assert.equal(controller.getSnapshot().result, undefined)
  assert.ok(controller.getSnapshot().notice.includes('已拒绝显示'))
  await controller.refresh() // 无 refreshResult 服务：无操作不抛错
  console.log('G controller extra negatives ok')
}

console.log('ALL EXTRA PROBES PASSED')
