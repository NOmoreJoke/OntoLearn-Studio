# UI498 两轮最终证据，只读归档

最小入口：`minimal-manifest.json`。只读取本 UI 会话、它明确产生的报告/输出及本树 marker 元数据；未操作 GUI、SQLite、新 runtime，未重跑验证、归档脚本或被拒操作，未修改报告或任何源码。

两轮均有官方完成终态：

| 轮次 | query | completed UTC | 工具数 | 最终消息 |
| --- | --- | --- | --- | --- |
| 原完整初审 | `01a162fe-7f0f-723d-ba12-d7ecaacb2e38` | 10:04:26.178Z | 80 | `finals/assistant-line-62.txt`，2317B/SHA `15386840…cabf9` |
| 环境事实纠正后续做 | `01a16313-94ec-7a82-8d60-618b0919deba` | 10:11:15.993Z | 21 | `finals/assistant-line-81.txt`，2413B/SHA `907a679f…761a0` |

首轮最终判“无法验证”，19023B 报告版本 SHA `3705e816d022e2f7b20b12d02eba183ebf4b9d560eb822ebb3289483b8ba71eb`。第二轮最终判“通过”，范围仅为未装配独立 UI 组件；现报告24568B/SHA `b7715b6dd4d8b4caadfdeebc59136923e610ff1280590b63f4a0e04010061cfd`。原始 Write 与逐次 Edit 重建10个报告版本，最后版本与当前报告逐字节相等。所有版本、精确输入/返回、行号与 JSON pointer 均已保存。没有由本收证任务更改原件。

owner 环境纠正消息1592字符/2622B、SHA `35f8c5051d5398094a6e93843ea6067ed01bd6efbb151b783f128ec088778c2d`，与第二轮实际 request user content 逐字节相等，随后18个请求沿用该正文。见 `correction-message-acceptance.json`。实际模型/权限设置见请求与启动记录：GLM-5.3、thinking enabled、effort max、yolo、唯一独立树；完整 CLI/runtime argv 未从源码倒推。

headless 证据分账：首轮真实失败是官方浏览器安装请求，完整 headless 当时未运行。补充后 reviewer 实际运行默认1248路径的最小 `chromium.launch({headless:true})`，随后制作验证脚本副本（仅组件路径及输出路径两行不同），实际执行完整验证，返回 `HEADLESS_EXIT=0`。`r3-headless.log` 全文可在该工具返回中找到；evidence.json 明示 `fixtureOnly:true/gui:false`，列8组检查。安装成功、版本读回及下载哈希本身没有被用作 headless 通过依据。完整日志、脚本、副本 diff、JSON、构建产物及3张PNG均按字节保存，见 `own-artifacts-manifest.json`。

本轮真实新截图读取有两次：1440宽图与390视口图，均由 Read 工具成功返回图像；另有首轮历史1440图的读取，已按原路径区分。官方 modelIO 有意省略 dataUrl 图像内容，因此不能恢复当时传给模型的转换JPEG精确像素；原PNG字节已独立保全。本收证者也仅通过本地文件图像查看器只读查看本轮1440/390原PNG，未操作桌面GUI或执行页面。该证据覆盖开发夹具，不能扩为真实引擎/正式App接线、原生系统或父模块验收。

保留的两处过程措辞问题（不改原报告）：

1. marker 探针实际检查 `chromium_headless_shell-1248/chrome-headless-shell-mac-arm64/INSTALLATION_COMPLETE`，即 binary 子目录；当前 revision 父目录的 `INSTALLATION_COMPLETE` 和 `DEPENDENCIES_VALIDATED` 另有真实元数据。`MARKER MISSING` 只证明被查子路径缺席，不能支持报告“官方 marker 缺席”的泛化。见 `owner-marker-location-note.json`。默认路径实际 launch/headless 成功不受这一措辞问题否定。
2. 报告§3仍残留“本轮无新截图，见4.3”，与§4.2、两次真实新截图 Read 和最终答复不一致。这是报告更新留下的旧句。

原样 `npm run check` 的 exit 1 及日志仍保留；受审面分项通过/排除证据目录后的 lint 与原样整体通过不可混称。tail 管道、tee日志、原工具返回均按原记录归档，不把管道前未保存 stdout 补造为全文。完整 browser process OS argv 未捕获，不由脚本源码倒推。

完整 modelIO 146858287B 按已保全63135430B原前缀核验后，仅新增83722857B后缀至 `private/`（0600）；恢复方案和组合 SHA 见 `raw-source-incremental-manifest.json`。完整 raw 含未导出的 headers/system/reasoning，不入分享包。`ui-tool-evidence.tar.gz` 仅含精确解码工具字段、最终正文、报告各版、用户纠正正文和本任务产物；原 JSON 词法字节通过私有前缀+后缀恢复。21746个工具表示均按原 source pointer 独立回比，差异0；无 delta/tail 轨迹元数据。

`package-receipt.json` 记录包SHA及逐成员读回结果；`shareable-file-manifest.json` 与 `file-manifest.json` 记录字节/哈希。主动工具请求中的 hook-state/.mimosa 路径扫描独立保存在 `active-tool-boundary-scan.json`，它无法排除自动 hook 注入。本归档未读取 S1 或另一模型意见，也未向原 reviewer 发送任何意见。
