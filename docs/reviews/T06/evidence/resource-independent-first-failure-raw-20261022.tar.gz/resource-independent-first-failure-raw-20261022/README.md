# 本agent首败与纠正原行保全

仅从本agent精确rollout按5个call ID摘取5调用/5返回共10原行，按原字节保存；不重演、不重跑，不修改报告、原总index或受审产品。line/offset/length/SHA/call_id见manifest。

- measurement首次：creates800 child已真实exit0；比较owner receipt的result字段触发KeyError，外层nested exec返回明确exit_code=1。原完整命令和返回见148/151。
- measurement纠正：162/165启动matrix并返回session71965；170/173读取完成，nested exec返回明确exit_code=0。首次create未重跑。
- owner首败回读辅助：208/211系统python3的zip(strict=True)触发TypeError；215/218明确uv项目Python后完成10行逐字节/SHA核验。这两个调用当时仅打印exec_command.output，原返回没有打印其exit_code字段，不能在本补充中伪造额外数值退出码。

原工具返回是合并文本，不能补造成分离stdout/stderr或OS运行时argv。所选5返回均未见截断标记；这仅指已保存原工具返回，不保证未打印字段或上游未捕获流。measurement child已有分离日志/receipt仍以原out为准。本目录新增raw保全不能覆盖首败，也不改变报告裁决。
