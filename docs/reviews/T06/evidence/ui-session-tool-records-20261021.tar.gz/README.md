# T06 UI 独立子 session 历史工具原行导出

3 个目标全部找到，无 gap。原始文件来自审查者自己的 /root/behavior_independent_review 子 session，未采用 root 或 UI 开发线会话。

- da37709 独立 vitest：call 第647行 / output 第651行，原始终态34通过、exit_code=0。原exec直接完成，无yield/sessionId/wait链。该call原本并行包含hash审计，原行完整保留，不把hash结果替代测试结果。
- 旧571虚拟入口装配失败：call 第484行 / output 第487行，原始exit_code=1。
- 旧571 build返回数组形态装配失败：call 第491行 / output 第494行，原始exit_code=1。

六个 .jsonl 每个严格保留一条原始二进制行（含原换行），不是重新序列化；manifest.json 给出绝对源、thread、call_id、1-based行号、0-based起始byte offset、含换行length/SHA。已逐片段重读原件并与导出逐字节核对。session_meta只留最小解析身份与源行位置/hash，未复制原meta/base_instructions。

未导出human/system/developer消息或完整会话。人工检查所选内容仅为临时工具代码、人工夹具、路径/hash与终态，未见凭据或真实业务数据；常见密钥模式检查也未命中。绝对本机路径作为来源证据有意保留。没有重跑测试/负例，没有修改任何repo；仅写本目录。
