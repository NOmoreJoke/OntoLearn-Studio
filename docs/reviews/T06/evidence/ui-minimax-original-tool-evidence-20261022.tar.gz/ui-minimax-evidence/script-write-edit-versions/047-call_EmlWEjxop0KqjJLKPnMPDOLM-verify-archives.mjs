/**
 * Independent read-only verification of the two T06 UI historical archives.
 * - verifies package bytes/SHA and internal manifest SHA
 * - enforces a regular-member whitelist: rejects absolute paths, "..", symlinks, hardlinks, devices
 * - re-reads every member from the archive and from the already-restored copy, comparing bytes + SHA
 * - never executes any archived code
 */
import { createHash } from 'node:crypto'
import { readFileSync, lstatSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
import path from 'node:path'

const root = process.argv[2]
const report = { packages: [], ok: true }

const sha = (buf) => createHash('sha256').update(buf).digest('hex')

// Minimal POSIX tar reader (ustar), read-only.
function readTar(buffer) {
  const entries = []
  let offset = 0
  let longName = null
  while (offset + 512 <= buffer.length) {
    const header = buffer.subarray(offset, offset + 512)
    if (header.every((byte) => byte === 0)) break
    const readString = (start, length) => {
      const raw = header.subarray(start, start + length)
      const end = raw.indexOf(0)
      return raw.subarray(0, end === -1 ? raw.length : end).toString('utf8')
    }
    const name = readString(0, 100)
    const sizeField = readString(124, 12)
    const size = parseInt(sizeField.trim() || '0', 8) || 0
    const typeflag = String.fromCharCode(header[156]) || '0'
    const prefix = readString(345, 155)
    const linkname = readString(157, 100)
    const dataStart = offset + 512
    const data = buffer.subarray(dataStart, dataStart + size)
    offset = dataStart + Math.ceil(size / 512) * 512
    if (typeflag === 'L') {
      longName = data.toString('utf8').replace(/\0+$/, '')
      continue
    }
    const full = longName ?? (prefix ? `${prefix}/${name}` : name)
    longName = null
    entries.push({ path: full, typeflag, linkname, size, data })
  }
  return entries
}

for (const spec of [
  {
    archive: 'archives/ui-original-artifacts-20261021.tar.gz',
    restored: 'ui-original-artifacts-20261021',
    manifestKey: 'entries',
    expectedSha: 'a51bfec8089f9a7db1578ebbfcc3570e1591beda51b956f2d8bf165a0cfab433',
    expectedBytes: 2232198,
    expectedManifestSha: '42950c37fededf9175de2433f35f420a7e30fa4b147e29edcda2f1cb344b629d',
  },
  {
    archive: 'archives/ui-session-tool-records-20261021.tar.gz',
    restored: 'ui-session-tool-records-20261021',
    manifestKey: 'items',
    expectedSha: '06d2e8636bbef29c6bb131bb3605c4f15e679d784137a2bffec5e58d472f5a3b',
    expectedBytes: 6698,
    expectedManifestSha: 'b35e8ae09fd445463dca559b1baa2390dbc3eb26060c0657840656b7315e2156',
  },
]) {
  const archivePath = path.join(root, spec.archive)
  const buffer = readFileSync(archivePath)
  const pkg = {
    archive: spec.archive,
    bytes: buffer.length,
    bytesMatch: buffer.length === spec.expectedBytes,
    sha256: sha(buffer),
    shaMatch: sha(buffer) === spec.expectedSha,
    manifestSha256: null,
    manifestShaMatch: false,
    whitelisted: [],
    rejected: [],
    verified: 0,
    mismatches: [],
  }
  const entries = readTar(buffer)
  const manifestEntry = entries.find((entry) => entry.path === 'manifest.json')
  pkg.manifestSha256 = sha(manifestEntry.data)
  pkg.manifestShaMatch = pkg.manifestSha256 === spec.expectedManifestSha
  const manifest = JSON.parse(manifestEntry.data.toString('utf8'))
  const declared = manifest[spec.manifestKey] ?? []

  const byPath = new Map(entries.map((entry) => [entry.path, entry]))
  for (const item of declared) {
    const memberPath = item.member ?? item.path ?? item.file
    const rejected =
      path.isAbsolute(memberPath) ||
      memberPath.includes('..') ||
      memberPath.startsWith('/')
    const entry = byPath.get(memberPath)
    if (rejected || !entry) {
      pkg.rejected.push({ member: memberPath, reason: rejected ? 'unsafe-path' : 'absent' })
      continue
    }
    if (entry.typeflag !== '0' && entry.typeflag !== '\0') {
      pkg.rejected.push({ member: memberPath, reason: `non-regular typeflag ${entry.typeflag}` })
      continue
    }
    if (entry.linkname) {
      pkg.rejected.push({ member: memberPath, reason: 'link target present' })
      continue
    }
    const archiveSha = sha(entry.data)
    const expectedSha = item.sha256
    const expectedBytes = item.bytes
    let restoredSha = null
    let restoredBytes = null
    try {
      const restoredPath = path.join(root, spec.restored, memberPath)
      const stat = lstatSync(restoredPath)
      if (!stat.isFile()) throw new Error('not a regular file')
      const restoredBuffer = readFileSync(restoredPath)
      restoredBytes = restoredBuffer.length
      restoredSha = sha(restoredBuffer)
    } catch (error) {
      pkg.mismatches.push({ member: memberPath, reason: `restored copy unreadable: ${error.message}` })
      continue
    }
    const ok =
      archiveSha === expectedSha &&
      entry.size === expectedBytes &&
      restoredSha === expectedSha &&
      restoredBytes === expectedBytes
    if (!ok) {
      pkg.mismatches.push({
        member: memberPath,
        archiveSha,
        expectedSha,
        restoredSha,
        entrySize: entry.size,
        expectedBytes,
        restoredBytes,
      })
    } else {
      pkg.verified += 1
    }
    pkg.whitelisted.push(memberPath)
  }
  // Any archive member that is not manifest.json or on the whitelist is unexpected.
  for (const entry of entries) {
    if (entry.path === 'manifest.json') continue
    if (!pkg.whitelisted.includes(entry.path)) {
      pkg.rejected.push({ member: entry.path, reason: 'not on manifest whitelist' })
    }
  }
  pkg.declaredCount = declared.length
  pkg.archiveMemberCount = entries.length
  pkg.allRegular = entries.every((entry) => entry.typeflag === '0' || entry.typeflag === '\0')
  report.packages.push(pkg)
  if (
    !pkg.bytesMatch ||
    !pkg.shaMatch ||
    !pkg.manifestShaMatch ||
    pkg.mismatches.length > 0 ||
    pkg.rejected.length > 0 ||
    pkg.verified !== declared.length
  ) {
    report.ok = false
  }
}

report.totalVerifiedMembers = report.packages.reduce((sum, pkg) => sum + pkg.verified, 0)
process.stdout.write(JSON.stringify(report, null, 2) + '\n')
process.exit(report.ok ? 0 : 1)
