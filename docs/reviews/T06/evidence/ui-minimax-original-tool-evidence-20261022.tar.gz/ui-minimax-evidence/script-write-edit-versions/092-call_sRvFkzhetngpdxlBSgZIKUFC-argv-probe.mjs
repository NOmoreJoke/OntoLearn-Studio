/** Read-only probe: record the real browser launch argv on the DEFAULT 1248 registry route (no executablePath). */
import { chromium } from '@playwright/test'

const browser = await chromium.launch({ headless: true })
const proc = browser.process()
console.log('resolved executable:', proc?.spawnfile)
console.log('spawnargs:', JSON.stringify(proc?.spawnargs, null, 2))
console.log('browser version:', browser.version())
await browser.close()
