/**
 * Independent read-only verification of the two T06 UI historical archives.
 * - verifies package bytes/SHA and internal manifest SHA
 * - enforces a regular-member whitelist: rejects absolute paths, "..", symlinks, links
 * - re-reads every member from the archive AND from the restored copy, comparing bytes + SHA
 * - never executes any archived code
 */
import { createHash } from 'node:crypto'
import { readFileSync, lstatSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
import path from 'node:path'

const root = process.argv[2]
const sha = (buf) => createHash('sha256').update(buf).digest('hex')

function readTar(buffer) {
  const entries = []
  let offset = 0
  let longName = null
  while (offset + 512 <= buffer.length) {
    const header = buffer.subarray(offset, offset + 512)
    if (header.every((byte) => byte === 0)) break
    const readString = (start, length) => {
      const raw = header.subarray(start, start + length)
      const end = raw.indexOf(0)
      return raw.subarray(0, end === -1 ? raw.length : end).toString('utf8')
    }
    const name = readString(0, 100)
    const size = parseInt(readString(124, 12).trim() || '0', 8) || 0
    const typeflag = String.fromCharCode(header[156]) || '0'
    const prefix = readString(345, 155)
    const linkname = readString(157, 100)
    const dataStart = offset + 512
    const data = buffer.subarray(dataStart, dataStart + size)
    offset = dataStart + Math.ceil(size / 512) * 512
    if (typeflag === 'L') {
      longName = data.toString('utf8').replace(/\0+$/, '')
      continue
    }
    entries.push({ path: longName ?? (prefix ? `${prefix}/${name}` : name), typeflag, linkname, size, data })
    longName = null
  }
  return entries
}

const report = { packages: [], ok: true }

for (const spec of [
  {
    archive: 'archives/ui-original-artifacts-20261021.tar.gz',
    restored: 'ui-original-artifacts-20261021',
    expectedSha: 'a51bfec8089f9a7db1578ebbfcc3570e1591beda51b956f2d8bf165a0cfab433',
    expectedBytes: 2232198,
    expectedManifestSha: '42950c37fededf9175de2433f35f420a7e30fa4b147e29edcda2f1cb344b629d',
    build: (manifest) =>
      manifest.entries.map((entry) => ({
        member: entry.member,
        bytes: entry.bytes,
        sha256: entry.sha256,
        source: entry.source,
      })),
  },
  {
    archive: 'archives/ui-session-tool-records-20261021.tar.gz',
    restored: 'ui-session-tool-records-20261021',
    expectedSha: '06d2e8636bbef29c6bb131bb3605c4f15e679d784137a2bffec5e58d472f5a3b',
    expectedBytes: 6698,
    expectedManifestSha: 'b35e8ae09fd445463dca559b1baa2390dbc3eb26060c0657840656b7315e2156',
    build: (manifest) => [
      ...manifest.records.map((record) => ({
        member: record.file,
        bytes: record.source_length_bytes_including_newline,
        sha256: record.sha256,
        source: `line ${record.source_line_number_1based} offset ${record.source_start_byte_offset_0based} ${record.role} ${record.call_id}`,
      })),
      { member: 'README.md', bytes: null, sha256: null, source: 'package readme' },
    ],
  },
]) {
  const raw = readFileSync(path.join(root, spec.archive))
  const buffer = raw[0] === 0x1f && raw[1] === 0x8b ? gunzipSync(raw) : raw
  const entries = readTar(buffer)
  const manifestEntry = entries.find((entry) => entry.path === 'manifest.json')
  const manifest = JSON.parse(manifestEntry.data.toString('utf8'))
  const pkg = {
    archive: spec.archive,
    packageBytes: raw.length,
    packageSha256: sha(raw),
    packageBytesMatch: raw.length === spec.expectedBytes,
    packageShaMatch: sha(raw) === spec.expectedSha,
    manifestSha256: sha(manifestEntry.data),
    manifestShaMatch: sha(manifestEntry.data) === spec.expectedManifestSha,
    archiveMemberCount: entries.length,
    allMembersRegular: entries.every((entry) => entry.typeflag === '0' || entry.typeflag === '\0'),
    noLinks: entries.every((entry) => !entry.linkname),
    noAbsoluteOrDotDot: entries.every(
      (entry) => !path.isAbsolute(entry.path) && !entry.path.split('/').includes('..'),
    ),
    verified: [],
    mismatches: [],
    rejected: [],
  }
  const declared = spec.build(manifest)
  const byPath = new Map(entries.map((entry) => [entry.path, entry]))
  for (const item of declared) {
    const memberPath = item.member
    if (path.isAbsolute(memberPath) || memberPath.split('/').includes('..')) {
      pkg.rejected.push({ member: memberPath, reason: 'unsafe path' })
      continue
    }
    const entry = byPath.get(memberPath)
    if (!entry) {
      pkg.rejected.push({ member: memberPath, reason: 'absent from archive' })
      continue
    }
    if (entry.typeflag !== '0' && entry.typeflag !== '\0') {
      pkg.rejected.push({ member: memberPath, reason: `non-regular typeflag ${entry.typeflag}` })
      continue
    }
    const archiveSha = sha(entry.data)
    let restoredSha = null
    let restoredBytes = null
    try {
      const restoredPath = path.join(root, spec.restored, memberPath)
      if (!lstatSync(restoredPath).isFile()) throw new Error('not regular file')
      const restored = readFileSync(restoredPath)
      restoredBytes = restored.length
      restoredSha = sha(restored)
    } catch (error) {
      pkg.mismatches.push({ member: memberPath, reason: `restored copy unreadable: ${error.message}` })
      continue
    }
    const shaOk = item.sha256 ? archiveSha === item.sha256 && restoredSha === item.sha256 : true
    const bytesOk = item.bytes ? entry.size === item.bytes && restoredBytes === item.bytes : true
    if (shaOk && bytesOk && archiveSha === restoredSha) {
      pkg.verified.push({ member: memberPath, bytes: restoredBytes, sha256: restoredSha })
    } else {
      pkg.mismatches.push({
        member: memberPath,
        archiveSha,
        manifestSha: item.sha256,
        restoredSha,
        entrySize: entry.size,
        manifestBytes: item.bytes,
        restoredBytes,
      })
    }
  }
  const whitelist = new Set(declared.map((item) => item.member))
  for (const entry of entries) {
    if (entry.path === 'manifest.json') continue
    if (!whitelist.has(entry.path)) pkg.rejected.push({ member: entry.path, reason: 'not on whitelist' })
  }
  pkg.declaredCount = declared.length
  pkg.verifiedCount = pkg.verified.length
  if (
    !pkg.packageBytesMatch ||
    !pkg.packageShaMatch ||
    !pkg.manifestShaMatch ||
    !pkg.allMembersRegular ||
    !pkg.noLinks ||
    !pkg.noAbsoluteOrDotDot ||
    pkg.mismatches.length > 0 ||
    pkg.rejected.length > 0 ||
    pkg.verifiedCount !== declared.length
  ) {
    pkg.ok = false
    report.ok = false
  } else {
    pkg.ok = true
  }
  report.packages.push(pkg)
}

report.totalVerifiedMembers = report.packages.reduce((sum, pkg) => sum + pkg.verifiedCount, 0)
process.stdout.write(JSON.stringify(report, null, 2) + '\n')
process.exit(report.ok ? 0 : 1)
