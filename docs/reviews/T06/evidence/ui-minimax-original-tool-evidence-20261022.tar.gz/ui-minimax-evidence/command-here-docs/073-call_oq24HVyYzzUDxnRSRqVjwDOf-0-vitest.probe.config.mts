import { defineConfig } from 'vitest/config'
export default defineConfig({
  root: '/Users/kyle/Documents/工作/知爻/本体/.worktrees/T06-ui-minimax-review-da37709',
  test: { include: ['out/t06-ui-review-headless/**/*.test.ts'] },
})
