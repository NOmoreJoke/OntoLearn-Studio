/** Read-only probe: record the real browser launch argv on the DEFAULT 1248 registry route (no executablePath). */
import { chromium } from '@playwright/test'

const server = await chromium.launchServer({ headless: true })
const proc = server.process()
console.log('resolved executable:', proc?.spawnfile)
console.log('spawnargs:', JSON.stringify(proc?.spawnargs, null, 2))
await server.close()
