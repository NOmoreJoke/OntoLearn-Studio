/** Read-only diagnostic probe: why did the "检查本地结构" click time out? */
import { createServer } from 'node:http'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { chromium } from '@playwright/test'

const output = process.argv[2]
const files = { '/': 'index.html', '/preview.js': 'preview.js', '/preview.css': 'preview.css' }
const server = createServer(async (request, response) => {
  const filename = files[request.url]
  if (!filename) {
    response.writeHead(404)
    response.end()
    return
  }
  response.setHeader('Content-Type', filename.endsWith('.js') ? 'text/javascript' : filename.endsWith('.css') ? 'text/css' : 'text/html')
  response.end(await readFile(path.join(output, filename)))
})
let browser
try {
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const port = server.address().port
  browser = await chromium.launch({ headless: true })
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  page.setDefaultTimeout(8000)
  const errors = []
  page.on('pageerror', (e) => errors.push(e.message))
  await page.goto(`http://127.0.0.1:${port}/`)

  const btn = page.getByRole('button', { name: '检查本地结构', exact: true })
  const before = await btn.evaluate((el) => ({
    disabled: el.disabled,
    visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
    rect: el.getBoundingClientRect().toJSON(),
  }))
  console.log('BEFORE fill:', JSON.stringify(before))

  await page.getByLabel('唯一事件 ID', { exact: true }).fill('E1')
  await page.getByLabel('事件类型', { exact: true }).fill('alarm')

  const after = await btn.evaluate((el) => ({
    disabled: el.disabled,
    visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
    rect: el.getBoundingClientRect().toJSON(),
  }))
  console.log('AFTER fill: ', JSON.stringify(after))

  // Sample the bounding box across consecutive frames to detect instability.
  const samples = []
  for (let i = 0; i < 6; i += 1) {
    samples.push(await btn.evaluate((el) => JSON.stringify(el.getBoundingClientRect().toJSON())))
    await page.waitForTimeout(120)
  }
  console.log('BOX SAMPLES:', samples.join(' | '))
  console.log('STABLE:', new Set(samples).size === 1)

  // What does the DOM say about context match / disabled state?
  const diag = await page.evaluate(() => {
    const root = document.querySelector('.behavior-workspace')
    const status = document.querySelector('[role="status"]')
    const runBtn = Array.from(document.querySelectorAll('button')).find((b) => b.textContent.includes('在隔离副本中测试'))
    return {
      statusText: status?.textContent,
      runBtnDisabled: runBtn?.disabled,
      pendingNote: document.querySelector('.behavior-pending')?.textContent,
      rootExists: !!root,
      bodyHeight: document.body.scrollHeight,
      scrollY: window.scrollY,
      innerHeight: window.innerHeight,
    }
  })
  console.log('DIAG:', JSON.stringify(diag, null, 2))
  console.log('PAGE ERRORS:', JSON.stringify(errors))

  try {
    await btn.click({ timeout: 5000 })
    console.log('CLICK OK')
  } catch (error) {
    console.log('CLICK FAILED:', error.message.split('\n').slice(0, 12).join('\n'))
  }
  console.log('STATUS AFTER CLICK:', await page.locator('[role="status"]').textContent())
} finally {
  await browser?.close()
  await new Promise((resolve, reject) => server.close((e) => (e ? reject(e) : resolve())))
}
