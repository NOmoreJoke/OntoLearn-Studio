import { describe, expect, it, vi } from 'vitest'
import { BehaviorController } from '../../apps/desktop/src/renderer/src/behavior/controller'
import {
  parseEvents,
  validateDraft,
  type Binding,
  type BehaviorDraft,
  type Catalog,
  type Context,
  type SampleRequest,
} from '../../apps/desktop/src/renderer/src/behavior/model'

const context: Context = {
  projectId: 'P',
  inputVersion: 'V1',
  behaviorVersion: 'B1',
  scopeId: 'isolated-1',
}
const catalog: Catalog = {
  objects: ['T1', 'W-test'],
  classes: ['TestObject', 'Notification'],
  properties: [
    { id: 'P', kind: 'single' },
    { id: 'links', kind: 'multi' },
  ],
  behaviorIds: ['saved'],
}
const draft: BehaviorDraft = {
  id: 'B',
  name: '行为',
  description: '说明',
  trigger: 'alarm',
  conditions: [{ kind: 'equals', object: 'T1', property: 'P', value: { kind: 'boolean', value: false } }],
  actions: [{ kind: 'update', object: 'T1', property: 'P', value: { kind: 'boolean', value: true } }],
  effect: '隔离副本产生通知',
  enabled: true,
  priority: 0,
  version: 1,
}
const event = {
  id: 'E-1',
  type: 'alarm',
  payload: '{"equipment":"T1"}',
  changes: [] as never[],
}
function result(binding: Binding, patch: Record<string, unknown> = {}) {
  return {
    binding,
    runId: 'R1',
    state: 'candidate',
    committed: false,
    freshness: 'current',
    freshnessDetail: '',
    assertionVersion: 'A1',
    inferenceVersion: 'I1',
    semanticsVersion: 'E1',
    conditions: [],
    actions: [],
    diff: { added: [], removed: [] },
    notifications: [],
    error: null,
    ...patch,
  }
}
function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (error: unknown) => void
  const promise = new Promise<T>((a, b) => {
    resolve = a
    reject = b
  })
  return { promise, resolve, reject }
}

describe('PROBE A: capability identity churn while a run is in flight', () => {
  it('records the exact observable state when the host re-creates equivalent callbacks', async () => {
    const gate = deferred<unknown>()
    const runA = vi.fn(() => gate.promise)
    const runB = vi.fn(() => gate.promise)
    const controller = new BehaviorController(context, catalog, draft, { runSample: runA })
    controller.editEvents([event])
    const inflight = controller.run()
    expect(controller.getSnapshot().pending?.kind).toBe('run')

    // Host re-renders and hands back an equivalent capability with new function identities.
    controller.configure(context, catalog, { runSample: runB })

    const snapshot = controller.getSnapshot()
    console.log('PROBE-A after identity churn:', JSON.stringify({
      pending: snapshot.pending,
      cancelling: snapshot.cancelling,
      notice: snapshot.notice,
      result: snapshot.result,
    }))

    // Can the user start a second run while the first is still unresolved?
    const second = controller.run()
    console.log('PROBE-A runSample call count after second run:', runA.mock.calls.length + runB.mock.calls.length)
    expect(runA.mock.calls.length + runB.mock.calls.length).toBeGreaterThan(1)

    gate.resolve(result((runB.mock.calls[0] as [SampleRequest])[0].binding))
    await inflight
    await second
    console.log('PROBE-A final snapshot:', JSON.stringify({
      pending: controller.getSnapshot().pending,
      result: controller.getSnapshot().result?.runId,
      notice: controller.getSnapshot().notice,
    }))
  })
})

describe('PROBE B: mixed payload (reserved key + ordinary business keys)', () => {
  it('records what happens to ordinary keys when one reserved key is present', () => {
    const parsed = parseEvents([
      { ...event, payload: '{"equipment":"T1","level":"high","__proto__":"x"}' },
    ])
    console.log('PROBE-B mixed payload issues:', JSON.stringify(parsed.issues))
    console.log('PROBE-B mixed payload delivered events:', JSON.stringify(parsed.events))
    console.log(
      'PROBE-B ordinary-key payload delivered events:',
      JSON.stringify(parseEvents([{ ...event, payload: '{"equipment":"T1","level":"high"}' }]).events),
    )
    console.log(
      'PROBE-B near-miss keys delivered events:',
      JSON.stringify(
        parseEvents([{ ...event, payload: '{"__proto_value":"a","Constructor":"b","normal":null}' }]).events,
      ),
    )
  })
})

describe('PROBE C/Q: explicit always never masks sibling conditions', () => {
  it('keeps sibling condition validity while allowing always', () => {
    const withAlways = validateDraft(
      { ...draft, conditions: [{ kind: 'always' }, { kind: 'equals', object: 'ghost', property: 'P', value: { kind: 'string', value: '' } }] },
      catalog,
    )
    console.log('PROBE-C always + unknown object issues:', JSON.stringify(withAlways))
    expect(withAlways.length).toBeGreaterThan(0)
    expect(validateDraft({ ...draft, conditions: [{ kind: 'always' }] }, catalog)).toEqual([])
  })
})

describe('PROBE E: create-then-reference inside one draft', () => {
  it('allows same-instance forward reference and rejects unknown targets', () => {
    console.log(
      'PROBE-E create then relate:',
      JSON.stringify(
        validateDraft(
          {
            ...draft,
            actions: [
              { kind: 'create', object: 'N1', classId: 'Notification' },
              { kind: 'relate', object: 'N1', property: 'links', target: 'T1' },
            ],
          },
          catalog,
        ),
      ),
    )
    console.log(
      'PROBE-E relate to never-created object:',
      JSON.stringify(
        validateDraft(
          { ...draft, actions: [{ kind: 'relate', object: 'T1', property: 'links', target: 'N9' }] },
          catalog,
        ),
      ),
    )
  })
})

describe('PROBE G: cancel service returns a mismatched binding', () => {
  it('records the observable state and whether the workspace recovers', async () => {
    const gate = deferred<unknown>()
    let binding!: Binding
    const run = (request: SampleRequest) => {
      binding = request.binding
      return gate.promise
    }
    const controller = new BehaviorController(context, catalog, draft, {
      runSample: run,
      cancelSample: async () => result({ ...binding, requestId: 'someone-elses-request' }, { state: 'cancelled' }),
    })
    controller.editEvents([event])
    const inflight = controller.run()
    await controller.cancel()
    const snapshot = controller.getSnapshot()
    console.log('PROBE-G after mismatched cancel:', JSON.stringify({
      pending: snapshot.pending,
      cancelling: snapshot.cancelling,
      notice: snapshot.notice,
      result: snapshot.result?.state,
    }))
    gate.resolve(result(binding))
    await inflight
    console.log('PROBE-G after original run resolves:', JSON.stringify({
      pending: controller.getSnapshot().pending,
      result: controller.getSnapshot().result?.state,
      notice: controller.getSnapshot().notice,
    }))
  })
})

describe('PROBE L: replay keeps event identity while request identity changes', () => {
  it('keeps the event id stable and only the request id changing', async () => {
    const received: SampleRequest[] = []
    const controller = new BehaviorController(context, catalog, draft, {
      runSample: async (request) => {
        received.push(request)
        return result(request.binding)
      },
    })
    controller.editEvents([{ ...event, id: ' E-1 ' }])
    await controller.run()
    await controller.run()
    console.log('PROBE-L event ids:', JSON.stringify(received.map((r) => r.events[0].id)))
    console.log('PROBE-L request ids distinct:', received[0].binding.requestId !== received[1].binding.requestId)
    console.log('PROBE-L request draft conditions:', JSON.stringify(received[0].draft.conditions))
    console.log('PROBE-L request events payload:', JSON.stringify(received[0].events[0].payload))
  })
})

describe('PROBE M: editing-existing-id exception boundary', () => {
  it('rejects a new id that collides even while another behavior is edited', () => {
    console.log(
      'PROBE-M editing other behavior, colliding id:',
      JSON.stringify(validateDraft({ ...draft, id: 'saved' }, { ...catalog, editingBehaviorId: 'other' })),
    )
    console.log(
      'PROBE-M editing same behavior:',
      JSON.stringify(validateDraft({ ...draft, id: 'saved' }, { ...catalog, editingBehaviorId: 'saved' })),
    )
  })
})

describe('PROBE W: free-text fields are not schema-constrained for sensitive content', () => {
  it('records that detail/reason accept arbitrary text', async () => {
    const controller = new BehaviorController(context, catalog, draft, {
      runSample: async (request) =>
        result(request.binding, {
          actions: [
            {
              eventId: 'E-1',
              behaviorId: 'B',
              index: 0,
              kind: 'update',
              state: 'planned',
              detail: '/Users/kyle/secret/path.sqlite stack trace at Object.<anonymous>',
            },
          ],
        }),
    })
    controller.editEvents([event])
    await controller.run()
    console.log(
      'PROBE-W detail rendered from service:',
      JSON.stringify(controller.getSnapshot().result?.actions[0]?.detail),
    )
  })
})
