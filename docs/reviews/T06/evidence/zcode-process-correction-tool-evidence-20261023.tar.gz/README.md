# 原SID的新后续补正回合：安全只读收证

唯一新回合由实际2944B cover全文哈希定位，非从旧turn或标题猜测：session `session_6f01f2e4b4e2b589b2c21916110aa5f0`，query `01a16542-f5ea-712d-aeaf-7337a10bb799`，turn `turn_7a31dd55-00b5-4ad1-8b1e-bfdd0346cb1e`。最小入口 `minimal-manifest.json`。

正式生命周期仅取单数log `zcode-2026-10-23.jsonl` 中本SID+本新turn的必要started/completed/failed：started `2026-10-22T20:17:29.597Z`；completed `20:25:31.622Z`，原行487B/SHA `f6701a324a723e572c766349e6b8c8e7a36568c501b4468f9b936c9039ff8346`。旧原turn19:33:57完成的事实未改变。新final来自source90，2287B/SHA `9061af2cacd6b0766de8bccc00e56563f3079ec90c1dd6a7c343b11a691206ef`，不以source completion或title冒官方终态。

补正文已全文读完并原样保全：`process-addendum-current-exact.md`，14233B/SHA `8a0d249da4001b984a90527fb955ca6f509de480b2b0fca23c08983b7fa09635`。单次Write与当前原件精确相等，无collector改写/格式化。作者维持私有S1 Pass、P2-1机制修复、P2-2风险/Q5/容量及父门开放；承认旧首败、tail证据缺口及原oracle/差分/peak表述问题；流程门是否关闭明确交总控。所有原意见及final全文保留，不由收证者改结论。

实际输入：`initial-new-turn-acceptance-proof.json`与`actual-attachment-body-proof.json`。官方paste/主派发/own新完整输入均86756B/SHA `be79cb305a4c3ed7f2056def3e9ccbf8628e8fec0fb148ec66edc78d1a92fc4a`。实际新请求user142为2944B cover/SHA `179939a28d73142e3b0467293e61d23be3e604141e78c8d5286708d32b804a7c`；attachment143连续编号1–491，最后491行真实为空。直接剥离**实际**编号重建86756B，实有末LF，与实际paste字节相等，没有补expected LF。只导出该精确附件块，无周边system。实际GLM-5.3/thinking enabled/effort max；fresh yolo为owner的UI读回来源，本收证未读global config或完整startup。

1905B更正、3292B v2索引、3063B固定snapshot、3403B更正JSON均有实际全文Read，去编号与精确新文件字节/SHA相等；原件另存`accepted-support/`。新snapshot不套旧2242B身份，不证明原turn完成缺失步骤。receipt的更正JSON SHA存在一个字符误写（…f8f99cef…，真实为…f8f98cef…）；双方仍为64位，实际文件和Read身份正确。

实际新增覆盖按方式分账，见 `owned-supplement-read-methods.json`：28份声明补读中，20份完整精确textRead，1份历史R1 input为部分Read加与完整Z input的diff比较，3份dispatch为diff比较，4份JSON为程序化parse/摘要。完整收到491行inline附件与显式文件Read1–269/491也分别列明，不抹掉完整受理，也不把显式文件Read虚写为全行返回。613→3be原25–39缺口通过本新回合sed20–45的完整literal返回补读；16项UI类别/bytes/SHA/Git相等和4个binary tar/hash/member metadata有实际新命令及JSON原件，未执行归档脚本。分类15旧流程+28新流程+16UI+4binary=63，另有13产品来源才为76；作者原文计数标签需分开理解。后续读取不回填原turn。

新增实际写面偏离已即时报告总控：source63 `call_384ae6fccaa24dc984996cfe` 先写`/tmp/glm53-pc-suffix.md`，在限定新out/补正文之外。精确command874B/SHA `8dde96dddb59ff60d26ea00bf7ce924fcc1fb3565dfbaf9073990f73da4e96cf`、return111B/SHA `dc1711745d4587422ba9f26e62bbec444c34efc6a434f068105e4a0d53864150`和原字段/offset/pointer均在`boundary-events/`。该tmp仅lstat，未读正文/哈希/删除/执行。补正文称证据仅写新out，未披露这一偏离。`isError=false`不当各child0，也不由此推为产品Fail。新回合未观察到isError或leading实际失败信封；无失败不等于所有管道child退出均被独立捕获。

`addendum-evidence-differences.json`逐项保留上述差异和证据边界，并记录v2“14目标逐件重算”未见新独立逐目标重hash命令（实际四个支持文件hash及v2全文Read可证）；不因此要求无变化重算，也不把receipt自身当独立证据。新工具未见产品pytest/check/helper/probe复测、被拒payload重试、旧脚本执行或GUI；新文档Prettier检查实际通过。源工具命令/返回和所有写入版本、metadata、final保持原值。

安全包只含本新turn的47个实际新工具请求及其返回（新context内重复的旧turn工具ID全部排除）、必要模型标量、精确输入块、允许支持原件、补正文/final和新out。完整source行、startup、system/header/thinking/auth/memory/其他session内容均不复制或分享。source-row-index及safe-row重构链以原row offset/length/SHA和JSONpointer绑定，不需导出整行上下文。未知`.mimosa`未读/哈希/删除。`protected-old-public-artifacts-check.json`核旧报告、旧out原件和旧封包未变；旧私有raw未访问/修改。

分享包和逐成员读回结果见`package-receipt.json`，成员bytes/SHA见`shareable-file-manifest.json`。本collector仅做标准库只读解析/比字节/数据封包，无模型发信/新任务/runtime/CUA/产品执行；脚本不入分享包。
