from pathlib import Path
import hashlib,json,re
R=Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_t06_s1_r2/minimax');O=Path('out/minimax-r2-process-review')
def h(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def rd(p):return json.loads((R/p).read_text())
tools=rd('native-snapshots/20261022T193910Z/tools.json');artifacts=rd('native-artifact-index/20261022T194006Z-artifacts.json')['files'];versions=rd('native-script-report-version-index.json')['versions'];verified=[]
for item in artifacts+versions:
 p=R/item['archive_path'];r=rec(p);assert r['bytes']==item['bytes'] and r['sha256']==item['sha256'];verified.append(r)
sourcecoverage=rd('native-source-read-coverage-progress.json')['sources'];rows=[]
for source in sourcecoverage:
 fixed=Path(source['path']).read_bytes();assert h(fixed)==source['local_sha256'];expected=fixed.decode().splitlines();received={};callids=[]
 for call in tools:
  if call['name']!='read' or not call['arguments']['path'].endswith('/'+source['path']):continue
  callids.append(call['call_id']);result=call.get('result')or{};text='\n'.join(x.get('text','') for x in result.get('content',[]) if x.get('type')=='text')
  for line in text.split('\n'):
   m=re.match(r'^\s*(\d+)→(.*)$',line)
   if m:
    n=int(m[1]);assert expected[n-1]==m[2],(source['path'],n);received[n]=m[2]
 if source['path'].endswith('counterexamples.json'):
  method='line54 full author recreation, raw diff exit1; line58 both full parse + all9 request/expected canonical SHA equal; allowed by frozen input'
 else:
  assert set(received)==set(range(1,len(expected)+1)),(source['path'],len(received),len(expected));method='full numbered native read union, exact line text independently checked'
 rows.append({'source':source['path'],'bytes':len(fixed),'sha256':h(fixed),'method':method,'read_calls':callids,'visible_lines':len(received)})
report=rec(R/'original-final-report.md');assert report['bytes']==36822 and report['sha256']=='18302fc1f3c267025b0a1435931792301c63140134a1dd03197587e0e1d22b6a'
final=rec(R/'native-final-response.md');assert final['sha256']=='c280bcd4a53c5e08da21c39a7ada6816ac1ae9d5e96b086460fcb389c577273e'
finalresult=next(x for x in artifacts if x['source'].endswith('adversarial-result.json'));data=json.loads((R/finalresult['archive_path']).read_text());assert data['total']==34 and data['failed']==0 and data['crashes']==[]
sectioncounts={x:sum(c['check'].startswith(x) for c in data['checks']) for x in ['A','B','C']}
failedrun=next(c for c in tools if c['source_line']==151 and c['name']=='bash');rt='\n'.join(x.get('text','') for x in failedrun['result']['content'] if x.get('type')=='text');failednames=[line for line in rt.splitlines() if line.startswith('FAILED:')]
index=rd('native-command-execution-index.json')['calls'];diffreads=[{'line':c['source_line'],'call_id':c['call_id'],'path':c['arguments']['path']} for c in tools if c['name']=='read' and 'diff' in c['arguments']['path']]
summary={'snapshot':'20261022T193910Z','native_tool_calls':len(tools),'command_task_calls':len(index),'verified_artifact_and_script_versions':len(verified),'report':report,'final':final,'sources13':rows,'adversarial_final':{'total':data['total'],'failed':data['failed'],'crashes':data['crashes'],'section_counts':sectioncounts,'json':rec(R/finalresult['archive_path'])},'seven_fail_group_output':failednames,'diff_Read_requests':diffreads,'verified_files':verified,'safety':'Only filtered own-M native tools/returns/artifacts and own fixed source13 read; no product/script executed, no model/task message, no CUA, no source/report mutation.'}
(O/'evidence-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:summary[k] for k in ['native_tool_calls','command_task_calls','verified_artifact_and_script_versions','report','final','adversarial_final','seven_fail_group_output','diff_Read_requests']},ensure_ascii=False,indent=2))
