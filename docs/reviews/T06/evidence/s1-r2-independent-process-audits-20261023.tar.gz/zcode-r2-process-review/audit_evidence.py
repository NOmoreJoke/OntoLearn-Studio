from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/Users/kyle/Documents/工作/知爻/本体/outputs/20261023_t06_s1_r2/zcode')
OUT=Path('out/zcode-r2-process-review')
def sha(b):return hashlib.sha256(b).hexdigest()
def item(path):
 p=Path(path);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def read(name):return json.loads((ROOT/name).read_text())
def text(v):
 if isinstance(v.get('content'),str):return v['content']
 if isinstance(v.get('output'),dict):return v['output'].get('value','')
 return ''
calls=read('calls-and-results.json');bash=read('bash-command-output-index.json');artifacts=read('own-artifacts-manifest.json')+read('own-stdout-manifest.json');recomputed=[]
for row in bash:
 for x in [row['command']]+row['returned_versions']:
  a=item(x['path']);assert a['bytes']==x['bytes'] and a['sha256']==x['sha256'];recomputed.append(a)
for row in artifacts:
 x=row['copy'];a=item(x['path']);assert a['bytes']==x['bytes'] and a['sha256']==x['sha256'];recomputed.append(a)
result_paths=sorted({p for c in calls for p in c['result_files']})
for path in result_paths:
 a=item(path);value=json.loads(Path(path).read_text());canonical=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode();assert sha(canonical)==Path(path).stem.removeprefix('result-');a['canonical_value_sha256']=sha(canonical);recomputed.append(a)
# Independently reconstruct actual Read return bytes, compare fixed product sources in our isolated tree.
validation_call=next(c for c in calls if c['id']=='call_7836a0124fa74630b562c02a')
validation_text=text(json.loads(Path(validation_call['result_files'][0]).read_text()))
decoded='\n'.join(s.split('\t',1)[1] for s in validation_text.split('\n'))
validation=json.loads(decoded);(OUT/'validation-return-decoded.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
source_rows=[]
for source,expected in validation['source_sha256'].items():
 fixed=Path(source).read_bytes();assert sha(fixed)==expected
 c=next((c for c in calls if c['name']=='Read' and c['input']['file_path'].endswith('/'+source)),None)
 if c:
  variants=[]
  for p in c['result_files']:
   value=text(json.loads(Path(p).read_text()));matches=[re.match(r'^(\d+)\t(.*)$',s) for s in value.split('\n')];assert all(matches)
   nums=[int(m[1]) for m in matches];assert nums==list(range(1,len(nums)+1));actual='\n'.join(m[2] for m in matches).encode();assert actual==fixed;variants.append(p)
  source_rows.append({'path':source,'method':'full numbered Read, independently decoded all returned variants','call_id':c['id'],'source_line':c['source_line'],'bytes':len(fixed),'sha256':expected,'all_return_variants_equal':True})
 else:
  assert source=='tests/fixtures/behavior/counterexamples.json'
  source_rows.append({'path':source,'method':'full JSON parsing on line31; author full canonical comparison success line32; explicitly allowed by frozen input','bytes':len(fixed),'sha256':expected,'literal_Read_required':False})
# Record final writer vs report copy and final stop message.
report=(ROOT/'report-current-exact.md').read_bytes();assert len(report)==23001 and sha(report)=='764b62939c30605bfb4d90b56c70469389d3fea5402cf51c3b84dad430290e79'
writer=next(c for c in calls if c['id']=='call_7024ebecd67442a4afd5a2e1');assert writer['input']['content'].encode()==report
# Current 13 source full diff starts from no files at base: product contents are covered even though full diff-reading procedure isn't.
base='5f910b52c69d86a1076b2032e5d3c63e715947f3';product='3be0397faf03de6520c47bf7d86f3dc2fd004287'
owned_status=subprocess.check_output(['git','diff','--name-status',base,product,'--',*validation['source_sha256']]).decode();assert len(owned_status.splitlines())==13 and all(s.startswith('A\t') for s in owned_status.splitlines())
# Diff of predecessor slice was persisted; compare its content and actual received union, without executing it.
log=next(x['copy'] for x in read('own-stdout-manifest.json') if 'call_54f' in x['copy']['path']);diff=Path(log['path']).read_text();lines=diff.split('\n')
diffread=next(c for c in calls if c['id']=='call_9a818fa1d5e741e182cb4409');value=text(json.loads(Path(diffread['result_files'][0]).read_text()));parts=[s.split('\t',1) for s in value.split('\n')];received={int(n):t for n,t in parts};assert all(lines[n-1]==t for n,t in received.items())
preview=next(c for c in bash if c['source_line']==40);previewtext=Path(preview['returned_versions'][0]['path']).read_text();preview_body=previewtext.split('Preview (first 2KB):\n',1)[1].rsplit('\n...\n',1)[0];preview_lines=preview_body.splitlines();exact_preview_full_line_count=0
for index,line in enumerate(preview_lines,1):
 if line==lines[index-1]:exact_preview_full_line_count=index
 else:break
missing=[n for n in range(1,len(lines)+1) if n not in received and n>exact_preview_full_line_count]
summary={'calls':len(calls),'bash':len(bash),'source_coverage':source_rows,'owned13_all_new_at_base':True,'owned_status':owned_status,'report':item(ROOT/'report-current-exact.md'),'writer_equals_report':True,'final':item(ROOT/'finals/assistant-line-58.txt'),'recomputed_evidence_files':len(recomputed),'result_value_files':len(result_paths),'read_predecessor_diff':{'bytes':len(diff.encode()),'sha256':sha(diff.encode()),'full_lines_including_empty':len(lines),'numbered_received_lines':[min(received),max(received)],'preview_full_matching_lines':exact_preview_full_line_count,'unproven_line_numbers_in_this_slice':missing,'limitation':'This is only predecessor613 -> product3be of three selected files, not base -> product all owned diff. Product13 full sources independently received; archived metadata and full diff-reading claim need separate support.'},'all_recomputed':recomputed,'source_scope':'Only collector filtered own-Z tool values, commands/returns/artifacts, frozen input, and fixed own-tree source13; no private model-IO raw/system/thought read, no current-MM read; no product or rejected script executed.'}
(OUT/'evidence-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['calls','bash','owned13_all_new_at_base','report','final','recomputed_evidence_files','result_value_files','read_predecessor_diff']},ensure_ascii=False,indent=2))
