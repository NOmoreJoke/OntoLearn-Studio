"""Reviewer-authored bounded re-measurement of the current 3be0397 implementation.

Re-derives the exact frozen cost inputs (creates-800 and the 1000x1000 decision
matrix) so that the input and full-output digests can be compared byte-for-byte
against the owner baseline recorded in out/review-common-history/evidence/.

Runs only the CURRENT implementation. The old 613 baseline is not re-executed
(131 s for the 800-create case); old/new equivalence for these exact inputs is
already established by the owner's paired runs whose digests are recorded in
validation-3be0397.json and whose preserved stdout this script compares against.

Writes only into out/reviewer-verify/.
"""

import gc
import hashlib
import json
import platform
import sys
import time
import tracemalloc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages/engine/src"))

from ontolearn_engine.behavior import planner as current  # noqa: E402

CORPUS = json.loads((ROOT / "tests/fixtures/behavior/counterexamples.json").read_text())
BASE = next(c["request"] for c in CORPUS["cases"] if c["id"] == "B-06")

OWNER_CREATES_800 = {
    "inputSha256": "400f6c0092085c16fc1060095707e78ee81926be30c43221ca1e85e7723c2da1",
    "fullOutputSha256": "54644b5221148575a4f43395cd479e470e1b0e4a3176b683d22e9736d3cba33c",
    "ownerWallSeconds": 0.636688124970533,
    "ownerBaselineWallSeconds": 131.51580287492834,
}
OWNER_MATRIX_1000 = {
    "inputSha256": "1a0a2c59b5286440a19b3bcb4c5e990f20a1758df125f4a7eb378d006837a782",
    "fullOutputSha256": "0964fe0afbe22f4d337b2fd5aaaa72d5f38f37c99aee7bf7b88f95f49b509f10",
    "ownerWallSeconds": 11.710347583983094,
    "ownerTracedPeakBytes": 340522343,
    "ownerBaselineWallSeconds": 11.62230708298739,
    "ownerBaselineTracedPeakBytes": 345860759,
}


def digest(value):
    result = hashlib.sha256()
    for chunk in json.JSONEncoder(
        ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).iterencode(value):
        result.update(chunk.encode())
    return result.hexdigest()


def event(identity="E1", sequence=0):
    return {
        "id": identity,
        "type": "test",
        "sequence": sequence,
        "version": "1",
        "payload": {"value": "payload"},
        "edits": [],
    }


def definition(identity, actions):
    return {
        "id": identity,
        "name": "n",
        "description": "d",
        "effect": "e",
        "version": "1",
        "enabled": True,
        "priority": 0,
        "trigger": {"event_type": "test"},
        "conditions": [{"op": "always"}],
        "actions": actions,
    }


def build(mode, size):
    import copy

    req = copy.deepcopy(BASE)
    if mode == "creates":
        req["events"] = [{**event(), "payload": {}}]
        initial = [{"property": "status", "value": "S1"}] * 50
        req["behaviors"] = [
            definition(f"B{i}", [{"kind": "create", "object": f"O{i}", "initial": initial}])
            for i in range(size)
        ]
    else:
        behavior_count, event_count = (200, 400) if size == 200 else (1000, 1000)
        req["events"] = [{**event(f"E{i}", i), "payload": {}} for i in range(event_count)]
        req["behaviors"] = [
            {
                **definition(f"B{i}", [{"kind": "notify", "message": "m"}]),
                "trigger": {"event_type": "never"},
            }
            for i in range(behavior_count)
        ]
    return req


def execute(req):
    prepared = current.prepare_events(req)
    derived = prepared.reasoning_input
    derived.pop("state")
    return current.plan_behaviors(
        prepared, {**derived, "version": "derived-v1", "status": "current", "facts": []}
    )


def measure(mode, size):
    req = build(mode, size)
    input_sha = digest(req)
    gc.collect()
    traced = mode == "matrix"
    if traced:
        tracemalloc.start()
    start = time.perf_counter()
    plan = execute(req)
    elapsed = time.perf_counter() - start
    peak = None
    if traced:
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    output_sha = digest(plan)
    checks = {}
    if mode == "matrix":
        offset = 0
        for behavior in sorted(req["behaviors"], key=lambda item: item["id"]):
            for ev in req["events"]:
                assert plan["decisions"][offset] == {
                    "event_id": ev["id"],
                    "behavior_id": behavior["id"],
                    "assertion_version": req["assertion_version"],
                    "reasoning_version": "derived-v1",
                    "conditions": [],
                    "reason": "event_mismatch",
                }
                offset += 1
        assert offset == len(plan["decisions"])
        assert plan["action_trace"] == []
        assert plan["candidate"] == plan["after_events"]
        # Every decision must own an independent conditions container.
        assert len({id(d["conditions"]) for d in plan["decisions"]}) == offset
        checks["independentConditionContainers"] = offset
    else:
        assert len(plan["action_trace"]) == size
        assert all(
            t["effect"] == "changed" and len(t["action"]["initial"]) == 50
            for t in plan["action_trace"]
        )
        assert len(plan["candidate"]["objects"]) == len(req["state"]["objects"]) + size
        assert len(plan["candidate"]["facts"]) == len(req["state"]["facts"]) + size
        checks["sourceActions"] = len(plan["action_trace"])
    return {
        "mode": mode,
        "size": size,
        "inputSha256": input_sha,
        "fullOutputSha256": output_sha,
        "decisions": len(plan["decisions"]),
        "sourceActions": len(plan["action_trace"]),
        "wallSeconds": elapsed,
        "pythonTracedPeakBytes": peak,
        "tracemallocEnabledDuringTime": traced,
        "measurementInterval": (
            "prepare_events + reasoning_input + plan_behaviors; excludes input hashing "
            "and post-run full-output checks/hash"
        ),
        "checks": checks,
    }


def main():
    results = []
    for size in (200, 400, 800):
        result = measure("creates", size)
        result["ownerBaselineWallSeconds"] = {
            200: 8.675141083076596,
            400: 33.184808082995005,
            800: 131.51580287492834,
        }[size]
        results.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
    matrix = measure("matrix", 1000)
    results.append(matrix)
    print(json.dumps(matrix, ensure_ascii=False), flush=True)

    creates800 = next(r for r in results if r["mode"] == "creates" and r["size"] == 800)
    verdict = {
        "creates800": {
            "inputShaMatchesOwner": creates800["inputSha256"]
            == OWNER_CREATES_800["inputSha256"],
            "fullOutputShaMatchesOwner": creates800["fullOutputSha256"]
            == OWNER_CREATES_800["fullOutputSha256"],
            "reviewerWallSeconds": creates800["wallSeconds"],
            "ownerCurrentWallSeconds": OWNER_CREATES_800["ownerWallSeconds"],
            "ownerBaselineWallSeconds": OWNER_CREATES_800["ownerBaselineWallSeconds"],
        },
        "matrix1000": {
            "inputShaMatchesOwner": matrix["inputSha256"] == OWNER_MATRIX_1000["inputSha256"],
            "fullOutputShaMatchesOwner": matrix["fullOutputSha256"]
            == OWNER_MATRIX_1000["fullOutputSha256"],
            "reviewerWallSeconds": matrix["wallSeconds"],
            "ownerCurrentWallSeconds": OWNER_MATRIX_1000["ownerWallSeconds"],
            "reviewerTracedPeakBytes": matrix["pythonTracedPeakBytes"],
            "ownerCurrentTracedPeakBytes": OWNER_MATRIX_1000["ownerTracedPeakBytes"],
            "ownerBaselineTracedPeakBytes": OWNER_MATRIX_1000["ownerBaselineTracedPeakBytes"],
        },
        "createsScaling": [
            {"size": r["size"], "reviewerWallSeconds": r["wallSeconds"]}
            for r in results
            if r["mode"] == "creates"
        ],
        "python": sys.version,
        "platform": platform.platform(),
        "currentPlannerSha256": hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
        "note": (
            "Current implementation only. The frozen 613 baseline was not re-executed; "
            "old/new equality for these exact inputs rests on the owner paired runs whose "
            "digests and preserved stdout are in out/review-common-history/evidence/."
        ),
    }
    out = ROOT / "out/reviewer-verify/measure-current.json"
    out.write_text(json.dumps({"results": results, "verdict": verdict}, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(verdict, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
