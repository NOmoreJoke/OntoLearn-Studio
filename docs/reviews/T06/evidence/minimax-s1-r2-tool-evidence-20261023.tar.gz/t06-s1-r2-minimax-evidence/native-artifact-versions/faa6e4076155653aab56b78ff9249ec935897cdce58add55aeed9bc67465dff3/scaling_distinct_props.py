"""Independent scaling variant: many DISTINCT single-valued properties per create.

The round-1 P2-1 trigger repeated the SAME status slot 50 times. This variant
uses 10 distinct single-valued properties per create, i.e. 10x more distinct
slots and facts, to check the new implementation is not merely tuned for the
repeated-slot shape.
"""
import copy, hashlib, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages/engine/src"))
from ontolearn_engine.behavior import planner as current

CORPUS = json.loads((ROOT / "tests/fixtures/behavior/counterexamples.json").read_text())
BASE = next(c["request"] for c in CORPUS["cases"] if c["id"] == "B-06")

def definition(identity, actions):
    return {"id": identity, "name": "n", "description": "d", "effect": "e", "version": "1",
            "enabled": True, "priority": 0, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

def run(size, props):
    req = copy.deepcopy(BASE)
    req["schema"] = {f"p{i}": {"kind": "literal", "cardinality": "one"} for i in range(props)}
    req["state"] = {"objects": ["X", "Y", "Z"], "facts": [], "notifications": []}
    req["events"] = [{"id": "E1", "type": "test", "sequence": 0, "version": "1", "payload": {}, "edits": []}]
    req["behaviors"] = [definition(f"B{i}", [{"kind": "create", "object": f"O{i}",
        "initial": [{"property": f"p{j}", "value": f"v{j}"} for j in range(props)]}]) for i in range(size)]
    start = time.perf_counter()
    prepared = current.prepare_events(req)
    derived = prepared.reasoning_input; derived.pop("state")
    plan = current.plan_behaviors(prepared, {**derived, "version": "v", "status": "current", "facts": []})
    elapsed = time.perf_counter() - start
    assert len(plan["action_trace"]) == size
    assert len(plan["candidate"]["facts"]) == size * props
    return {"size": size, "props": props, "wallSeconds": elapsed,
            "facts": len(plan["candidate"]["facts"]),
            "sourceActions": len(plan["action_trace"])}

rows = [run(s, 10) for s in (200, 400, 800)]
print(json.dumps(rows, ensure_ascii=False, indent=2))
Path(ROOT / "out/reviewer-verify/scaling-distinct-props.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n")
