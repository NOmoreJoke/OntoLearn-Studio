"""Probe: does the _edit compatibility wrapper silently dedupe unvalidated facts?

_Workspace indexes facts by canonical JSON key. _state() rejects duplicate facts
before any workspace is built in prepare_events, but _edit(state, ...) constructs
a workspace from whatever state the caller passes. This probe checks what the
private wrapper does with a state that _state() would have rejected.
"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages/engine/src"))
from ontolearn_engine.behavior import planner

schema = {"status": {"kind": "literal", "cardinality": "one"}}
classes = []
dup = {"subject": "X", "property": "status", "value": "v"}
state = {"objects": ["X"], "facts": [dict(dup), dict(dup)], "notifications": []}

# 1) _state() on the same state rejects the duplicate.
try:
    planner._state(dict(state), schema, classes)
    print("state-validate: NOT rejected")
except planner.BehaviorError as error:
    print("state-validate reason:", error.reason, "location:", error.location)

# 2) _edit() on the same state.
try:
    planner._edit(state, {"kind": "declare", "object": "Y"}, schema, classes)
    print("edit wrapper: accepted; facts now =", state["facts"], "count =", len(state["facts"]))
except planner.BehaviorError as error:
    print("edit wrapper reason:", error.reason, error.location)

# 3) same-value duplicate facts differing only in list position.
state2 = {"objects": ["X"], "facts": [dict(dup), dict(dup)], "notifications": []}
planner._edit(state2, {"kind": "declare", "object": "Y"}, schema, classes)
print("silently deduped duplicate facts:", len(state2["facts"]))
