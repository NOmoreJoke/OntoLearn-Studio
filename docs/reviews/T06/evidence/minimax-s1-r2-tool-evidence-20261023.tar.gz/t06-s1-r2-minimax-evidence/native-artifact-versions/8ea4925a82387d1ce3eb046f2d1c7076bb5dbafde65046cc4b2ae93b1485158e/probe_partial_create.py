"""Probe: failure evidence for a create edit whose later initial field fails."""
import copy, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages/engine/src"))
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events

req = {
    "scope": {"project_id": "p", "scenario_id": "s", "mode": "sample"},
    "run_id": "r", "round": 1, "base_revision": "rev", "assertion_version": "av",
    "ontology_version": "ov", "rules_version": "rv", "behavior_version": "bv",
    "classes": [],
    "schema": {"status": {"kind": "literal", "cardinality": "one"}},
    "state": {"objects": ["X"], "facts": [], "notifications": []},
    "events": [{"id": "E1", "type": "t", "sequence": 0, "version": "1", "payload": {},
                "edits": [{"kind": "create", "object": "NEW",
                           "initial": [{"property": "status", "value": "ok"},
                                       {"property": "nope", "value": "bad"}]}]}],
    "consumption": {"scope": {"project_id": "p", "scenario_id": "s", "mode": "sample"},
                    "events": [], "instances": []},
    "behaviors": [{"id": "BA", "name": "BA", "description": "d", "effect": "e", "version": "1",
                   "enabled": True, "priority": 0, "trigger": {"event_type": "t"},
                   "conditions": [{"op": "always"}], "actions": [{"kind": "notify", "message": "m"}]}],
}
original = copy.deepcopy(req)
try:
    prepared = prepare_events(req)
    derived = prepared.reasoning_input; derived.pop("state")
    plan_behaviors(prepared, {**derived, "version": "v", "status": "current", "facts": []})
    print("no error")
except BehaviorError as error:
    print("reason:", error.reason, "| location:", error.location)
    print("evidence:", json.dumps(error.evidence, ensure_ascii=False, sort_keys=True))
    print("input unchanged:", req == original)
