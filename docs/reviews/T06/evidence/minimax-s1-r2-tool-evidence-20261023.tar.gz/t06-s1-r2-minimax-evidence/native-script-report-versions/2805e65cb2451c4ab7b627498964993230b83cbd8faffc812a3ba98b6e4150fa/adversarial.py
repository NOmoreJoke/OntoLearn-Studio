"""Reviewer-authored independent adversarial probe for T06-S1 candidate 3be0397.

Read-only against the repository: imports the product modules and a Git-exported
old baseline from out/, never writes into the reviewed tree.

Sections:
  A. Exhaustive first-conflict oracle (independent re-implementation of the old
     global combinations semantics vs planner._first_conflict).
  B. Full-pipeline differential: current planner vs baseline_613.py on randomized
     requests, comparing complete plan JSON or complete reason/location/evidence.
  C. Targeted adversarial negatives against the current implementation.
"""

import copy
import importlib.util
import itertools
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages/engine/src"))

from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events  # noqa: E402
from ontolearn_engine.behavior import planner as current_planner  # noqa: E402

RESULTS = []

_SCHEMA = {
    "status": {"kind": "literal", "cardinality": "one"},
    "other": {"kind": "literal", "cardinality": "one"},
    "tags": {"kind": "literal", "cardinality": "many"},
    "link": {"kind": "relation", "cardinality": "many"},
    "type": {"kind": "class", "cardinality": "many"},
}


def check(name, condition, detail=""):
    RESULTS.append({"check": name, "ok": bool(condition), "detail": str(detail)[:400]})
    if not condition:
        print(f"FAIL {name}: {detail}")
    return bool(condition)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def load_baseline():
    path = ROOT / "out/review-common-history/baseline_613.py"
    spec = importlib.util.spec_from_file_location("baseline_613", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------- section A
def oracle_writes(intents, schema):
    """Independent re-implementation of the single-value write extraction."""
    writes = []
    for intent in intents:
        action = intent["action"]
        if action["kind"] == "set":
            writes.append(
                {
                    "subject": action["subject"],
                    "property": action["property"],
                    "value": action["value"],
                    "intent": intent,
                }
            )
        elif action["kind"] == "create":
            for field in action.get("initial", []):
                if schema[field["property"]]["cardinality"] == "one":
                    writes.append(
                        {
                            "subject": action["object"],
                            "property": field["property"],
                            "value": field["value"],
                            "intent": intent,
                        }
                    )
    return writes


def oracle_first_conflict(intents, schema):
    """Old global combinations semantics, written from the old source contract."""
    writes = oracle_writes(intents, schema)
    for a, b in itertools.combinations(writes, 2):
        left, right = a["intent"], b["intent"]
        if (left["event_id"], left["behavior_id"]) == (right["event_id"], right["behavior_id"]):
            continue
        if (a["subject"], a["property"]) == (b["subject"], b["property"]) and canonical(
            a["value"]
        ) != canonical(b["value"]):
            return a, b
    return None


def section_a():
    schema = {
        "status": {"kind": "literal", "cardinality": "one"},
        "other": {"kind": "literal", "cardinality": "one"},
    }
    instances = [("E1", "BA"), ("E1", "BB"), ("E2", "BA"), ("E2", "BB")]
    values = ["v1", "v2", "v3"]
    mismatch = 0
    compared = 0
    # Exhaustive single-slot sequences up to length 5.
    elements = list(itertools.product(instances, values))
    for length in range(0, 6):
        for combo in itertools.product(elements, repeat=length):
            intents = []
            for index, (instance, value) in enumerate(combo):
                intents.append(
                    {
                        "event_id": instance[0],
                        "behavior_id": instance[1],
                        "action_index": index,
                        "action": {
                            "kind": "set",
                            "subject": "X",
                            "property": "status",
                            "value": value,
                        },
                    }
                )
            expected = oracle_first_conflict(intents, schema)
            actual = current_planner._first_conflict(intents, schema)
            compared += 1
            if (expected is None) != (actual is None):
                mismatch += 1
                continue
            if expected is None:
                continue
            if (expected[0]["intent"], expected[1]["intent"]) != (
                actual[0]["intent"],
                actual[1]["intent"],
            ):
                mismatch += 1
    check(
        "A1 exhaustive single-slot first-conflict equals old combinations",
        mismatch == 0,
        f"compared={compared} mismatch={mismatch}",
    )

    # Two slots: the global minimum (i,j) must win across buckets.
    mismatch2 = 0
    compared2 = 0
    slots = ["status", "other"]
    elements2 = list(itertools.product(instances, values, slots))
    for length in range(0, 4):
        for combo in itertools.product(elements2, repeat=length):
            intents = []
            for index, (instance, value, slot) in enumerate(combo):
                intents.append(
                    {
                        "event_id": instance[0],
                        "behavior_id": instance[1],
                        "action_index": index,
                        "action": {
                            "kind": "set",
                            "subject": "X",
                            "property": slot,
                            "value": value,
                        },
                    }
                )
            expected = oracle_first_conflict(intents, schema)
            actual = current_planner._first_conflict(intents, schema)
            compared2 += 1
            if (expected is None) != (actual is None):
                mismatch2 += 1
                continue
            if expected is None:
                continue
            if (expected[0]["intent"], expected[1]["intent"]) != (
                actual[0]["intent"],
                actual[1]["intent"],
            ):
                mismatch2 += 1
    check(
        "A2 exhaustive two-slot cross-bucket minimum preserved",
        mismatch2 == 0,
        f"compared={compared2} mismatch={mismatch2}",
    )

    # create.initial contributes several writes from one intent (positions advance).
    mismatch3 = 0
    compared3 = 0
    rng = random.Random(20261023)
    for _ in range(40000):
        intents = []
        for index in range(rng.randint(0, 5)):
            kind = rng.choice(["set", "create"])
            instance = rng.choice(instances)
            value = rng.choice(values)
            if kind == "set":
                action = {
                    "kind": "set",
                    "subject": rng.choice(["X", "Y"]),
                    "property": rng.choice(slots),
                    "value": value,
                }
            else:
                action = {
                    "kind": "create",
                    "object": rng.choice(["N1", "N2"]),
                    "initial": [
                        {"property": rng.choice(slots), "value": rng.choice(values)},
                        {"property": rng.choice(slots), "value": rng.choice(values)},
                    ],
                }
            intents.append(
                {
                    "event_id": instance[0],
                    "behavior_id": instance[1],
                    "action_index": index,
                    "action": action,
                }
            )
        expected = oracle_first_conflict(intents, schema)
        actual = current_planner._first_conflict(intents, schema)
        compared3 += 1
        if (expected is None) != (actual is None):
            mismatch3 += 1
            continue
        if expected is None:
            continue
        if (expected[0]["intent"], expected[1]["intent"]) != (
            actual[0]["intent"],
            actual[1]["intent"],
        ):
            mismatch3 += 1
    check(
        "A3 randomized create.initial multi-write first-conflict equals oracle",
        mismatch3 == 0,
        f"compared={compared3} mismatch={mismatch3}",
    )

    # A4 degenerate cross-bucket cases: a late slot conflict must not be hidden by
    # an earlier-closing slot, and a same-instance/different-value chain must not
    # swallow the cross-instance conflict.
    def seq(entries):
        intents = []
        for index, (instance, value, slot) in enumerate(entries):
            intents.append(
                {
                    "event_id": instance[0],
                    "behavior_id": instance[1],
                    "action_index": index,
                    "action": {
                        "kind": "set",
                        "subject": "X",
                        "property": slot,
                        "value": value,
                    },
                }
            )
        return intents

    degenerate = [
        (
            "A4a same-instance different value then cross-instance same value",
            [
                (("E1", "BA"), "v1", "status"),
                (("E1", "BA"), "v2", "status"),
                (("E1", "BB"), "v1", "status"),
            ],
            (1, 2),
        ),
        (
            "A4b late-slot conflict must outrank an earlier-closing other slot",
            [
                (("E1", "BA"), "v1", "status"),
                (("E1", "BA"), "v1", "other"),
                (("E1", "BB"), "v2", "other"),
                (("E1", "BB"), "v2", "status"),
            ],
            (0, 3),
        ),
        (
            "A4c duplicate (instance,value) representatives are collapsed for search only",
            [
                (("E1", "BA"), "v1", "status"),
                (("E1", "BA"), "v1", "status"),
                (("E1", "BA"), "v2", "status"),
                (("E1", "BB"), "v1", "status"),
            ],
            (2, 3),
        ),
    ]
    degenerate_ok = True
    degenerate_detail = []
    for label, entries, expected_pair in degenerate:
        intents = seq(entries)
        expected = oracle_first_conflict(intents, _SCHEMA)
        actual = current_planner._first_conflict(intents, _SCHEMA)
        got = (
            None
            if expected is None
            else (
                next(i for i, w in enumerate(intents) if w is expected[0]["intent"]),
                next(i for i, w in enumerate(intents) if w is expected[1]["intent"]),
            )
        )
        actual_positions = None
        if actual is not None:
            actual_positions = (
                next(i for i, w in enumerate(intents) if w is actual[0]["intent"]),
                next(i for i, w in enumerate(intents) if w is actual[1]["intent"]),
            )
        ok = actual_positions == expected_pair == got
        degenerate_ok = degenerate_ok and ok
        degenerate_detail.append(f"{label}: oracle={got} impl={actual_positions} want={expected_pair}")
    check("A4 degenerate cross-bucket first-pair cases", degenerate_ok, "; ".join(degenerate_detail))


# ---------------------------------------------------------------- section B
def base_request():
    return {
        "scope": {"project_id": "p", "scenario_id": "s", "mode": "sample"},
        "run_id": "run-1",
        "round": 1,
        "base_revision": "rev-1",
        "assertion_version": "av-1",
        "ontology_version": "ov-1",
        "rules_version": "rv-1",
        "behavior_version": "bv-1",
        "classes": ["C1"],
        "schema": {
            "status": {"kind": "literal", "cardinality": "one"},
            "tags": {"kind": "literal", "cardinality": "many"},
            "link": {"kind": "relation", "cardinality": "many"},
            "type": {"kind": "class", "cardinality": "many"},
        },
        "state": {
            "objects": ["X", "Y", "Z"],
            "facts": [
                {"subject": "X", "property": "status", "value": "old"},
                {"subject": "X", "property": "tags", "value": "t1"},
                {"subject": "Y", "property": "link", "value": "Z"},
            ],
            "notifications": [],
        },
        "events": [],
        "consumption": {
            "scope": {"project_id": "p", "scenario_id": "s", "mode": "sample"},
            "events": [],
            "instances": [],
        },
        "behaviors": [],
    }


def random_request(rng):
    req = base_request()
    for index in range(rng.randint(1, 3)):
        req["events"].append(
            {
                "id": f"E{index}",
                "type": "test",
                "sequence": index,
                "version": "1",
                "payload": {"target": rng.choice(["X", "Y", "Z"])},
                "edits": [],
            }
        )
    for index in range(rng.randint(1, 3)):
        actions = []
        for _ in range(rng.randint(1, 3)):
            pick = rng.choice(["set", "add", "create", "notify"])
            if pick == "set":
                actions.append(
                    {
                        "kind": "set",
                        "subject": rng.choice(["X", "Y", "Z"]),
                        "property": "status",
                        "value": rng.choice(["a", "b", 1, True, False, 1.0]),
                    }
                )
            elif pick == "add":
                actions.append(
                    {
                        "kind": "add",
                        "subject": rng.choice(["X", "Y", "Z"]),
                        "property": rng.choice(["tags", "link"]),
                        "value": rng.choice(["t2", "Z", "X"]),
                    }
                )
            elif pick == "create":
                actions.append(
                    {
                        "kind": "create",
                        "object": rng.choice(["N1", "N2", "N3"]),
                        "initial": [
                            {
                                "property": "status",
                                "value": rng.choice(["a", "b", "c"]),
                            }
                        ],
                    }
                )
            else:
                actions.append({"kind": "notify", "message": f"m{index}"})
        req["behaviors"].append(
            {
                "id": f"B{index}",
                "name": f"B{index}",
                "description": "d",
                "effect": "e",
                "version": "1",
                "enabled": rng.choice([True, True, False]),
                "priority": rng.choice([0, 1, -1]),
                "trigger": {"event_type": "test"},
                "conditions": [{"op": "always"}],
                "actions": actions,
            }
        )
    return req


def run_pipeline(module, req):
    try:
        prepared = module.prepare_events(req)
        derived = prepared.reasoning_input
        derived.pop("state")
        derived.update(version="derived-v1", status="current", facts=[])
        return ("plan", module.plan_behaviors(prepared, derived))
    except module.BehaviorError as error:
        return (
            "error",
            {"reason": error.reason, "location": error.location, "evidence": error.evidence},
        )
    except Exception as error:  # unexpected exception type is itself a finding
        return ("unexpected", f"{type(error).__name__}: {error}")


def section_b(baseline):
    rng = random.Random(2026102207)
    plan_cases = 0
    error_cases = 0
    unexpected = []
    mismatches = []
    for index in range(1500):
        req = random_request(rng)
        original = copy.deepcopy(req)
        new_out = run_pipeline(current_planner, req)
        old_out = run_pipeline(baseline, original)
        if new_out[0] == "unexpected" or old_out[0] == "unexpected":
            unexpected.append((index, new_out[0], old_out[0]))
            continue
        if new_out[0] != old_out[0]:
            mismatches.append((index, "kind", new_out[0], old_out[0]))
            continue
        if new_out[0] == "plan":
            plan_cases += 1
            if canonical(new_out[1]) != canonical(old_out[1]):
                mismatches.append((index, "plan"))
        else:
            error_cases += 1
            if canonical(new_out[1]) != canonical(old_out[1]):
                mismatches.append((index, "error", canonical(new_out[1])[:200]))
    check(
        "B1 full-pipeline differential: no unexpected exception",
        not unexpected,
        f"unexpected={unexpected[:5]}",
    )
    check(
        "B2 full-pipeline differential: complete plan/error equal to old baseline",
        not mismatches,
        f"plan={plan_cases} error={error_cases} mismatches={mismatches[:5]}",
    )


# ---------------------------------------------------------------- section C
def simple(actions, objects=("X", "Y", "Z"), facts=None, behaviors=None, events=None):
    req = base_request()
    req["state"] = {
        "objects": list(objects),
        "facts": facts if facts is not None else [],
        "notifications": [],
    }
    req["behaviors"] = behaviors if behaviors is not None else [definition("BA", actions)]
    req["events"] = events if events is not None else [event("E1", 0)]
    return req


def definition(identity, actions, priority=0, conditions=None, trigger=None):
    return {
        "id": identity,
        "name": identity,
        "description": "d",
        "effect": "e",
        "version": "1",
        "enabled": True,
        "priority": priority,
        "trigger": trigger or {"event_type": "test"},
        "conditions": conditions or [{"op": "always"}],
        "actions": actions,
    }


def event(identity, sequence, edits=None, payload=None):
    return {
        "id": identity,
        "type": "test",
        "sequence": sequence,
        "version": "1",
        "payload": payload or {},
        "edits": edits or [],
    }


def execute(req, facts=None):
    prepared = prepare_events(req)
    derived = prepared.reasoning_input
    derived.pop("state")
    return plan_behaviors(
        prepared, {**derived, "version": "derived-v1", "status": "current", "facts": facts or []}
    )


def expect_error(req, reason, name):
    original = copy.deepcopy(req)
    try:
        execute(req)
    except BehaviorError as error:
        evidence = error.evidence
        ok = error.reason == reason and req == original
        if "stage" in evidence:
            # Staged plan/event errors must never publish a candidate, a new
            # consumption or an executed action.
            ok = ok and evidence.get("committed") is False
            ok = ok and "candidate" not in evidence and "consumption" not in evidence
            ok = ok and evidence.get("executed_actions", []) == []
        check(name, ok, f"reason={error.reason} loc={error.location} req_unchanged={req == original}")
        return error
    check(name, False, "no error raised")
    return None


def section_c():
    # C1 typed JSON distinction in cross-instance competition.
    for left, right in ((1, 1.0), (1, True), (False, 0), ("1", 1)):
        req = simple(
            [{"kind": "set", "subject": "X", "property": "status", "value": left}],
            behaviors=[
                definition("BA", [{"kind": "set", "subject": "X", "property": "status", "value": left}]),
                definition("BB", [{"kind": "set", "subject": "X", "property": "status", "value": right}]),
            ],
        )
        expect_error(req, "competing_write", f"C1 typed conflict {left!r} vs {right!r}")
    # C2 same value across instances is idempotent, other actions retained.
    req = simple(
        [{"kind": "set", "subject": "X", "property": "status", "value": 1}],
        behaviors=[
            definition(
                "BA",
                [
                    {"kind": "set", "subject": "X", "property": "status", "value": 1},
                    {"kind": "notify", "message": "one"},
                ],
            ),
            definition(
                "BB",
                [
                    {"kind": "set", "subject": "X", "property": "status", "value": 1},
                    {"kind": "notify", "message": "two"},
                ],
            ),
        ],
    )
    plan = execute(req)
    check(
        "C2 same-value cross-instance keeps both notifications and one fact",
        [n["message"] for n in plan["candidate"]["notifications"]] == ["one", "two"]
        and [f for f in plan["candidate"]["facts"] if f["property"] == "status"]
        == [{"subject": "X", "property": "status", "value": 1}],
        canonical(plan["candidate"]),
    )
    # C3 internal middle overwrite still competes with a peer.
    req = simple(
        [],
        behaviors=[
            definition(
                "BA",
                [
                    {"kind": "set", "subject": "X", "property": "status", "value": "a"},
                    {"kind": "set", "subject": "X", "property": "status", "value": "b"},
                ],
            ),
            definition("BB", [{"kind": "set", "subject": "X", "property": "status", "value": "c"}]),
        ],
    )
    error = expect_error(req, "competing_write", "C3 internal middle write competes")
    if error is not None:
        values = [i["action"]["value"] for i in error.evidence["conflict"]]
        # Old global combinations semantics: the FIRST write of the internal
        # sequence is the left element of the first conflicting pair.
        check("C3b conflict pair matches old global first pair", values == ["a", "c"], values)
        check(
            "C3c conflict pair equals independent oracle",
            [
                (w["intent"]["behavior_id"], w["value"])
                for w in oracle_first_conflict(error.evidence["intents"], _SCHEMA)
            ]
            == [("BA", "a"), ("BB", "c")],
            canonical(error.evidence["conflict"]),
        )
    # C4 delete_object removes incoming relation edges; declare does not restore facts.
    req = simple(
        [{"kind": "notify", "message": "m"}],
        facts=[
            {"subject": "X", "property": "link", "value": "Y"},
            {"subject": "Y", "property": "link", "value": "Z"},
            {"subject": "Y", "property": "tags", "value": "old"},
        ],
        events=[
            event(
                "E1",
                0,
                edits=[
                    {"kind": "delete_object", "object": "Y"},
                    {"kind": "declare", "object": "Y"},
                ],
            )
        ],
    )
    plan = execute(req)
    facts = plan["candidate"]["facts"]
    check(
        "C4 delete removes outgoing + relation incoming edges; declare does not restore",
        facts == []
        and plan["candidate"]["objects"] == ["X", "Y", "Z"],
        canonical(plan["candidate"]),
    )
    # C5 notification id colliding with an existing object id, and object id colliding
    # with an existing notification id.
    req = simple([{"kind": "notify", "id": "X", "message": "m"}])
    expect_error(req, "duplicate_identity", "C5a notify id collides with object id")
    req = simple(
        [{"kind": "notify", "message": "m"}],
        facts=[],
        events=[event("E1", 0, edits=[{"kind": "declare", "object": "N"}])],
        behaviors=[
            definition("BA", [{"kind": "create", "object": "N"}]),
        ],
    )
    expect_error(req, "duplicate_identity", "C5b create id collides with declared/notification id")
    # C6 each decision owns an independent conditions container.
    req = simple(
        [{"kind": "notify", "message": "m"}],
        behaviors=[
            definition("BA", [{"kind": "notify", "message": "a"}]),
            definition("BB", [{"kind": "notify", "message": "b"}]),
        ],
        events=[event("E0", 0), event("E1", 1)],
    )
    plan = execute(req)
    plan["decisions"][0]["conditions"].append({"local": True})
    untouched = all(
        len(d["conditions"]) == 1 for d in plan["decisions"][1:]
    )
    check("C6 decision conditions containers are independent", untouched, canonical(plan["decisions"]))
    # C7 cross-call isolation: a mutated result must not affect a later call.
    first = execute(req)
    first["candidate"]["facts"].append({"subject": "X", "property": "tags", "value": "poison"})
    first["candidate"]["objects"].append("POISON")
    second = execute(req)
    check(
        "C7 cross-call isolation (no shared mutable workspace)",
        "POISON" not in second["candidate"]["objects"]
        and all(f["value"] != "poison" for f in second["candidate"]["facts"]),
        canonical(second["candidate"]),
    )
    # C8 1000 source-action limit counts a create with many initial fields as one action.
    create = {
        "kind": "create",
        "object": {"event_template": "N:{eventId}"},
        "initial": [{"property": "status", "value": "v"} for _ in range(5)],
    }
    req = simple(
        [create],
        behaviors=[definition("BA", [create])],
        events=[event(str(i), i) for i in range(1000)],
    )
    plan = execute(req)
    check(
        "C8a 1000 source actions with 5 initial fields each is accepted",
        len(plan["action_trace"]) == 1000
        and len([f for f in plan["candidate"]["facts"] if f["property"] == "status"]) == 1000,
        len(plan["action_trace"]),
    )
    req["events"].append(event("last", 1000))
    expect_error(req, "action_limit", "C8b 1001 source actions rejected")
    # C9 unknown field / non-finite JSON / lone surrogate.
    req = simple([{"kind": "notify", "message": "m"}])
    req["unexpected"] = 1
    expect_error(req, "invalid_shape", "C9a unknown top-level field rejected")
    req = simple([{"kind": "notify", "message": "m"}])
    req["events"][0]["payload"]["bad"] = float("nan")
    expect_error(req, "invalid_json", "C9b NaN payload rejected")
    req = simple([{"kind": "notify", "message": "m"}])
    req["events"][0]["id"] = "\ud800"
    expect_error(req, "invalid_json", "C9c lone surrogate rejected")
    # C10 template whitelist: only eventId/behaviorId, single substitution, no re-interpretation.
    req = simple(
        [{"kind": "notify", "message": "m", "id": {"event_template": "N:{eventId}:{behaviorId}"}}]
    )
    req["events"][0]["id"] = "{behaviorId}"
    plan = execute(req)
    check(
        "C10 template substitutes once and does not reinterpret inserted text",
        plan["candidate"]["notifications"][0]["id"] == "N:{behaviorId}:BA",
        plan["candidate"]["notifications"][0]["id"],
    )
    req = simple([{"kind": "notify", "message": "m", "id": {"event_template": "{payload.x}"}}])
    expect_error(req, "invalid_expression", "C10b non-whitelisted template placeholder rejected")
    # C11 event source position vs execution order in failure evidence.
    req = simple(
        [{"kind": "notify", "message": "m"}],
        events=[
            event("E2", 10, edits=[{"kind": "set", "subject": "ghost", "property": "status", "value": 1}]),
            event("E1", 0),
        ],
    )
    error = expect_error(req, "invalid_object", "C11 event failure keeps source position")
    if error is not None:
        ev = error.evidence
        check(
            "C11b failure evidence carries original event_index and sequence",
            ev.get("event_index") == 0 and ev.get("event_sequence") == 10 and ev.get("event_id") == "E2",
            canonical(ev),
        )
    # C12 reasoning contradiction on a single-valued slot is rejected.
    req = simple(
        [{"kind": "notify", "message": "m"}],
        facts=[{"subject": "X", "property": "status", "value": "old"}],
    )
    original = copy.deepcopy(req)
    try:
        prepared = prepare_events(req)
        derived = prepared.reasoning_input
        derived.pop("state")
        plan_behaviors(
            prepared,
            {
                **derived,
                "version": "derived-v1",
                "status": "current",
                "facts": [{"subject": "X", "property": "status", "value": "new"}],
            },
        )
        check("C12 reasoning single-value contradiction rejected", False, "no error raised")
    except BehaviorError as error:
        check(
            "C12 reasoning single-value contradiction rejected",
            error.reason == "cardinality_violation" and req == original,
            f"reason={error.reason} loc={error.location}",
        )
    # C13 conditions evaluated on the frozen snapshot, not on later candidate writes.
    req = simple(
        [{"kind": "set", "subject": "X", "property": "status", "value": "on"}],
        facts=[{"subject": "X", "property": "status", "value": "off"}],
        behaviors=[
            definition(
                "BA",
                [{"kind": "set", "subject": "X", "property": "status", "value": "on"}],
                conditions=[
                    {"op": "has", "subject": "X", "property": "status", "value": "off"}
                ],
            )
        ],
    )
    plan = execute(req)
    check(
        "C13 condition uses the pre-action frozen snapshot",
        plan["decisions"][0]["reason"] == "triggered"
        and plan["decisions"][0]["conditions"][0]["satisfied"] is True,
        canonical(plan["decisions"][0]),
    )
    # C14 diff is before -> candidate and includes event-stage changes.
    req = simple(
        [{"kind": "notify", "message": "m"}],
        facts=[{"subject": "X", "property": "status", "value": "before"}],
        events=[
            event(
                "E1",
                0,
                edits=[{"kind": "set", "subject": "X", "property": "status", "value": "after-event"}],
            )
        ],
    )
    plan = execute(req)
    check(
        "C14 diff baseline is before -> candidate (event stage included)",
        plan["diff"]["removed"]
        == [["fact", {"subject": "X", "property": "status", "value": "before"}]]
        and plan["diff"]["added"]
        == [["fact", {"subject": "X", "property": "status", "value": "after-event"}]],
        canonical(plan["diff"]),
    )
    # C15 consumption scope must match exactly.
    req = simple([{"kind": "notify", "message": "m"}])
    req["consumption"]["scope"]["scenario_id"] = "other"
    expect_error(req, "consumption_scope_mismatch", "C15 consumption scope mismatch rejected")
    # C16 peer cannot reference an object created by another instance.
    req = simple(
        [],
        behaviors=[
            definition("BA", [{"kind": "create", "object": "N1"}]),
            definition("BB", [{"kind": "set", "subject": "N1", "property": "status", "value": "x"}]),
        ],
    )
    expect_error(req, "invalid_object", "C16 peer cannot use another instance's create")
    # C17 reasoning facts are visible to conditions (frozen union).
    req = simple(
        [{"kind": "notify", "message": "m"}],
        behaviors=[
            definition(
                "BA",
                [{"kind": "notify", "message": "m"}],
                conditions=[
                    {"op": "has", "subject": "X", "property": "tags", "value": "derived"}
                ],
            )
        ],
    )
    plan = execute(req, facts=[{"subject": "X", "property": "tags", "value": "derived"}])
    check(
        "C17 reasoning facts participate in condition evaluation",
        plan["decisions"][0]["reason"] == "triggered",
        canonical(plan["decisions"][0]),
    )


def main():
    baseline = load_baseline()
    crashes = []
    for name, fn in (
        ("A", section_a),
        ("B", lambda: section_b(baseline)),
        ("C", section_c),
    ):
        try:
            fn()
        except Exception as error:  # a probe crash is itself recorded, never hidden
            crashes.append(f"{name}: {type(error).__name__}: {error}")
            check(f"{name} section completed without probe crash", False, crashes[-1])
    failed = [r for r in RESULTS if not r["ok"]]
    summary = {
        "total": len(RESULTS),
        "failed": len(failed),
        "crashes": crashes,
        "checks": RESULTS,
    }
    out = ROOT / "out/reviewer-verify/adversarial-result.json"
    out.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"total": len(RESULTS), "failed": len(failed), "crashes": crashes}, ensure_ascii=False))
    for entry in failed:
        print("FAILED:", entry["check"], entry["detail"])
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
