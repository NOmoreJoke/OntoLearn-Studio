import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events

CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, edits=None, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": edits or []}
def defn(i, actions, priority=0, conditions=None, enabled=True, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": enabled,
            "priority": priority, "trigger": trigger or {"event_type": "test"},
            "conditions": conditions or [{"op": "always"}], "actions": actions}

out=[]
# Q1: success-path duplicate event (identical content, two array slots) -> which source index?
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E1", 5)]
req["behaviors"] = [defn("BM", [{"kind":"notify","message":"m"}])]
plan = execute(req)
out.append(("Q1_success_duplicate_event_trace", json.dumps(plan["event_trace"]),
            "accepted_has_index=" + str(any("event_index" in a for a in prepare_events(req).document["accepted"]))))

# Q2: duplicate id different content in same batch -> rejected (whole batch)
req = req_of("B-06")
req["events"] = [ev("E1", 0), {**ev("E1", 5), "version":"2"}]
try:
    execute(req); out.append(("Q2_dup_id_diff_content","PLAN_OK",""))
except BehaviorError as e:
    out.append(("Q2_dup_id_diff_content", e.reason, json.dumps(e.evidence)))

# Q3: equal sequence -> tie-break by event id
req = req_of("B-06")
req["events"] = [ev("ZB", 3), ev("ZA", 3)]
req["behaviors"] = [defn("BM", [{"kind":"notify","message":"m"}])]
plan = execute(req)
out.append(("Q3_equal_seq_tiebreak", json.dumps([(t["event_id"]) for t in plan["action_trace"]]), ""))

# Q4: create-vs-set same value across instances (create object already in state)
req = req_of("B-06")
req["events"] = [ev("E1", 0, edits=[{"kind":"create","object":"new"}])]
req["behaviors"] = [defn("BA", [{"kind":"create","object":"new","initial":[{"property":"status","value":"S1"}]}]),
                    defn("BB", [{"kind":"set","subject":"new","property":"status","value":"S1"}])]
try:
    plan = execute(req)
    out.append(("Q4_create_vs_set_same_value", "PLAN_OK", json.dumps(plan["candidate"]["facts"][:3])))
except BehaviorError as e:
    out.append(("Q4_create_vs_set_same_value", e.reason, e.location))

# Q5: PERFORMANCE of conflict scan at the 1000-action limit with multi-field creates
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
init = [{"property": "status", "value": "S1"}, {"property": "level", "value": "High"},
        {"property": "P", "value": True}]
req["behaviors"] = [defn("BA", [{"kind":"create","object":f"O{i}","initial":init} for i in range(1000)])]
t0=time.time(); plan = execute(req); dt=time.time()-t0
out.append(("Q5_perf_1000_creates_3_single_fields", f"{dt:.2f}s", f"actions={len(plan['action_trace'])}"))

# Q6: bigger — 1000 creates x 8 single-cardinality initial fields
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
init8 = [{"property":"status","value":"S1"},{"property":"level","value":"High"},{"property":"P","value":True},
         {"property":"rdf:type","value":"TestObject"},{"property":"equipment","value":"001"},
         {"property":"eventId","value":"E1"}]
req["behaviors"] = [defn("BA", [{"kind":"create","object":f"O{i}","initial":init8} for i in range(1000)])]
t0=time.time()
try:
    plan = execute(req); dt=time.time()-t0
    out.append(("Q6_perf_1000_creates_6_fields", f"{dt:.2f}s", f"actions={len(plan['action_trace'])}"))
except BehaviorError as e:
    dt=time.time()-t0
    out.append(("Q6_perf_1000_creates_6_fields", f"{dt:.2f}s", e.reason))

# Q7: decisions volume (behaviors x events)
req = req_of("B-06")
req["events"] = [ev(f"E{i}", i) for i in range(1000)]
req["behaviors"] = [defn(f"B{j}", [{"kind":"notify","message":"m"}]) for j in range(50)]
t0=time.time(); plan = execute(req); dt=time.time()-t0
out.append(("Q7_decisions_volume", f"{dt:.2f}s", f"decisions={len(plan['decisions'])} traces={len(plan['action_trace'])}"))

for r in out: print(" || ".join(str(x) for x in r))
