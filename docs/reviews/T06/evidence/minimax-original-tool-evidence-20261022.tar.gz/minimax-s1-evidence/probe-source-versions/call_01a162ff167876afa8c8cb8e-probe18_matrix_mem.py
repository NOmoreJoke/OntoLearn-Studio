import copy, json, sys, time, tracemalloc
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
print("=== behaviors x accepted events decision matrix size (planner.py:698-751) ===")
for B, E in ((200, 400), (1000, 1000)):
    req = req_of("B-06")
    req["events"]=[{"id":f"E{j}","type":"test","sequence":j,"version":"1","payload":{},"edits":[]} for j in range(E)]
    req["behaviors"]=[{"id":f"B{i}","name":"n","description":"d","effect":"e","version":"1","enabled":True,
                       "priority":0,"trigger":{"event_type":"test"},"conditions":[{"op":"always"}],
                       "actions":[{"kind":"notify","message":"m"}]} for i in range(B)]
    tracemalloc.start(); t0=time.time()
    p=prepare_events(req); plan_behaviors(p, reasoning(p))
    dt=time.time()-t0; cur, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
    print(f"  behaviors={B} events={E} -> decisions={B*E} peak={peak/1e6:.0f}MB wall={dt:.1f}s")
