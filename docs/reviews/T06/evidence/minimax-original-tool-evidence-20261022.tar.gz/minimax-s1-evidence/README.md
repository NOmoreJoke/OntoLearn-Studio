# MiniMax S1 完整收证

原报告原字节保留：25,539 bytes，SHA-256 `1404505d57ec6310f1a0d62646f63441a03913afd895aaa5772c0166be1f90b5`。作者结论为有条件通过，2 P2 + 4 P3，不构成双 Pass。此包不代作者改报告，不复跑任何探针，不改变受审源码。

`final-response.md` 是真正最终回答全文；`terminal-business-events.json` 与 `stream-boundaries.json` 保留 stop / turn_completed / finished / [DONE] / stream-done。序号0–19356连续，19,355个chunk，解码42,546,357 bytes。

`tools.json` 保留172次完整最终工具参数与返回，`command-index.json` 和 `execution-evidence-index.json` 便于核对命令、实际退出、计时、输出截断与后台任务。99份本线bash后台output.log全字节归档，无缺失。模型原命令已经tail的输出仅有tail，不能恢复未保留的上游stdout；“工具成功/ shell exit 0”不能代替无pipefail管道中Python的真实成功。

`probe-final/` 为24个最终探针；`probe-source-versions/` 为25份实际命令中的初始here-doc版本。后续sed/python修改命令、失败与修正全保留在tools.json；`corpus-repro/`和baseline-probe.json保留本次自有临时材料。所有脚本只静态读取，没有执行。

完整事实差异及失败链在facts-and-differences.json。关键限定：

- 报告引用5096382b…是较早冻结输入；实际唯一派发正文为15,831 bytes / a795b582…，两份原件和实际send-body都保留。
- AGENTS 78df2825…是开始时快照；当前de15f6ce…是后续政策更新，不应当作产品源码漂移。
- npm run check只保留tail -40，CHECK_EXIT=0和1174 Python测试可见。630 TS来自另一次npm test的明确返回，不能声称fullcheck完整stdout已归档。
- probe15后半有unhashable dict、probe22结尾有KeyError；probe23只有header，真实竞争失败证据来自probe24。probe13被主动取消，无已记录数字退出码。其余失败/修正逐链列出。
- probe17的50 initial为同一status=S1槽重复50次；probe18的346MB为tracemalloc traced peak，并非RSS。所有性能数字只是这些输入与当时运行的观测。
- runtime permission GET的bypassPermissions有独立读回；不是session字段。model/effort有本session正式读回。

`outside-read-audit.json` 检查全部172次显式工具行为：未见hook-state或.mimosa文件内容读取。.mimosa只出现在目录metadata；其他工作树/报告文件名可出现在git状态。31次read均为本任务来源或自有输入；精确参数在read-scope.json。显式工具阴性不能证明隐式hook/memory隔离；session memory_policy启用本身也不能证明已接触其他审查意见。内置agent list曾返回persona/systemPrompt，完整返回仅留私有原件，分享版整条返回已剔除。

隐私边界：上级目录private-*和stream-frame-index.json是私有原流/思考/系统/headers材料，0600；绝不进入本可分享tar包。分享包只包含报告、最终回答、工具业务证据与本任务脚本/输出，内置persona返回已去除。manifest.json/SHA256SUMS覆盖包内每件原始字节（清单自身除外）；上层private-manifest.json覆盖私有恢复件。
