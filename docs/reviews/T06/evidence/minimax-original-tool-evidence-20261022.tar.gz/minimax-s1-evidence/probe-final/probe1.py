import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events

CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}

def req_of(case):
    return copy.deepcopy(CASE[case]["request"])

def reasoning(prepared, facts=None):
    r = prepared.reasoning_input
    r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}

def execute(req, facts=None):
    p = prepare_events(req)
    return plan_behaviors(p, reasoning(p, facts))

def ev(i="E1", seq=0, edits=None, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1",
            "payload": payload or {}, "edits": edits or []}

def defn(i, actions, priority=0, conditions=None, enabled=True, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1",
            "enabled": enabled, "priority": priority,
            "trigger": trigger or {"event_type": "test"},
            "conditions": conditions or [{"op": "always"}], "actions": actions}

def create(obj="new", initial=None):
    return {"kind": "create", "object": obj,
            "initial": initial if initial is not None else [
                {"property": "rdf:type", "value": "WorkOrder"},
                {"property": "status", "value": "S1"}]}

results = []

# ---- PROBE A: two DIFFERENT instances create the SAME object with IDENTICAL initial values
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BA", [create("new")]), defn("BB", [create("new")])]
try:
    plan = execute(req)
    results.append(("A_same_object_same_values", "PLAN_OK", json.dumps(plan["candidate"]["objects"])))
except BehaviorError as e:
    results.append(("A_same_object_same_values", e.reason, e.location))

# ---- PROBE B: same behavior, two events -> two instances, same value write
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E2", 1)]
req["behaviors"] = [defn("BM", [{"kind": "set", "subject": "W-test", "property": "status", "value": "S1"},
                                {"kind": "notify", "message": "n"}])]
plan = execute(req)
results.append(("B_two_instances_same_value",
                json.dumps([(n["event_id"], n["behavior_id"]) for n in plan["candidate"]["notifications"]]),
                json.dumps(plan["consumption"]["instances"])))

# ---- PROBE C: create initial with cardinality 'many' property -> not in competition
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BA", [create("new", [{"property": "rdf:type", "value": "WorkOrder"}])]),
                    defn("BB", [create("new", [{"property": "rdf:type", "value": "Other"}])])]
try:
    plan = execute(req)
    results.append(("C_many_cardinality_create", "PLAN_OK",
                    json.dumps([f for f in plan["candidate"]["facts"] if f["subject"] == "new"])))
except BehaviorError as e:
    results.append(("C_many_cardinality_create", e.reason, e.location))

# ---- PROBE D: declared sequence vs input array order divergence
req = req_of("B-06")
req["events"] = [ev("E-first-in-array", 10), ev("E-second-in-array", 0)]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "n"}])]
plan = execute(req)
results.append(("D_declared_seq_vs_array_order",
                json.dumps([(t["event_id"], t["action_index"]) for t in plan["action_trace"]]),
                json.dumps(plan["event_trace"])))

# ---- PROBE E: reasoning facts contradicting single-valued property
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "n"}])]
p = prepare_events(req)
r = reasoning(p, [{"subject": "W-test", "property": "status", "value": "CONTRADICTION"}])
try:
    plan_behaviors(p, r)
    results.append(("E_reasoning_contradiction", "PLAN_OK", ""))
except BehaviorError as e:
    results.append(("E_reasoning_contradiction", e.reason, e.location))

# ---- PROBE F: cross-instance competition where one side is create.initial, other is set
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BA", [create("new", [{"property": "status", "value": "S1"}])]),
                    defn("BB", [{"kind": "set", "subject": "new", "property": "status", "value": "S2"}])]
try:
    execute(req)
    results.append(("F_create_vs_set_competition", "PLAN_OK", ""))
except BehaviorError as e:
    results.append(("F_create_vs_set_competition", e.reason, json.dumps(e.evidence.get("conflict_slot"))))

# ---- PROBE G: notify id collision across two instances of same behavior, explicit id
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E2", 1)]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "n", "id": "FIXED-ID"}])]
try:
    execute(req)
    results.append(("G_notify_id_collision", "PLAN_OK", ""))
except BehaviorError as e:
    results.append(("G_notify_id_collision", e.reason, e.location))

# ---- PROBE H: consumption ledger pre-seeded with event id, then same event re-sent w/ different content
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["consumption"]["events"] = [{"event_id": "E1", "fingerprint": "0"*64}]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "n"}])]
try:
    execute(req)
    results.append(("H_ledger_event_different_content", "PLAN_OK", ""))
except BehaviorError as e:
    results.append(("H_ledger_event_different_content", e.reason, e.location))

for row in results:
    print(" | ".join(str(x) for x in row))
