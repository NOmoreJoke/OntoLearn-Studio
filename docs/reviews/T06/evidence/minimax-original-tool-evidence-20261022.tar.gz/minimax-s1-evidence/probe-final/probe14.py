import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== X1: event_field resolution is payload-value typed, JSON type preserved ===")
req = req_of("B-06"); req["events"]=[ev("E1",0,payload={"b":True,"i":1,"s":"x"})]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}]),
                  defn("BB",[{"kind":"set","subject":"T1","property":"P","value":{"event_field":"b"}}])]
pl = execute(req)
print("  bool payload -> fact value:", json.dumps([f for f in pl["candidate"]["facts"] if f["property"]=="P"]))

print("=== X2: static/dynamic object reference rules ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"NONEXISTENT","property":"status","value":"S1"}])]
try: execute(req); print("  static unknown subject: PLAN_OK (gap!)")
except BehaviorError as e: print("  static unknown subject ->", e.reason, e.location)

print("=== X3: dynamic subject validated at instance resolution ===")
req = req_of("B-06"); req["events"]=[ev("E1",0,payload={"t":"NONEXISTENT"})]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":{"event_field":"t"},"property":"status","value":"S1"}])]
try: execute(req); print("  dynamic unknown subject: PLAN_OK (gap!)")
except BehaviorError as e: print("  dynamic unknown subject ->", e.reason, e.location, "| stage=", e.evidence.get("stage"))

print("=== X4: peer-create not referenceable from another instance ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"made-by-A"}]),
                  defn("BB",[{"kind":"set","subject":"made-by-A","property":"status","value":"S1"}])]
try: execute(req); print("  peer-create reference: PLAN_OK (gap!)")
except BehaviorError as e: print("  peer-create reference ->", e.reason, e.location)

print("=== X5: same-instance own create IS referenceable ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"mine"},
                             {"kind":"set","subject":"mine","property":"status","value":"S1"}])]
pl = execute(req)
print("  own-create reference -> PLAN_OK, facts:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="mine"]))

print("=== X6: multivalue add vs single set cardinality mismatch rejected ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"add","subject":"001","property":"status","value":"S1"}])]
try: execute(req); print("  add on single-cardinality: PLAN_OK (gap!)")
except BehaviorError as e: print("  add on single-cardinality ->", e.reason, e.location)

print("=== X7: template whitelist - unknown placeholder rejected ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":{"event_template":"X-{payload.target}"},"initial":[]}])]
try: execute(req); print("  non-whitelisted placeholder: PLAN_OK (gap!)")
except BehaviorError as e: print("  non-whitelisted placeholder ->", e.reason, e.location)
