import json, time
from itertools import combinations
def _json(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)

print("=== A: conflict-scan cost (planner.py:804) at bounded sizes ===")
for N in (2000, 4000, 8000):
    writes=[{"subject":f"O{i}","property":"status","value":"S1","intent":{"event_id":"E1","behavior_id":"B"}} for i in range(N)]
    t0=time.time(); hit=0
    for a,b in combinations(writes,2):
        if (a["subject"],a["property"])==(b["subject"],b["property"]) and (_json(a["value"])!=_json(b["value"])):
            hit+=1
    dt=time.time()-t0
    print(f"  writes={N} pairs={N*(N-1)//2} -> {dt:.2f}s")

print("=== B: _put rescan cost (planner.py:178) at bounded sizes ===")
for N in (5000, 10000, 20000):
    facts=[{"subject":f"O{i}","property":"status","value":"S1"} for i in range(N)]
    t0=time.time()
    _ = ({"subject":"X","property":"status","value":"S1"} not in {_json(x) for x in facts})
    print(f"  facts={N} one put -> {time.time()-t0:.3f}s")
