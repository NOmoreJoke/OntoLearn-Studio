import json, time
from itertools import combinations
def _json(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)

print("=== isolated cost of the combinations() conflict scan (planner.py:804) ===")
for F, N in ((50,1000),(50,2000)):
    writes=[{"subject":f"O{i}","property":"status","value":"S1","intent":{"event_id":f"E{i}","behavior_id":"B"}} for i in range(N) for _ in range(F)]
    t0=time.time(); n=0
    for a,b in combinations(writes,2):
        if (a["subject"],a["property"])==(b["subject"],b["property"]) and (_json(a["value"])!=_json(b["value"])):
            n+=1
    print(f"  writes={len(writes)} pairs={len(writes)*(len(writes)-1)//2} -> {time.time()-t0:.1f}s (no early exit; all subjects distinct)")

print("=== isolated cost of _put's per-write full-fact _json rescan (planner.py:178) ===")
facts=[{"subject":f"O{i}","property":"status","value":"S1"} for i in range(20000)]
t0=time.time()
for f in facts[:2000]:
    _ = ({"subject":"X","property":"status","value":"S1"} not in {_json(x) for x in facts})
print(f"  2000 puts over 20000 facts -> {time.time()-t0:.1f}s for 2000 of the ~N puts => quadratic in facts")
