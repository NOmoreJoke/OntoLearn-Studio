import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

# U1: exactly 1000 source actions allowed, 1001 rejected
for n in (1000, 1001):
    req = req_of("B-06"); req["events"]=[ev("E1",0)]
    req["behaviors"]=[defn(f"B{i}",[{"kind":"notify","message":"m"}]) for i in range(n)]
    try:
        pl=execute(req); res=f"OK actions={len(pl['action_trace'])}"
    except BehaviorError as e: res=f"{e.reason}"
    print(f"U1 {n} single-action behaviors -> {res}")

# U2: create counts as ONE source action regardless of initial field count
req = req_of("B-06"); req["events"]=[ev("E1",0)]
init=[{"property":"status","value":"S1"}]*50
req["behaviors"]=[defn(f"B{i}",[{"kind":"create","object":f"O{i}","initial":init}]) for i in range(1000)]
try:
    pl=execute(req); print("U2 1000 creates x50 initial -> OK actions=", len(pl["action_trace"]))
except BehaviorError as e: print("U2 1000 creates x50 initial ->", e.reason)

# U3: reasoning staleness / binding / current-version rejections
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}])]
p = prepare_events(req)
r = reasoning(p); r["status"]="stale"
try:
    plan_behaviors(p, r); print("U3 stale status -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U3 stale status ->", e.reason, e.location)
r = reasoning(p); r["binding"]="0"*64
try:
    plan_behaviors(p, r); print("U3 stale binding -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U3 stale binding ->", e.reason, e.location)
r = reasoning(p); r["ontology_version"]="other"
try:
    plan_behaviors(p, r); print("U3 stale ontology -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U3 stale ontology ->", e.reason, e.location)

# U4: unknown field / non-finite JSON / NaN / unicode surrogate rejections
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m","surprise":1}])]
try: execute(req); print("U4 unknown action field -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U4 unknown action field ->", e.reason, e.location)
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}])]
req["state"]["facts"].append({"subject":"T1","property":"P","value":float("nan")})
try: execute(req); print("U4 NaN -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U4 NaN ->", e.reason, e.location)
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}])]
req["state"]["facts"].append({"subject":"T1","property":"P","value":"\ud800"})
try: execute(req); print("U4 lone surrogate -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U4 lone surrogate ->", e.reason, e.location)

# U5: consumption scope mismatch rejected
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["consumption"]["scope"]={"project_id":"other","scenario_id":"B-06","mode":"sample"}
try: execute(req); print("U5 consumption scope -> PLAN_OK (unexpected)")
except BehaviorError as e: print("U5 consumption scope ->", e.reason, e.location)
