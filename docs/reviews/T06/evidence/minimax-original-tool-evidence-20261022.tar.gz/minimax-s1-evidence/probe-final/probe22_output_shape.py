import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
req = req_of("B-06")
req["events"]=[{"id":"E2","type":"test","sequence":5,"version":"1","payload":{},"edits":[]},
               {"id":"E1","type":"test","sequence":1,"version":"1","payload":{},"edits":[]}]
req["behaviors"]=[{"id":"BA","name":"n","description":"d","effect":"e","version":"1","enabled":True,
                   "priority":0,"trigger":{"event_type":"test"},"conditions":[{"op":"always"}],
                   "actions":[{"kind":"notify","message":"m"}]}]
p = prepare_events(req); pl = plan_behaviors(p, reasoning(p))
print("top-level keys:", sorted(pl.keys()))
print("event_trace:", json.dumps(pl["event_trace"]))
print("consumption.events:", json.dumps(pl["consumption"]["events"]))
print("consumption.instances:", json.dumps(pl["consumption"]["instances"]))
print("diff keys:", json.dumps(pl["diff"])[:300])
print("committed:", pl["committed"], "| executed_actions:", pl["executed_actions"])
print("has source index anywhere in output?:",
      "event_index" in json.dumps(pl), "| 'source' in output?:", "source" in json.dumps(pl))
