import copy, json, sys, cProfile, pstats, io
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
req = req_of("B-06")
req["events"]=[{"id":"E1","type":"test","sequence":0,"version":"1","payload":{},"edits":[]}]
init=[{"property":"status","value":"S1"}]*50
req["behaviors"]=[{"id":f"B{i}","name":"n","description":"d","effect":"e","version":"1","enabled":True,
                   "priority":0,"trigger":{"event_type":"test"},"conditions":[{"op":"always"}],
                   "actions":[{"kind":"create","object":f"O{i}","initial":init}]} for i in range(400)]
pr=cProfile.Profile(); pr.enable()
p=prepare_events(req); plan_behaviors(p, reasoning(p))
pr.disable()
s=io.StringIO(); ps=pstats.Stats(pr,stream=s).sort_stats("cumulative"); ps.print_stats(18)
print(s.getvalue()[:3200])
