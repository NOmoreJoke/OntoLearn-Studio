import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": []}
def defn(i, actions, priority=0, etype="test"):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": etype},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== W1: repeated SINGLE-VALUE property inside one create.initial ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[
    {"property":"status","value":"FIRST"},{"property":"status","value":"SECOND"}]}])]
try:
    pl = execute(req)
    print("  single-value repeated -> facts:",
          json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O1"]))
    print("  trace:", json.dumps(pl["action_trace"]))
except BehaviorError as e:
    print("  single-value repeated ->", e.reason, e.location)

print("=== W1b: repeated MULTI-VALUE property inside one create.initial (contrast) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[
    {"property":"tags","value":"A"},{"property":"tags","value":"B"}]}])]
try:
    pl = execute(req)
    print("  multi-value repeated -> facts:",
          json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O1"]))
except BehaviorError as e:
    print("  multi-value repeated ->", e.reason, e.location)

print("=== P3: cross-instance SAME-VALUE create of the SAME object id ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"SHARED","initial":[{"property":"status","value":"S1"}]}]),
                  defn("BB",[{"kind":"create","object":"SHARED","initial":[{"property":"status","value":"S1"}]}])]
try:
    pl = execute(req); print("  same-value same-object create -> OK objects=", pl["candidate"]["objects"])
except BehaviorError as e:
    print("  same-value same-object create ->", e.reason, e.location)

print("=== P3b: event_trace / accepted on SUCCESS path: is original source index kept? ===")
req = req_of("B-06"); req["events"]=[ev("E1",0), ev("E2",1)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}], etype="test")]
pl = execute(req)
print("  event_trace:", json.dumps(pl.get("event_trace")))
print("  consumption.events:", json.dumps(pl["consumption"]["events"]))
