import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions, pri=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": pri, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}
print("=== cross-instance single-value DIFFERENT value -> whole round rejected ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"T1","property":"status","value":"S1"}]),
                  defn("BB",[{"kind":"set","subject":"T1","property":"status","value":"S2"}])]
p = prepare_events(req)
try:
    plan_behaviors(p, reasoning(p)); print("  PLAN_OK (gap)")
except BehaviorError as e:
    evd=e.evidence
    print("  reason:", e.reason, "| location:", e.location)
    print("  evidence keys:", sorted(evd.keys()))
    print("  conflict_slot:", json.dumps(evd.get("conflict_slot")))
    print("  has candidate:", "candidate" in evd, "| committed:", evd.get("committed"))
    print("  decisions count:", len(evd.get("decisions") or []))
    print("  action_trace:", json.dumps(evd.get("action_trace"))[:150])
