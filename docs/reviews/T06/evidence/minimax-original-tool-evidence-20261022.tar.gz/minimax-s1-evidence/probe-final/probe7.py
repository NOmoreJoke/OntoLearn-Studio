import copy, json, sys, time, tracemalloc
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": []}
def defn(i, actions, priority=0, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": trigger or {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== T1: input request NOT mutated on failure (correct baseline) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"new","initial":[
    {"property":"status","value":"S1"},{"property":"level","value":{"event_field":"missing"}}]}])]
orig = copy.deepcopy(req)
try:
    execute(req)
except BehaviorError as e:
    print("  request unchanged after failure:", req == orig)
    print("  reason/loc:", e.reason, e.location, "| initial_index:", e.evidence.get("initial_index"))

print("=== T2: event_template re-entrancy (single-pass whitelist) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0,payload={"x":"{behaviorId}"})]
req["behaviors"]=[defn("BA",[{"kind":"create","object":{"event_template":"T-{eventId}"},"initial":[]}])]
pl = execute(req)
print("  created object:", [o for o in pl["candidate"]["objects"] if o.startswith("T-")])

print("=== T3: priority desc beats behavior id asc ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"low"}],priority=0),
                  defn("BZ",[{"kind":"notify","message":"high"}],priority=9)]
pl = execute(req)
print("  notification order:", [(n["behavior_id"],n["message"]) for n in pl["candidate"]["notifications"]])

print("=== T4: same-instance sequential update allowed; peer different value rejected ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"W-test","property":"status","value":"S1"},
                             {"kind":"set","subject":"W-test","property":"status","value":"S2"}])]
pl = execute(req)
print("  same-instance sequential ok, final status:",
      [f["value"] for f in pl["candidate"]["facts"] if f["subject"]=="W-test" and f["property"]=="status"])
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"W-test","property":"status","value":"S1"},
                             {"kind":"set","subject":"W-test","property":"status","value":"S2"}]),
                  defn("BB",[{"kind":"set","subject":"W-test","property":"status","value":"S3"}])]
try:
    execute(req); print("  peer different value: PLAN_OK (unexpected)")
except BehaviorError as e:
    print("  peer different value rejected:", e.reason)

print("=== T5: decisions matrix memory at 1000x1000 (no trigger) ===")
req = req_of("B-06")
req["events"] = [ev(f"E{i}", i, typ="other") for i in range(1000)]
req["behaviors"] = [defn(f"B{j}", [{"kind":"notify","message":"m"}]) for j in range(1000)]
tracemalloc.start(); t0=time.time()
try:
    pl = execute(req); res=f"decisions={len(pl['decisions'])}"
except BehaviorError as e: res=f"err {e.reason}"
cur, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
print(f"  -> {time.time()-t0:.2f}s {res} peak={peak/1e6:.1f}MB")
