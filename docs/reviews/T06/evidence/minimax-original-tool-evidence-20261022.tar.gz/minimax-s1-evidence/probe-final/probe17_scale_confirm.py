import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
print("=== end-to-end: N creates x 50 single-value initial (end-to-end wall clock) ===")
for N in (200, 400, 800):
    req = req_of("B-06")
    req["events"]=[{"id":"E1","type":"test","sequence":0,"version":"1","payload":{},"edits":[]}]
    init=[{"property":"status","value":"S1"}]*50
    req["behaviors"]=[{"id":f"B{i}","name":"n","description":"d","effect":"e","version":"1","enabled":True,
                       "priority":0,"trigger":{"event_type":"test"},"conditions":[{"op":"always"}],
                       "actions":[{"kind":"create","object":f"O{i}","initial":init}]} for i in range(N)]
    t0=time.time(); p=prepare_events(req); plan_behaviors(p, reasoning(p)); dt=time.time()-t0
    print(f"  creates={N} x50 initial -> {dt:.1f}s")
