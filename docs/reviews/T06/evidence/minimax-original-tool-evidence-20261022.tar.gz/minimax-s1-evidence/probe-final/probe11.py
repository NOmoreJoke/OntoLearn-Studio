import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== W1: duplicate property inside ONE create.initial (single-cardinality) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O","initial":[
    {"property":"status","value":"FIRST"},{"property":"status","value":"SECOND"}]}])]
pl = execute(req)
print("  facts on O:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O"]))
print("  -> duplicate slot silently LAST-WINS (no error)")

print("=== W2: duplicate property inside one create.initial (many-cardinality) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O","initial":[
    {"property":"rdf:type","value":"WorkOrder"},{"property":"rdf:type","value":"TestObject"}]}])]
pl = execute(req)
print("  facts on O:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O"]))

print("=== W3: same-value cross-instance create + per-instance notify: are other actions preserved? ===")
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[{"kind":"create","object":"new","initial":[
                            {"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S1"}]},
                           {"kind":"notify","message":"m"}])]
try:
    pl = execute(req)
    print("  PLAN_OK notifications:", len(pl["candidate"]["notifications"]))
except BehaviorError as e:
    print("  FAILED:", e.reason, "|", e.location, "| notifications preserved:", "candidate" in e.evidence)

print("=== W4: same-value cross-instance create using instance_id (distinct identities) + notify ===")
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[{"kind":"create","object":{"instance_id":"W"},"initial":[
                            {"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S1"}]},
                           {"kind":"notify","message":"m"}])]
pl = execute(req)
print("  PLAN_OK objects:", [o for o in pl["candidate"]["objects"] if o.startswith("W:")],
      "notifications:", len(pl["candidate"]["notifications"]))
