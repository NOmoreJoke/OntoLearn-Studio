import copy, json, sys, hashlib
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
from ontolearn_engine.behavior.baseline_adapter import adapt_case, load_bundle, project_candidate, RDF_TYPE
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, edits=None, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": edits or []}
def defn(i, actions, priority=0, conditions=None, enabled=True, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": enabled,
            "priority": priority, "trigger": trigger or {"event_type": "test"},
            "conditions": conditions or [{"op": "always"}], "actions": actions}
def create(obj, initial=None):
    return {"kind":"create","object":obj,"initial":initial if initial is not None else
            [{"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S1"}]}

print("=== F1: cross-instance SAME-VALUE create of same object identity ===")
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[create("new")])]
try:
    pl = execute(req)
    print("F1 PLAN_OK objects=", json.dumps(pl["candidate"]["objects"]),
          "notifications=", json.dumps(pl["candidate"]["notifications"]))
except BehaviorError as e:
    print("F1 FAILED reason=", e.reason, "loc=", e.location,
          "evidence_keys=", sorted(e.evidence.keys()),
          "committed=", e.evidence.get("committed"),
          "has_candidate=", "candidate" in e.evidence)

print("=== F2: cross-instance DIFFERENT-value create of same object identity ===")
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[create("new",[{"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S1"}])]),
                  defn("BM2",[create("new",[{"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S2"}])])]
try:
    execute(req); print("F2 PLAN_OK")
except BehaviorError as e:
    print("F2 reason=", e.reason, "conflict_slot=", json.dumps(e.evidence.get("conflict_slot")))

print("=== F3: cross-instance same-value create, DIFFERENT objects (instance_id) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[create({"instance_id":"W"},[{"property":"rdf:type","value":"WorkOrder"},{"property":"status","value":"S1"}])])]
try:
    pl = execute(req)
    print("F3 PLAN_OK objects=", json.dumps(pl["candidate"]["objects"]),
          "notifications=", len(pl["candidate"]["notifications"]))
except BehaviorError as e:
    print("F3 FAILED", e.reason, e.location)

print("=== F4: declared sequence vs array order for action execution ===")
req = req_of("B-06"); req["events"]=[ev("E-M4",1),ev("E-M3",0)]
req["behaviors"]=[defn("BM",[{"kind":"notify","message":"m"}])]
pl = execute(req)
print("F4 trace=", json.dumps([(t["event_id"],t["action_index"]) for t in pl["action_trace"]]))

print("=== F5: plan['before'] canonicalization vs original input state ===")
req = req_of("B-06")
orig = copy.deepcopy(req["state"])
pl = execute(req)
print("F5 before==orig?", pl["before"]==orig,
      "orig_fact_keys=", list(orig["facts"][0].keys()),
      "plan_fact_keys=", list(pl["before"]["facts"][0].keys()),
      "input_mutated?", req["state"]!=orig)

print("=== F6: LR5 #1 independent reproduction (expanded identity IRI validation) ===")
bundle = load_bundle("out/t09-approved-873c8c0","aaaef2c023320038bc155640566bdc69e0bb862a2836d7cc6ef49f4a632ac39e")
data = bundle.document
model = json.loads(json.dumps(data["G-behavior.json"]))
ns = data["conventions.json"]["namespace"]
for b in model["behaviors"]:
    b["id"] = "bad id"
case = json.loads(json.dumps(data["cases.json"]["cases"][0]))
case["baseline"]="G-behavior"
for k in ("baselineVersion","inputVersion","ruleVersion","behaviorVersion","semanticsVersion"):
    case[k] = model["fixtureVersion"] if k=="baselineVersion" else model[k]
class FakeBundle:
    def __init__(self, d): self.document=d; self.manifest_sha256="x"
fb = FakeBundle({"manifest":data["manifest"], "G-behavior.json":model, "G-base.json":model,
                 "cases.json":{"cases":[case]}, "conventions.json":data["conventions.json"]})
try:
    adapted = adapt_case(fb, case["id"], {"project_id":"p","scenario_id":"s","mode":"sample"}, "r")
    p = prepare_events(adapted["request"])
    pl = plan_behaviors(p, reasoning(p))
    try:
        project_candidate(pl, model, ns)
        print("F6 PROJECTION_SUCCEEDED -- no IRI validation (REGRESSION)")
    except BehaviorError as e:
        print("F6 projection rejected:", e.reason, e.location, "committed=", pl["committed"])
except BehaviorError as e:
    print("F6 earlier rejection:", e.reason, e.location)

print("=== F7: probe reproducibility vs committed evidence canonical hash ===")
mine = json.load(open("/tmp/T06-REVIEWER-61396a5-probe.json"))
canon = hashlib.sha256(json.dumps(mine, ensure_ascii=False, sort_keys=True, separators=(",",":")).encode()).hexdigest()
print("F7 my canonical sha256 =", canon)
print("F7 committed expected    = 0e6d1a210b593c9689612eb56b58ae3ff98a1d4a84ee83dec97fb42c451dbd66")
