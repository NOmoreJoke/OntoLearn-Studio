import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== unbounded initial field count (no cap in _definitions) ===")
for F in (16, 32):
    req = req_of("B-06"); req["events"]=[ev("E1",0)]
    init=[{"property":"status","value":"S1"}]*F   # repeated single-cardinality slot
    req["behaviors"]=[defn("BA",[{"kind":"create","object":f"O{i}","initial":init} for i in range(1000)])]
    t0=time.time()
    try:
        pl=execute(req); res=f"ok actions={len(pl['action_trace'])}"
    except BehaviorError as e: res=e.reason
    print(f"  1000 creates x {F} initial fields (writes~{1000*F}) -> {time.time()-t0:.1f}s {res}")
