import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": []}
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": 0, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}
print("=== failure evidence shape: executed_actions / candidate / consumption ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[{"property":"status","value":"S1"}]}])]
# force a conflict: two instances, same single-value prop, different values
req["behaviors"].append(defn("BB",[{"kind":"set","subject":"O1","property":"status","value":"OTHER"}]))
p = prepare_events(req)
try:
    plan_behaviors(p, reasoning(p))
except BehaviorError as e:
    evd = e.evidence
    print("  reason:", e.reason, "| location:", e.location)
    print("  evidence keys:", sorted(evd.keys()))
    print("  committed:", evd.get("committed"))
    print("  executed_actions:", evd.get("executed_actions"))
    print("  has candidate key:", "candidate" in evd)
    print("  discarded_actions:", json.dumps(evd.get("discarded_actions"))[:200])
    print("  action_trace:", json.dumps(evd.get("action_trace"))[:120])
    print("  consumption:", json.dumps(evd.get("consumption"))[:120])
