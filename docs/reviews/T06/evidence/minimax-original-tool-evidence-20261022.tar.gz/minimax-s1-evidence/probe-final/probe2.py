import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events

CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}

def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, edits=None, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": edits or []}
def defn(i, actions, priority=0, conditions=None, enabled=True, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": enabled,
            "priority": priority, "trigger": trigger or {"event_type": "test"},
            "conditions": conditions or [{"op": "always"}], "actions": actions}

out = []

# P1: same-value cross-instance single write must KEEP both instances' other actions/notifications
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E2", 1)]
req["behaviors"] = [defn("BM", [{"kind": "set", "subject": "W-test", "property": "status", "value": "S1"},
                                {"kind": "notify", "message": "m"}])]
plan = execute(req)
out.append(("P1_same_value_keeps_other_actions",
  json.dumps(plan["candidate"]["notifications"], ensure_ascii=False),
  json.dumps([f for f in plan["candidate"]["facts"] if f["subject"]=="W-test" and f["property"]=="status"])))

# P2: SAME behavior, two events, DIFFERENT values -> must be competing_write (cross-instance)
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E2", 1)]
req["behaviors"] = [defn("BM", [{"kind": "set", "subject": "W-test", "property": "status", "value": "S1"}]),
                    defn("BM2", [{"kind": "set", "subject": "W-test", "property": "status", "value": "S2"}])]
try:
    execute(req); out.append(("P2_diff_behavior_diff_value", "PLAN_OK", ""))
except BehaviorError as e:
    out.append(("P2_diff_behavior_diff_value", e.reason, json.dumps(e.evidence.get("conflict"))))

# P3: same behavior, two events, DIFFERENT values (dynamic per-event value)
req = req_of("B-06")
req["events"] = [ev("E1", 0, payload={"v":"S1"}), ev("E2", 1, payload={"v":"S2"})]
req["behaviors"] = [defn("BM", [{"kind": "set", "subject": "W-test", "property": "status",
                                 "value": {"event_field": "v"}}])]
try:
    execute(req); out.append(("P3_same_behavior_two_events_diff_value", "PLAN_OK", ""))
except BehaviorError as e:
    out.append(("P3_same_behavior_two_events_diff_value", e.reason,
                json.dumps([[c["event_id"],c["behavior_id"]] for c in e.evidence.get("conflict",[])])))

# P4: success-path duplicate event -> is original source index retained anywhere?
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E1", 5)]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "m"}])]
plan = execute(req)
out.append(("P4_success_duplicate_event_trace", json.dumps(plan["event_trace"]),
            json.dumps([p["event"]["id"] for p in prepare_events(req).document["accepted"]])))

# P5: two instances same behavior same event? (eventId,behaviorId) uniqueness
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BM", [{"kind": "notify", "message": "m"}])]
plan = execute(req)
out.append(("P5_instance_uniqueness", json.dumps(plan["consumption"]["instances"]), ""))

# P6: multi-value add same value across instances -> dedup, other actions kept
req = req_of("B-06")
req["events"] = [ev("E1", 0), ev("E2", 1)]
req["behaviors"] = [defn("BM", [{"kind": "add", "subject": "001", "property": "rdf:type", "value": "TestObject"},
                                {"kind": "notify", "message": "m"}])]
plan = execute(req)
out.append(("P6_multivalue_dedup", json.dumps([f for f in plan["candidate"]["facts"] if f["subject"]=="001"]),
            json.dumps([n["message"] for n in plan["candidate"]["notifications"]])))

# P7: notification ORDER must follow E.1 instance order (priority desc, behavior id, seq, event id)
req = req_of("B-06")
req["events"] = [ev("E2", 1), ev("E1", 0)]
req["behaviors"] = [defn("BZ", [{"kind":"notify","message":"z"}], priority=0),
                    defn("BA", [{"kind":"notify","message":"a"}], priority=0)]
plan = execute(req)
out.append(("P7_notification_order", json.dumps([(n["behavior_id"],n["event_id"]) for n in plan["candidate"]["notifications"]]), ""))

# P8: condition evaluated against frozen snapshot (post-event), NOT live candidate
req = req_of("B-06")
req["events"] = [ev("E1", 0, edits=[{"kind":"set","subject":"W-test","property":"status","value":"FROM-EVENT"}])]
req["behaviors"] = [defn("BA", [{"kind":"set","subject":"W-test","property":"status","value":"S1"}]),
                    defn("BB", [{"kind":"notify","message":"m"}],
                         conditions=[{"op":"has","subject":"W-test","property":"status","value":"FROM-EVENT"}])]
plan = execute(req)
out.append(("P8_condition_uses_frozen_post_event", json.dumps([(d["behavior_id"],d["reason"]) for d in plan["decisions"]]), ""))

# P9: reasoning fact is ADDED to frozen snapshot (union) -> condition can see derived fact
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BA", [{"kind":"notify","message":"m"}],
                         conditions=[{"op":"has","subject":"002","property":"rdf:type","value":"HighRiskEquipment"}])]
p = prepare_events(req)
r = reasoning(p, [{"subject":"002","property":"rdf:type","value":"HighRiskEquipment"}])
plan = plan_behaviors(p, r)
out.append(("P9_reasoning_union_condition", json.dumps([(d["behavior_id"],d["reason"]) for d in plan["decisions"]]), ""))

# P10: does a *failed* condition leave zero consumption/candidate in returned data?
req = req_of("B-06")
req["events"] = [ev("E1", 0)]
req["behaviors"] = [defn("BA", [{"kind":"notify","message":"m"}],
                         conditions=[{"op":"has","subject":"missing","property":"status","value":"x"}])]
plan = execute(req)
out.append(("P10_not_triggered_consumption", json.dumps(plan["consumption"]), ""))

for r in out:
    print(" || ".join(str(x) for x in r))
