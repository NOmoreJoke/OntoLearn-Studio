import copy, json, sys, time, resource
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== S1: decisions blowup (behaviors x events) with NO triggering behavior ===")
for nb, ne in ((50, 100), (100, 200), (200, 400)):
    req = req_of("B-06")
    req["events"] = [ev(f"E{i}", i, typ="other") for i in range(ne)]   # type mismatch -> none trigger
    req["behaviors"] = [defn(f"B{j}", [{"kind":"notify","message":"m"}]) for j in range(nb)]
    t0=time.time()
    try:
        pl = execute(req); res=f"decisions={len(pl['decisions'])}"
    except BehaviorError as e:
        res = f"err {e.reason}"
    print(f"  behaviors={nb} events={ne} -> {time.time()-t0:.2f}s {res}")

print("=== S2: writes blowup at the documented 1000-action ceiling, compound create ===")
for F in (4, 8, 16):
    req = req_of("B-06"); req["events"]=[ev("E1",0)]
    init = [{"property":"status","value":"S1"},{"property":"level","value":"High"},
            {"property":"P","value":True},{"property":"eventId","value":"E1"}]
    init = (init * 4)[:F]  # repeat slots to reach F writes
    req["behaviors"]=[defn("BA",[{"kind":"create","object":f"O{i}","initial":init} for i in range(1000)])]
    t0=time.time()
    try:
        pl=execute(req); res=f"ok actions={len(pl['action_trace'])}"
    except BehaviorError as e: res=e.reason
    print(f"  F={F} writes~{1000*F} -> {time.time()-t0:.2f}s {res}")

print("=== S3: error text safety + initial_index on dynamic initial failure ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"new","initial":[
    {"property":"status","value":"S1"},
    {"property":"level","value":{"event_field":"missing"}}]}])]
try:
    execute(req)
except BehaviorError as e:
    print("  text=", str(e), "| reason=", e.reason, "| loc=", e.location,
          "| initial_index=", e.evidence.get("initial_index"),
          "| has_candidate=", "candidate" in e.evidence,
          "| committed=", e.evidence.get("committed"))

print("=== S4: input request not mutated on failure ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
orig = copy.deepcopy(req)
req["behaviors"]=[defn("BA",[{"kind":"create","object":"new","initial":[
    {"property":"status","value":"S1"},{"property":"level","value":{"event_field":"missing"}}]}])]
try:
    execute(req)
except BehaviorError as e:
    print("  request unchanged after failure:", req == orig)
