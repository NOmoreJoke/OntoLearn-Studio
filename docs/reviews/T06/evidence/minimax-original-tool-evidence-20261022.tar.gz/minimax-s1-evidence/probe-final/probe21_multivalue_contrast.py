import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": 0, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}
print("=== multi-value (rdf:type) repeated inside one create.initial -> both kept? ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[
    {"property":"rdf:type","value":"Equipment"},{"property":"rdf:type","value":"HighRiskEquipment"}]}])]
try:
    pl = execute(req)
    print("  facts:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O1"]))
except BehaviorError as e:
    print("  ->", e.reason, e.location)
print("=== multi-value via add action, same instance ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"add","subject":"T1","property":"rdf:type","value":"Equipment"},
                             {"kind":"add","subject":"T1","property":"rdf:type","value":"HighRiskEquipment"}])]
try:
    pl = execute(req)
    print("  facts:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="T1" and f["property"]=="rdf:type"]))
except BehaviorError as e:
    print("  ->", e.reason, e.location)
