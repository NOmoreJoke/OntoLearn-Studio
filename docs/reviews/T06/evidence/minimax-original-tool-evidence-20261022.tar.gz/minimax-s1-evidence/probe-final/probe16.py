import json, time
def _json(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)
print("=== B: _put per-write full-fact rescan (planner.py:178) ===")
for N in (5000, 10000, 20000, 40000):
    facts=[{"subject":f"O{i}","property":"status","value":"S1"} for i in range(N)]
    t0=time.time()
    _ = _json({"subject":"X","property":"status","value":"S1"}) not in {_json(x) for x in facts}
    print(f"  facts={N} one put -> {time.time()-t0:.3f}s")
