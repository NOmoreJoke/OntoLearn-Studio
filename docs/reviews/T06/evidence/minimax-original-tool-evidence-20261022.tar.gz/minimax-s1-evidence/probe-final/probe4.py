import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, edits=None, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": edits or []}
def defn(i, actions, priority=0, conditions=None, enabled=True, trigger=None):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": enabled,
            "priority": priority, "trigger": trigger or {"event_type": "test"},
            "conditions": conditions or [{"op": "always"}], "actions": actions}

print("=== SEMANTIC PROBES ===")
# P1
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[{"kind":"set","subject":"W-test","property":"status","value":"S1"},{"kind":"notify","message":"m"}])]
pl = execute(req)
print("P1_same_value_keeps_other_actions:", json.dumps(pl["candidate"]["notifications"],ensure_ascii=False),
      json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="W-test" and f["property"]=="status"]))
# P2
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[{"kind":"set","subject":"W-test","property":"status","value":"S1"}]),
                  defn("BM2",[{"kind":"set","subject":"W-test","property":"status","value":"S2"}])]
try:
    execute(req); print("P2_diff_value_cross_instance: PLAN_OK")
except BehaviorError as e:
    print("P2_diff_value_cross_instance:", e.reason, json.dumps([[c["event_id"],c["behavior_id"]] for c in e.evidence["conflict"]]))
# P3
req = req_of("B-06"); req["events"]=[ev("E1",0,payload={"v":"S1"}),ev("E2",1,payload={"v":"S2"})]
req["behaviors"]=[defn("BM",[{"kind":"set","subject":"W-test","property":"status","value":{"event_field":"v"}}])]
try:
    execute(req); print("P3_same_behavior_two_events_diff_value: PLAN_OK")
except BehaviorError as e:
    print("P3_same_behavior_two_events_diff_value:", e.reason,
          json.dumps([[c["event_id"],c["behavior_id"]] for c in e.evidence["conflict"]]))
# P5
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BM",[{"kind":"notify","message":"m"}])]
print("P5_instance_uniqueness:", json.dumps(execute(req)["consumption"]["instances"]))
# P6 multivalue dedup
req = req_of("B-06"); req["events"]=[ev("E1",0),ev("E2",1)]
req["behaviors"]=[defn("BM",[{"kind":"add","subject":"001","property":"rdf:type","value":"TestObject"},{"kind":"notify","message":"m"}])]
pl = execute(req)
print("P6_multivalue_dedup:", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="001"]),
      json.dumps([n["message"] for n in pl["candidate"]["notifications"]]))
# P7 notification order by E.1 4-layer key
req = req_of("B-06"); req["events"]=[ev("E2",1),ev("E1",0)]
req["behaviors"]=[defn("BZ",[{"kind":"notify","message":"z"}],priority=0),defn("BA",[{"kind":"notify","message":"a"}],priority=0)]
pl = execute(req)
print("P7_notification_order:", json.dumps([(n["behavior_id"],n["event_id"]) for n in pl["candidate"]["notifications"]]))
# P8 condition sees post-event frozen snapshot
req = req_of("B-06"); req["events"]=[ev("E1",0,edits=[{"kind":"set","subject":"W-test","property":"status","value":"FROM-EVENT"}])]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"W-test","property":"status","value":"S1"}]),
                  defn("BB",[{"kind":"notify","message":"m"}],conditions=[{"op":"has","subject":"W-test","property":"status","value":"FROM-EVENT"}])]
pl = execute(req)
print("P8_condition_uses_frozen:", json.dumps([(d["behavior_id"],d["reason"]) for d in pl["decisions"]]))
# P9 reasoning union
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}],conditions=[{"op":"has","subject":"002","property":"rdf:type","value":"HighRiskEquipment"}])]
p = prepare_events(req); r = reasoning(p,[{"subject":"002","property":"rdf:type","value":"HighRiskEquipment"}])
pl = plan_behaviors(p,r)
print("P9_reasoning_union_condition:", json.dumps([(d["behavior_id"],d["reason"]) for d in pl["decisions"]]))
# P10 not-triggered -> no consumption instance
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"notify","message":"m"}],conditions=[{"op":"has","subject":"W-test","property":"status","value":"NOT-THERE"}])]
pl = execute(req)
print("P10_not_triggered_consumption:", json.dumps(pl["consumption"]))

print("=== CONFLICT SCAN SCALING (N actions, F single-value initial fields each) ===")
for F in (2,4,8,16):
    req = req_of("B-06"); req["events"]=[ev("E1",0)]
    init=[{"property":p,"value":v} for p,v in
          [("status","S1"),("level","High"),("P",True),("eventId","E1")][:min(F,4)]]
    while len(init)<F: init.append({"property":"status","value":"S%d"%len(init)})
    # keep only single-cardinality props: status, level, P, eventId are all 'one'
    req["behaviors"]=[defn("BA",[{"kind":"create","object":"O%d"%i,"initial":init} for i in range(1000)])]
    t0=time.time()
    try:
        pl=execute(req); res=f"ok actions={len(pl['action_trace'])}"
    except BehaviorError as e: res=e.reason
    print(f"F={F} writes~{1000*F} -> {time.time()-t0:.2f}s {res}")
