import copy, json, sys, time
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
from ontolearn_engine.behavior.baseline_adapter import project_candidate, _iri, RDF_TYPE
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test", payload=None):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": payload or {}, "edits": []}
def defn(i, actions, priority=0):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": priority, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== V1 (LR-1 P1 repro): consumed ledger + re-delivered same event = no-op, NOT duplicate_identity ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"const-obj","initial":[{"property":"status","value":"S1"}]}])]
pl1 = execute(req)
print("  round1 objects:", [o for o in pl1["candidate"]["objects"] if o=="const-obj"])
req2 = copy.deepcopy(req)
req2["consumption"] = pl1["consumption"]
req2["state"] = pl1["candidate"]
pl2 = execute(req2)
print("  round2 ok, no duplicate_identity; events consumed:",
      json.dumps(pl2["consumption"]["events"]))

print("=== V2 (LR-5 P2#1 independent repro): project_candidate rejects bad identities ===")
model = json.loads(open("out/t09-approved-873c8c0/tests/fixtures/product-baselines/G-behavior.json").read())
ns = json.load(open("out/t09-approved-873c8c0/tests/fixtures/product-baselines/conventions.json"))["namespace"]
base = {"candidate": {"objects":["urn:x:1"], "facts":[{"subject":"urn:x:1","property":RDF_TYPE,"value":"urn:x:T"}], "notifications":[]},
        "action_trace": [], "consumption": {"scope":{},"events":[],"instances":[]}}
for label, mut in (
    ("bad fact subject", lambda p: p["candidate"]["facts"].append({"subject":"bad subject","property":RDF_TYPE,"value":"urn:x:T"})),
    ("bad fact predicate", lambda p: p["candidate"]["facts"].append({"subject":"urn:x:1","property":"bad pred","value":"urn:x:T"})),
    ("bad notification id", lambda p: p["candidate"]["notifications"].append({"id":"bad id","event_id":"E1","behavior_id":"B","action_index":0,"message":"m"})),
    ("bad notification event", lambda p: p["candidate"]["notifications"].append({"id":"urn:x:N1","event_id":"bad event","behavior_id":"B","action_index":0,"message":"m"})),
):
    p = copy.deepcopy(base); mut(p)
    try:
        project_candidate(p, model, ns); print(f"  {label}: ACCEPTED (gap!)")
    except BehaviorError as e:
        print(f"  {label}: rejected {e.reason}/{e.location}")

print("=== V3: Diff baseline = pre-event request state vs candidate (includes event-stage effects) ===")
req = req_of("B-06")
req["events"]=[ev("E1",0,typ="test",payload={},)]
req["events"][0]["edits"]=[{"kind":"create","object":"EV-1"},{"kind":"set","subject":"EV-1","property":"status","value":"Open"}]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"W-test","property":"status","value":"S1"}])]
pl = execute(req)
added_kinds = sorted({x[0] for x in pl["diff"]["added"]})
print("  diff added categories:", added_kinds, "| after_events has EV-1:", "EV-1" in pl["after_events"]["objects"])
print("  diff includes event-stage fact EV-1/status:",
      any(x[0]=="fact" and x[1]["subject"]=="EV-1" for x in pl["diff"]["added"]))

print("=== V4: worst-case conflict scan at documented 1000-action ceiling ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
init=[{"property":"status","value":"S1"}]*50
req["behaviors"]=[defn(f"B{i}",[{"kind":"create","object":f"O{i}","initial":init}]) for i in range(1000)]
t0=time.time()
try:
    pl=execute(req); print(f"  1000 creates x50 initial (50000 writes) -> {time.time()-t0:.1f}s ok actions={len(pl['action_trace'])}")
except BehaviorError as e: print(f"  -> {time.time()-t0:.1f}s {e.reason}")
