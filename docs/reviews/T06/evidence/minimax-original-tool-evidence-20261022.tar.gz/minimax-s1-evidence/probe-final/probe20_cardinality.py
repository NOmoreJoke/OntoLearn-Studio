import copy, json, sys
sys.path.insert(0, "packages/engine/src")
from ontolearn_engine.behavior import BehaviorError, plan_behaviors, prepare_events
CORPUS = json.loads(open("tests/fixtures/behavior/counterexamples.json").read())
CASE = {c["id"]: c for c in CORPUS["cases"]}
def req_of(c): return copy.deepcopy(CASE[c]["request"])
def reasoning(p, facts=None):
    r = p.reasoning_input; r.pop("state")
    return {**r, "version": "derived-v1", "status": "current", "facts": facts or []}
def execute(req, facts=None):
    p = prepare_events(req); return plan_behaviors(p, reasoning(p, facts))
def ev(i="E1", seq=0, typ="test"):
    return {"id": i, "type": typ, "sequence": seq, "version": "1", "payload": {}, "edits": []}
def defn(i, actions):
    return {"id": i, "name": i, "description": "d", "effect": "e", "version": "1", "enabled": True,
            "priority": 0, "trigger": {"event_type": "test"},
            "conditions": [{"op": "always"}], "actions": actions}

print("=== multi-value property repeated inside one create.initial (contrast) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[
    {"property":"rdf:type","value":"urn:t:A"},{"property":"rdf:type","value":"urn:t:B"}]}])]
try:
    pl = execute(req)
    print("  rdf:type repeated ->", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="O1"]))
except BehaviorError as e:
    print("  rdf:type repeated ->", e.reason, e.location)

print("=== two SET actions on same instance, same single-value prop, DIFFERENT values ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"set","subject":"T1","property":"status","value":"FIRST"},
                             {"kind":"set","subject":"T1","property":"status","value":"SECOND"}])]
try:
    pl = execute(req)
    print("  same-instance two sets ->", json.dumps([f for f in pl["candidate"]["facts"] if f["subject"]=="T1" and f["property"]=="status"]))
    print("  trace effects:", json.dumps([t.get("effect") for t in pl["action_trace"]]))
except BehaviorError as e:
    print("  same-instance two sets ->", e.reason, e.location)

print("=== same, but via two separate create.initial ACTIONS in one instance (different objects) ===")
req = req_of("B-06"); req["events"]=[ev("E1",0)]
req["behaviors"]=[defn("BA",[{"kind":"create","object":"O1","initial":[{"property":"status","value":"FIRST"}]},
                             {"kind":"create","object":"O2","initial":[{"property":"status","value":"SECOND"}]}])]
try:
    pl = execute(req)
    print("  two creates ->", json.dumps([f for f in pl["candidate"]["facts"] if f["property"]=="status" and f["subject"] in ("O1","O2")]))
except BehaviorError as e:
    print("  two creates ->", e.reason, e.location)
