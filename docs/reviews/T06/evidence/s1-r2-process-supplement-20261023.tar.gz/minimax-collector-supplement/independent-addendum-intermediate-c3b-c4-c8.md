# 独立补正文：中间探针失败轮次（原包不变）

原固定包718135B / SHA256 `402085e028cc7486df0722b2d144ba13f3aea5713983f00007060d89798bebbe` 保持不变；作者报告36822B / SHA18302fc1…也不改。此补充只把包内已存在的原返文明确列出。

- 原source line122：`call_01a16518a53a725aa6bef771` 启动缩减范围后的adversarial.py，task `bg_c0c90088-9824-4fb3-b129-dd2faeb9cee6`，首次返回只是started。
- source line127的`call_01a16518d52473e18644422a`（结果line129）与line131的`call_01a16518ffec7656a969a4cc`（结果line132）都真实返回：C3b FAIL（实际[a,c]）、C4 FAIL（实际facts=[]），随后C8抛`BehaviorError: action_limit: behavior.actions`、`EXIT=1`。
- 后一调用明确返回`no result file (crash before write)`，不能将该轮当成有result JSON的完整测试轮；后来34/34结果不能覆盖此轮。
- 前一followup外壳exit1来自最后ps/grep零匹配；后一followup外壳exit0来自fallback echo。原probe exit1由原日志EXIT与traceback独立证明，不能混用外壳退出码。

随后真实probe edit分别修改C3b预期/补oracle、C4删除后的预期、C8由1000行为×1000事件改为1行为×1000事件并用event-template区分对象，另加各section崩溃捕获。完整原调用/返回及old/new edit都在同名JSON，且已在固定包native-tools.json、对应bg日志和首败索引中保全。作者§9未单列此中间轮次，本补充不替作者改写报告、不重跑、不改产品。
