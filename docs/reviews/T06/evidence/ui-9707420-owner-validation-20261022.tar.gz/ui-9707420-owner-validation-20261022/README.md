# 可恢复的owner原始验证证据

新9707420候选的首次完整check、全部headless成功/失败、locator诊断、截图、来源和完整diff可恢复；原始首败不得被后续通过掩盖。

源文件/日志/原工具记录不执行；tracemalloc不是RSS，headless不是原生Electron。源路径/命令/真实exit以原receipt为准。MANIFEST不含自身。
