# T06 992f：原session流程补正收件与有限后继判断

结论：**接收两个真实完成的新补正turn、原稿、独审与安全包；指定双审的流程门仍不能关闭。建议根将本次补正收件结案为“真实完成／过程不通过或未闭”，停止给这两个原任务继续补正。若仍需取得合规的完整指定双审，应准备同一3be候选的两个全新完整独立审查任务，而非再补一个旧任务回合。** 本审不替作者撤回私有S1 Pass、不推导产品算法Fail，也不授新任务/运行票或改state。

## 读取覆盖和固定身份

实际owner树 `.worktrees/T06-behavior`。入口 `docs/reviews/T06/round-2/process-correction-completion-receipt-20261023.json`8415B/SHA `381245b4e6ee89b02c00eb495b9d477bc9b0b4b33a815028d9559f571d380429`，current=固定commit `992f5b4a0369867e2898d85449a55dcbc6f684fa` Git blob。该commit唯一parent为55df1ee0e67c0007e7e942925665a6d2cc7a6e9f，diff-tree仅15件docs/evidence路径，没有产品路径。product3be0397faf03de6520c47bf7d86f3dc2fd004287、base5f910b52c69d86a1076b2032e5d3c63e715947f3分域保持。

所有正式文字均分块**全文已覆盖**：

| 文件 | bytes / SHA256 | 本审完整读取范围 |
| --- | --- | --- |
| zcode-glm53-process-addendum-20261023.md |14233 / 8a0d249da4001b984a90527fb955ca6f509de480b2b0fca23c08983b7fa09635|1–52全部 |
| minimax-m31flash-process-addendum-20261023.md |44073 / ac735a150b1678f4382cc76c456df7d740ab9713eb15e4a32e4003d32b3da82c|1–120、121–240、241–350全部 |
| zcode-process-correction-independent-review-20261023.md |21320 / f8350c67ad8c4a4b93caa5ff20d31b2ab6a4401b6fa13f02b175124b462ac618|1–75、76–146全部 |
| minimax-process-correction-independent-review-20261023.md |18202 / 7ebbf7ddb1c7f09648d141e357d9e103c36281d0509f0dc0ef39f063e47cd33d|1–62、63–121全部 |
| process-correction-owner-disposition-20261023.md |6928 / d7463b4fedc772a17c1688b967b0e4d0dc77e3e496438dac798ddc9ba1416f89|1–49全部 |

两完整终答11/27行亦全文读（2287B/9061af2c…、3536B/e2f890cf…）。上述及入口声明11件当前文件均直接核bytes/SHA且等992f固定Git内容。没有拿独审摘要替两作者原稿全文。本轮这些正式报告分块显示未丢正文；后文一次manifest展示截断属于元数据工具首错，已纠正，不混为正式报告缺读。

## 安全封存与真实终态

直接核三个外层归档current=固定Git、bytes/SHA：

- Z：1100375B，30add7c3eccf4549ee36a5b509775c909887bb6994aa7801e8981ae3967248bc，441唯一regular安全相对成员；其440项shareable清单逐项核存在/size/SHA格式，未重复全585成员body重哈希。
- M：1909883B，a0097231e9eefa860020f938c689b139d9408a0775b96cbd8e271c7d3969fdf5，144唯一regular成员；142项file-manifest逐项核存在/size/SHA格式。owner已完整逐成员hash与143条SHA256SUMS、独审亦已核；本审明确承接这些既有证明。
- 独审包：135762B，5cda9c6d62239dfb5a8953d8ed639abb17ec069bfbf9fa92ce90cdd1f34a0ffb，17唯一regular成员；16声明件本审直接逐件重哈希匹配。包内两completion-review与主目录原件相同，owner protection记录39源/9旧报告输入及AGENTS保护，不冒称本审重新读取39产品源。

仅从这些安全包读取必要精确事件/边界元数据。Z `new-turn-lifecycle.json`严格绑定原SID session_6f01f2e4b4e2b589b2c21916110aa5f0、新query01a16542-f5ea-712d-aeaf-7337a10bb799、新turn turn_7a31dd55-00b5-4ad1-8b1e-bfdd0346cb1e，正式turn.completed为2026-10-22T20:25:31.622Z；20:25:31.344Z只是正文final source时间。M安全`new-original-turn-terminal-receipt.json`596B严格绑定SID mvs_055614846c1142d08810f229513d46ca、新turn6e418fd2-061f-4df6-951c-a9fe6903a1d3，terminal_outcome=completed、updated_at_ms1792700961720（20:29:21.720Z），idle只是辅助。接收已封官方窄回执，没有自行查DB/native历史或把旧turn终态重复算新完成。

本次创建新session=0；每原SID一次补正，不给完整创建计数增量。旧原回合及当前补正真实完成，与流程未通过同时成立。原报告/终答仍是原时点原件；后续事实不能回填原19:33/19:38已完成原门。

## 仍阻断流程关闭的具体事实

### P2流程：新写面偏离且完成声明未披露

Z独审L120–134、owner处置L25及安全边界原命令/返回共同支持：call_384ae6fccaa24dc984996cfe明确`> /tmp/glm53-pc-suffix.md`，超出只准新out/补正文的写面。874B命令SHA8dde96dd…及111B返回SHA dc171174…已从包内精确核对。后半Python只比较授权body与frozen，不能证明tmp正文、管道各child code或完整来源；isError=false/`|| true`不补证。Z原稿L5/L52及终答仍称只新out，遗漏这次偏离。

M独审L69–84、owner L37与安全new-tmp-boundary-events支持：call_01a1654b9c2b7135b458b336实际写/tmp/diff_coverage_table.md，call_01a1654c36d770539573bc4b随后cat。两原命令1409/319B和返回866/6735B，本审从安全副本直接重算相符；host exit0只限所存host，不自造其他child状态。M原稿L21/L338及终答“仅写两处”遗漏它。本审未访问、hash、清理、执行两个物理tmp，不能为证明安全而越界补看。

两项均是有证据的流程违规/披露失败，不能因产品Pass降为已合规，也不因此推定源被改、tmp执行、凭据泄露或算法Fail。旧已记录流程Fail与这次新偏离须分别保留。

### P2流程：完整审读与输入范围仍未由现证据闭合

- Z输入完整inline1–491重建86756B/be79成立；不能说只收到269行。但实际显式Read仅1–170、170–269，原稿L5“全文分段读回”没有完成相同工具步骤。三份历史dispatch只有彼此短diff/head，没有任何完整共同基文（Z独审L71–86）；input不是dispatch，不能循环差分恢复未知共同正文。四JSON确实完整json.load，但backlog/两readback/t09只返回有限摘要/检查，不能据此签所有owned内容全核（独审L88–94）。20份新owned完整Read、M历史input由完整Z input+实际1c1重构、613缺25–39、UI16/binary4的批准metadata核验均可承接，不能抹为全无效，也不能合成原稿L50“全部闭合”。
- M实际附件101720B/b826身份存在，但安全可见Read只1–444/78974B；445–603未捕获=UNKNOWN，不写成“确定未执行”，也不以hidden textFile或模型自述填补（M独审L29–37，原稿L142声称过满）。76行段表可算术闭合1–24034，但方法本身L*26/L31/P4/B4/M11，不是本轮literal全读。31个L项仅30个完整，旧Z dispatch缺8819–8852仍UNKNOWN；非遮盖实际diff可核2694行。完整生成diff文件/hash和全表不替全文审读（独审L39–61，原稿L70/L151/L217）。
- M UI交界call_01a16549ca8075f3a66ec963实际显示9340–9379，交入历史UI块9368–9379共12行。共享redaction清单10处是同一调用重复记录，不能算10次独立越界；隐藏textFile去除。内容性质保持UNKNOWN，不能随作者L38/L225称其仅metadata，更不能打开未遮盖内容来换绿。它是历史UI交界，不自动扩大成读取当前Z peer，也不推定造成何种产品意见影响。

这些是原完整流程门的真实缺证，不新增“所有JSON必须literal dump”政策：结构化核验可以接受其实际覆盖字段，但不能将有限字段检查宣称全部语义已核。M压缩后无授权回溯路线，不能把UNKNOWN写成0，也不再追history-catalog/其他全局来源。

### P3事实精度：保原件，根不得补出Pass

Z独审L45/L49/L107–108指出：receipt正确SHA只有一字符差异，错误值仍64位不是65位；13产品与15旧历史分账，不能把列13产品的“15”标签直接当总数；510跳空为1–8累计；typed conflict oracle的_json不修复末tuple==非类型保真，更不能据未比较字段声称槽/位置全等。139明确JSON断言、1500 canonical是各自有限证据。

M独审L86–113指出：C15应为原报告漏列失败成员，不是那次脚本无该负例；原expect_error对前置空evidence要求committed=false过宽才是原因。wrapper成本“可忽略”原独审恰在拒绝作者自己的暗示，不能改写为独审提出；规范化before须“事件前”，不能混作行为前。prefix首次语义不匹配→修正，native Edit isError=true→后继成功，均保留；Edit无child，不编exit1。作者“唯一8条更正、全部已闭合”不能压住这些及新tmp偏离。根可在控制处置中准确列事实，不能替作者改原文、等级或签结论。

## 产品判断与父门保留

私有产品S1 Pass及M四P3原作者裁决保持，不由流程审强迫改为产品Fail；同样不得由根把二人Pass改称合规完整双审。原4P3未实施建议不写已修。P2-1仅所定位可避免机制与有限输入观察；P2-2仍P2容量风险，tracemalloc非RSS、百万完整B×E必要成本/Q5与设备规模阈值未批准、生产/容量门持续开放，不降验收或分页/裁剪输出求绿。

父FR600–604、真实Store/推理/资源/Agent、正式G.3/完整B用例、native两OS、970UI新任务0、package、人验、CI/远端/push/PR/merge等均未通过；原blocked Goal不重建、reset或完成。补正归档不赋予GUI租约。

## 一次有限后继：停止补正，准备全新完整双审

建议根做如下具体处置，当前仅是控制建议，不是启动票：

1. 将992f原稿/两终态/独审/三个安全包作为**已完成补正收件**固定；原两任务的流程结果保持不通过/未闭，不再向它们发补正消息。旧缺失流、被遮盖12行、压缩缺口永久按现可证程度留UNKNOWN，不再复演被拒操作、追原生历史或操作tmp补洞。
2. 由原owner按一次准备票建立两份fresh独立review环境，冻结同一product3be/base5f及原完整私有S1 scope，保持13产品、原全部验收、历史失败/旧意见/4P3/P2容量门；不先改产品、删collector/历史或降scope求Pass。原76范围按既有明确口径固定：允许owned全文共同材料、批准的结构化核验维度、UI16与binary4的metadata边界；不能将UI原意见混入需全文的连续diff。把旧R2/本补正及独审作为**共同、同版、已封的前轮历史**提供双方，不给任何新轮对方提示/意见；安全删盖规则与UNKNOWN在共同清单明示，不泄出被禁UI内容。
3. fresh两份完整正文/manifest、source与env身份、唯一新报告/out写面先静态预检；临时输出若必要，只准本方新out中的精确临时子目录/TMPDIR，不默认批准硬编码/tmp。GLM-5.3最高/yolo与M3.1-Flash xhigh/始终授权及当前政策不降。根另排GUI/正式创建票，真实SID/原turn与连续可见完整输入证明采集到后才计新创建；本审既不创建也不计数。
4. 新任务作**完整独立重审**，不是仅替旧作者补表/重写结论。运行授权和必要普通检查按原合同在新票明确；固定完整raw可作为历史证据逐项核，不能冒称新执行。必须记录真实child退出、完整双流/首败及重试，不能为了历史缺exit反复重跑旧探针或用现重跑回填旧Fail。分块审读即时保连续范围/尾LF/实际返回，不以requested limit、hash/统计表或压缩摘要代正文；标准结构化大JSON核验按其真正覆盖的字段明示。
5. 根完整接收两个fresh原稿、正式原turn终态、全部意见及独立流程核验后，再判该新轮合规完整双审；原轮仍留原结论与Fail。若新轮出现问题按该轮具体事实处置，不预设再来“补正若干轮”。父功能/平台/容量门仍逐门另验。

此安排是保原合同的有限替换审查入口，不要求现在证明新任务运行结果才准准备，也不授权额外研究或无穷历史恢复。只要目标仍是获得合规完整指定双审，现包不能直接免掉这两个fresh完整审查。

## 方法与本审首错

仅自写stdlib文本/JSON/hash/tar metadata及只读Git。没有产品/import/tests/helper/原归档脚本/DB/CUA、物理tmp或任何私密native历史/未遮盖UI访问；没有任务/消息创建或state/owner写入。两个大工具安全包仅外层hash、metadata/manifest及必要小原件，不重读585成员全文；独审17件小包hash直接核。

本审一次manifest检查误把Z的list清单当dict，打印了安全manifest元数据并被展示截断，随后TypeError退出1；改为按实际list/dict结构，440/142项metadata校验成功。只涉及清单，不触产品或被禁内容，保此审计工具首错，不充产品失败；不把该截断当报告已读遗漏。最终写入仅本MD/JSON。

实际报告生成UTC：`2026-10-22T20:47:20.294525+00:00`。
