# 可恢复的owner原始验证证据

新3be0397候选的真实完整check/等价/同输入串行成本/探针与首败原行必须可恢复，保留脚本与完整diff用于指定全范围重审。

源文件/日志/原工具记录不执行；tracemalloc不是RSS，headless不是原生Electron。源路径/命令/真实exit以原receipt为准。MANIFEST不含自身。
