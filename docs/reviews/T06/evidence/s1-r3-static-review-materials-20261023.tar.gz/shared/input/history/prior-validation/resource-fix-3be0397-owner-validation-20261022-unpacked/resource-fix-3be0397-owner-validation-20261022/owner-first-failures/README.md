# S1资源修复真实首败与纠正

精确摘自本owner原Codex rollout中五个工具调用/对应输出，共10原行；完整原行字节、行号及offset见manifest。没有重演首败。只含本线S1实现/测试调用，不含当前UI审查意见。

- 10:09:24：ruff check通过但format --check exit1，`_put`一行需格式化；原命令整体exit1。
- 10:09:39：格式化exit0后，旧122测试收集exit2：baseline_adapter导入的`_edit`被删；恢复兼容wrapper，10:09:58旧122项exit0。
- 10:11:59：新测试首次lint E501 exit1，随后format已修；首次17测试1 failed/16 passed，比较raw dict插入顺序使JSON dumps不等；修正为sort_keys保留值类型比较，不删除值/顺序/trace断言。
- 10:12:10：ruff check/format与全部139项通过；原工具返回exit0。后续完整check另有原stdout/stderr/receipt。

这些是工具实际保留的输出；不补造命令未捕获的OS argv或截断上游stdout。原row输出中的source token元数据原样保留。
