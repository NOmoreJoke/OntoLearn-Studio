"""Record exact child command, complete streams and real return code, without a shell."""

import datetime
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parent
label, cwd, *command = sys.argv[1:]
assert command and label.replace("-", "").replace("_", "").isalnum()
assert not (root / (label + ".json")).exists(), "preserve previous run; choose a new label"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.perf_counter()
process = subprocess.Popen(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = process.communicate()
files = []
for name, data in [("stdout", stdout), ("stderr", stderr)]:
    path = root / (label + "." + name + ".log")
    path.write_bytes(data)
    files.append({"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
record = {
    "startedAt": started,
    "finishedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "elapsedSeconds": time.perf_counter() - begin,
    "commandArgv": command,
    "cwd": cwd,
    "pid": process.pid,
    "exitCode": process.returncode,
    "shell": False,
    "completeCapturedStreams": files,
    "stdoutTailForDisplayOnly": stdout.decode(errors="replace").splitlines()[-10:],
    "stderrTailForDisplayOnly": stderr.decode(errors="replace").splitlines()[-10:],
}
(root / (label + ".json")).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(record, ensure_ascii=False, indent=2))
sys.exit(process.returncode)
