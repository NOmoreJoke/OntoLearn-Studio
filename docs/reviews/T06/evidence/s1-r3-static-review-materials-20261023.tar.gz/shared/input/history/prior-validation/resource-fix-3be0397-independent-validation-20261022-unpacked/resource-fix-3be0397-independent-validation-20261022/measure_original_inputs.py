"""Bounded evidence, using frozen 613 code as an oracle without modifying either tree."""

import argparse
import copy
import gc
import hashlib
import importlib.util
import json
import platform
import random
import sys
import time
import tracemalloc
from pathlib import Path

from ontolearn_engine.behavior import planner as current

FROZEN_SHA = "9d2474a377c3d57da28aed0461e33d1846f21e34c8a862749122e029b522970a"


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value):
    result = hashlib.sha256()
    for chunk in json.JSONEncoder(
        ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).iterencode(value):
        result.update(chunk.encode())
    return result.hexdigest()


def load_baseline(path):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == FROZEN_SHA
    spec = importlib.util.spec_from_file_location("t06_frozen_613_planner", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def execute(module, req, facts):
    prepared = module.prepare_events(req)
    derived = prepared.reasoning_input
    derived.pop("state")
    return module.plan_behaviors(
        prepared, {**derived, "version": "derived-v1", "status": "current", "facts": facts}
    )


def outcome(module, req, facts):
    original = copy.deepcopy(req)
    try:
        value = {"kind": "plan", "value": execute(module, req, facts)}
    except module.BehaviorError as error:
        value = {
            "kind": "domain_error",
            "reason": error.reason,
            "location": error.location,
            "evidence": error.evidence,
        }
    except Exception as error:
        value = {"kind": "unexpected_exception", "type": type(error).__name__, "text": str(error)}
    assert encoded(req) == encoded(original), "caller request mutated"
    return value


def event(identity="E1", sequence=0):
    return {
        "id": identity,
        "type": "test",
        "sequence": sequence,
        "version": "1",
        "payload": {"value": "payload"},
        "edits": [],
    }


def definition(identity, actions):
    return {
        "id": identity,
        "name": "n",
        "description": "d",
        "effect": "e",
        "version": "1",
        "enabled": True,
        "priority": 0,
        "trigger": {"event_type": "test"},
        "conditions": [{"op": "always"}],
        "actions": actions,
    }


def randomized(base, seed):
    rng = random.Random(seed)
    req = copy.deepcopy(base)
    req["state"] = {"objects": ["X", "Y", "Z"], "facts": [], "notifications": []}
    req["schema"] = {
        "status": {"kind": "literal", "cardinality": "one"},
        "tags": {"kind": "literal", "cardinality": "many"},
        "link": {"kind": "relation", "cardinality": "many"},
    }
    values = [False, 0, 1, 1.0, "x", "y", "雪"]
    for obj in ["X", "Y", "Z"]:
        if rng.randrange(2):
            req["state"]["facts"].append(
                {"subject": obj, "property": "status", "value": rng.choice(values)}
            )
    req["events"] = [event("E" + str(i), i) for i in range(rng.randint(1, 4))]
    for ev in req["events"]:
        for _ in range(rng.randrange(4)):
            kind = rng.choice(["set", "add", "remove", "delete_object", "declare", "create"])
            if kind in ["delete_object", "declare", "create"]:
                edit = {"kind": kind, "object": rng.choice(["X", "Y", "Z", "NEW"])}
            else:
                edit = {
                    "kind": kind,
                    "subject": rng.choice(["X", "Y", "Z", "ghost"]),
                    "property": "status" if kind == "set" else "tags",
                    "value": rng.choice(values),
                }
            ev["edits"].append(edit)
    req["behaviors"] = []
    for i in range(rng.randint(1, 4)):
        actions = []
        for j in range(rng.randint(1, 5)):
            kind = rng.choice(["set", "set", "add", "notify", "create"])
            if kind == "notify":
                action = {"kind": kind, "message": str(rng.choice(values))}
                if rng.randrange(2):
                    action["id"] = "N" + str(j)
            elif kind == "create":
                action = {
                    "kind": kind,
                    "object": rng.choice(["NEW", "X", {"event_template": f"O{i}:{{eventId}}"}]),
                    "initial": [
                        {"property": "status", "value": rng.choice(values)}
                        for _ in range(rng.randrange(4))
                    ],
                }
            else:
                action = {
                    "kind": kind,
                    "subject": rng.choice(["X", "Y", "Z", {"event_field": "missing"}]),
                    "property": "status" if kind == "set" else "tags",
                    "value": rng.choice(values),
                }
            actions.append(action)
        behavior = definition(chr(65 + i), actions)
        behavior["enabled"] = bool(rng.randrange(4))
        behavior["priority"] = rng.randint(-2, 2)
        if rng.randrange(4) == 0:
            behavior["trigger"] = {"event_type": "never"}
        if rng.randrange(3) == 0:
            behavior["conditions"] = [
                {"op": "has", "subject": "X", "property": "status", "value": rng.choice(values)}
            ]
        req["behaviors"].append(behavior)
    if rng.randrange(5) == 0:
        req["events"].append(copy.deepcopy(req["events"][0]))
    rng.shuffle(req["events"])
    facts = []
    if rng.randrange(4) == 0:
        facts = [{"subject": "X", "property": "status", "value": rng.choice(values)}]
    return req, facts


def equivalence(baseline, corpus, count):
    cases = [(c["id"], c["request"], c["reasoning_facts"]) for c in corpus["cases"]]
    base = next(c["request"] for c in corpus["cases"] if c["id"] == "B-06")
    cases.extend((f"seed-{seed}", *randomized(base, seed)) for seed in range(count))
    counts, rolling = {}, hashlib.sha256()
    for label, req, facts in cases:
        left, right = outcome(baseline, req, facts), outcome(current, req, facts)
        if encoded(left) != encoded(right):
            Path("mismatch.json").write_text(
                json.dumps({"case": label, "request": req, "facts": facts, "baseline": left, "current": right}, ensure_ascii=False, indent=2)
            )
            raise AssertionError(label + ": full output/error evidence mismatch")
        counts[right["kind"]] = counts.get(right["kind"], 0) + 1
        rolling.update((label + "\n" + encoded(right) + "\n").encode())
    assert counts.get("unexpected_exception", 0) == 0, counts
    return {"cases": len(cases), "counts": counts, "allFullOutputAndErrorEvidenceEqual": True, "rollingSha256": rolling.hexdigest()}


def measure(module, base, mode, size):
    req = copy.deepcopy(base)
    if mode == "creates":
        req["events"] = [{**event(), "payload": {}}]
        initial = [{"property": "status", "value": "S1"}] * 50
        req["behaviors"] = [
            definition(f"B{i}", [{"kind": "create", "object": f"O{i}", "initial": initial}])
            for i in range(size)
        ]
    else:
        behavior_count, event_count = (200, 400) if size == 200 else (1000, 1000)
        req["events"] = [{**event(f"E{i}", i), "payload": {}} for i in range(event_count)]
        req["behaviors"] = [
            {**definition(f"B{i}", [{"kind": "notify", "message": "m"}]), "trigger": {"event_type": "never"}}
            for i in range(behavior_count)
        ]
    input_sha = digest(req)
    gc.collect()
    if mode == "matrix":
        tracemalloc.start()
    start = time.perf_counter()
    plan = execute(module, req, [])
    elapsed = time.perf_counter() - start
    peak = None
    if mode == "matrix":
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    # Completeness is verified after the measured interval, without pruning outputs.
    if mode == "matrix":
        offset = 0
        for behavior in sorted(req["behaviors"], key=lambda item: item["id"]):
            for ev in req["events"]:
                assert plan["decisions"][offset] == {
                    "event_id": ev["id"], "behavior_id": behavior["id"],
                    "assertion_version": req["assertion_version"], "reasoning_version": "derived-v1",
                    "conditions": [], "reason": "event_mismatch",
                }
                offset += 1
        assert offset == len(plan["decisions"])
        assert plan["action_trace"] == []
        assert plan["candidate"] == plan["after_events"]
        assert len({id(d["conditions"]) for d in plan["decisions"]}) == offset
    else:
        assert len(plan["action_trace"]) == size
        assert all(t["effect"] == "changed" and len(t["action"]["initial"]) == 50 for t in plan["action_trace"])
        assert len(plan["candidate"]["objects"]) == len(req["state"]["objects"]) + size
        assert len(plan["candidate"]["facts"]) == len(req["state"]["facts"]) + size
    return {
        "mode": mode, "size": size, "inputSha256": input_sha, "fullOutputSha256": digest(plan),
        "decisions": len(plan["decisions"]), "sourceActions": len(plan["action_trace"]),
        "wallSeconds": elapsed, "pythonTracedPeakBytes": peak, "tracemallocEnabledDuringTime": mode == "matrix",
        "measurementInterval": "prepare_events + reasoning_input + plan_behaviors; excludes input hashing and post-run full-output checks/hash",
        "completeOutputAndIndependentConditionListsChecked": True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-planner", required=True, type=Path)
    parser.add_argument("--corpus", required=True, type=Path)
    parser.add_argument("--mode", choices=["equivalence", "creates", "matrix"], required=True)
    parser.add_argument("--implementation", choices=["baseline", "current"], default="current")
    parser.add_argument("--count", type=int, default=1000)
    parser.add_argument("--size", type=int, default=200)
    args = parser.parse_args()
    baseline = load_baseline(args.baseline_planner)
    corpus = json.loads(args.corpus.read_text())
    if args.mode == "equivalence":
        result = equivalence(baseline, corpus, args.count)
    else:
        base = next(c["request"] for c in corpus["cases"] if c["id"] == "B-06")
        result = measure(baseline if args.implementation == "baseline" else current, base, args.mode, args.size)
    print(json.dumps({
        "argv": sys.argv, "cwd": str(Path.cwd()), "python": sys.version, "platform": platform.platform(),
        "baselineFileSha256": hashlib.sha256(args.baseline_planner.read_bytes()).hexdigest(),
        "currentFileSha256": hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
        "implementation": args.implementation, "result": result,
    }, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
