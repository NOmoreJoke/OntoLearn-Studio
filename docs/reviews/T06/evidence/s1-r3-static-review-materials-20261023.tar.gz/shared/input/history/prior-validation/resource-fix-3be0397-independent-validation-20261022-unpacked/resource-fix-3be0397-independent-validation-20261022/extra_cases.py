import copy,json,importlib.util,sys
from pathlib import Path
p=Path('out/independent-resource-review')
spec=importlib.util.spec_from_file_location('independent_extra',p/'adversarial.py')
# Do not execute the full corpus again; reuse only helper definitions before exhaustive section.
ns={};source=(p/'adversarial.py').read_text().split('# Exhaustive independent pair oracle;')[0];exec(compile(source,'extra-helper-definitions','exec'),ns)
r=ns['req']();r['schema'].update({f'field{i}':{'kind':'literal','cardinality':'one'} for i in range(10)})
r['behaviors']=[ns['behavior'](f'B{j:02}',[{'kind':'create','object':f'O{j:02}','initial':[{'property':f'field{i}','value':i} for i in range(10)]},{'kind':'notify','message':f'B{j:02}'}]) for j in range(20)]
a=ns['run'](ns['old'],r);b=ns['run'](ns['new'],r);assert ns['enc'](a)==ns['enc'](b);assert len(b['value']['candidate']['facts'])==200 and len(b['value']['action_trace'])==40
result={'20_create_x_10_distinct_single_slots_and_notifications':'complete_old_new_equal','full_output_sha256':ns['h'](b)};(p/'extra-cases.result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
