import copy,hashlib,importlib.util,itertools,json,random,sys
from pathlib import Path
from ontolearn_engine.behavior import planner as new
OUT=Path('out/independent-resource-review')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('independent_baseline',OUT/'baseline_613.py')
def enc(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def h(x):return hashlib.sha256(enc(x).encode()).hexdigest()
def run(m,r,f=[]):
 original=enc(r);p=m.prepare_events(r);d=p.reasoning_input;d.pop('state');d.update(version='independent',status='current',facts=f)
 try:result={'kind':'plan','value':m.plan_behaviors(p,d)}
 except m.BehaviorError as e:result={'kind':'error','reason':e.reason,'location':e.location,'evidence':e.evidence}
 assert enc(r)==original
 return result
corpus=json.loads(Path('tests/fixtures/behavior/counterexamples.json').read_text())
base=copy.deepcopy(corpus['cases'][5]['request'])
def event(i='E',seq=0):return dict(id=i,type='test',sequence=seq,version='1',payload={},edits=[])
def behavior(i,acts):return dict(id=i,name=i,description='independent',effect='internal',version='1',enabled=True,priority=0,trigger={'event_type':'test'},conditions=[{'op':'always'}],actions=acts)
def req():
 r=copy.deepcopy(base);r['events']=[event()];r['schema']={'one':{'kind':'literal','cardinality':'one'},'many':{'kind':'literal','cardinality':'many'},'rel':{'kind':'relation','cardinality':'many'},'type':{'kind':'class','cardinality':'many'}};r['classes']=['C','D'];r['state']={'objects':['X','Y','Z'],'facts':[],'notifications':[]};r['behaviors']=[];return r
def write(v,obj='X',prop='one',kind='set'):return dict(kind=kind,subject=obj,property=prop,value=v)
# Exhaustive independent pair oracle; compares first actual write, not final value.
schema=req()['schema'];checked=0
for n in range(9):
 for word in itertools.product(range(4),repeat=n):
  intents=[{'event_id':'E','behavior_id':str(atom//2),'action_index':i,'action':write(atom%2)} for i,atom in enumerate(word)]
  actual=new._first_conflict(intents,schema)
  expected=None
  for i,j in itertools.combinations(range(n),2):
   if word[i]//2!=word[j]//2 and word[i]%2!=word[j]%2:
    expected=(new._single_writes(intents[i],schema)[0],new._single_writes(intents[j],schema)[0]);break
  assert enc(actual)==enc(expected),(word,actual,expected)
  checked+=1
rng=random.Random(2026102207)
# Mixed slots/types and compound creates, including duplicate pairs and non-final initials.
for trial in range(6000):
 intents=[];writes=[]
 for i in range(rng.randrange(1,16)):
  if rng.randrange(3)==0:
   a={'kind':'create','object':rng.choice(['X','Y']), 'initial':[{'property':rng.choice(['one','many']),'value':rng.choice([False,0,True,1,1.0,'x','y'])} for _ in range(rng.randrange(6))]}
  else:a=write(rng.choice([False,0,True,1,1.0,'x','y']),rng.choice(['X','Y']))
  t={'event_id':rng.choice(['E1','E2']), 'behavior_id':rng.choice(['A','B','C']),'action_index':i,'action':a};intents.append(t)
  if a['kind']=='create':writes.extend({'subject':a['object'],**f,'intent':t} for f in a['initial'] if f['property']=='one')
  else:writes.append({'subject':a['subject'],'property':a['property'],'value':a['value'],'intent':t})
 expected=None
 for a,b in itertools.combinations(writes,2):
  if (a['intent']['event_id'],a['intent']['behavior_id'])!=(b['intent']['event_id'],b['intent']['behavior_id']) and (a['subject'],a['property'])==(b['subject'],b['property']) and enc(a['value'])!=enc(b['value']):expected=(a,b);break
 assert enc(new._first_conflict(intents,schema))==enc(expected),trial
# Full pipeline old/new differential: successful event-edit lifecycles + failures + mixed reasoning.
counts={};roll=hashlib.sha256()
def outcome(m,r,f=[]):
 try:return run(m,r,f)
 except m.BehaviorError as e:return dict(kind='error',reason=e.reason,location=e.location,evidence=e.evidence)
def compare(label,r,f=[]):
 a=outcome(old,r,f);b=outcome(new,r,f)
 if enc(a)!=enc(b):(OUT/'mismatch.json').write_text(enc(dict(label=label,request=r,old=a,new=b)));raise AssertionError(label)
 counts[b['kind']]=counts.get(b['kind'],0)+1;roll.update((label+'\n'+enc(b)+'\n').encode());return b
for c in corpus['cases']:compare(c['id'],copy.deepcopy(c['request']),c['reasoning_facts'])
for trial in range(1500):
 r=req();r['events']=[event('E'+str(i),i) for i in range(rng.randrange(1,4))]
 # Strictly valid setup lifecycle ensures many probes reach simulation.
 for e in r['events']:
  e['edits']=[{'kind':'declare','object':'TMP'},write(False,'TMP'),write(0,'TMP','many','add'),write(False,'TMP','many','add'),{'kind':'add','subject':'X','property':'rel','value':'TMP'},{'kind':'delete_object','object':'TMP'},{'kind':'create','object':'TMP','initial':[{'property':'one','value':rng.choice([1,1.0,False,0])}]},{'kind':'remove','subject':'X','property':'many','value':'absent'}]
 for i in range(rng.randrange(1,5)):
  actions=[]
  for j in range(rng.randrange(1,7)):
   k=rng.randrange(6)
   if k in (0,1):a=write(rng.choice([False,0,True,1,1.0,'x','y']),rng.choice(['X','Y','TMP']))
   elif k==2:a=write(rng.choice([False,0,1,1.0,'x']),rng.choice(['X','Y']),'many','add')
   elif k==3:a={'kind':'notify','id':{'event_template':f'N:{i}:{j}:{{eventId}}'},'message':str(j)}
   elif k==4:a={'kind':'create','object':{'event_template':f'C:{i}:{j}:{{eventId}}'},'initial':[{'property':'one','value':rng.choice([False,0,1,1.0])} for _ in range(rng.randrange(4))]}
   else:a={'kind':'set','subject':'X','property':'one','value':{'event_field':'missing'}}
   actions.append(a)
  b=behavior(chr(65+i),actions);b['priority']=rng.randrange(-2,3)
  if rng.randrange(5)==0:b['trigger']={'event_type':'never'}
  if rng.randrange(6)==0:b['enabled']=False
  if rng.randrange(5)==0:b['conditions']=[{'op':'has','subject':'X','property':'many','value':0}]
  r['behaviors'].append(b)
 if trial%9==0:r['events'].append(copy.deepcopy(r['events'][0]))
 if trial%17==0:r['events'][-1]['version']='different'
 rng.shuffle(r['events']);compare('random-'+str(trial),r)
# Explicit negative input/state validation must occur before indexes can deduplicate.
for label,mutate in [
 ('dup_object',lambda r:r['state']['objects'].append('X')),
 ('dup_fact',lambda r:r['state']['facts'].extend([{'subject':'X','property':'one','value':0}]*2)),
 ('typed_single_conflict',lambda r:r['state']['facts'].extend([{'subject':'X','property':'one','value':v} for v in [False,0]])),
 ('notify_object',lambda r:r['state']['notifications'].append(dict(id='X',event_id='E',behavior_id='A',action_index=0,message='m'))),
 ('initial_dynamic',lambda r:r['behaviors'][0].update(actions=[{'kind':'create','object':'C','initial':[{'property':'one','value':0},{'property':'one','value':{'event_field':'missing'}}]}])),
 ('notify_then_create',lambda r:r['behaviors'][0].update(actions=[{'kind':'notify','id':'N','message':'m'},{'kind':'create','object':'N'}])),
 ('create_then_notify',lambda r:r['behaviors'][0].update(actions=[{'kind':'create','object':'N'},{'kind':'notify','id':'N','message':'m'}])),
 ('malformed_delete',lambda r:r['events'][0].update(edits=[{'kind':'delete_object','object':{}}])),
]:
 r=req();r['behaviors']=[behavior('A',[write(0)])];mutate(r);result=compare(label,r);assert result['kind']=='error';assert 'candidate' not in result['evidence'] and 'consumption' not in result['evidence']
 if label=='initial_dynamic':assert result['evidence']['initial_index']==1
# Deep result ownership across calls and within key state/decision branches.
r=req();r['behaviors']=[behavior('A',[write(0),write(0,'X','many','add')])];r['events']=[event('E1',0),event('E2',1)];p=new.prepare_events(r);d=p.reasoning_input;d.pop('state');d.update(version='independent',status='current',facts=[])
a=new.plan_behaviors(p,d);b=new.plan_behaviors(p,d);snapshot=enc(b)
a['candidate']['facts'][0]['value']='mutated';a['decisions'][0]['conditions'][0]['reason']='mutated';a['before']['objects'].clear();assert enc(b)==snapshot and enc(new.plan_behaviors(p,d))==snapshot
assert a['decisions'][1]['conditions'][0]['reason']=='explicit_always'
# Consumption lifecycle independent of sequence/version mismatch detection.
r=req();r['behaviors']=[behavior('A',[{'kind':'create','object':'C'}])];one=compare('constant-create-first',r)['value'];r['state']=one['candidate'];r['consumption']=one['consumption'];r['round']=2;r['events'][0]['sequence']=50
repeat=compare('repeat-sequence',r);assert repeat['value']['action_trace']==[]
r['events'][0]['version']='2';assert compare('repeat-content-conflict',r)['reason']=='event_identity_conflict'
# Replay author fixture in own output directory; script never imports planner.
source=Path('tests/fixtures/behavior/build_corpus.py').read_text();exec(compile(source,'build_corpus.py','exec'),{'__file__':str(OUT/'build_corpus.py'),'__name__':'independent_fixture_author'})
assert enc(json.loads((OUT/'counterexamples.json').read_text()))==enc(corpus)
result=dict(exhaustive_conflict_sequences=checked,mixed_slot_typed_compound_cases=6000,full_differential_counts=counts,full_differential_sha256=roll.hexdigest(),ownership_and_consumption='passed',author_corpus_semantically_equal=True)
(OUT/'adversarial.result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
