import json,os,pathlib,subprocess,time
p=pathlib.Path("out/independent-resource-review")
argv=["npm","run","check"]
start=time.time()
with (p/"check.stdout").open("wb") as out,(p/"check.stderr").open("wb") as err:
 r=subprocess.run(argv,stdout=out,stderr=err,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
(p/"check.receipt.json").write_text(json.dumps({"argv":argv,"cwd":os.getcwd(),"exit":r.returncode,"wall_seconds":time.time()-start},indent=2))
