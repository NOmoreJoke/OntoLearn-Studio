"""Sequential original-input measurements; fail if complete old/new results differ."""

import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
cwd = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T06-behavior"
baseline = "/Users/kyle/Documents/工作/知爻/本体/.worktrees/T06-review-61396a5/packages/engine/src/ontolearn_engine/behavior/planner.py"
helper = root / "verify_equivalence_and_cost.py"
summary = {
    "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "helperSha256": hashlib.sha256(helper.read_bytes()).hexdigest(),
    "method": "Sequential fresh processes, same exact original probe17/18 inputs; creates uses wall time, matrix wall+tracemalloc peak, not RSS. Whole output equality checked after measured interval. Other desktop tasks may run; no controlled production capacity claim.",
    "runs": [],
}
with (root / "cost-matrix-orchestration.log").open("wb") as log:
    for mode, sizes in [("creates", [200, 400, 800]), ("matrix", [200, 1000])]:
        for size in sizes:
            pair = []
            for implementation in ["baseline", "current"]:
                label = f"cost-{mode}-{size}-{implementation}-1"
                command = [
                    sys.executable, str(root / "run_evidence.py"), label, cwd,
                    "uv", "run", "--frozen", "python", str(helper),
                    "--baseline-planner", baseline,
                    "--corpus", "tests/fixtures/behavior/counterexamples.json",
                    "--mode", mode, "--size", str(size), "--implementation", implementation,
                ]
                print("START " + label, flush=True)
                completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                log.write(completed.stdout + completed.stderr)
                log.flush()
                assert completed.returncode == 0, label + ": see preserved complete streams"
                result = json.loads((root / (label + ".stdout.log")).read_text())
                summary["runs"].append({"label": label, **result})
                pair.append(result["result"])
                print(json.dumps({"label": label, "result": result["result"]}), flush=True)
            assert pair[0]["inputSha256"] == pair[1]["inputSha256"], "input mismatch"
            assert pair[0]["fullOutputSha256"] == pair[1]["fullOutputSha256"], "output mismatch"
            (root / "cost-matrix-progress.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
summary["finishedAt"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
summary["allPairedFullInputsAndOutputsEqual"] = True
(root / "cost-matrix-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print("ALL COMPLETE INPUTS AND OUTPUTS MATCH", flush=True)
